# No greeting
unsetopt BEEP

# Aliases
alias neofetch="neofetch --ascii /usr/local/share/logo.txt | sed 's/.*/\x1b[93m&\x1b[0m/'"
alias ls='ls --color=auto'

# History
HISTSIZE=10000
SAVEHIST=10000
HISTFILE=~/.zsh_history
setopt HIST_IGNORE_DUPS SHARE_HISTORY

# Autocompletado
autoload -Uz compinit && compinit

# Syntax highlighting
source /usr/share/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh
ZSH_HIGHLIGHT_STYLES[command]='fg=#ff7d2e'
ZSH_HIGHLIGHT_STYLES[builtin]='fg=#ff7d2e'
ZSH_HIGHLIGHT_STYLES[function]='fg=#ff7d2e'
ZSH_HIGHLIGHT_STYLES[keyword]='fg=#ef5a33'
ZSH_HIGHLIGHT_STYLES[single-quoted-argument]='fg=#fec431'
ZSH_HIGHLIGHT_STYLES[double-quoted-argument]='fg=#fec431'
ZSH_HIGHLIGHT_STYLES[comment]='fg=#555555'
ZSH_HIGHLIGHT_STYLES[unknown-token]='fg=#ee5a6f'

# Autosuggestions
ZSH_AUTOSUGGEST_HIGHLIGHT_STYLE='fg=#555555'
source /usr/share/zsh-autosuggestions/zsh-autosuggestions.zsh

# Prompt
source /usr/share/powerlevel9k/powerlevel9k.zsh-theme
POWERLEVEL9K_LEFT_PROMPT_ELEMENTS=(context dir vcs)
POWERLEVEL9K_RIGHT_PROMPT_ELEMENTS=()
POWERLEVEL9K_PROMPT_ON_NEWLINE=false
POWERLEVEL9K_DIR_BACKGROUND='202'
POWERLEVEL9K_DIR_FOREGROUND='black'
POWERLEVEL9K_VCS_CLEAN_BACKGROUND='green'
POWERLEVEL9K_VCS_MODIFIED_BACKGROUND='yellow'
POWERLEVEL9K_VCS_FOREGROUND='black'
