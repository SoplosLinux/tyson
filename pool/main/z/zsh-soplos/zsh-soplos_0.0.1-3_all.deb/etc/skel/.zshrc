# No greeting
unsetopt BEEP

# Aliases
alias neofetch="neofetch --ascii /usr/local/share/logo.txt | sed 's/.*/\x1b[93m&\x1b[0m/'"
alias ls='ls --color=auto'

# History
HISTSIZE=10000
SAVEHIST=10000
HISTFILE=~/.zsh_history
setopt HIST_IGNORE_DUPS SHARE_HISTORY

# Autocompletado
autoload -Uz compinit && compinit

# Syntax highlighting
source /usr/share/zsh-syntax-highlighting/zsh-syntax-highlighting.zsh
ZSH_HIGHLIGHT_STYLES[command]='fg=#ff7d2e'
ZSH_HIGHLIGHT_STYLES[builtin]='fg=#ff7d2e'
ZSH_HIGHLIGHT_STYLES[function]='fg=#ff7d2e'
ZSH_HIGHLIGHT_STYLES[keyword]='fg=#ef5a33'
ZSH_HIGHLIGHT_STYLES[single-quoted-argument]='fg=#fec431'
ZSH_HIGHLIGHT_STYLES[double-quoted-argument]='fg=#fec431'
ZSH_HIGHLIGHT_STYLES[comment]='fg=#555555'
ZSH_HIGHLIGHT_STYLES[unknown-token]='fg=#ee5a6f'

# Autosuggestions
ZSH_AUTOSUGGEST_HIGHLIGHT_STYLE='fg=#555555'
source /usr/share/zsh-autosuggestions/zsh-autosuggestions.zsh

# Prompt
autoload -U colors && colors

_SEP=$''

_git_info() {
    local branch
    branch=$(git symbolic-ref --short HEAD 2>/dev/null) || return
    if [[ -n $(git status --porcelain 2>/dev/null) ]]; then
        echo -n " %K{yellow}%F{black}${_SEP} ${branch} %f%k%F{yellow}${_SEP}%f"
    else
        echo -n " %K{green}%F{black}${_SEP} ${branch} %f%k%F{green}${_SEP}%f"
    fi
}

setopt PROMPT_SUBST
PROMPT='%K{202}%F{black} %n@%m %f%k%F{202}%K{238}${_SEP}%F{white} %~ %f%k%F{238}${_SEP}%f$(_git_info) '
