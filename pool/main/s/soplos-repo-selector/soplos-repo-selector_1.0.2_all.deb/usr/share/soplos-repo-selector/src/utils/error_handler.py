"""
Sistema de manejo de errores y logging
"""

import os
import sys
import traceback
import logging
import subprocess
from datetime import datetime
from typing import Optional, Any, Callable

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib

# Añadir importación de traducciones
from src.i18n.strings import get_string

class ErrorHandler:
    """Maneja errores y diálogos de la aplicación"""
    
    _instance = None
    _logger = None
    _parent_window = None
    
    @classmethod
    def initialize(cls, parent_window=None, log_level=logging.INFO):
        """Inicializa el sistema de manejo de errores"""
        if cls._instance is None:
            cls._instance = cls()
            cls._parent_window = parent_window
            cls._setup_logging(log_level)
    
    @classmethod
    def _setup_logging(cls, log_level):
        """Configura el sistema de logging"""
        # Crear directorio de logs
        log_dir = os.path.expanduser("~/.local/share/soplos-repo-selector/logs")
        os.makedirs(log_dir, exist_ok=True)
        
        # Configurar logger
        cls._logger = logging.getLogger('soplos-repo-selector')
        cls._logger.setLevel(log_level)
        
        # Handler para archivo
        log_file = os.path.join(log_dir, f"soplos-repo-selector-{datetime.now().strftime('%Y%m%d')}.log")
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        file_handler.setFormatter(file_formatter)
        cls._logger.addHandler(file_handler)
        
        # Handler para consola (solo errores críticos)
        console_handler = logging.StreamHandler(sys.stderr)
        console_handler.setLevel(logging.ERROR)
        console_formatter = logging.Formatter('%(levelname)s: %(message)s')
        console_handler.setFormatter(console_formatter)
        cls._logger.addHandler(console_handler)
    
    @classmethod
    def show_error_dialog(cls, title: str, message: str, parent=None, details: str = None):
        """Muestra un diálogo de error al usuario"""
        parent = parent or cls._parent_window
        
        dialog = Gtk.MessageDialog(
            transient_for=parent,
            flags=0,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.CLOSE,
            text=title
        )
        
        dialog.format_secondary_text(message)
        
        # Añadir detalles si están disponibles
        if details:
            dialog.set_property("use-markup", True)
            expander = Gtk.Expander(label="Detalles técnicos")
            
            scroll = Gtk.ScrolledWindow()
            scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            scroll.set_size_request(400, 200)
            
            text_view = Gtk.TextView()
            text_view.set_editable(False)
            text_view.get_buffer().set_text(details)
            scroll.add(text_view)
            
            expander.add(scroll)
            dialog.get_content_area().pack_start(expander, True, True, 0)
            dialog.show_all()
        
        dialog.run()
        dialog.destroy()
    
    @classmethod
    def show_warning_dialog(cls, title: str, message: str, parent=None):
        """Muestra un diálogo de advertencia"""
        parent = parent or cls._parent_window
        
        dialog = Gtk.MessageDialog(
            transient_for=parent,
            flags=0,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.OK,
            text=title
        )
        
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()
    
    @classmethod
    def handle_subprocess_error(cls, process: subprocess.CompletedProcess, operation: str):
        """Maneja errores de subprocesos"""
        if process.returncode != 0:
            error_msg = f"Error en {operation}"
            details = f"Código de salida: {process.returncode}\n"
            details += f"STDERR: {process.stderr}\n" if process.stderr else ""
            details += f"STDOUT: {process.stdout}\n" if process.stdout else ""
            
            cls.log_error(error_msg, details)
            return False
        return True
    
    @classmethod
    def log_info(cls, message: str):
        """Registra mensaje informativo"""
        if cls._logger:
            cls._logger.info(message)
    
    @classmethod
    def log_warning(cls, message: str):
        """Registra advertencia"""
        if cls._logger:
            cls._logger.warning(message)
    
    @classmethod
    def log_error(cls, message: str, exception: Exception = None):
        """Registra error"""
        if cls._logger:
            if exception:
                cls._logger.error(f"{message}: {str(exception)}", exc_info=True)
            else:
                cls._logger.error(message)
    
    @staticmethod
    def show_speed_test_error(parent_window, error_type, details=""):
        """Muestra error específico de test de velocidad"""
        error_messages = {
            'no_internet': {
                'title': 'Sin conexión a Internet',
                'message': 'No se puede realizar el test de velocidad sin conexión a Internet.\n\nVerifique su conexión de red.'
            },
            'timeout': {
                'title': 'Timeout en test de velocidad',
                'message': 'El test de velocidad tardó demasiado tiempo.\n\nIntente con menos repositorios o verifique su conexión.'
            },
            'permission_error': {
                'title': 'Error de permisos',
                'message': 'No se tienen los permisos necesarios para realizar el test.\n\nEjecute la aplicación como administrador.'
            }
        }
        
        error_info = error_messages.get(error_type, {
            'title': 'Error en test de velocidad',
            'message': f'Ocurrió un error durante el test de velocidad.\n\n{details}'
        })
        
        ErrorHandler.show_error_dialog(
            error_info['title'],
            error_info['message'],
            parent_window
        )

def safe_execute(func: Callable, *args, **kwargs) -> tuple[bool, Any]:
    """Ejecuta una función de forma segura capturando errores"""
    try:
        result = func(*args, **kwargs)
        return True, result
    except Exception as e:
        ErrorHandler.log_error(f"Error ejecutando {func.__name__}", e)
        return False, str(e)

def requires_privileges(func: Callable) -> Callable:
    """Decorador para funciones que requieren privilegios de administrador"""
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except PermissionError:
            ErrorHandler.show_error_dialog(
                "Permisos insuficientes",
                "Esta operación requiere privilegios de administrador."
            )
            return False
    return wrapper

# Funciones de conveniencia para logging
def log_info(message: str):
    """Función de conveniencia para logging de información"""
    ErrorHandler.log_info(message)

def log_warning(message: str):
    """Función de conveniencia para logging de advertencias"""
    ErrorHandler.log_warning(message)

def log_error(message: str, exception: Exception = None):
    """Función de conveniencia para logging de errores"""
    ErrorHandler.log_error(message, exception)
