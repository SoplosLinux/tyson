import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gio, GLib, Gdk

import os
import sys

from src.config.constants import APP_ID, APP_NAME, APP_VERSION
from src.gui.window import MainWindow
from src.i18n.strings import set_language, get_current_language, detect_system_language
from src.utils.error_handler import log_info, log_warning, log_error

class SoplosRepoSelector(Gtk.Application):
    """
    Clase principal de la aplicación Soplos Repo Selector.
    Coordina la ventana principal y gestiona la aplicación Gtk.
    """
    def __init__(self):
        super().__init__(application_id=APP_ID,
                        flags=Gio.ApplicationFlags.FLAGS_NONE)
        
        # Inicializar variables de la aplicación
        self.window = None
        
        # Configurar la aplicación
        self.setup_application()
        
        # Configurar atajos de teclado globales
        self.setup_global_accelerators()
    
    def setup_application(self):
        """Configura los parámetros globales de la aplicación"""
        # Establecer identificadores de aplicación globales
        GLib.set_prgname(APP_ID)
        GLib.set_application_name(APP_NAME)
        
        # Configurar para mejor integración con sistema de ventanas
        self.setup_window_integration()
        
        # Configurar idioma basado en locale del sistema
        self.setup_language()
    
    def setup_window_integration(self):
        """Configura integración con el sistema de ventanas (tanto X11 como Wayland)"""
        # Configurar clase de programa para mejor integración
        if hasattr(Gdk, 'set_program_class'):
            Gdk.set_program_class(APP_ID)
        
        # Configurar icono por defecto
        if hasattr(Gtk.Window, 'set_default_icon_name'):
            Gtk.Window.set_default_icon_name(APP_ID)
        
        # Log del entorno detectado
        session_type = os.environ.get('XDG_SESSION_TYPE', 'unknown')
        desktop = os.environ.get('XDG_CURRENT_DESKTOP', 'unknown')
        log_info(f"Entorno detectado: {session_type} en {desktop}")
    
    def setup_language(self):
        """Configura el idioma basado en la configuración del sistema"""
        system_lang = detect_system_language()
        set_language(system_lang)
        log_info(f"Idioma configurado: {get_current_language()}")
    
    def setup_global_accelerators(self):
        """Configura atajos de teclado globales de la aplicación"""
        # Acción global para salir
        quit_action = Gio.SimpleAction.new("quit", None)
        quit_action.connect("activate", self._on_quit_activate)
        self.add_action(quit_action)
        
        # Acción para mostrar ayuda
        help_action = Gio.SimpleAction.new("help", None)
        help_action.connect("activate", self._on_help_activate)
        self.add_action(help_action)
        
        # Acción para mostrar acerca de
        about_action = Gio.SimpleAction.new("about", None)
        about_action.connect("activate", self._on_about_activate)
        self.add_action(about_action)
        
        # Configurar atajos globales
        self.set_accels_for_action("app.quit", ["<Control>q", "<Alt>F4"])
        self.set_accels_for_action("app.help", ["F1"])
        self.set_accels_for_action("app.about", ["<Control><Shift>a"])
    
    def _on_quit_activate(self, action, param):
        """Maneja la acción de salir"""
        if self.window:
            self.window.on_close_clicked(None)
    
    def _on_help_activate(self, action, param):
        """Muestra la ayuda"""
        pass
    
    def _on_about_activate(self, action, param):
        """Muestra el diálogo Acerca de"""
        if self.window:
            about_dialog = Gtk.AboutDialog()
            about_dialog.set_transient_for(self.window)
            about_dialog.set_modal(True)
            about_dialog.set_program_name(APP_NAME)
            about_dialog.set_version(APP_VERSION)
            about_dialog.set_comments("Gestor de repositorios para sistemas Debian")
            about_dialog.set_website("https://soploslinux.com")
            about_dialog.set_license_type(Gtk.License.GPL_3_0)
            about_dialog.run()
            about_dialog.destroy()
    
    def do_startup(self):
        """Invocado durante el inicio de la aplicación"""
        Gtk.Application.do_startup(self)
        
        # Configurar tema oscuro si es necesario
        self.setup_dark_theme()
    
    def setup_dark_theme(self):
        """Configura el tema oscuro si está habilitado en el sistema"""
        try:
            settings = Gtk.Settings.get_default()
            if settings:
                # Para Plasma 6, intentar detectar tema oscuro
                if os.environ.get('KDE_SESSION_VERSION') == '6':
                    try:
                        import subprocess
                        result = subprocess.run(['kreadconfig6', '--group', 'KDE', '--key', 'LookAndFeelPackage'], 
                                              capture_output=True, text=True, timeout=5)
                        if result.returncode == 0 and 'dark' in result.stdout.lower():
                            settings.set_property("gtk-application-prefer-dark-theme", True)
                            log_info("Tema oscuro activado para Plasma 6")
                    except Exception as e:
                        log_warning(f"No se pudo detectar tema de Plasma 6: {e}")
                
                # Para otros entornos, usar configuración GTK estándar
                try:
                    from gi.repository import Gio
                    gtk_settings = Gio.Settings.new("org.gnome.desktop.interface")
                    theme_name = gtk_settings.get_string("gtk-theme").lower()
                    if 'dark' in theme_name:
                        settings.set_property("gtk-application-prefer-dark-theme", True)
                        log_info("Tema oscuro activado desde configuración GTK")
                except Exception as e:
                    log_warning(f"No se pudo leer configuración GTK: {e}")
                    
        except Exception as e:
            log_warning(f"Error configurando tema: {e}")
    
    def do_activate(self):
        """Gestiona la activación de la aplicación"""
        # Si ya hay una ventana, mostrarla
        if self.window:
            self.window.present()
            return
            
        # Crear la ventana principal
        self.window = MainWindow(application=self)
        
        # Configurar propiedades de la ventana para mejor integración
        self.window.set_wmclass(APP_ID, APP_ID)
        self.window.set_title(APP_NAME)
        
        # Configurar el rol de la ventana
        if hasattr(self.window, 'set_role'):
            self.window.set_role("main-window")
        
        # Conectar la señal de cierre
        self.window.connect('delete-event', self._on_window_close_request)
        
        # Mostrar la ventana
        self.window.show_all()
    
    def _on_window_close_request(self, window, event):
        """Maneja la petición de cierre de ventana"""
        should_close = not window.on_delete_event(window, event)
        
        if should_close:
            self.quit()
            return False
        else:
            return True
    
    def clean_stale_cache_files(self, verbose=False):
        """Elimina archivos de caché de Python"""
        try:
            import shutil
            
            app_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            
            if verbose:
                log_info(f"Limpiando archivos de caché en: {app_dir}")
            
            for root, dirs, files in os.walk(app_dir):
                if '__pycache__' in dirs:
                    pycache_dir = os.path.join(root, '__pycache__')
                    try:
                        if os.access(pycache_dir, os.W_OK):
                            shutil.rmtree(pycache_dir)
                            if verbose:
                                log_info(f"Limpiado directorio de caché: {pycache_dir}")
                    except Exception as e:
                        if verbose:
                            log_warning(f"No se pudo limpiar {pycache_dir}: {e}")
                    
                    dirs.remove('__pycache__')
                
                for file in files:
                    if file.endswith(('.pyc', '.pyo')):
                        try:
                            file_path = os.path.join(root, file)
                            if os.access(file_path, os.W_OK):
                                os.remove(file_path)
                                if verbose:
                                    log_info(f"Eliminado archivo: {file_path}")
                        except Exception as e:
                            if verbose:
                                log_warning(f"No se pudo eliminar {file}: {e}")
        
        except Exception as e:
            log_warning(f"Error limpiando archivos de caché: {e}")

def create_application():
    """Crea y devuelve la instancia de la aplicación"""
    app = SoplosRepoSelector()
    
    # Limpiar archivos antiguos al inicio
    app.clean_stale_cache_files(verbose=True)
    
    return app

def main():
    """Punto de entrada para la aplicación"""
    app = create_application()
    return app.run(None)

if __name__ == '__main__':
    main()
