import os
import sys
import subprocess
import locale as stdlib_locale
from pathlib import Path

# Añadir el directorio raíz al PYTHONPATH
root_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
sys.path.insert(0, root_dir)

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gio, GLib, GdkPixbuf, Gdk
from src.repo.manager import RepoManager
from src.i18n.strings import get_string, set_language, get_available_languages, get_current_language
# Añadir esta importación para acceder a las cadenas actuales
from src.i18n import strings as i18n_strings
from src.gui.dialogs.speed_dialog import RepoSpeedDialog
from src.gui.dialogs.repo_dialog import RepoDialog
from src.gui.widgets.repo_list import RepoListWidget
from src.gui.widgets.gpg_list import GPGKeyListWidget
# Importar correctamente las constantes de la aplicación desde constants.py en lugar de main
from src.config.constants import APP_ID, APP_NAME, APP_VERSION, DEFAULT_WINDOW_WIDTH, DEFAULT_WINDOW_HEIGHT, PREDEFINED_REPOS
from src.utils.error_handler import ErrorHandler, log_info, log_error, log_warning

def escape_markup(text):
    """Escapa caracteres especiales para markup GTK"""
    return text.replace('&', '&amp;')\
               .replace('<', '&lt;')\
               .replace('>', '&gt;')\
               .replace('"', '&quot;')\
               .replace("'", '&#39;')

class MainWindow(Gtk.ApplicationWindow):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        
        # Usar las constantes definidas en src.config.constants
        self.app_id = APP_ID
        self.wmclass = APP_ID
        
        # NUEVO: Configurar identificadores para Wayland INMEDIATAMENTE
        self.set_wmclass(self.wmclass, self.wmclass)
        
        # NUEVO: Configurar program class para Wayland
        try:
            from gi.repository import Gdk
            if hasattr(Gdk, 'set_program_class'):
                Gdk.set_program_class(APP_ID)
        except Exception as e:
            log_warning(f"No se pudo establecer program_class en ventana: {e}")
        
        # NUEVO: Configurar startup ID para Wayland
        startup_id = os.environ.get('GDK_STARTUP_NOTIFICATION_ID', '')
        if startup_id and startup_id != '0':
            try:
                self.set_startup_id(startup_id)
                log_info(f"Startup ID configurado: {startup_id}")
            except Exception as e:
                log_warning(f"No se pudo establecer startup_id: {e}")
        
        # Establecer el icono desde el sistema primero
        self.set_icon_name(self.app_id)
        
        # Si no encuentra el icono del sistema, usar el local
        if not self.get_icon():
            try:
                window_icon_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 
                                       'assets/icons/com.soplos.reposelector.png')
                window_icon = GdkPixbuf.Pixbuf.new_from_file(window_icon_path)
                self.set_icon(window_icon)
                Gtk.Window.set_default_icon(window_icon)
            except Exception as e:
                print(f"Error al cargar el icono: {e}")

        # Establecer el título de la ventana usando el nombre de la aplicación
        self.set_title(get_string('window_title', APP_NAME))
        
        # Conectar señal delete-event antes de todo
        self.connect('delete-event', self.on_delete_event)
        
        # CORREGIDO: Obtener dimensiones de la pantalla de forma más robusta
        try:
            display = Gdk.Display.get_default()
            monitor = display.get_primary_monitor()
            
            if monitor is not None:
                geometry = monitor.get_geometry()
                screen_height = geometry.height
            else:
                # Fallback: usar el primer monitor disponible
                n_monitors = display.get_n_monitors()
                if n_monitors > 0:
                    monitor = display.get_monitor(0)
                    geometry = monitor.get_geometry()
                    screen_height = geometry.height
                else:
                    # Fallback final: usar dimensiones predeterminadas
                    screen_height = 768
                    log_warning("No se pudo detectar el monitor, usando dimensiones predeterminadas")
        except Exception as e:
            # Fallback en caso de cualquier error
            screen_height = 768
            log_warning(f"Error al obtener dimensiones de pantalla: {e}")
        
        # Ajustar tamaño de ventana usando las constantes definidas
        self.set_default_size(DEFAULT_WINDOW_WIDTH, min(DEFAULT_WINDOW_HEIGHT, screen_height - 100))

        # Inicializar el gestor de repositorios
        self.repo_manager = RepoManager()
        
        # Inicializar el sistema de manejo de errores con esta ventana como padre
        ErrorHandler.initialize(parent_window=self)
        
        # Crear la interfaz
        self._create_ui()
        
        # NUEVO: Configurar atajos de teclado
        self._setup_keyboard_accelerators()
        
        # Cargar los repositorios existentes
        self._load_repos()
        
        # Inicializar el caché de widgets para optimizar búsquedas
        self._widget_cache = {}
        
    def _setup_keyboard_accelerators(self):
        """Configura los atajos de teclado de la aplicación"""
        # Obtener el grupo de acciones de la aplicación
        action_group = Gio.SimpleActionGroup()
        self.insert_action_group("win", action_group)
        
        # Acción para aplicar cambios (Ctrl+S)
        apply_action = Gio.SimpleAction.new("apply", None)
        apply_action.connect("activate", lambda action, param: self.on_apply_changes_clicked(self.apply_button))
        action_group.add_action(apply_action)
        
        # Acción para actualizar repositorios (Ctrl+U)
        update_action = Gio.SimpleAction.new("update", None)
        update_action.connect("activate", lambda action, param: self.on_update_repos_clicked(self.update_button))
        action_group.add_action(update_action)
        
        # Acción para buscar repositorios rápidos (Ctrl+F)
        find_action = Gio.SimpleAction.new("find-fast", None)
        find_action.connect("activate", lambda action, param: self.on_find_fastest_repos_clicked(self.fast_repos_button))
        action_group.add_action(find_action)
        
        # Acción para añadir repositorio (Ctrl+N)
        add_repo_action = Gio.SimpleAction.new("add-repo", None)
        add_repo_action.connect("activate", lambda action, param: self.repo_list.on_add_repo_clicked(self.repo_list.add_button))
        action_group.add_action(add_repo_action)
        
        # Acción para editar repositorio (Ctrl+E)
        edit_repo_action = Gio.SimpleAction.new("edit-repo", None)
        edit_repo_action.connect("activate", lambda action, param: self.repo_list.on_edit_repo_clicked(self.repo_list.edit_button))
        action_group.add_action(edit_repo_action)
        
        # Acción para eliminar repositorio (Delete)
        remove_repo_action = Gio.SimpleAction.new("remove-repo", None)
        remove_repo_action.connect("activate", lambda action, param: self.repo_list.on_remove_repo_clicked(self.repo_list.remove_button))
        action_group.add_action(remove_repo_action)
        
        # Acción para cerrar (Ctrl+Q)
        quit_action = Gio.SimpleAction.new("quit", None)
        quit_action.connect("activate", lambda action, param: self.on_close_clicked(self.close_button))
        action_group.add_action(quit_action)
        
        # Configurar atajos de teclado para la aplicación
        app = self.get_application()
        if app:
            app.set_accels_for_action("win.apply", ["<Control>s"])
            app.set_accels_for_action("win.update", ["<Control>u"])
            app.set_accels_for_action("win.find-fast", ["<Control>f"])
            app.set_accels_for_action("win.add-repo", ["<Control>n"])
            app.set_accels_for_action("win.edit-repo", ["<Control>e"])
            app.set_accels_for_action("win.remove-repo", ["Delete"])
            app.set_accels_for_action("win.quit", ["<Control>q"])
    
    def _create_ui(self):
        """Crea la interfaz de usuario principal"""
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        main_box.set_margin_top(10)
        main_box.set_margin_bottom(10)
        main_box.set_margin_start(10)
        main_box.set_margin_end(10)
        self.add(main_box)
        
        # Panel superior con idioma
        top_panel = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        top_panel.set_halign(Gtk.Align.END)
        main_box.pack_start(top_panel, False, False, 0)
        
        # Selector de idioma
        language_label = Gtk.Label()
        language_label.set_markup_with_mnemonic(get_string("language", "_Idioma") + ":")
        language_label.set_name("language_label")
        top_panel.pack_start(language_label, False, False, 0)
        
        self.language_combo = Gtk.ComboBoxText()
        language_label.set_mnemonic_widget(self.language_combo)  # IMPORTANTE: Asociar mnemonic
        languages = get_available_languages()
        current_lang = get_current_language()
        
        # Ordenar idiomas de manera personalizada
        # Definir un orden específico para los idiomas prioritarios
        priority_langs = ['en', 'es', 'de', 'fr', 'it', 'pt', 'ro', 'ru']
        
        # Primero añadir los idiomas prioritarios en el orden especificado
        for lang_code in priority_langs:
            if lang_code in languages:
                self.language_combo.append(lang_code, languages[lang_code])
                if lang_code == current_lang:
                    self.language_combo.set_active_id(lang_code)
        
        # Luego añadir el resto de idiomas en orden alfabético por nombre
        remaining_langs = [(code, name) for code, name in languages.items() if code not in priority_langs]
        for code, name in sorted(remaining_langs, key=lambda x: x[1]):
            self.language_combo.append(code, name)
            if code == current_lang and self.language_combo.get_active() == -1:
                self.language_combo.set_active_id(code)
        
        self.language_combo.connect('changed', self.on_language_changed)
        top_panel.pack_start(self.language_combo, False, False, 0)
        
        # Crear notebook con mnemonics en las pestañas
        self.notebook = Gtk.Notebook()
        main_box.pack_start(self.notebook, True, True, 0)
        
        # Página 1: Repositorios CON mnemonic
        repo_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        repo_tab_label = Gtk.Label()
        repo_tab_label.set_markup_with_mnemonic(get_string("repositories", "_Repositorios"))
        self.notebook.append_page(repo_page, repo_tab_label)
        
        # Título de la sección de repositorios
        title_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        repo_page.pack_start(title_box, False, False, 0)
        
        # Título y descripción
        title_icon = Gtk.Image.new_from_icon_name("software-properties", Gtk.IconSize.DIALOG)
        title_box.pack_start(title_icon, False, False, 0)
        
        title_text_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        title_box.pack_start(title_text_box, True, True, 0)
        
        self.title_label = Gtk.Label()
        self.title_label.set_markup(f"<span size='x-large' weight='bold'>{get_string('repo_manager', 'Gestor de Repositorios Debian')}</span>")
        self.title_label.set_halign(Gtk.Align.START)
        self.title_label.set_name("title_label")
        title_text_box.pack_start(self.title_label, False, False, 0)
        
        self.desc_label = Gtk.Label(label=get_string('repo_description', 'Administra los repositorios APT de tu sistema'))
        self.desc_label.set_halign(Gtk.Align.START)
        self.desc_label.set_name("description_label")
        title_text_box.pack_start(self.desc_label, False, False, 0)
        
        # Separador
        separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        repo_page.pack_start(separator, False, False, 0)
        
        # Widget de lista de repositorios
        self.repo_list = RepoListWidget()
        self.repo_list.connect('repo-changed', self.on_repo_changed)
        repo_page.pack_start(self.repo_list, True, True, 0)
        
        # Botón para buscar repositorios más rápidos
        fast_repos_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        repo_page.pack_start(fast_repos_box, False, False, 0)
        
        # CORREGIR: Usar Button.new_with_mnemonic para mnemonics
        self.fast_repos_button = Gtk.Button.new_with_mnemonic(get_string("find_fastest_repos", "Buscar Repositorios Más _Rápidos"))
        self.fast_repos_button.connect("clicked", self.on_find_fastest_repos_clicked)
        fast_repos_box.pack_start(self.fast_repos_button, False, False, 0)
        
        # Espaciador
        fast_repos_box.pack_start(Gtk.Box(), True, True, 0)
        
        # Botón de actualización
        self.update_button = Gtk.Button.new_with_mnemonic(get_string("update_repos", "_Actualizar Repositorios"))
        self.update_button.connect("clicked", self.on_update_repos_clicked)
        fast_repos_box.pack_start(self.update_button, False, False, 0)
        
        # Frame para repositorios predefinidos populares
        self.predef_frame = Gtk.Frame(label=get_string("popular_repos", "Repositorios Predefinidos Populares"))
        self.predef_frame.set_name("predef_frame")  # Establecer nombre para búsqueda posterior
        repo_page.pack_start(self.predef_frame, False, True, 0)
        
        predef_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        predef_box.set_margin_top(10)
        predef_box.set_margin_bottom(10)
        predef_box.set_margin_start(10)
        predef_box.set_margin_end(10)
        self.predef_frame.add(predef_box)
        
        # Botones para repositorios predefinidos
        repo_buttons = [
            (get_string("google_chrome", "Google Chrome"), ["google-chrome", "chrome", "web-browser"], self.on_chrome_repo_clicked),
            (get_string("vscode", "VSCode"), ["code", "visual-studio-code", "vscode", "text-editor"], self.on_vscode_repo_clicked),
            (get_string("docker", "Docker"), ["docker", "application-x-docker", "applications-system"], self.on_docker_repo_clicked),
            (get_string("obs_studio", "OBS Studio"), ["com.obsproject.Studio", "obs", "obs-studio", "camera-video", "video-display"], self.on_obs_repo_clicked)
        ]
        
        for label, icon_names, callback in repo_buttons:
            button = Gtk.Button()
            button_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
            
            # Buscar el primer icono disponible en la lista
            icon = None
            icon_found = False
            
            for icon_name in icon_names:
                try:
                    icon = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.DIALOG)
                    # Verificar si el icono existe realmente
                    icon_theme = Gtk.IconTheme.get_default()
                    if icon_theme.has_icon(icon_name):
                        icon_found = True
                        break
                except Exception as e:
                    print(f"Error al cargar icono {icon_name}: {e}")
                    pass
            
            # Si no se encuentra ningún icono, usar uno genérico
            if not icon_found:
                icon = Gtk.Image.new_from_icon_name("package", Gtk.IconSize.DIALOG)
            
            button_box.pack_start(icon, False, False, 0)
            
            # Etiqueta del repositorio
            repo_label = Gtk.Label(label=label)
            button_box.pack_start(repo_label, False, False, 0)
            
            button.add(button_box)
            button.connect("clicked", callback)
            predef_box.pack_start(button, True, True, 0)
        
        # Página 2: Claves GPG CON mnemonic
        gpg_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        gpg_tab_label = Gtk.Label()
        gpg_tab_label.set_markup_with_mnemonic(get_string("gpg_keys", "Claves _GPG"))
        self.notebook.append_page(gpg_page, gpg_tab_label)
        
        # Título de la sección de claves GPG
        gpg_title_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        gpg_page.pack_start(gpg_title_box, False, False, 0)
        
        # Título y descripción
        gpg_title_icon = Gtk.Image.new_from_icon_name("dialog-password", Gtk.IconSize.DIALOG)
        gpg_title_box.pack_start(gpg_title_icon, False, False, 0)
        
        gpg_title_text_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        gpg_title_box.pack_start(gpg_title_text_box, True, True, 0)
        
        self.gpg_title_label = Gtk.Label()
        self.gpg_title_label.set_markup(f"<span size='x-large' weight='bold'>{get_string('gpg_key_manager', 'Gestor de Claves GPG')}</span>")
        self.gpg_title_label.set_halign(Gtk.Align.START)
        self.gpg_title_label.set_name("gpg_title_label")
        gpg_title_text_box.pack_start(self.gpg_title_label, False, False, 0)
        
        self.gpg_desc_label = Gtk.Label(label=get_string('gpg_key_description', 'Administra las claves GPG para tus repositorios'))
        self.gpg_desc_label.set_halign(Gtk.Align.START)
        self.gpg_desc_label.set_name("gpg_description_label")
        gpg_title_text_box.pack_start(self.gpg_desc_label, False, False, 0)
        
        # Separador
        gpg_separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        gpg_page.pack_start(gpg_separator, False, False, 0)
        
        # Widget de lista de claves GPG
        self.gpg_key_list = GPGKeyListWidget()
        self.gpg_key_list.connect('key-imported', self.on_key_imported)
        gpg_page.pack_start(self.gpg_key_list, True, True, 0)
        
        # Barra de progreso
        self.progress_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.progress_box.set_no_show_all(True)  # Inicialmente oculto
        main_box.pack_start(self.progress_box, False, False, 0)
        
        progress_label_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
        self.progress_box.pack_start(progress_label_box, False, False, 0)
        
        self.progress_spinner = Gtk.Spinner()
        progress_label_box.pack_start(self.progress_spinner, False, False, 0)
        
        self.progress_label = Gtk.Label(label=get_string("processing", "Procesando..."))
        self.progress_label.set_halign(Gtk.Align.START)
        progress_label_box.pack_start(self.progress_label, True, True, 0)
        
        # Barra de progreso
        self.progressbar = Gtk.ProgressBar()
        self.progressbar.set_show_text(True)
        self.progress_box.pack_start(self.progressbar, False, False, 0)
        
        # Botones principales CON mnemonics correctos
        button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        button_box.set_halign(Gtk.Align.END)
        button_box.set_margin_top(10)
        main_box.pack_end(button_box, False, False, 0)
        
        # CORREGIR: Usar Button.new_with_mnemonic para mnemonics
        self.close_button = Gtk.Button.new_with_mnemonic(get_string("close", "_Cerrar"))
        self.close_button.connect("clicked", self.on_close_clicked)
        button_box.pack_start(self.close_button, False, False, 0)
        
        self.apply_button = Gtk.Button.new_with_mnemonic(get_string("apply", "_Aplicar Cambios"))
        self.apply_button.connect("clicked", self.on_apply_changes_clicked)
        self.apply_button.get_style_context().add_class("suggested-action")
        button_box.pack_start(self.apply_button, False, False, 0)
        
        # Spinner para operaciones
        self.spinner = Gtk.Spinner()
        button_box.pack_start(self.spinner, False, False, 0)
        
    def _load_repos(self):
        """Carga los repositorios del sistema"""
        self.repo_list.clear()
        
        # Mostrar spinner mientras carga
        self.spinner.start()
        self.set_sensitive(False)
        
        # Mostrar barra de progreso
        self._show_progress_bar(get_string("loading_repos", "Cargando repositorios..."), 0.0)
        
        # Usar GLib.idle_add para no bloquear la UI
        GLib.idle_add(self._do_load_repos)
    
    def _do_load_repos(self):
        """Realiza la carga de repositorios en segundo plano"""
        try:
            repos = self.repo_manager.get_all_repos()
            
            total = len(repos)
            for i, repo in enumerate(repos):
                # Actualizar barra de progreso
                fraction = float(i) / max(total, 1)
                GLib.idle_add(self.progressbar.set_fraction, fraction)
                GLib.idle_add(self.progressbar.set_text, 
                             get_string("loading_repo_progress", "Cargando repositorio {0} de {1}").format(i+1, total))
                
                self.repo_list.add_repo(
                    not repo['disabled'],  # Activo
                    repo['type'],          # Tipo
                    repo['uri'],           # URI
                    repo['distribution'],  # Distribución
                    repo['components'],    # Componentes
                    repo['comment']        # Comentario
                )
            
            # Actualizar barra de progreso a completado
            GLib.idle_add(self.progressbar.set_fraction, 1.0)
            GLib.idle_add(self.progressbar.set_text, 
                         get_string("loaded_repos", "Cargados {0} repositorios").format(total))
            
        except Exception as e:
            log_error("Error al cargar repositorios", e)
            GLib.idle_add(self._hide_progress_bar)
            
            # Corregir la forma de manejar la excepción en el GLib.idle_add
            error_msg = str(e)  # Guardar el mensaje de error antes de pasar al lambda
            GLib.idle_add(lambda: ErrorHandler.show_error_dialog(
                get_string("error", "Error"), 
                get_string("error_loading_repos", "Error al cargar repositorios: {0}").format(error_msg),
                self
            ))
        
        # Detener spinner y restaurar sensibilidad
        GLib.idle_add(self.spinner.stop)
        GLib.idle_add(self.set_sensitive, True)
        
        # Ocultar barra de progreso después de un retraso
        GLib.timeout_add(1500, self._hide_progress_bar)
        
        return False  # Importante para GLib.idle_add
    
    def _show_progress_bar(self, message, fraction=0.0):
        """Muestra la barra de progreso con un mensaje"""
        self.progress_label.set_text(message)
        self.progressbar.set_fraction(fraction)
        self.progressbar.set_text(f"{int(fraction * 100)}%")
        self.progress_spinner.start()
        
        # Cambiar a set_visible(True) en lugar de usar show_all()
        self.progress_box.set_no_show_all(False)
        self.progress_box.set_visible(True)
        self.progress_box.show_all()

    def _update_progress_bar(self, fraction, text=None):
        """Actualiza el progreso de la barra"""
        self.progressbar.set_fraction(fraction)
        if text:
            self.progressbar.set_text(text)
        else:
            self.progressbar.set_text(f"{int(fraction * 100)}%")
    
    def _hide_progress_bar(self):
        """Oculta la barra de progreso"""
        self.progress_spinner.stop()
        self.progress_box.set_visible(False)
        self.progress_box.set_no_show_all(True)
        return False  # Importante para usar con GLib.timeout_add
    
    def on_repo_changed(self, widget):
        """Maneja los cambios en los repositorios"""
        # Este método se llama cuando hay cambios en la lista de repositorios
        # Se puede usar para habilitar/deshabilitar botones, actualizar contadores, etc.
        pass
    
    def on_key_imported(self, widget, success, path_or_error):
        """Maneja el evento de importación de clave GPG"""
        if success:
            self._show_info_dialog(get_string('key_imported', 'Clave importada:') + f" {os.path.basename(path_or_error)}")
        else:
            self._show_error_dialog(get_string('key_import_error', 'Error al importar clave:') + f" {path_or_error}")
    
    def on_find_fastest_repos_clicked(self, button):
        """Abre el diálogo para buscar los repositorios más rápidos y añade los seleccionados"""
        try:
            # Recopilar URLs de repositorios actuales para evitar duplicados
            current_repos = []
            def collect_repos(model, path, iter, data):
                uri = model[iter][2]
                if uri not in data:
                    data.append(uri)
            self.repo_list.repos_store.foreach(collect_repos, current_repos)

            # Mostrar diálogo de velocidad
            from src.gui.dialogs.speed_dialog import RepoSpeedDialog
            dialog = RepoSpeedDialog(self, current_repos)
            response = dialog.run()
            if response == Gtk.ResponseType.OK:
                selected_repos = dialog.get_selected_repos()
                if selected_repos:
                    for repo in selected_repos:
                        self.repo_list.add_repo(
                            True,
                            repo.get('type', 'deb'),
                            repo['uri'],
                            repo['distribution'],
                            repo['components'],
                            get_string('added_via_speed_test', 'Añadido mediante test de velocidad')
                        )
                    self._show_info_dialog(get_string("repos_added", "Repositorios añadidos correctamente"))
                else:
                    self._show_info_dialog(get_string("no_repos_selected", "No se seleccionaron repositorios"))
            dialog.destroy()
        except Exception as e:
            log_error("Error al buscar repositorios rápidos", e)
            self._show_error_dialog(get_string("error_finding_repos", "Error al buscar repositorios rápidos: {0}").format(str(e)))
    
    def on_update_repos_clicked(self, button):
        """Actualiza la lista de paquetes (apt update)"""
        # Guardar los repositorios actuales antes de actualizar
        self.save_current_repos_state()
        
        self.spinner.start()
        button.set_sensitive(False)
        
        # Mostrar barra de progreso
        self._show_progress_bar(get_string("updating_repos", "Actualizando repositorios..."), 0.0)
        
        # Usar GLib.idle_add para ejecutar apt update en segundo plano
        GLib.idle_add(self._do_update_repos, button)
        
    def save_current_repos_state(self):
        """Guarda el estado actual de los repositorios para restaurarlos después de actualizar"""
        self.saved_repos = []
        self.repo_list.repos_store.foreach(self._collect_repos, self.saved_repos)
    
    def _collect_repos(self, model, path, iter, repos_list):
        """Recopila información de repositorios desde el modelo de datos"""
        # Extraer datos de la fila
        active = model[iter][0]
        repo_type = model[iter][1]
        uri = model[iter][2]
        distribution = model[iter][3]
        components = model[iter][4]
        comment = model[iter][5]
        
        # Buscar si este repositorio ya existe en el sistema
        # para mantener su archivo de origen y formato
        existing_repos = self.repo_manager.get_all_repos(use_cache=False)
        found_repo = None
        
        for existing in existing_repos:
            if (existing['uri'] == uri and 
                existing['distribution'] == distribution and 
                existing['type'] == repo_type):
                found_repo = existing
                break
        
        # Si encontramos un repo existente, usar su información
        if found_repo:
            repo = {
                'disabled': not active,  # Importante: respetar el estado de activación actual
                'type': repo_type,
                'uri': uri,
                'distribution': distribution,
                'components': components,
                'comment': comment,
                'file': found_repo['file'],
                'format': found_repo.get('format', 'legacy')
            }
        else:
            # Para repositorios nuevos, usar archivo apropiado y formato DEB822 si es posible
            format_type = 'deb822' if self.repo_manager.use_modern_format else 'legacy'
            file_extension = '.sources' if self.repo_manager.use_modern_format else '.list'
            
            # Determinar archivo adecuado basado en URI y distribución
            if "security.debian.org" in uri:
                # Repositorios de seguridad siempre van en un archivo separado
                file_path = f'/etc/apt/sources.list.d/debian-security{file_extension}'
            elif "debian.org" in uri:
                # Para otros repos oficiales Debian usar formato moderno
                if distribution.endswith('-backports'):
                    file_path = f'/etc/apt/sources.list.d/debian-backports{file_extension}'
                else:
                    file_path = f'/etc/apt/sources.list.d/debian{file_extension}'
            else:
                # Para otros repos, crear un archivo basado en el hostname
                hostname = uri.split('//')[-1].split('/')[0].replace(".", "-")
                file_path = f'/etc/apt/sources.list.d/{hostname}{file_extension}'
            
            repo = {
                'disabled': not active,  # Importante: respetar el estado de activación actual
                'type': repo_type,
                'uri': uri,
                'distribution': distribution,
                'components': components,
                'comment': comment,
                'file': file_path,
                'format': format_type
            }
        
        # Añadir el repositorio (nuevo o existente) a la lista guardada
        repos_list.append(repo)
    
    def _do_update_repos(self, button):
        """Ejecuta el comando apt update y maneja la salida"""
        try:
            # Mostrar información de progreso
            self._update_progress_bar(0.1, get_string("updating_repos", "Actualizando repositorios..."))
            
            # Usar pkexec para obtener privilegios elevados
            process = subprocess.Popen(
                ['pkexec', 'apt', 'update'],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # Leer la salida línea por línea
            for stdout_line in iter(process.stdout.readline, ''):
                if not stdout_line:
                    break
                    
                # Filtrar líneas de progreso de apt
                if stdout_line.startswith(("Get:", "Hit:", "Ign:")):
                    continue
                
                # Mostrar cada línea en la barra de progreso
                GLib.idle_add(self._update_progress_bar, 0.5, stdout_line.strip())
            
            # Esperar a que el proceso termine
            process.stdout.close()
            return_code = process.wait()
            
            # Leer cualquier error
            stderr_output = process.stderr.read()
            
            # Comprobar si hubo errores
            if return_code != 0:
                if "permission denied" in stderr_output.lower() or "permiso denegado" in stderr_output.lower():
                    GLib.idle_add(self._show_error_dialog, 
                                get_string("permission_error", "Error de permisos: No tiene privilegios para actualizar repositorios"))
                else:
                    GLib.idle_add(self._show_error_dialog, 
                                get_string("error_updating_repos", "Error al actualizar repositorios: {0}").format(stderr_output.strip()))
            else:
                GLib.idle_add(self._show_info_dialog, get_string("repos_updated", "Repositorios actualizados correctamente"))
    
        except subprocess.SubprocessError as e:
            log_error("Error al ejecutar apt update", e)
            # Verificar si es un error relacionado con pkexec cancelado por el usuario
            if isinstance(e, subprocess.CalledProcessError) and e.returncode == 126:
                GLib.idle_add(self._show_info_dialog, get_string("update_cancelled", "Actualización cancelada por el usuario"))
            else:
                GLib.idle_add(self._show_error_dialog, get_string("error_updating_repos", "Error al actualizar repositorios: {0}").format(str(e)))
    
        except Exception as e:
            log_error("Error al ejecutar apt update", e)
            GLib.idle_add(self._show_error_dialog, get_string("error_updating_repos", "Error al actualizar repositorios: {0}").format(str(e)))
    
        finally:
            # Detener spinner y restaurar botón
            GLib.idle_add(self.spinner.stop)
            GLib.idle_add(button.set_sensitive, True)
            GLib.idle_add(self._hide_progress_bar)
    
    def _populate_repos(self):
        """Llena la lista de repositorios desde el gestor de repositorios"""
        self.repo_list.clear()
        try:
            repos = self.repo_manager.get_all_repos()
            for repo in repos:
                self.repo_list.add_repo(
                    not repo.get('disabled', False),
                    repo.get('type', 'deb'),
                    repo.get('uri', ''),
                    repo.get('distribution', ''),
                    repo.get('components', ''),
                    repo.get('comment', '')
                )
        except Exception as e:
            log_error("Error al poblar la lista de repositorios", e)
            self._show_error_dialog(get_string("error_loading_repos", "Error al cargar repositorios: {0}").format(str(e)))

    def on_language_changed(self, combo):
        """Cambia el idioma de la interfaz"""
        lang_code = combo.get_active_id()
        if lang_code:
            set_language(lang_code)
            self._update_ui_strings()
    
    def _update_ui_strings(self):
        """Actualiza las cadenas de la interfaz según el idioma actual"""
        # Actualizar título de la ventana
        self.set_title(get_string('window_title', APP_NAME))
        
        # Actualizar títulos y descripciones principales SIN mnemonics
        self.title_label.set_markup(f"<span size='x-large' weight='bold'>{get_string('repo_manager', 'Gestor de Repositorios Debian')}</span>")
        self.desc_label.set_text(get_string('repo_description', 'Administra los repositorios APT de tu sistema'))
        self.gpg_title_label.set_markup(f"<span size='x-large' weight='bold'>{get_string('gpg_key_manager', 'Gestor de Claves GPG')}</span>")
        self.gpg_desc_label.set_text(get_string('gpg_key_description', 'Administra las claves GPG para tus repositorios'))
        
        # Actualizar pestañas del notebook CON mnemonics
        repo_tab_label = self.notebook.get_tab_label(self.notebook.get_nth_page(0))
        if repo_tab_label:
            repo_tab_label.set_markup_with_mnemonic(get_string("repositories", "_Repositorios"))
        
        gpg_tab_label = self.notebook.get_tab_label(self.notebook.get_nth_page(1))
        if gpg_tab_label:
            gpg_tab_label.set_markup_with_mnemonic(get_string("gpg_keys", "Claves _GPG"))
        
        # Actualizar botones principales CON mnemonics
        self.close_button.set_label(get_string("close", "_Cerrar"))
        self.close_button.set_use_underline(True)
        
        self.apply_button.set_label(get_string("apply", "_Aplicar Cambios"))
        self.apply_button.set_use_underline(True)
        
        self.fast_repos_button.set_label(get_string("find_fastest_repos", "Buscar Repositorios Más _Rápidos"))
        self.fast_repos_button.set_use_underline(True)
        
        self.update_button.set_label(get_string("update_repos", "_Actualizar Repositorios"))
        self.update_button.set_use_underline(True)
        
        # Actualizar etiqueta de idioma CON mnemonic
        language_label = None
        for child in self.get_children():
            if hasattr(child, 'get_children'):
                for subchild in child.get_children():
                    if hasattr(subchild, 'get_name') and subchild.get_name() == "language_label":
                        language_label = subchild
                        break
        if language_label:
            language_label.set_markup_with_mnemonic(get_string("language", "_Idioma") + ":")
        
        # Actualizar widgets hijos
        if hasattr(self, "repo_list"):
            self.repo_list.update_ui_strings(i18n_strings._current_strings)
        if hasattr(self, "gpg_key_list"):
            self.gpg_key_list.update_ui_strings(i18n_strings._current_strings)
        
        # Actualizar botones de repositorios predefinidos
        self._update_predefined_repo_buttons()
    
    def _update_predefined_repo_buttons(self):
        """Actualiza las etiquetas de los botones de repositorios predefinidos"""
        # Mapeo de nombres de repos a claves de traducción
        repo_name_mapping = {
            "google_chrome": "Google Chrome",
            "vscode": "VSCode", 
            "docker": "Docker",
            "obs_studio": "OBS Studio"
        }
        
        def find_and_update_buttons(widget):
            if isinstance(widget, Gtk.Button):
                # Buscar el box interno del botón
                button_child = widget.get_child()
                if isinstance(button_child, Gtk.Box):
                    for box_child in button_child.get_children():
                        if isinstance(box_child, Gtk.Label):
                            current_text = box_child.get_text()
                            # Actualizar con traducciones
                            for key, default in repo_name_mapping.items():
                                if current_text == default or current_text == get_string(key, default):
                                    box_child.set_text(get_string(key, default))
                                    break
            elif hasattr(widget, 'get_children'):
                for child in widget.get_children():
                    find_and_update_buttons(child)
        
        if hasattr(self, 'predef_frame'):
            find_and_update_buttons(self.predef_frame)

    def _show_info_dialog(self, message):
        """Muestra un diálogo de información"""
        ErrorHandler.show_warning_dialog(get_string("success", "Éxito"), message, parent=self)

    def _show_error_dialog(self, message):
        """Muestra un diálogo de error"""
        ErrorHandler.show_error_dialog(get_string("error", "Error"), message, parent=self)

    def on_delete_event(self, window, event):
        """Maneja el evento cuando el usuario intenta cerrar la ventana."""
        # Mostrar diálogo de confirmación usando ErrorHandler
        from gi.repository import Gtk
        title = get_string("close", "Cerrar")
        message = get_string("close_confirm", "¿Está seguro de que desea cerrar la aplicación?")
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.NONE,
            text=title
        )
        dialog.format_secondary_text(message)
        dialog.add_button(get_string("no", "No"), Gtk.ResponseType.NO)
        dialog.add_button(get_string("yes", "Sí"), Gtk.ResponseType.YES)
        dialog.set_default_response(Gtk.ResponseType.YES)
        response = dialog.run()
        dialog.destroy()
        if response == Gtk.ResponseType.NO:
            return True
        else:
            self._cleanup_before_exit()
            return False

    def on_close_clicked(self, button):
        """Maneja el clic en el botón Cerrar"""
        # En lugar de emitir delete-event, llamar directamente al método de cierre
        should_close = not self.on_delete_event(self, None)
        if should_close:
            # Cerrar la aplicación
            if hasattr(self, 'get_application') and self.get_application():
                self.get_application().quit()
            else:
                # Fallback: usar Gtk.main_quit si no hay aplicación
                try:
                    Gtk.main_quit()
                except:
                    # Último recurso: salir del programa
                    import sys
                    sys.exit(0)
    
    def _cleanup_before_exit(self):
        """Realiza limpieza antes de salir de la aplicación"""
        try:
            # Guardar configuración de ventana si es necesario
            from src.config.app_settings import settings
            
            # Guardar tamaño de ventana
            if not self.is_maximized():
                width, height = self.get_size()
                settings.set_window_size(width, height)
            
            settings.set('window_maximized', self.is_maximized())
            
            # Siempre limpiar los archivos de caché al salir, independientemente de la configuración
            # Esto asegura que se limpien incluso si la configuración está corrupta
            self._clean_pycache_files()
            
            # También actualizar la configuración para futuras ejecuciones
            settings.set('clean_pycache_on_exit', True)
            
        except Exception as e:
            log_warning(f"Error durante limpieza al salir: {e}")
    
    def _clean_pycache_files(self):
        """Limpia archivos __pycache__ al salir"""
        try:
            import shutil
            import os
            import sys
            
            # Asegurarnos de no crear nuevos archivos .pyc
            sys.dont_write_bytecode = True
            
            # Buscar directorios __pycache__ en el directorio de la aplicación
            app_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
            log_info(f"Limpiando archivos de caché en: {app_dir}")
            
            # Eliminar los intentos de cambiar permisos que causaban errores
            
            for root, dirs, files in os.walk(app_dir):
                if '__pycache__' in dirs:
                    pycache_dir = os.path.join(root, '__pycache__')
                    try:
                        # Solo intentar eliminar si tenemos permisos
                        if os.access(pycache_dir, os.W_OK):
                            shutil.rmtree(pycache_dir)
                            log_info(f"Limpiado directorio de caché: {pycache_dir}")
                        else:
                            log_warning(f"Sin permisos para limpiar: {pycache_dir}")
                    except Exception as e:
                        log_warning(f"No se pudo limpiar {pycache_dir}: {e}")
                    
                    # Remover del listado para evitar procesarlo de nuevo
                    dirs.remove('__pycache__')
                
                # También limpiar archivos .pyc/.pyo sueltos
                for file in files:
                    if file.endswith(('.pyc', '.pyo')):
                        try:
                            file_path = os.path.join(root, file)
                            # Solo intentar eliminar si tenemos permisos
                            if os.access(file_path, os.W_OK):
                                os.remove(file_path)
                                log_info(f"Eliminado archivo: {file_path}")
                            else:
                                log_warning(f"Sin permisos para eliminar: {file_path}")
                        except Exception as e:
                            log_warning(f"No se pudo eliminar {file}: {e}")
        
        except Exception as e:
            log_warning(f"Error limpiando archivos de caché: {e}")
    
    def on_chrome_repo_clicked(self, button):
        """Añade el repositorio de Google Chrome"""
        try:
            repo = PREDEFINED_REPOS["chrome"]
            self.repo_list.add_repo(
                repo["active"],
                repo["type"],
                repo["uri"],
                repo["distribution"],
                repo["components"],
                get_string("chrome_comment", repo["comment"])
            )
            
            # Instalar la clave GPG si es necesario
            from src.repo.gpg_manager import GPGManager
            gpg_manager = GPGManager()
            success, msg = gpg_manager.download_key(repo["uri"])
            if success:
                log_info(get_string("key_installed", "Clave GPG instalada correctamente"))
            else:
                log_warning(get_string("key_install_warning", "Aviso: No fue posible instalar la clave GPG"))
                
            self._show_info_dialog(get_string("repo_added", "Repositorio añadido: {0}").format("Google Chrome"))
            
        except Exception as e:
            log_error(f"Error al añadir repositorio Chrome: {e}", e)
            self._show_error_dialog(f"Error: {str(e)}")
    
    def on_vscode_repo_clicked(self, button):
        """Añade el repositorio de Visual Studio Code"""
        try:
            repo = PREDEFINED_REPOS["vscode"]
            self.repo_list.add_repo(
                repo["active"],
                repo["type"],
                repo["uri"],
                repo["distribution"],
                repo["components"],
                get_string("vscode_comment", repo["comment"])
            )
            
            # Instalar la clave GPG si es necesario
            from src.repo.gpg_manager import GPGManager
            gpg_manager = GPGManager()
            success, msg = gpg_manager.download_key(repo["uri"])
            if success:
                log_info(get_string("key_installed", "Clave GPG instalada correctamente"))
            else:
                log_warning(get_string("key_install_warning", "Aviso: No fue posible instalar la clave GPG"))
                
            self._show_info_dialog(get_string("repo_added", "Repositorio añadido: {0}").format("Visual Studio Code"))
            
        except Exception as e:
            log_error(f"Error al añadir repositorio VS Code: {e}", e)
            self._show_error_dialog(f"Error: {str(e)}")
    
    def on_docker_repo_clicked(self, button):
        """Añade el repositorio de Docker"""
        try:
            repo = PREDEFINED_REPOS["docker"]
            # Si la distribución es un comando, intentar resolverla
            dist = repo["distribution"]
            if dist.startswith("$("):
                import subprocess
                try:
                    lsb = subprocess.run(['lsb_release', '-cs'], capture_output=True, text=True)
                    if lsb.returncode == 0:
                        dist = lsb.stdout.strip()
                    else:
                        dist = "stable"
                except Exception:
                    dist = "stable"
            self.repo_list.add_repo(
                repo["active"],
                repo["type"],
                repo["uri"],
                dist,
                repo["components"],
                get_string("docker_comment", repo["comment"])
            )
            
            # Instalar la clave GPG si es necesario
            from src.repo.gpg_manager import GPGManager
            gpg_manager = GPGManager()
            success, msg = gpg_manager.download_key(repo["uri"])
            if success:
                log_info(get_string("key_installed", "Clave GPG instalada correctamente"))
            else:
                log_warning(get_string("key_install_warning", "Aviso: No fue posible instalar la clave GPG"))
                
            self._show_info_dialog(get_string("repo_added", "Repositorio añadido: {0}").format("Docker"))
            
        except Exception as e:
            log_error(f"Error al añadir repositorio Docker: {e}", e)
            self._show_error_dialog(f"Error: {str(e)}")
    
    def on_obs_repo_clicked(self, button):
        """Añade el repositorio de OBS Studio"""
        try:
            repo = PREDEFINED_REPOS["obs"]
            dist = repo["distribution"]
            if dist.startswith("$("):
                import subprocess
                try:
                    lsb = subprocess.run(['lsb_release', '-cs'], capture_output=True, text=True)
                    if lsb.returncode == 0:
                        dist = lsb.stdout.strip()
                    else:
                        dist = "stable"
                except Exception:
                    dist = "stable"
            self.repo_list.add_repo(
                repo["active"],
                repo["type"],
                repo["uri"],
                dist,
                repo["components"],
                get_string("obs_comment", repo["comment"])
            )
            
            # Instalar la clave GPG si es necesario
            from src.repo.gpg_manager import GPGManager
            gpg_manager = GPGManager()
            success, msg = gpg_manager.download_key(repo["uri"])
            if success:
                log_info(get_string("key_installed", "Clave GPG instalada correctamente"))
            else:
                log_warning(get_string("key_install_warning", "Aviso: No fue posible instalar la clave GPG"))
                
            self._show_info_dialog(get_string("repo_added", "Repositorio añadido: {0}").format("OBS Studio"))
            
        except Exception as e:
            log_error(f"Error al añadir repositorio OBS Studio: {e}", e)
            self._show_error_dialog(f"Error: {str(e)}")
    
    def on_apply_changes_clicked(self, button):
        """Aplica los cambios a los archivos de repositorios"""
        try:
            # Deshabilitar el botón mientras se procesan los cambios
            button.set_sensitive(False)
            self.spinner.start()
            
            # Mostrar barra de progreso
            self._show_progress_bar(get_string("applying_changes", "Aplicando cambios a los repositorios..."), 0.0)
            
            # Obtener lista de archivos de repositorio existentes antes de aplicar cambios
            existing_repo_files = []
            try:
                sources_dir = '/etc/apt/sources.list.d'
                main_sources = '/etc/apt/sources.list'
                
                if os.path.exists(sources_dir):
                    existing_repo_files = [os.path.join(sources_dir, f) for f in os.listdir(sources_dir) 
                                        if f.endswith('.list') or f.endswith('.sources')]
                
                if os.path.exists(main_sources):
                    existing_repo_files.append(main_sources)
            except Exception as e:
                log_warning(f"Error al obtener la lista de archivos de repositorio existentes: {e}")
            
            # Recopilar todos los repositorios actuales
            current_repos = []
            self.repo_list.repos_store.foreach(self._collect_repos, current_repos)

            if not current_repos:
                self._show_info_dialog(get_string("no_repos_to_save", "No hay repositorios que guardar"))
                self._hide_progress_bar()
                self.spinner.stop()
                button.set_sensitive(True)
                return

            # Filtrar solo repositorios Debian oficiales para escribirlos
            debian_repos = []
            for repo in current_repos:
                uri = repo['uri']
                if "debian.org" in uri or "debian.net" in uri or "security.debian.org" in uri:
                    debian_repos.append(repo)
            # Agrupar por archivo .sources
            repos_by_file = {}
            for repo in debian_repos:
                file_path = repo.get('file', '/etc/apt/sources.list.d/debian.sources')
                if file_path not in repos_by_file:
                    repos_by_file[file_path] = []
                repos_by_file[file_path].append(repo)
            
            # Número total de archivos a procesar
            total_files = len(repos_by_file)
            processed = 0
            
            # Crear script que se ejecutará con privilegios elevados
            temp_script = os.path.join(GLib.get_tmp_dir(), f"soplos-repo-update-{os.getpid()}.sh")
            
            with open(temp_script, 'w') as f:
                f.write("#!/bin/bash\n")
                f.write("# Script generado por Soplos Repo Selector\n\n")
                f.write("set -e\n\n")  # Salir en caso de error
                
                # Hacer una copia de seguridad de los archivos originales
                f.write("# Hacer copia de seguridad de archivos originales\n")
                f.write("BACKUP_DIR=\"/tmp/soplos-repo-backup-$(date +%s)\"\n")
                f.write("mkdir -p \"$BACKUP_DIR\"\n")
                # Solo copiar archivos .sources gestionados por el programa
                for file_path in repos_by_file.keys():
                    f.write(f"if [ -f \"{file_path}\" ]; then cp \"{file_path}\" \"$BACKUP_DIR/\"; fi\n")
                f.write("\n")
                
                # Para cada archivo de repositorio gestionado
                for file_path, repos in repos_by_file.items():
                    processed += 1
                    progress = processed / total_files

                    # Actualizar barra de progreso
                    GLib.idle_add(self._update_progress_bar, progress,
                                 get_string("saving_changes", "Guardando cambios...") + f" ({processed}/{total_files})")

                    # Crear directorio si no existe
                    f.write(f"mkdir -p $(dirname \"{file_path}\")\n")

                    # Determinar si es formato deb822 o legacy basado en extensión
                    is_deb822 = file_path.endswith('.sources')

                    if is_deb822:
                        # Formato deb822 (.sources)
                        f.write(f"cat > \"{file_path}\" << 'EOF'\n")
                        for repo in repos:
                            # --- Generación estricta DEB822 ---
                            repo_types = [t for t in repo['type'].split() if t in ('deb', 'deb-src')]
                            if not repo_types:
                                repo_types = ['deb']
                            f.write(f"Types: {' '.join(repo_types)}\n")
                            uri = repo['uri']
                            if not uri.endswith('/'):
                                uri += '/'
                            f.write(f"URIs: {uri}\n")
                            suite = repo['distribution'].strip()
                            f.write(f"Suites: {suite}\n")
                            comps = [c for c in repo['components'].split() if c]
                            if comps:
                                f.write(f"Components: {' '.join(comps)}\n")
                            # Añadir Signed-By SOLO para Debian/mirrors oficiales
                            signed_by = repo.get('signed_by', '').strip()
                            if (
                                "debian.org" in uri or
                                "debian.net" in uri or
                                "security.debian.org" in uri or
                                "cloudfront.debian.net" in uri
                            ):
                                signed_by = "/usr/share/keyrings/debian-archive-keyring.gpg"
                            if signed_by:
                                f.write(f"Signed-By: {signed_by}\n")
                            # No escribir comentarios ni líneas extra
                            f.write("\n")  # Línea en blanco entre bloques
                        f.write("EOF\n\n")
                    else:
                        # Formato legacy (.list)
                        f.write(f"cat > \"{file_path}\" << 'EOF'\n")
                        for repo in repos:
                            prefix = '# ' if repo.get('disabled', False) else ''
                            repo_types = [t for t in repo['type'].split() if t in ('deb', 'deb-src')]
                            if not repo_types:
                                repo_types = ['deb']
                            for rt in repo_types:
                                f.write(f"{prefix}{rt} {repo['uri']} {repo['distribution']} {repo['components']}\n")
                                # Añadir Signed-By como opción solo si corresponde
                                signed_by = repo.get('signed_by', '').strip()
                                uri = repo['uri']
                                if (
                                    "debian.org" in uri or
                                    "debian.net" in uri or
                                    "security.debian.org" in uri or
                                    "cloudfront.debian.net" in uri
                                ):
                                    signed_by = "/usr/share/keyrings/debian-archive-keyring.gpg"
                                if signed_by and not repo.get('disabled', False):
                                    f.write(f"# Signed by: {signed_by}\n")
                        f.write("\nEOF\n\n")
                
                # Eliminar SOLO archivos .sources gestionados por el programa que ya no están en la lista actualizada
                f.write("# Eliminar archivos .sources antiguos gestionados por el programa\n")
                f.write("for file in /etc/apt/sources.list.d/*.sources; do\n")
                f.write("  keep=0\n")
                for file_path in repos_by_file.keys():
                    f.write(f"  if [ \"$file\" = \"{file_path}\" ]; then keep=1; fi\n")
                f.write("  if [ $keep -eq 0 ] && [ -f \"$file\" ]; then\n")
                f.write("    echo \"Eliminando archivo obsoleto: $file\"\n")
                f.write("    rm \"$file\"\n")
                f.write("  fi\n")
                f.write("done\n\n")
                
                # Restaurar las claves GPG necesarias para los repositorios
                f.write("# Asegurarnos de que todas las claves GPG necesarias estén disponibles\n")
                f.write("# Mozilla\n")
                f.write("if grep -q 'mozilla' /etc/apt/sources.list.d/*.list 2>/dev/null; then\n")
                f.write("  if [ ! -f \"/etc/apt/keyrings/packages.mozilla.org.asc\" ]; then\n")
                f.write("    echo \"Restaurando clave Mozilla...\"\n")
                f.write("    curl -fsSL https://packages.mozilla.org/apt/repo-signing-key.gpg | tee /etc/apt/keyrings/packages.mozilla.org.asc > /dev/null\n")
                f.write("  fi\n")
                f.write("fi\n\n")
                
                f.write("# Liquorix\n")
                f.write("if grep -q 'liquorix' /etc/apt/sources.list.d/*.list 2>/dev/null; then\n")
                f.write("  if [ ! -f \"/etc/apt/keyrings/liquorix-keyring.gpg\" ]; then\n")
                f.write("    echo \"Restaurando clave Liquorix...\"\n")
                f.write("    curl -fsSL https://liquorix.net/linux-liquorix.pub | tee /etc/apt/keyrings/liquorix-keyring.gpg > /dev/null\n")
                f.write("  fi\n")
                f.write("fi\n\n")
                
                f.write("# Tyron\n")
                f.write("if grep -q 'tyron' /etc/apt/sources.list.d/*.list 2>/dev/null; then\n")
                f.write("  if [ ! -f \"/usr/share/keyrings/tyron.gpg\" ]; then\n")
                f.write("    echo \"Restaurando clave Tyron...\"\n")
                f.write("    curl -fsSL https://raw.githubusercontent.com/SoplosLinux/tyron/main/keyring/tyron-keyring.gpg | tee /usr/share/keyrings/tyron.gpg > /dev/null\n")
                f.write("  fi\n")
                f.write("fi\n\n")
                
                # Verificar sintaxis de fuentes para evitar problemas
                f.write("echo \"Verificando la sintaxis de los repositorios...\"\n")
                f.write("if command -v apt-config &> /dev/null; then\n")
                f.write("    apt-config dump > /dev/null 2>&1\n")
                f.write("    if [ $? -ne 0 ]; then\n")
                f.write("        echo \"Error: Los cambios realizados pueden haber causado un problema de sintaxis.\" >&2\n")
                f.write("        # Restaurar copia de seguridad en caso de error\n")
                f.write("        echo \"Restaurando configuración anterior...\" >&2\n")
                f.write("        cp -a \"$BACKUP_DIR/\"* /etc/apt/ 2>/dev/null || true\n")
                f.write("        exit 1\n")
                f.write("    fi\n")
                f.write("fi\n\n")
                
                # Verificar las claves GPG necesarias
                f.write("echo \"Verificando claves GPG necesarias...\"\n")
                f.write("# Asegurar que existan los directorios de claves\n")
                f.write("mkdir -p /usr/share/keyrings /etc/apt/keyrings\n\n")
                
                # Actualizar índices si todo está correcto
                f.write("echo \"Actualizando índices de repositorios...\"\n")
                f.write("apt-get update -qq || true\n")
                
                # Limpiar copias de seguridad si todo fue exitoso
                f.write("\n# Limpiar copias de seguridad si todo fue exitoso\n")
                f.write("rm -rf \"$BACKUP_DIR\"\n")
            
            # Hacer el script ejecutable
            os.chmod(temp_script, 0o755)
            
            # Ejecutar el script con pkexec
            process = subprocess.Popen(
                ["pkexec", "bash", temp_script],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # Esperar a que el proceso termine
            stdout, stderr = process.communicate()
            
            # Limpiar el archivo temporal
            try:
                os.unlink(temp_script)
            except:
                pass
            
            if process.returncode == 0:
                # Invalidar la caché del repo_manager para forzar recarga
                self.repo_manager.invalidate_cache()
                
                # Mostrar mensaje de éxito
                self._update_progress_bar(1.0, get_string("changes_applied_success", "Cambios aplicados correctamente"))
                GLib.timeout_add(1500, lambda: self._show_info_dialog(get_string("changes_applied", "Cambios aplicados correctamente")))
                
                # Recargar la lista para confirmar cambios - IMPORTANTE: use_cache=False para forzar recarga
                GLib.timeout_add(2000, lambda: self._load_repos_no_cache())
            else:
                # Mostrar mensaje de error
                error_message = stderr.strip() or "Error desconocido"
                self._show_error_dialog(get_string("apply_error", "Error al aplicar cambios: {0}").format(error_message))
                
        except subprocess.SubprocessError as e:
            # Verificar si es un error relacionado con pkexec cancelado por el usuario
            if isinstance(e, subprocess.CalledProcessError) and e.returncode == 126:
                self._show_info_dialog(get_string("operation_cancelled", "Operación cancelada por el usuario"))
            else:
                self._show_error_dialog(get_string("apply_error", "Error al aplicar cambios: {0}").format(str(e)))
                
        except Exception as e:
            log_error("Error al aplicar cambios a los repositorios", e)
            self._show_error_dialog(get_string("apply_error", "Error al aplicar cambios: {0}").format(str(e)))
            
        finally:
            # Limpiar y restaurar la interfaz
            self._hide_progress_bar()
            self.spinner.stop()
            button.set_sensitive(True)
    
    def _load_repos_no_cache(self):
        """Recarga los repositorios sin usar caché"""
        self.repo_list.clear()
        
        # Mostrar spinner mientras carga
        self.spinner.start()
        self.set_sensitive(False)
        
        # Mostrar barra de progreso
        self._show_progress_bar(get_string("loading_repos", "Cargando repositorios..."), 0.0)
        
        # Forzar invalidación de caché
        self.repo_manager.invalidate_cache()
        
        # Usar GLib.idle_add para no bloquear la UI
        GLib.idle_add(self._do_load_repos)
