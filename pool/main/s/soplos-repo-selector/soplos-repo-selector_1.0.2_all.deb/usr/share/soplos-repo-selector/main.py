#!/usr/bin/env python3
"""
Punto de entrada principal para Soplos Repo Selector
"""

import sys
import os
import signal
import locale
import shutil

# Configurar el entorno antes de importar GTK
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
os.environ['NO_AT_BRIDGE'] = '1'

# Añadir el directorio raíz al PYTHONPATH
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def setup_environment():
    """Configura el entorno de ejecución"""
    try:
        # Configurar locale
        locale.setlocale(locale.LC_ALL, '')
    except locale.Error:
        # Si falla, usar locale por defecto
        pass
    
    # Configurar codificación UTF-8
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8')
    if hasattr(sys.stderr, 'reconfigure'):
        sys.stderr.reconfigure(encoding='utf-8')
        

def handle_signal(signum, frame):
    """Maneja señales del sistema para cierre limpio"""
    print(f"\nSignal received: {signum}, closing application...")
    sys.exit(0)

def clean_all_pycache(base_dir):
    """Elimina todos los directorios __pycache__ y archivos .pyc"""
    for root, dirs, files in os.walk(base_dir, topdown=False):
        for file in files:
            if file.endswith('.pyc') or file.endswith('.pyo'):
                try:
                    file_path = os.path.join(root, file)
                    if os.access(file_path, os.W_OK):
                        os.remove(file_path)
                except Exception:
                    pass
        
        # Eliminar directorios __pycache__
        for dir_name in dirs:
            if dir_name == '__pycache__':
                try:
                    dir_path = os.path.join(root, dir_name)
                    if os.access(dir_path, os.W_OK):
                        shutil.rmtree(dir_path)
                except Exception:
                    pass

def main():
    """Función principal de la aplicación"""
    try:
        # Configurar entorno
        setup_environment()
        
        # Configurar manejo de señales
        signal.signal(signal.SIGINT, handle_signal)
        signal.signal(signal.SIGTERM, handle_signal)
        
        # Limpiar archivos de caché antiguos al inicio
        base_dir = os.path.dirname(os.path.abspath(__file__))
        clean_all_pycache(base_dir)
        
        # Verificar dependencias antes de continuar
        from src.utils.dependency_checker import DependencyChecker
        checker = DependencyChecker()
        if not checker.check_all_dependencies():
            print("Error: Faltan dependencias críticas. Abortando...")
            return 1
        
        # Importar y crear la aplicación GTK
        from src.gui.app import create_application
        app = create_application()
        
        # Ejecutar la aplicación
        return app.run(sys.argv)
        
    except KeyboardInterrupt:
        print("\nApplication interrupted by user")
        return 0
    except Exception as e:
        print(f"Critical error: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())
