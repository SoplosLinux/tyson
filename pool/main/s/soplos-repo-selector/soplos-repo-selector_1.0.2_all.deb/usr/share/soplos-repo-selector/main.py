#!/usr/bin/env python3
"""
Punto de entrada principal para Soplos Repo Selector
"""

import sys
import os
import signal
import locale
import shutil

# Configurar el entorno antes de importar GTK
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
os.environ['NO_AT_BRIDGE'] = '1'

# Añadir el directorio raíz al PYTHONPATH
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def setup_environment():
    """Configura el entorno de ejecución"""
    # Deshabilitar warnings de accesibilidad para Wayland
    os.environ['NO_AT_BRIDGE'] = '1'
    
    # Configuraciones específicas para Wayland
    if os.environ.get('WAYLAND_DISPLAY'):
        # Habilitar soporte nativo de Wayland para GTK
        os.environ['GDK_BACKEND'] = 'wayland'
        # Configurar escalado para alta resolución
        if 'GDK_SCALE' not in os.environ:
            os.environ['GDK_SCALE'] = '1'
        if 'GDK_DPI_SCALE' not in os.environ:
            os.environ['GDK_DPI_SCALE'] = '1'
    else:
        # Fallback para X11
        os.environ['GDK_BACKEND'] = 'x11'
    
    # Configurar variables de aplicación
    os.environ['WMCLASS'] = 'com.soplos.reposelector'
    os.environ['GDK_STARTUP_ID'] = os.environ.get('STARTUP_ID', '0')
    
    # Prevenir creación de archivos .pyc
    sys.dont_write_bytecode = True
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    
    # Configurar encoding
    os.environ['PYTHONIOENCODING'] = 'utf-8'

def setup_gtk_theme():
    """Configura el tema GTK según el entorno"""
    import gi
    gi.require_version('Gtk', '3.0')
    from gi.repository import Gtk, Gio
    
    # Detectar tema oscuro en diferentes entornos de escritorio
    dark_theme = False
    
    # Plasma 6 / KDE
    if os.environ.get('KDE_SESSION_VERSION') == '6' or os.environ.get('DESKTOP_SESSION') == 'plasma':
        try:
            # Comprobar configuración de Plasma via kreadconfig6
            import subprocess
            result = subprocess.run(['kreadconfig6', '--group', 'Colors:Window', '--key', 'BackgroundNormal'], 
                                  capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                color = result.stdout.strip()
                # Si el color de fondo es oscuro (valores RGB bajos)
                if color and ',' in color:
                    rgb_values = [int(x) for x in color.split(',')[:3]]
                    avg_brightness = sum(rgb_values) / 3
                    dark_theme = avg_brightness < 128
        except:
            # Fallback: comprobar via gsettings si está disponible
            try:
                result = subprocess.run(['gsettings', 'get', 'org.gnome.desktop.interface', 'gtk-theme'], 
                                      capture_output=True, text=True, timeout=5)
                if result.returncode == 0:
                    theme_name = result.stdout.strip().strip("'\"").lower()
                    dark_theme = 'dark' in theme_name or 'breeze-dark' in theme_name
            except:
                pass
    
    # GNOME / otras configuraciones GTK
    else:
        try:
            settings = Gio.Settings.new("org.gnome.desktop.interface")
            theme_name = settings.get_string("gtk-theme").lower()
            dark_theme = 'dark' in theme_name
        except:
            pass
    
    # Aplicar tema oscuro si se detecta
    if dark_theme:
        settings = Gtk.Settings.get_default()
        if settings:
            settings.set_property("gtk-application-prefer-dark-theme", True)
            settings.set_property("gtk-theme-name", "Adwaita-dark")

def handle_signal(signum, frame):
    """Maneja señales del sistema"""
    from src.utils.error_handler import log_info
    log_info(f"Signal received: {signum}, closing application")
    
    try:
        # Intentar cerrar la aplicación GTK limpiamente
        import gi
        gi.require_version('Gtk', '3.0')
        from gi.repository import Gtk
        if Gtk.main_level() > 0:
            Gtk.main_quit()
    except:
        pass
    
    sys.exit(0)

def clean_all_pycache(base_dir):
    """Limpia todos los archivos __pycache__ del directorio base"""
    for root, dirs, files in os.walk(base_dir, topdown=False):
        # Eliminar directorios __pycache__
        for dir_name in dirs:
            if dir_name == '__pycache__':
                try:
                    dir_path = os.path.join(root, dir_name)
                    if os.access(dir_path, os.W_OK):
                        shutil.rmtree(dir_path)
                except Exception:
                    pass

def main():
    """Función principal de la aplicación"""
    try:
        # Configurar entorno
        setup_environment()
        
        # Configurar manejo de señales
        signal.signal(signal.SIGINT, handle_signal)
        signal.signal(signal.SIGTERM, handle_signal)
        
        # Limpiar archivos de caché antiguos al inicio
        base_dir = os.path.dirname(os.path.abspath(__file__))
        clean_all_pycache(base_dir)
        
        # Configurar tema GTK antes de crear widgets
        setup_gtk_theme()
        
        # Verificar dependencias antes de continuar
        from src.utils.dependency_checker import DependencyChecker
        checker = DependencyChecker()
        if not checker.check_all_dependencies():
            print("Error: Faltan dependencias críticas. Abortando...")
            return 1
        
        # Importar y crear la aplicación GTK
        from src.gui.app import create_application
        app = create_application()
        
        # Ejecutar la aplicación
        return app.run(sys.argv)
        
    except KeyboardInterrupt:
        print("\nApplication interrupted by user")
        return 0
    except Exception as e:
        print(f"Critical error: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())
