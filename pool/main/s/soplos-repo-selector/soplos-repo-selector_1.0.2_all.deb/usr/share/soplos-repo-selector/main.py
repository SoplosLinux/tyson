#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Punto de entrada principal para Soplos Repo Selector
"""

import os
import sys
import signal
import shutil
import locale
import warnings

# Deshabilitar bus de accesibilidad ANTES de importar cualquier cosa
os.environ['NO_AT_BRIDGE'] = '1'
os.environ['AT_SPI_BUS'] = '0'

# Suprimir advertencias de accesibilidad
warnings.filterwarnings('ignore', '.*Couldn\'t connect to accessibility bus.*', Warning)
warnings.filterwarnings('ignore', '.*Failed to connect to socket.*', Warning)

# Añadir el directorio raíz al PYTHONPATH
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.append(BASE_DIR)

def configure_environment():
    """Configura el entorno para funcionar correctamente en X11 y Wayland"""
    # Configurar variables básicas de aplicación
    os.environ['WMCLASS'] = 'com.soplos.reposelector'
    os.environ['GDK_STARTUP_ID'] = os.environ.get('STARTUP_ID', '0')
    
    # Prevenir creación de archivos .pyc
    sys.dont_write_bytecode = True
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    
    # Configurar encoding
    os.environ['PYTHONIOENCODING'] = 'utf-8'
    
    # Detectar entorno (NO forzar backend específico)
    wayland_session = os.environ.get('XDG_SESSION_TYPE') == 'wayland'
    kde_desktop = os.environ.get('XDG_CURRENT_DESKTOP', '').lower().find('kde') >= 0
    
    if wayland_session and kde_desktop:
        # Solo para KDE Plasma con Wayland, usar portal para mejor integración
        os.environ['GTK_USE_PORTAL'] = '1'
        print("Entorno detectado: KDE Plasma con Wayland")
    elif wayland_session:
        print("Entorno detectado: Wayland")
    else:
        print("Entorno detectado: X11")

def setup_gtk_theme():
    """Configura el tema GTK según el entorno"""
    import gi
    gi.require_version('Gtk', '3.0')
    from gi.repository import Gtk
    
    # Detectar tema oscuro en diferentes entornos de escritorio
    dark_theme = False
    
    # Plasma 6 / KDE
    if os.environ.get('KDE_SESSION_VERSION') == '6' or os.environ.get('DESKTOP_SESSION') == 'plasma':
        try:
            import subprocess
            # Comprobar configuración de Plasma via kreadconfig6
            result = subprocess.run(['kreadconfig6', '--group', 'Colors:Window', '--key', 'BackgroundNormal'], 
                                  capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                color = result.stdout.strip()
                if color and ',' in color:
                    rgb_values = [int(x) for x in color.split(',')[:3]]
                    avg_brightness = sum(rgb_values) / 3
                    dark_theme = avg_brightness < 128
        except:
            pass
    
    # Aplicar tema oscuro si se detecta
    if dark_theme:
        settings = Gtk.Settings.get_default()
        if settings:
            settings.set_property("gtk-application-prefer-dark-theme", True)

def handle_signal(signum, frame):
    """Maneja señales del sistema"""
    print(f"Signal received: {signum}, closing application")
    
    try:
        import gi
        gi.require_version('Gtk', '3.0')
        from gi.repository import Gtk
        if Gtk.main_level() > 0:
            Gtk.main_quit()
    except:
        pass
    
    sys.exit(0)

def clean_all_pycache(base_dir):
    """Limpia todos los archivos __pycache__ del directorio base"""
    for root, dirs, files in os.walk(base_dir, topdown=False):
        for dir_name in dirs:
            if dir_name == '__pycache__':
                try:
                    dir_path = os.path.join(root, dir_name)
                    if os.access(dir_path, os.W_OK):
                        shutil.rmtree(dir_path)
                except Exception:
                    pass

def main():
    """Función principal de la aplicación"""
    try:
        # Configurar entorno ANTES de importar GTK
        configure_environment()
        
        # Configurar manejo de señales
        signal.signal(signal.SIGINT, handle_signal)
        signal.signal(signal.SIGTERM, handle_signal)
        
        # Limpiar archivos de caché antiguos al inicio
        clean_all_pycache(BASE_DIR)
        
        # Configurar tema GTK antes de crear widgets
        setup_gtk_theme()
        
        # Verificar dependencias antes de continuar
        try:
            from src.utils.dependency_checker import DependencyChecker
            checker = DependencyChecker()
            if not checker.check_all_dependencies():
                print("Error: Faltan dependencias críticas. Abortando...")
                return 1
        except ImportError:
            print("Warning: No se pudo importar dependency_checker, continuando...")
        
        # Importar y crear la aplicación GTK DESPUÉS de configurar el entorno
        from src.gui.app import create_application
        app = create_application()
        
        if app is None:
            print("Error: No se pudo crear la aplicación")
            return 1
        
        print("Iniciando aplicación...")
        
        # Ejecutar la aplicación
        return app.run(sys.argv)
        
    except KeyboardInterrupt:
        print("\nAplicación interrumpida por el usuario")
        return 0
    except Exception as e:
        print(f"Error crítico: {e}")
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())
