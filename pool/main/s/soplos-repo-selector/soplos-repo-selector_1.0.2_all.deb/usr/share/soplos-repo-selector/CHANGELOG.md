# Changelog

Todos los cambios notables de este proyecto serán documentados en este archivo.

El formato está basado en [Keep a Changelog](https://keepachangelog.com/es/1.0.0/),
y este proyecto adhiere al [Semantic Versioning](https://semver.org/lang/es/).

## [1.0.0] - 2025-05-08

### Añadido
- Interfaz gráfica completa desarrollada con GTK3
- Gestión segura de repositorios con autenticación PolicyKit
- **Diálogo avanzado de búsqueda de repositorios más rápidos**
- **Pruebas reales de velocidad de descarga (no solo ping)**
- **Filtrado geográfico de mirrors por país/región**
- **Plantillas de configuración predefinidas:**
  - Debian Stable (completo)
  - Debian Testing/Trixie (completo)
  - Debian Sid/Unstable (completo)
  - Soplos Linux Tyron (híbrido)
- **Selección múltiple de distribuciones y componentes**
- **Categorización automática de repositorios (rápido/medio/lento)**
- **Validación automática de conectividad de repositorios**
- Gestión completa de claves GPG con importación y descarga
- Funcionalidad para habilitar/deshabilitar repositorios de APT
- Actualización automática de caché de paquetes tras cambios
- Sistema de logging y manejo de errores robusto
- **Soporte completo para internacionalización (8 idiomas):**
  - Español, Inglés, Francés, Portugués
  - Alemán, Italiano, Ruso, Rumano
- Interfaz responsiva que se adapta al tamaño de ventana
- Validación de permisos y estado del sistema
- Empaquetado completo para distribuciones Debian/Ubuntu
- Archivo .desktop para integración con el menú de aplicaciones
- Documentación completa y metadatos del proyecto
- Sistema de limpieza automática de archivos de caché Python
- Manejo elegante de señales del sistema (SIGINT, SIGTERM)
- Configuración automática del entorno de ejecución

### Características del Test de Velocidad
- **Descarga real de archivos InRelease para medición precisa**
- **Timeout configurado para evitar bloqueos**
- **Clasificación visual con emojis (✅ Excelente, ✓ Bueno, ⚠️ Aceptable, 🐢 Lento)**
- **Ordenamiento automático por velocidad al finalizar**
- **Soporte para configuraciones híbridas como Soplos Linux Tyron**
- **Detección automática de URLs de seguridad especializadas**

### Características de Internacionalización
- **Sistema de strings centralizado y extensible**
- **Traducciones completas para todas las funcionalidades**
- **Soporte para formatos de fecha y número localizados**
- **Fallbacks automáticos al idioma por defecto**

[1.0.0]: https://github.com/SoplosLinux/tyron/releases/tag/soplos-repo-selector-v1.0.0
