# Soplos Repository Selector

[![License: GPL-3.0+](https://img.shields.io/badge/License-GPL--3.0%2B-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![Version](https://img.shields.io/badge/version-1.0.0-green.svg)]()

Una herramienta gráfica para gestionar repositorios de software en sistemas Debian/Ubuntu con funciones avanzadas para encontrar los servidores más rápidos.

*A graphical tool to manage software repositories in Debian/Ubuntu systems with advanced features to find the fastest servers.*

## 📝 Descripción

Soplos Repository Selector es un gestor gráfico intuitivo para repositorios de software que permite habilitar, deshabilitar y gestionar fuentes de software de manera segura en sistemas basados en Debian y Ubuntu, con funciones especiales para encontrar los mirrors más rápidos y gestionar claves GPG.

## ✨ Características

- Gestión segura de repositorios con autenticación PolicyKit
- Búsqueda automática de los repositorios más rápidos
- Gestión completa de claves GPG
- Habilitar y deshabilitar repositorios de APT
- Actualización automática de caché de paquetes
- Soporte para múltiples idiomas
- Interfaz gráfica moderna desarrollada con GTK3
- Integración completa con el sistema
- Compatible con XFCE

## 📸 Capturas de pantalla

### Ventana principal del Selector de Repositorios Soplos
![Ventana principal](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-repo-selector/screenshots/screenshot1.png)

### Búsqueda de repositorios más rápidos
![Búsqueda de repositorios más rápidos](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-repo-selector/screenshots/screenshot2.png)

### Gestión de claves GPG
![Gestión de claves GPG](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-repo-selector/screenshots/screenshot3.png)

### Añadir y editar repositorios
![Añadir y editar repositorios](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-repo-selector/screenshots/screenshot4.png)

## 🔧 Instalación

### Desde paquete DEB (recomendado)
```bash
sudo dpkg -i soplos-repo-selector_1.0.0_all.deb
sudo apt-get install -f  # Si hay dependencias faltantes
```

### Dependencias
```bash
sudo apt install python3 python3-gi python3-gi-cairo gir1.2-gtk-3.0 python3-requests policykit-1 apt gnupg curl
```

## 🚀 Uso

### Desde el menú de aplicaciones
Busca "Soplos Repository Selector" en el menú de aplicaciones.

### Desde línea de comandos
```bash
soplos-repo-selector
```

## 🌐 Idiomas soportados

- Español
- Inglés
- Francés
- Portugués
- Alemán
- Italiano
- Ruso
- Rumano

## 📄 Licencia

Este proyecto está licenciado bajo [GPL-3.0+](https://www.gnu.org/licenses/gpl-3.0.html) (GNU General Public License versión 3 o posterior).

Esta licencia garantiza las siguientes libertades:
- La libertad de usar el programa para cualquier propósito
- La libertad de estudiar cómo funciona el programa y modificarlo
- La libertad de distribuir copias del programa
- La libertad de mejorar el programa y publicar esas mejoras

Cualquier trabajo derivado debe distribuirse bajo la misma licencia (GPL-3.0+).

Para más detalles, consulte el archivo LICENSE o visite [gnu.org/licenses/gpl-3.0](https://www.gnu.org/licenses/gpl-3.0.html).

## 👥 Desarrolladores

Desarrollado por [Equipo de Soplos](https://soploslinux.com)

## 🔗 Enlaces

- [Página web](https://soploslinux.com)
- [Reportar problemas](https://github.com/SoplosLinux/tyron/issues)
- [Ayuda](https://soploslinux.com)

## 📦 Versiones

### v1.0.0 (08/05/2025)
- Versión inicial de lanzamiento
- Interfaz gráfica completa con GTK3
- Gestión segura de repositorios
- Búsqueda de repositorios más rápidos
- Gestión completa de claves GPG
- Soporte para internacionalización
