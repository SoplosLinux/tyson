"""
Módulo para gestión de traducciones
"""
import os
import sys
import locale as stdlib_locale
import importlib
from typing import Dict

# Diccionario de idiomas soportados
_LANGUAGES = {
    "es": "Español",
    "en": "English",
    "fr": "Français",
    "pt": "Português",
    "de": "Deutsch",
    "it": "Italiano",
    "ru": "Русский",
    "ro": "Română"
}

# El idioma actual (se establece en set_language)
_current_lang = "es"  # Usar español por defecto

# El diccionario de strings del idioma actual
_current_strings = {}

# Variables de control y depuración
_debug_mode = True
_translation_override = None

def enable_debug(enable=True):
    """Activa o desactiva el modo de depuración"""
    global _debug_mode
    _debug_mode = enable

def get_string(key: str, default: str = None) -> str:
    """Obtiene una cadena traducida"""
    global _current_strings
    
    if _debug_mode and key not in _current_strings:
        print(f"DEBUG: Cadena faltante '{key}' en idioma '{_current_lang}'")
    
    return _current_strings.get(key, default or key)

def get_available_languages() -> Dict[str, str]:
    """Retorna idiomas disponibles"""
    return _LANGUAGES.copy()

def get_current_language() -> str:
    """Retorna el idioma actual"""
    return _current_lang

def detect_system_language() -> str:
    """Detecta el idioma del sistema"""
    try:
        # Intentar obtener el locale del sistema
        system_locale = stdlib_locale.getdefaultlocale()[0]
        if system_locale:
            lang_code = system_locale.split('_')[0].lower()
            if lang_code in _LANGUAGES:
                return lang_code
    except:
        pass
    
    # Intentar variables de entorno
    for env_var in ['LANGUAGE', 'LANG', 'LC_ALL']:
        env_value = os.environ.get(env_var, '')
        if env_value:
            lang_code = env_value.split('_')[0].split('.')[0].lower()
            if lang_code in _LANGUAGES:
                return lang_code
    
    # Por defecto español
    return "es"

def check_language_override():
    """Verifica argumentos de línea de comando para forzar idioma"""
    global _translation_override
    
    for i, arg in enumerate(sys.argv):
        if arg == '--lang' and i + 1 < len(sys.argv):
            lang = sys.argv[i + 1]
            if lang in _LANGUAGES:
                _translation_override = lang
                break

def set_language(lang_code: str) -> bool:
    """Establece el idioma activo y carga las traducciones"""
    global _current_lang, _current_strings
    
    if lang_code not in _LANGUAGES:
        return False
    
    _current_lang = lang_code
    
    try:
        if lang_code == "es":
            module = importlib.import_module('src.i18n.translations.es')
            _current_strings = module.SPANISH
        elif lang_code == "en":
            module = importlib.import_module('src.i18n.translations.en')
            _current_strings = module.ENGLISH
        elif lang_code == "fr":
            module = importlib.import_module('src.i18n.translations.fr')
            _current_strings = module.FRENCH
        elif lang_code == "pt":
            module = importlib.import_module('src.i18n.translations.pt')
            _current_strings = module.PORTUGUESE
        elif lang_code == "de":
            module = importlib.import_module('src.i18n.translations.de')
            _current_strings = module.GERMAN
        elif lang_code == "it":
            module = importlib.import_module('src.i18n.translations.it')
            _current_strings = module.ITALIAN
        elif lang_code == "ru":
            module = importlib.import_module('src.i18n.translations.ru')
            _current_strings = module.RUSSIAN
        elif lang_code == "ro":
            module = importlib.import_module('src.i18n.translations.ro')
            _current_strings = module.ROMANIAN
        
        return True
    except ImportError as e:
        print(f"Error cargando traducciones para {lang_code}: {e}")
        return False

def check_missing_translation_keys():
    """Verifica claves de traducción faltantes"""
    if _debug_mode:
        try:
            from src.i18n.translations.es import SPANISH
            missing = []
            for key in SPANISH.keys():
                if key not in _current_strings:
                    missing.append(key)
            if missing:
                print(f"Claves faltantes en {_current_lang}: {missing}")
        except ImportError:
            pass

# Revisar argumentos de línea de comando
check_language_override()

# Inicializar con el idioma detectado (o español por defecto)
if _translation_override:
    set_language(_translation_override)
else:
    set_language(detect_system_language())
