"""
Módulo para gestión de traducciones
"""
import sys
import os
import locale as stdlib_locale
from typing import Dict

# Diccionario de idiomas soportados
_LANGUAGES = {
    "es": "Español",
    "en": "English",
    "fr": "Français",
    "pt": "Português",
    "de": "Deutsch",
    "it": "Italiano",
    "ru": "Русский",
    "ro": "Română"
}

# El idioma actual (se establece en set_language)
_current_lang = "es"  # Usar español por defecto

# El diccionario de strings del idioma actual
_current_strings = {}

# Variables de control y depuración
_debug_mode = True
_translation_override = None

def enable_debug(enable=True):
    """Activa o desactiva el modo de depuración"""
    global _debug_mode
    _debug_mode = enable

def get_string(key: str, default: str = None) -> str:
    """Obtiene una cadena traducida"""
    global _current_strings
    
    if _debug_mode and key not in _current_strings:
        print(f"Missing translation key: {key}")
    
    return _current_strings.get(key, default or key)

def get_available_languages() -> Dict[str, str]:
    """Retorna idiomas disponibles"""
    return _LANGUAGES.copy()

def get_current_language() -> str:
    """Retorna el idioma actual"""
    return _current_lang

def detect_system_language() -> str:
    """Detecta el idioma del sistema"""
    try:
        # Obtener locale del sistema
        lang, encoding = stdlib_locale.getdefaultlocale()
        if lang:
            # Extraer código de idioma (los primeros 2 caracteres)
            lang_code = lang[:2].lower()
            if lang_code in _LANGUAGES:
                return lang_code
    except:
        pass
    
    # Intentar variables de entorno
    for env_var in ['LANGUAGE', 'LANG', 'LC_ALL']:
        env_value = os.environ.get(env_var, '').lower()
        if env_value:
            lang_code = env_value[:2]
            if lang_code in _LANGUAGES:
                return lang_code
    
    # Por defecto español
    return "es"

def check_language_override():
    """Verifica argumentos de línea de comando para forzar idioma"""
    global _translation_override
    
    for i, arg in enumerate(sys.argv):
        if arg == '--lang' and i + 1 < len(sys.argv):
            _translation_override = sys.argv[i + 1]
            break

def set_language(lang_code: str) -> bool:
    """Establece el idioma activo y carga las traducciones"""
    global _current_lang, _current_strings
    
    if lang_code not in _LANGUAGES:
        return False
    
    _current_lang = lang_code
    
    # Cargar las traducciones del idioma
    try:
        if lang_code == "es":
            from src.i18n.translations.es import SPANISH
            _current_strings = SPANISH
        elif lang_code == "en":
            from src.i18n.translations.en import ENGLISH
            _current_strings = ENGLISH
        elif lang_code == "fr":
            from src.i18n.translations.fr import FRENCH
            _current_strings = FRENCH
        elif lang_code == "de":
            from src.i18n.translations.de import GERMAN
            _current_strings = GERMAN
        elif lang_code == "it":
            from src.i18n.translations.it import ITALIAN
            _current_strings = ITALIAN
        elif lang_code == "pt":
            from src.i18n.translations.pt import PORTUGUESE
            _current_strings = PORTUGUESE
        elif lang_code == "ru":
            from src.i18n.translations.ru import RUSSIAN
            _current_strings = RUSSIAN
        elif lang_code == "ro":
            from src.i18n.translations.ro import ROMANIAN
            _current_strings = ROMANIAN
        else:
            # Fallback a español
            from src.i18n.translations.es import SPANISH
            _current_strings = SPANISH
            
        return True
    except ImportError as e:
        print(f"Error loading language {lang_code}: {e}")
        # Fallback a español
        try:
            from src.i18n.translations.es import SPANISH
            _current_strings = SPANISH
            return True
        except:
            return False

def check_missing_translation_keys():
    """Verifica si faltan claves de traducción"""
    # Esta función se puede usar para debug
    pass

# Revisar argumentos de línea de comando
check_language_override()

# Inicializar con el idioma detectado (o español por defecto)
if _translation_override:
    set_language(_translation_override)
else:
    detected_lang = detect_system_language()
    set_language(detected_lang)
