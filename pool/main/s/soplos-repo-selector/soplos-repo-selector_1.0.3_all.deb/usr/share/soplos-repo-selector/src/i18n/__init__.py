"""
Módulo de internacionalización
"""

from src.i18n.strings import set_language, get_string, get_available_languages, get_current_language
