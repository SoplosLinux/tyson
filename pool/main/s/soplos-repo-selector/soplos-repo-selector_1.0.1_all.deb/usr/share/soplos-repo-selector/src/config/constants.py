"""
Constantes globales para Soplos Repo Selector
"""

# Identificación de la aplicación
APP_ID = "com.soplos.reposelector"
APP_NAME = "Soplos Repo Selector"
APP_VERSION = "1.0.0"

# Rutas de sistema
KEYRINGS_DIR = '/usr/share/keyrings'
ETC_KEYRINGS_DIR = '/etc/apt/keyrings'
SOURCES_DIR = '/etc/apt/sources.list.d'
MAIN_SOURCES = '/etc/apt/sources.list'

# Ajustes de UI
DEFAULT_WINDOW_WIDTH = 800
DEFAULT_WINDOW_HEIGHT = 600
DEFAULT_MARGIN = 10
SPACING_NORMAL = 6
SPACING_LARGE = 10

# Mapeos para repositorios
COMMON_REPO_KEYS = {
    "packages.microsoft.com": ["/usr/share/keyrings/packages.microsoft.gpg", "/usr/share/keyrings/microsoft.gpg"],
    "dl.google.com": ["/usr/share/keyrings/google-chrome.gpg"],
    "deb.debian.org": ["/usr/share/keyrings/debian-archive-keyring.gpg"],
    "security.debian.org": ["/usr/share/keyrings/debian-archive-keyring.gpg"],
    "liquorix.net": ["/etc/apt/keyrings/liquorix-keyring.gpg"],
    "download.docker.com": ["/usr/share/keyrings/docker-archive-keyring.gpg"],
    "packages.mozilla.org": ["/usr/share/keyrings/mozilla.gpg"],
    "ppa.launchpad.net": ["/etc/apt/keyrings/ppa-obsproject.gpg"]
}

# Repositorios predefinidos
PREDEFINED_REPOS = {
    "chrome": {
        "name": "Google Chrome",
        "active": True,
        "type": "deb",
        "uri": "http://dl.google.com/linux/chrome/deb/",
        "distribution": "stable",
        "components": "main",
        "comment": "# Google Chrome Repository"
    },
    "vscode": {
        "name": "Visual Studio Code",
        "active": True,
        "type": "deb",
        "uri": "https://packages.microsoft.com/repos/code",
        "distribution": "stable",
        "components": "main",
        "comment": "# Visual Studio Code Repository"
    },
    "docker": {
        "name": "Docker",
        "active": True,
        "type": "deb",
        "uri": "https://download.docker.com/linux/debian",
        "distribution": "$(lsb_release -cs)",
        "components": "stable",
        "comment": "# Docker Repository"
    },
    "obs": {
        "name": "OBS Studio",
        "active": True,
        "type": "deb",
        "uri": "http://ppa.launchpad.net/obsproject/obs-studio/ubuntu",
        "distribution": "$(lsb_release -cs)",
        "components": "main",
        "comment": "# OBS Studio Repository"
    }
}
