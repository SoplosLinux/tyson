import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, GObject
import os
import subprocess
from pathlib import Path
from src.i18n.strings import get_string

class GPGKeyListWidget(Gtk.Box):
    """Widget para mostrar y gestionar claves GPG"""
    
    __gsignals__ = {
        'key-selected': (GObject.SignalFlags.RUN_FIRST, None, (str,)),
        'key-imported': (GObject.SignalFlags.RUN_FIRST, None, (bool, str)),
    }

    def __init__(self):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=8)

        # Barra de búsqueda
        self.search_entry = Gtk.SearchEntry()
        self.search_entry.set_placeholder_text(get_string("search_key", "Buscar clave..."))
        self.search_entry.connect("search-changed", self.on_search_changed)
        self.pack_start(self.search_entry, False, False, 0)

        # Modelo: Nombre, Ruta, Formato, Descripción, En uso por
        self.keys_store = Gtk.ListStore(str, str, str, str, str)

        # Lista de claves GPG
        scrolled_window = Gtk.ScrolledWindow()
        scrolled_window.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scrolled_window.set_shadow_type(Gtk.ShadowType.ETCHED_IN)
        self.pack_start(scrolled_window, True, True, 0)

        # Vista de árbol para claves
        self.keys_view = Gtk.TreeView(model=self.keys_store)
        # Columnas
        self._add_text_column(get_string("name", "Nombre"), 0)
        self._add_text_column(get_string("path", "Ruta"), 1)
        self._add_text_column(get_string("format", "Formato"), 2)
        self._add_text_column(get_string("description", "Descripción"), 3)
        self._add_text_column(get_string("in_use_by", "En uso por"), 4)
        self.keys_view.set_headers_clickable(True)
        scrolled_window.add(self.keys_view)

        # Selección
        self.selection = self.keys_view.get_selection()
        self.selection.set_mode(Gtk.SelectionMode.SINGLE)
        self.selection.connect("changed", self.on_key_selection_changed)

        # Panel de botones - CORREGIDO: Volver a botones simples con iconos
        key_buttons = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        self.pack_start(key_buttons, False, False, 0)

        self.import_button = Gtk.Button.new_from_icon_name("document-open", Gtk.IconSize.BUTTON)
        self.import_button.set_tooltip_text(get_string("import_key_tooltip", "Importar clave GPG"))
        self.import_button.connect("clicked", self.on_import_key_clicked)
        key_buttons.pack_start(self.import_button, False, False, 0)

        self.download_button = Gtk.Button.new_from_icon_name("network-server", Gtk.IconSize.BUTTON)
        self.download_button.set_tooltip_text(get_string("download_key_tooltip", "Descargar clave GPG"))
        self.download_button.connect("clicked", self.on_download_key_clicked)
        key_buttons.pack_start(self.download_button, False, False, 0)

        self.view_button = Gtk.Button.new_from_icon_name("document-properties", Gtk.IconSize.BUTTON)
        self.view_button.set_tooltip_text(get_string("view_key_tooltip", "Ver detalles de clave"))
        self.view_button.connect("clicked", self.on_view_key_clicked)
        self.view_button.set_sensitive(False)
        key_buttons.pack_start(self.view_button, False, False, 0)

        self.delete_button = Gtk.Button.new_from_icon_name("edit-delete", Gtk.IconSize.BUTTON)
        self.delete_button.set_tooltip_text(get_string("delete_key", "Eliminar clave"))
        self.delete_button.connect("clicked", self.on_delete_key_clicked)
        self.delete_button.set_sensitive(False)
        key_buttons.pack_start(self.delete_button, False, False, 0)

        key_buttons.pack_start(Gtk.Box(), True, True, 0)

        # Panel de detalles
        self.details_label = Gtk.Label()
        self.details_label.set_xalign(0)
        self.details_label.set_selectable(True)
        self.details_label.set_margin_top(4)
        self.pack_start(self.details_label, False, False, 0)

        # Directorios estándar
        self.keyrings_dir = '/usr/share/keyrings'
        self.etc_keyrings_dir = '/etc/apt/keyrings'

        # Cargar claves
        self.refresh_keys()

    def _add_text_column(self, title, index):
        renderer = Gtk.CellRendererText()
        renderer.set_property("ellipsize", True)
        renderer.set_property("xpad", 8)
        column = Gtk.TreeViewColumn(title, renderer, text=index)
        column.set_resizable(True)
        column.set_expand(True)
        column.set_sort_column_id(index)
        self.keys_view.append_column(column)
        return column

    def clear(self):
        self.keys_store.clear()

    def refresh_keys(self, filter_text=""):
        self.clear()
        key_dirs = [self.keyrings_dir, self.etc_keyrings_dir]
        # Obtener repos para saber en qué repos se usa cada clave
        try:
            from src.repo.manager import RepoManager
            repo_manager = RepoManager()
            repos = repo_manager.get_all_repos(use_cache=False)
        except Exception:
            repos = []
        for dir_path in key_dirs:
            if os.path.exists(dir_path):
                for file in sorted(os.listdir(dir_path)):
                    if file.endswith(('.gpg', '.asc', '.pgp')):
                        key_path = os.path.join(dir_path, file)
                        if filter_text and filter_text not in file.lower() and filter_text not in key_path.lower():
                            continue
                        format_type = get_string("ascii_gpg", "ASCII") if file.endswith('.asc') else get_string("binary_gpg", "Binario GPG")
                        description = self._get_key_description(key_path)
                        # Buscar en qué repos se usa esta clave
                        in_use_by = ", ".join(
                            r['uri'] for r in repos if key_path in (r.get('signed_by') or "")
                        ) if repos else ""
                        self.keys_store.append([file, key_path, format_type, description, in_use_by])

    def on_search_changed(self, entry):
        text = entry.get_text().strip().lower()
        self.refresh_keys(filter_text=text)

    def get_selected_key(self):
        model, iter = self.selection.get_selected()
        if iter:
            return {
                'name': model[iter][0],
                'path': model[iter][1],
                'format': model[iter][2],
                'description': model[iter][3],
                'in_use_by': model[iter][4]
            }
        return None

    def on_key_selection_changed(self, selection):
        model, iter = selection.get_selected()
        has_selection = iter is not None
        self.view_button.set_sensitive(has_selection)
        self.delete_button.set_sensitive(has_selection)
        if has_selection:
            key_path = model[iter][1]
            details = self.get_key_details(key_path)
            self.details_label.set_text(details)
            self.emit('key-selected', key_path)
        else:
            self.details_label.set_text("")

    def get_key_details(self, key_path):
        try:
            out = subprocess.check_output(
                ["gpg", "--show-keys", "--with-fingerprint", "--with-colons", key_path],
                universal_newlines=True, stderr=subprocess.DEVNULL
            )
            lines = out.splitlines()
            uids = [l.split(':')[9] for l in lines if l.startswith('uid:')]
            fpr = next((l.split(':')[9] for l in lines if l.startswith('fpr:')), "")
            exp = next((l.split(':')[6] for l in lines if l.startswith('pub:')), "")
            details = f"{get_string('fingerprint', 'Fingerprint')}: {fpr}\n"
            if uids:
                details += f"{get_string('uid', 'UID')}: {uids[0]}\n"
            if exp:
                details += f"{get_string('expires', 'Expira')}: {exp}\n"
            return details
        except Exception:
            return get_string("key_details_error", "No se pudieron obtener detalles de la clave.")

    def _get_key_description(self, key_path):
        try:
            result = subprocess.run(
                ["gpg", "--show-keys", "--with-colons", key_path],
                capture_output=True, 
                text=True,
                timeout=2
            )
            if result.returncode == 0:
                for line in result.stdout.splitlines():
                    parts = line.split(':')
                    if len(parts) > 9:
                        if parts[0] == "uid":
                            return parts[9]
                        elif parts[0] == "pub" and len(parts) > 1:
                            return f"{get_string('id', 'ID')}: {parts[4]}"
            return get_string("gpg_key", "Clave GPG")
        except:
            return get_string("gpg_key", "Clave GPG")

    def on_import_key_clicked(self, button):
        parent = self.get_toplevel()
        dialog = Gtk.FileChooserDialog(
            title=get_string("select_gpg_key", "Seleccionar clave GPG"), 
            parent=parent,
            action=Gtk.FileChooserAction.OPEN
        )
        dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OPEN, Gtk.ResponseType.OK
        )
        gpg_filter = Gtk.FileFilter()
        gpg_filter.set_name(get_string("gpg_key_files", "Archivos de clave GPG"))
        gpg_filter.add_pattern("*.gpg")
        gpg_filter.add_pattern("*.asc")
        gpg_filter.add_pattern("*.pgp")
        dialog.add_filter(gpg_filter)
        all_filter = Gtk.FileFilter()
        all_filter.set_name(get_string("all_files", "Todos los archivos"))
        all_filter.add_pattern("*")
        dialog.add_filter(all_filter)
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            key_path = dialog.get_filename()
            dialog.destroy()
            key_name = os.path.basename(key_path)
            # Prevenir duplicados por fingerprint
            if self._is_duplicate_key(key_path):
                self._show_error(get_string("duplicate_key", "Ya existe una clave con este fingerprint."))
                return
            name_dialog = Gtk.Dialog(
                title=get_string("key_name_dialog", "Nombre de la clave"), 
                parent=parent,
                flags=0
            )
            name_dialog.add_buttons(
                Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
                Gtk.STOCK_OK, Gtk.ResponseType.OK
            )
            name_dialog.set_default_size(350, -1)
            content_area = name_dialog.get_content_area()
            content_area.set_margin_top(10)
            content_area.set_margin_bottom(10)
            content_area.set_margin_start(10)
            content_area.set_margin_end(10)
            content_area.set_spacing(6)
            label = Gtk.Label(label=get_string("key_name_label", "Nombre para la clave importada:"))
            content_area.pack_start(label, False, False, 0)
            entry = Gtk.Entry()
            entry.set_text(key_name)
            entry.set_activates_default(True)
            content_area.pack_start(entry, False, False, 0)
            name_dialog.set_default_response(Gtk.ResponseType.OK)
            content_area.show_all()
            name_response = name_dialog.run()
            if name_response == Gtk.ResponseType.OK:
                new_key_name = entry.get_text().strip()
                if not new_key_name.endswith(('.gpg', '.asc', '.pgp')):
                    new_key_name += '.gpg'
                dst_dir = self.etc_keyrings_dir if os.path.exists(self.etc_keyrings_dir) else self.keyrings_dir
                os.makedirs(dst_dir, exist_ok=True)
                dst_path = os.path.join(dst_dir, new_key_name)
                try:
                    result = subprocess.run(
                        ["pkexec", "cp", key_path, dst_path], 
                        check=True,
                        capture_output=True
                    )
                    subprocess.run(
                        ["pkexec", "chmod", "644", dst_path], 
                        check=True
                    )
                    self.refresh_keys()
                    self.emit('key-imported', True, dst_path)
                except subprocess.CalledProcessError as e:
                    self.emit('key-imported', False, str(e))
            name_dialog.destroy()
        else:
            dialog.destroy()

    def on_download_key_clicked(self, button):
        parent = self.get_toplevel()
        dialog = Gtk.Dialog(
            title=get_string("download_gpg_key", "Descargar clave GPG"),
            parent=parent,
            flags=0
        )
        dialog.add_buttons(
            Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL,
            Gtk.STOCK_OK, Gtk.ResponseType.OK
        )
        dialog.set_default_size(400, -1)
        content_area = dialog.get_content_area()
        content_area.set_margin_top(10)
        content_area.set_margin_bottom(10)
        content_area.set_margin_start(10)
        content_area.set_margin_end(10)
        content_area.set_spacing(6)
        label = Gtk.Label(label=get_string("gpg_url_label", "URL de la clave GPG:"))
        content_area.pack_start(label, False, False, 0)
        url_entry = Gtk.Entry()
        url_entry.set_placeholder_text(get_string("gpg_url_placeholder", "https://ejemplo.com/key.gpg"))
        url_entry.set_activates_default(True)
        content_area.pack_start(url_entry, True, True, 0)
        name_label = Gtk.Label(label=get_string("gpg_name_label", "Nombre para guardar la clave:"))
        content_area.pack_start(name_label, False, False, 10)
        name_entry = Gtk.Entry()
        name_entry.set_placeholder_text("nombre-clave.gpg")
        content_area.pack_start(name_entry, True, True, 0)
        dialog.set_default_response(Gtk.ResponseType.OK)
        content_area.show_all()
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            url = url_entry.get_text().strip()
            key_name = name_entry.get_text().strip()
            if not url:
                self._show_error(get_string("invalid_url", "URL inválida"))
                dialog.destroy()
                return
            # Descargar a temporal para comprobar duplicados
            import tempfile
            with tempfile.NamedTemporaryFile(delete=False) as tmpf:
                tmp_path = tmpf.name
            try:
                subprocess.run(["curl", "-fsSL", url, "-o", tmp_path], check=True)
                if self._is_duplicate_key(tmp_path):
                    self._show_error(get_string("duplicate_key", "Ya existe una clave con este fingerprint."))
                    os.unlink(tmp_path)
                    dialog.destroy()
                    return
            except Exception:
                self._show_error(get_string("invalid_url", "URL inválida"))
                os.unlink(tmp_path)
                dialog.destroy()
                return
            # Generar nombre si está vacío
            if not key_name:
                import hashlib
                key_name = hashlib.md5(url.encode()).hexdigest() + '.gpg'
            elif not key_name.endswith(('.gpg', '.asc', '.pgp')):
                key_name += '.gpg'
            dst_dir = self.etc_keyrings_dir if os.path.exists(self.etc_keyrings_dir) else self.keyrings_dir
            os.makedirs(dst_dir, exist_ok=True)
            dst_path = os.path.join(dst_dir, key_name)
            try:
                command = f"gpg --dearmor < {tmp_path} > {dst_path} && chmod 644 {dst_path}"
                subprocess.run(["pkexec", "bash", "-c", command], check=True)
                self.refresh_keys()
                self.emit('key-imported', True, dst_path)
            except Exception as e:
                self.emit('key-imported', False, str(e))
            finally:
                os.unlink(tmp_path)
        dialog.destroy()

    def on_view_key_clicked(self, button):
        key = self.get_selected_key()
        if not key:
            return
        parent = self.get_toplevel()
        dialog = Gtk.Dialog(
            title=get_string("gpg_key_details", "Detalles de {0}").format(key['name']),
            parent=parent,
            flags=0,
            buttons=(Gtk.STOCK_CLOSE, Gtk.ResponseType.CLOSE)
        )
        dialog.set_default_size(500, 400)
        content_area = dialog.get_content_area()
        content_area.set_margin_top(10)
        content_area.set_margin_bottom(10)
        content_area.set_margin_start(10)
        content_area.set_margin_end(10)
        content_area.set_spacing(6)
        info_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        content_area.pack_start(info_box, False, False, 0)
        fields = [
            (get_string("name", "Nombre") + ":", key['name']),
            (get_string("path", "Ruta") + ":", key['path']),
            (get_string("format", "Formato") + ":", key['format']),
            (get_string("in_use_by", "En uso por") + ":", key['in_use_by'])
        ]
        for label_text, value in fields:
            field_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            label = Gtk.Label(label=label_text)
            label.set_halign(Gtk.Align.START)
            label.set_width_chars(10)
            field_box.pack_start(label, False, False, 0)
            value_label = Gtk.Label(label=value)
            value_label.set_halign(Gtk.Align.START)
            value_label.set_selectable(True)
            field_box.pack_start(value_label, True, True, 0)
            info_box.pack_start(field_box, False, False, 0)
        separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        content_area.pack_start(separator, False, False, 10)
        scrolled_win = Gtk.ScrolledWindow()
        scrolled_win.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        content_area.pack_start(scrolled_win, True, True, 0)
        text_view = Gtk.TextView()
        text_view.set_editable(False)
        text_view.set_wrap_mode(Gtk.WrapMode.WORD)
        text_buffer = text_view.get_buffer()
        scrolled_win.add(text_view)
        self._load_key_details(key['path'], text_buffer)
        content_area.show_all()
        dialog.run()
        dialog.destroy()

    def _load_key_details(self, key_path, text_buffer):
        try:
            result = subprocess.run(
                ["gpg", "--show-keys", key_path],
                capture_output=True, 
                text=True
            )
            if result.returncode == 0:
                text_buffer.set_text(result.stdout)
            else:
                result = subprocess.run(
                    ["gpg", "--list-packets", key_path],
                    capture_output=True, 
                    text=True
                )
                if result.returncode == 0:
                    text_buffer.set_text(result.stdout)
                else:
                    text_buffer.set_text(get_string("key_details_error", "No se pudo obtener información detallada de la clave."))
        except Exception as e:
            text_buffer.set_text(f"Error al cargar los detalles de la clave: {str(e)}")

    def on_delete_key_clicked(self, button):
        key = self.get_selected_key()
        if not key:
            return
        key_path = key['path']
        in_use = bool(key['in_use_by'])
        parent = self.get_toplevel()
        msg = get_string("delete_key_confirm", "¿Seguro que desea eliminar la clave?\n") + key_path
        if in_use:
            msg += "\n\n" + get_string("key_in_use_warning", "Advertencia: Esta clave está en uso por algún repositorio.")
        dialog = Gtk.MessageDialog(
            transient_for=parent,
            flags=0,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.OK_CANCEL,
            text=get_string("delete_key", "Eliminar clave")
        )
        dialog.format_secondary_text(msg)
        response = dialog.run()
        dialog.destroy()
        if response == Gtk.ResponseType.OK:
            try:
                os.remove(key_path)
                self.refresh_keys()
            except Exception as e:
                self._show_error(get_string("delete_key_error", "No se pudo eliminar la clave: ") + str(e))

    def _is_duplicate_key(self, key_path):
        """Comprueba si ya existe una clave con el mismo fingerprint"""
        try:
            new_fpr = subprocess.check_output(
                ["gpg", "--with-fingerprint", "--with-colons", "--show-keys", key_path],
                universal_newlines=True, stderr=subprocess.DEVNULL
            )
            new_fpr_val = next((l.split(':')[9] for l in new_fpr.splitlines() if l.startswith('fpr:')), None)
            if not new_fpr_val:
                return False
            # Buscar en los keyrings existentes
            key_dirs = [self.keyrings_dir, self.etc_keyrings_dir]
            for dir_path in key_dirs:
                if os.path.exists(dir_path):
                    for file in os.listdir(dir_path):
                        if file.endswith(('.gpg', '.asc', '.pgp')):
                            path = os.path.join(dir_path, file)
                            try:
                                fpr = subprocess.check_output(
                                    ["gpg", "--with-fingerprint", "--with-colons", "--show-keys", path],
                                    universal_newlines=True, stderr=subprocess.DEVNULL
                                )
                                fpr_val = next((l.split(':')[9] for l in fpr.splitlines() if l.startswith('fpr:')), None)
                                if fpr_val == new_fpr_val:
                                    return True
                            except Exception:
                                continue
            return False
        except Exception:
            return False

    def _show_error(self, message):
        parent = self.get_toplevel()
        dialog = Gtk.MessageDialog(
            transient_for=parent,
            flags=0,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=get_string("error", "Error")
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()

    def update_ui_strings(self, strings):
        # Actualizar placeholder de búsqueda
        self.search_entry.set_placeholder_text(strings.get('search_key', "Buscar clave..."))
        
        self.import_button.set_tooltip_text(strings.get('import_key_tooltip', "Importar clave GPG"))
        self.download_button.set_tooltip_text(strings.get('download_key_tooltip', "Descargar clave GPG"))
        self.view_button.set_tooltip_text(strings.get('view_key_tooltip', "Ver detalles de clave"))
        self.delete_button.set_tooltip_text(strings.get('delete_key', "Eliminar clave"))
        column_titles = ['name', 'path', 'format', 'description', 'in_use_by']
        translated_titles = [
            strings.get('name', "Nombre"),
            strings.get('path', "Ruta"),
            strings.get('format', "Formato"),
            strings.get('description', "Descripción"),
            strings.get('in_use_by', "En uso por")
        ]
        for i, title in enumerate(column_titles):
            if i < len(self.keys_view.get_columns()):
                column = self.keys_view.get_column(i)
                if column:
                    column.set_title(translated_titles[i])
