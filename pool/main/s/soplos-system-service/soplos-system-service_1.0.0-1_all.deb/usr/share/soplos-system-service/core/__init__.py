APP_VERSION = "1.0.0-1"
APP_ID = "org.soplos.systemservice"
