# gettext language dictionaries package
