# Paquete de utilidades generales
