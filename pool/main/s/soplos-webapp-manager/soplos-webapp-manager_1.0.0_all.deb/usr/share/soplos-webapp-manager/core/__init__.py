"""
Core module initialization.
"""
