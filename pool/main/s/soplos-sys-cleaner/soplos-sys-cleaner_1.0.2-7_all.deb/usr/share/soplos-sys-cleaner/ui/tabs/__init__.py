"""UI tabs init."""
