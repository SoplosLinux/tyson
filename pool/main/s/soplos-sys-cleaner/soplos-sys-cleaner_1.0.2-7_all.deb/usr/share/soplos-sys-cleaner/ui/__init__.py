"""UI module init."""
