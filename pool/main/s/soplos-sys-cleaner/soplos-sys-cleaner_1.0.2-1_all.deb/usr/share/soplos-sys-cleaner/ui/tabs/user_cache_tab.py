"""
User Cache tab: ~/.cache breakdown with selective removal.
"""

import os
import threading
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib

from core.i18n_manager import _
from utils.constants import fmt_size as _fmt_size


class UserCacheTab(Gtk.Box):

    def __init__(self, parent_window):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.parent = parent_window
        self._entries = []
        self._checkboxes = {}
        self._build_ui()

    def _build_ui(self):
        toolbar = Gtk.Box(spacing=10)
        toolbar.set_margin_start(12)
        toolbar.set_margin_end(12)
        toolbar.set_margin_top(12)
        toolbar.set_margin_bottom(8)

        self.info_label = Gtk.Label(label="")
        self.info_label.set_halign(Gtk.Align.START)
        toolbar.pack_start(self.info_label, True, True, 0)

        self.select_all_btn = Gtk.CheckButton(label=_("Select all"))
        self.select_all_btn.connect('toggled', self._on_select_all)
        toolbar.pack_end(self.select_all_btn, False, False, 0)
        self.pack_start(toolbar, False, False, 0)

        card = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        card.get_style_context().add_class('summary-card')
        card.set_margin_start(12)
        card.set_margin_end(12)
        card.set_margin_bottom(8)
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        card.pack_start(scroll, True, True, 0)
        self.pack_start(card, True, True, 0)

        self.list_box = Gtk.ListBox()
        self.list_box.set_selection_mode(Gtk.SelectionMode.NONE)
        scroll.add(self.list_box)

        actions = Gtk.Box(spacing=12)
        actions.set_halign(Gtk.Align.CENTER)
        actions.set_margin_top(10)
        actions.set_margin_bottom(12)

        self.remove_btn = Gtk.Button()
        btn_box = Gtk.Box(spacing=6)
        btn_box.pack_start(Gtk.Image.new_from_icon_name('user-trash', Gtk.IconSize.BUTTON), False, False, 0)
        btn_box.pack_start(Gtk.Label(label=_("Remove Selected")), False, False, 0)
        self.remove_btn.add(btn_box)
        self.remove_btn.get_style_context().add_class('destructive-action')
        self.remove_btn.connect('clicked', self._on_remove_clicked)
        self.remove_btn.set_sensitive(False)
        actions.pack_start(self.remove_btn, False, False, 0)
        self.pack_start(actions, False, False, 0)
        self.show_all()

    def populate(self, results: dict):
        self._entries = results.get('user_cache_entries', [])
        self._fill_list()

    def _fill_list(self):
        for row in self.list_box.get_children():
            row.destroy()
        self._checkboxes.clear()

        total = sum(e.size_bytes for e in self._entries)
        self.info_label.set_text(
            _("{} item(s) — {}").format(len(self._entries), _fmt_size(total))
        )

        if not self._entries:
            row = Gtk.ListBoxRow()
            lbl = Gtk.Label(label=_("User cache is empty"))
            lbl.set_margin_top(20)
            lbl.set_margin_bottom(20)
            row.add(lbl)
            self.list_box.add(row)
        else:
            for entry in self._entries:
                row = Gtk.ListBoxRow()
                row_box = Gtk.Box(spacing=12)
                row_box.set_margin_start(12)
                row_box.set_margin_end(12)
                row_box.set_margin_top(6)
                row_box.set_margin_bottom(6)

                check = Gtk.CheckButton()
                check.connect('toggled', self._on_check_toggled)
                self._checkboxes[entry.path] = check
                row_box.pack_start(check, False, False, 0)

                icon_name = 'folder' if os.path.isdir(entry.path) else 'text-x-generic'
                row_box.pack_start(Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.MENU), False, False, 0)

                lbl = Gtk.Label(label=entry.name)
                lbl.set_halign(Gtk.Align.START)
                lbl.set_ellipsize(3)
                row_box.pack_start(lbl, True, True, 0)

                size_lbl = Gtk.Label(label=_fmt_size(entry.size_bytes))
                size_lbl.get_style_context().add_class('dim-label')
                size_lbl.set_width_chars(9)
                size_lbl.set_halign(Gtk.Align.END)
                row_box.pack_end(size_lbl, False, False, 0)

                row.add(row_box)
                self.list_box.add(row)

        self.list_box.show_all()

    def _on_select_all(self, btn):
        for check in self._checkboxes.values():
            check.set_active(btn.get_active())

    def _on_check_toggled(self, check):
        self.remove_btn.set_sensitive(any(c.get_active() for c in self._checkboxes.values()))

    def _on_remove_clicked(self, btn):
        selected = [path for path, check in self._checkboxes.items() if check.get_active()]
        if not selected:
            return

        dialog = Gtk.MessageDialog(
            parent=self.parent, modal=True,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.YES_NO,
            text=_("Remove selected cache entries?")
        )
        dialog.format_secondary_text(_("{} item(s) will be permanently deleted.").format(len(selected)))
        response = dialog.run()
        dialog.destroy()
        if response != Gtk.ResponseType.YES:
            return

        self.remove_btn.set_sensitive(False)

        def do_remove():
            from cleaner.remover import delete_temp_paths
            self.parent.set_ui_state(_("Clearing user cache..."), pulse=True)
            success, msg = delete_temp_paths(selected)
            GLib.idle_add(self.parent.set_ui_state, msg, 1.0 if success else 0.0, False, True)
            GLib.idle_add(self.remove_btn.set_sensitive, True)
            if success:
                GLib.timeout_add_seconds(1, lambda: self.parent.start_user_scan())
            GLib.timeout_add_seconds(4, lambda: self.parent.set_ui_state("", visible=False))

        threading.Thread(target=do_remove, daemon=True).start()
