import os
import shutil

class AutostartManager:
    def __init__(self):
        self.autostart_dir = os.path.expanduser('~/.config/autostart')
        
        # Buscar el archivo .desktop en diferentes ubicaciones posibles
        self.desktop_source_paths = [
            '/usr/share/applications/com.soplos.welcomelive.desktop',  # Ubicación estándar en la ISO Live
            '/usr/local/bin/soplos-welcome-live-tyson/assets/com.soplos.welcomelive.desktop'  # Ubicación en desarrollo
        ]
        self.desktop_target = os.path.join(self.autostart_dir, 'com.soplos.welcomelive.desktop')

    def is_enabled(self):
        """Verifica si welcome-live está en autostart"""
        return os.path.exists(self.desktop_target)

    def toggle(self):
        """Activa/desactiva el autostart"""
        if self.is_enabled():
            # Desactivar
            if os.path.exists(self.desktop_target):
                os.remove(self.desktop_target)
        else:
            # Activar
            self._copy_desktop_file()

    def enable(self):
        """Activa el autostart de forma segura"""
        try:
            if not self.is_enabled():
                self._copy_desktop_file()
                # Verificar que se creó correctamente
                if not os.path.exists(self.desktop_target):
                    print("Error: No se pudo crear el archivo de autostart")
                    return False
                return True
            return True  # Ya estaba habilitado
        except Exception as e:
            print(f"Error activando autostart: {e}")
            return False

    def disable(self):
        """Desactiva el autostart"""
        if os.path.exists(self.desktop_target):
            os.remove(self.desktop_target)
    
    def _copy_desktop_file(self):
        """Busca y copia el archivo desktop a la carpeta autostart"""
        os.makedirs(self.autostart_dir, exist_ok=True)
        
        # Intentar con cada posible ubicación del archivo desktop
        for source_path in self.desktop_source_paths:
            if os.path.exists(source_path):
                shutil.copy2(source_path, self.desktop_target)
                print(f"Autostart habilitado: {source_path} -> {self.desktop_target}")
                return True
        
        # Si llegamos aquí, no se encontró el archivo
        print(f"Error: No se encuentra el archivo .desktop en ninguna ubicación conocida")
        
        # Intentar crear uno básico como último recurso
        self._create_basic_desktop_file()
        return False
        
    def _create_basic_desktop_file(self):
        """Crea un archivo desktop básico como último recurso"""
        try:
            with open(self.desktop_target, 'w') as f:
                f.write("""[Desktop Entry]
Version=1.0
Type=Application
Name=Soplos Welcome Live
Comment=Welcome screen for Soplos Linux Live Environment
Exec=soplos-welcome-live
Icon=com.soplos.welcomelive
Terminal=false
Categories=Settings;DesktopSettings;GTK;Utility;
StartupNotify=true
StartupWMClass=com.soplos.welcomelive
X-GNOME-SingleWindow=true
""")
            print("Se creó un archivo desktop básico como respaldo")
        except Exception as e:
            print(f"Error creando archivo desktop básico: {e}")