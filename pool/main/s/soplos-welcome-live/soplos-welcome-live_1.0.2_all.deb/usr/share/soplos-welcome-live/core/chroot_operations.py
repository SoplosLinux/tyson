import subprocess
import os
import json
import shutil
import logging
from config.strings import STRINGS

class SystemOperations:
    def __init__(self):
        # Cambiar de /mnt/soplos_rescue a simplemente /mnt/chroot
        self.mount_point = "/mnt/chroot"
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        # Obtener idioma del sistema
        current_locale = os.getenv('LANG', 'en_US.UTF-8')
        self.current_lang = current_locale.split('_')[0]

        # Añadir tipos de sistemas de archivos soportados
        self.supported_filesystems = {
            'ext2', 'ext3', 'ext4', 'btrfs', 'xfs', 'jfs', 'reiserfs',
            'vfat', 'fat32', 'ntfs', 'exfat'
        }
        
        # Tipos de filesystem que NO son montables para chroot
        self.non_mountable_types = {
            'swap', 'extended', 'LVM2_member', 'crypto_LUKS', 
            'linux-swap(v1)', 'linux-swap(v0)', None, '', 'linux-raid-member'
        }
        
        # Registro de particiones montadas para limpieza
        self.mounted_partitions = []
        
        # Configurar manejador de señales para limpieza automática
        import signal
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

    def _signal_handler(self, signum, frame):
        """Manejador de señales para limpieza automática"""
        self.logger.warning(f"Señal {signum} recibida, iniciando limpieza...")
        self.unmount_all()
        exit(1)

    def _validate_system_requirements(self):
        """Valida que las herramientas necesarias estén disponibles"""
        required_tools = ['lsblk', 'mount', 'umount', 'blkid', 'chroot']
        missing_tools = []
        
        for tool in required_tools:
            try:
                subprocess.run(['which', tool], capture_output=True, check=True, timeout=5)
            except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
                missing_tools.append(tool)
        
        if missing_tools:
            raise Exception(f"Herramientas requeridas no encontradas: {', '.join(missing_tools)}")

    def _is_mounted(self, device_or_path):
        """Verifica si un dispositivo o ruta está montado"""
        try:
            result = subprocess.run(['mount'], capture_output=True, text=True, timeout=5)
            return device_or_path in result.stdout
        except subprocess.TimeoutExpired:
            self.logger.warning("Timeout verificando montajes")
            return False
        except Exception as e:
            self.logger.warning(f"Error verificando montajes: {e}")
            return False

    def _safe_unmount(self, mount_point, force=False):
        """Desmonta de forma segura un punto de montaje"""
        if not self._is_mounted(mount_point):
            return True
            
        try:
            # Intentar desmontaje normal primero
            cmd = ['umount', mount_point]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                self.logger.info(f"Desmontado exitosamente: {mount_point}")
                return True
            
            # Si falla y force=True, intentar desmontaje lazy
            if force:
                cmd = ['umount', '-l', mount_point]
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
                if result.returncode == 0:
                    self.logger.info(f"Desmontado con -l: {mount_point}")
                    return True
                
                # Último recurso: forzar desmontaje
                cmd = ['umount', '-f', mount_point]
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
                if result.returncode == 0:
                    self.logger.info(f"Desmontado con -f: {mount_point}")
                    return True
            
            self.logger.error(f"No se pudo desmontar {mount_point}: {result.stderr}")
            return False
            
        except subprocess.TimeoutExpired:
            self.logger.error(f"Timeout desmontando {mount_point}")
            return False
        except Exception as e:
            self.logger.error(f"Error desmontando {mount_point}: {e}")
            return False

    def get_disks(self):
        """Obtiene lista de discos con manejo robusto de errores"""
        try:
            # Validar que las herramientas necesarias estén disponibles
            self._validate_system_requirements()
            
            cmd = "lsblk -lnp -o NAME,SIZE,MODEL -d -I 8,259"
            result = subprocess.run(cmd.split(), capture_output=True, text=True, timeout=15)
            
            if result.returncode != 0:
                self.logger.error(f"Error ejecutando lsblk: {result.stderr}")
                raise Exception(f"Error al listar discos: {result.stderr}")
            
            disks = []
            for line in result.stdout.splitlines():
                if line.strip():
                    parts = line.split()
                    if len(parts) >= 2:
                        device = parts[0]
                        size = parts[1]
                        model = ' '.join(parts[2:]) if len(parts) > 2 else STRINGS[self.current_lang]['labels']['device']
                        
                        # Validar que el dispositivo existe y es accesible
                        if os.path.exists(device):
                            disks.append((device, size, model))
                        else:
                            self.logger.warning(f"Dispositivo no accesible: {device}")
            
            if not disks:
                raise Exception("No se encontraron discos válidos")
                
            return disks
            
        except subprocess.TimeoutExpired:
            self.logger.error("Timeout al ejecutar lsblk para obtener discos")
            raise Exception("Timeout al detectar discos")
        except Exception as e:
            self.logger.error(f"Error obteniendo discos: {str(e)}")
            raise Exception(f"Error al cargar discos: {str(e)}")

    def get_disk_partitions(self, disk_name):
        """Obtiene las particiones de un disco específico con detección mejorada y manejo robusto"""
        try:
            # Validar que el disco existe
            if not os.path.exists(disk_name):
                raise Exception(f"El disco {disk_name} no existe o no es accesible")
            
            # Actualizar idioma por si cambió
            self.update_current_language()
            
            # Usar lsblk con más información y formato JSON para mejor parsing
            cmd = ['lsblk', '-f', '-J', '-o', 'NAME,SIZE,FSTYPE,LABEL,MOUNTPOINT,PARTLABEL', disk_name]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
            
            if result.returncode != 0:
                self.logger.warning(f"lsblk JSON falló: {result.stderr}")
                # Fallback al método anterior si JSON falla
                return self._get_partitions_fallback(disk_name)
            
            try:
                lsblk_data = json.loads(result.stdout)
            except json.JSONDecodeError as e:
                self.logger.warning(f"Error parseando JSON de lsblk: {e}")
                # Si falla el parsing JSON, usar método fallback
                return self._get_partitions_fallback(disk_name)
            
            partitions = []
            
            # Procesar dispositivos de bloque
            for device in lsblk_data.get('blockdevices', []):
                # Procesar particiones del dispositivo
                children = device.get('children', [])
                if not children:
                    self.logger.info(f"No se encontraron particiones en {disk_name}")
                    continue
                    
                for partition in children:
                    try:
                        partition_info = self._process_partition_info(partition)
                        if partition_info and self._is_partition_mountable(partition_info):
                            # Validar que la partición es realmente accesible
                            if self._validate_partition_access(partition_info):
                                partitions.append(partition_info)
                    except Exception as e:
                        self.logger.warning(f"Error procesando partición: {e}")
                        continue
            
            if not partitions:
                raise Exception(f"No se encontraron particiones montables en {disk_name}")
            
            # Sugerir puntos de montaje mejorados
            self._suggest_mount_points(partitions)
            
            self.logger.info(f"Encontradas {len(partitions)} particiones montables en {disk_name}")
            return partitions
            
        except subprocess.TimeoutExpired:
            self.logger.error("Timeout al ejecutar lsblk")
            raise Exception("Timeout al detectar particiones")
        except Exception as e:
            self.logger.error(f"Error obteniendo particiones: {str(e)}")
            # Intentar con método fallback como último recurso
            try:
                return self._get_partitions_fallback(disk_name)
            except Exception as fallback_error:
                self.logger.error(f"Error en método fallback: {fallback_error}")
                raise Exception(f"No se pudieron detectar particiones en {disk_name}: {str(e)}")

    def _validate_partition_access(self, partition_info):
        """Valida que una partición sea accesible"""
        device = partition_info.get('device', '')
        
        try:
            # Verificar que el dispositivo existe
            if not os.path.exists(device):
                self.logger.warning(f"Dispositivo no existe: {device}")
                return False
            
            # Verificar permisos de lectura
            if not os.access(device, os.R_OK):
                self.logger.warning(f"Sin permisos de lectura: {device}")
                return False
            
            # Intentar obtener información con blkid
            result = subprocess.run(['blkid', device], 
                                  capture_output=True, text=True, timeout=5)
            
            # Si blkid no devuelve información, puede ser una partición sin formato
            # pero aún así puede ser válida para algunos casos
            if result.returncode != 0 and partition_info.get('fstype'):
                self.logger.warning(f"blkid falló para {device}, pero tiene fstype")
            
            return True
            
        except subprocess.TimeoutExpired:
            self.logger.warning(f"Timeout validando {device}")
            return False
        except Exception as e:
            self.logger.warning(f"Error validando {device}: {e}")
            return False

    def _is_partition_mountable(self, partition_info):
        """Verifica si una partición es montable para chroot con validación mejorada"""
        fstype = partition_info.get('fstype', '').lower()
        device = partition_info.get('device', '')
        
        # Excluir tipos no montables
        if fstype in self.non_mountable_types:
            self.logger.debug(f"Partición {device} excluida por tipo no montable: {fstype}")
            return False
        
        # Excluir particiones extendidas (no tienen filesystem)
        if not fstype and 'extended' in device.lower():
            self.logger.debug(f"Partición {device} excluida por ser extendida")
            return False
        
        # Verificar si está ya montada en el sistema
        if self._is_mounted(device):
            self.logger.warning(f"Partición {device} ya está montada")
            # Aún puede ser montable en otro punto, así que no la excluimos
        
        # Para particiones sin filesystem, verificar si son particiones reales
        if not fstype:
            try:
                # Usar blkid para obtener más información
                blkid_result = subprocess.run(['blkid', device], 
                                            capture_output=True, text=True, timeout=5)
                
                # Si blkid no encuentra información y no hay filesystem, probablemente no es montable
                if blkid_result.returncode != 0 and 'TYPE=' not in blkid_result.stdout:
                    self.logger.debug(f"Partición {device} sin filesystem detectado")
                    return False
                    
            except subprocess.TimeoutExpired:
                self.logger.warning(f"Timeout verificando {device} con blkid")
                return False
            except Exception as e:
                self.logger.warning(f"Error verificando {device}: {e}")
                return False
        
        # Verificar que el filesystem esté en la lista de soportados si está definido
        if fstype and fstype not in self.supported_filesystems:
            self.logger.warning(f"Filesystem {fstype} no está en la lista de soportados para {device}")
            # No excluir automáticamente, puede ser que funcione de todos modos
        
        self.logger.debug(f"Partición {device} ({fstype}) es montable")
        return True

    def _get_partitions_fallback(self, disk_name):
        """Método fallback para detección de particiones"""
        try:
            cmd = ['lsblk', '-lnp', '-o', 'NAME,SIZE,FSTYPE,MOUNTPOINT', disk_name]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            
            if result.returncode != 0:
                raise Exception(f"Error ejecutando lsblk: {result.stderr}")
            
            partitions = []
            
            for line in result.stdout.strip().split('\n'):
                parts = line.split()
                if not parts or parts[0] == disk_name:
                    continue
                
                device = parts[0]
                size = parts[1] if len(parts) > 1 else 'Desconocido'
                fstype = parts[2].lower() if len(parts) > 2 and parts[2] != '' else ''
                mountpoint = parts[3] if len(parts) > 3 else ''
                
                partition_info = {
                    'device': device,
                    'size': size,
                    'fstype': fstype,
                    'label': '',
                    'mountpoint': mountpoint,
                    'suggested_mount': None
                }
                
                if self._is_partition_mountable(partition_info):
                    partitions.append(partition_info)
            
            self._suggest_mount_points(partitions)
            return partitions
            
        except Exception as e:
            self.logger.error(f"Error en método fallback: {str(e)}")
            raise

    def _suggest_mount_points(self, partitions):
        """Sugiere puntos de montaje de forma inteligente"""
        # Resetear sugerencias
        for partition in partitions:
            partition['suggested_mount'] = None
        
        # Contadores para evitar duplicados
        suggested_counts = {'/': 0, '/boot': 0, '/boot/efi': 0, '/home': 0}
        
        # Primera pasada: asignaciones por tipo de filesystem y etiquetas
        for partition in partitions:
            fstype = partition['fstype']
            label = partition['label'].lower()
            
            # EFI/ESP siempre va a /boot/efi
            if fstype in ['vfat', 'fat32'] and ('efi' in label or 'esp' in label):
                if suggested_counts['/boot/efi'] == 0:
                    partition['suggested_mount'] = '/boot/efi'
                    suggested_counts['/boot/efi'] += 1
                    continue
            
            # Particiones por etiqueta
            if 'root' in label and suggested_counts['/'] == 0:
                partition['suggested_mount'] = '/'
                suggested_counts['/'] += 1
            elif 'boot' in label and 'efi' not in label and suggested_counts['/boot'] == 0:
                partition['suggested_mount'] = '/boot'
                suggested_counts['/boot'] += 1
            elif 'home' in label and suggested_counts['/home'] == 0:
                partition['suggested_mount'] = '/home'
                suggested_counts['/home'] += 1
        
        # Segunda pasada: asignaciones por tipo de filesystem
        for partition in partitions:
            if partition['suggested_mount'] is not None:
                continue
                
            fstype = partition['fstype']
            
            # Sistemas de archivos Linux nativos
            if fstype in ['ext4', 'btrfs', 'xfs']:
                if suggested_counts['/'] == 0:
                    partition['suggested_mount'] = '/'
                    suggested_counts['/'] += 1
                elif suggested_counts['/boot'] == 0:
                    partition['suggested_mount'] = '/boot'
                    suggested_counts['/boot'] += 1
                elif suggested_counts['/home'] == 0:
                    partition['suggested_mount'] = '/home'
                    suggested_counts['/home'] += 1
            
            # Particiones FAT para /boot/efi si no hay ninguna asignada
            elif fstype in ['vfat', 'fat32'] and suggested_counts['/boot/efi'] == 0:
                partition['suggested_mount'] = '/boot/efi'
                suggested_counts['/boot/efi'] += 1

    def execute_chroot(self):
        """Ejecuta el chroot"""
        subprocess.run(['chroot', self.mount_point], check=True)

    def execute_gparted(self):
        """Ejecuta GParted usando la ruta absoluta"""
        try:
            subprocess.Popen(['pkexec', '/usr/sbin/gparted'])
        except Exception as e:
            print(f"Error ejecutando GParted: {e}")

    def _validate_mounted_system(self):
        """Verifica si el sistema montado es un Linux válido
        
        Retorna:
            bool: True si el sistema parece un Linux válido, False en caso contrario
        """
        # Verificar directorios y archivos esenciales que deberían existir en un sistema Linux
        essential_paths = [
            '/bin', '/usr/bin', '/lib', '/usr/lib', 
            '/etc/fstab', '/etc/passwd', '/etc/shadow'
        ]
        
        # Al menos un shell debe existir
        shell_paths = ['/bin/bash', '/bin/sh', '/usr/bin/bash', '/usr/bin/sh']
        
        # Verificar directorios esenciales
        essential_found = 0
        for path in essential_paths:
            full_path = os.path.join(self.mount_point, path.lstrip('/'))
            if os.path.exists(full_path):
                essential_found += 1
        
        # Verificar si hay al menos un shell 
        shell_found = False
        for shell in shell_paths:
            full_path = os.path.join(self.mount_point, shell.lstrip('/'))
            if os.path.exists(full_path):
                shell_found = True
                break
        
        # Consideramos válido si hay al menos 3 directorios/archivos esenciales y un shell
        return essential_found >= 3 and shell_found

    def unmount_all(self):
        """Desmonta todas las particiones y sistemas de archivos virtuales con limpieza robusta"""
        try:
            self.logger.info("Iniciando desmontaje completo de sistemas de archivos")
            
            # Lista de puntos de montaje en orden inverso (importante para desmontaje)
            mount_points = [
                f"{self.mount_point}/dev/pts",
                f"{self.mount_point}/dev",
                f"{self.mount_point}/proc", 
                f"{self.mount_point}/sys",
                f"{self.mount_point}/boot/efi",
                f"{self.mount_point}/boot",
                self.mount_point
            ]
            
            # Verificar procesos que puedan estar usando los puntos de montaje
            self._kill_processes_using_mountpoint()
            
            success_count = 0
            total_mounted = 0
            
            for mount_point in mount_points:
                if self._is_mounted(mount_point):
                    total_mounted += 1
                    if self._safe_unmount(mount_point, force=True):
                        success_count += 1
                        # Esperar un poco para que el sistema procese el desmontaje
                        import time
                        time.sleep(0.1)
            
            # Verificar que todo se desmontó correctamente
            remaining_mounts = []
            for mount_point in mount_points:
                if self._is_mounted(mount_point):
                    remaining_mounts.append(mount_point)
            
            if remaining_mounts:
                self.logger.warning(f"Algunos puntos de montaje no se pudieron desmontar: {remaining_mounts}")
                
                # Intentar desmontaje forzado como último recurso
                for mount_point in remaining_mounts:
                    try:
                        subprocess.run(['sudo', 'umount', '-f', mount_point], 
                                     capture_output=True, timeout=5)
                    except:
                        pass
                return False
            else:
                self.logger.info(f"Desmontaje exitoso: {success_count}/{total_mounted} puntos desmontados")
                
                # Limpiar directorio de montaje si está vacío
                try:
                    if os.path.exists(self.mount_point) and not os.listdir(self.mount_point):
                        os.rmdir(self.mount_point)
                        self.logger.info(f"Directorio de montaje eliminado: {self.mount_point}")
                except Exception as e:
                    self.logger.warning(f"No se pudo eliminar directorio de montaje: {e}")
                
                return True
                
        except Exception as e:
            self.logger.error(f"Error en desmontaje completo: {e}")
            return False

    def _kill_processes_using_mountpoint(self):
        """Mata procesos que puedan estar usando el punto de montaje"""
        try:
            # Usar fuser para encontrar procesos que usan el punto de montaje
            result = subprocess.run(['fuser', '-m', self.mount_point], 
                                  capture_output=True, text=True, timeout=5)
            
            if result.returncode == 0 and result.stdout.strip():
                self.logger.warning(f"Procesos usando {self.mount_point}: {result.stdout.strip()}")
                
                # Intentar matar procesos suavemente primero
                subprocess.run(['fuser', '-k', '-m', self.mount_point], 
                             capture_output=True, timeout=5)
                
                import time
                time.sleep(1)
                
                # Verificar si aún hay procesos
                result = subprocess.run(['fuser', '-m', self.mount_point], 
                                      capture_output=True, text=True, timeout=5)
                
                if result.returncode == 0 and result.stdout.strip():
                    # Forzar terminación si es necesario
                    subprocess.run(['fuser', '-k', '-9', '-m', self.mount_point], 
                                 capture_output=True, timeout=5)
                    self.logger.warning("Procesos terminados forzadamente")
                    
        except subprocess.TimeoutExpired:
            self.logger.warning("Timeout verificando procesos en punto de montaje")
        except FileNotFoundError:
            # fuser no está disponible, continuar sin él
            pass
        except Exception as e:
            self.logger.warning(f"Error verificando procesos: {e}")

    def update_current_language(self):
        """Actualiza el idioma actual desde las variables de entorno con validación"""
        try:
            current_locale = os.getenv('LANG', 'en_US.UTF-8')
            new_lang = current_locale.split('_')[0]
            
            # Validar que el idioma existe en STRINGS
            if new_lang in STRINGS:
                if new_lang != self.current_lang:
                    self.logger.info(f"Idioma actualizado de {self.current_lang} a {new_lang}")
                    self.current_lang = new_lang
            else:
                if self.current_lang != 'en':
                    self.logger.warning(f"Idioma {new_lang} no disponible, usando inglés")
                    self.current_lang = 'en'  # Fallback a inglés
                    
        except Exception as e:
            self.logger.error(f"Error actualizando idioma: {e}")
            # Mantener idioma actual en caso de error

    def mount_and_chroot(self, root_part, boot_part=None, efi_part=None):
        """Monta las particiones y ejecuta chroot con mensajes internacionalizados"""
        try:
            # Actualizar idioma por si cambió
            self.update_current_language()
            
            # Obtener strings traducidos para el terminal
            t = STRINGS[self.current_lang]['chroot']['terminal']
            
            # Primero desmontar cualquier montaje anterior para evitar conflictos
            self.unmount_all()
            
            # Script para montar todo con mensajes traducidos
            mount_script = f"""#!/bin/bash
# {t['creating_mount_point']} - {self.mount_point}
sudo rm -rf {self.mount_point} 2>/dev/null || true
sudo mkdir -p {self.mount_point}
sudo chmod 755 {self.mount_point}

# Verificar que el punto de montaje existe
if [ ! -d "{self.mount_point}" ]; then
    echo "{t['error_create_mount']} {self.mount_point}"
    exit 1
fi

# Limpiar cualquier montaje anterior
sudo umount -l {self.mount_point}/dev/pts 2>/dev/null || true
sudo umount -l {self.mount_point}/dev 2>/dev/null || true
sudo umount -l {self.mount_point}/proc 2>/dev/null || true
sudo umount -l {self.mount_point}/sys 2>/dev/null || true
sudo umount -l {self.mount_point}/boot/efi 2>/dev/null || true
sudo umount -l {self.mount_point}/boot 2>/dev/null || true
sudo umount -l {self.mount_point} 2>/dev/null || true

echo "{t['mount_point']}: {self.mount_point}"
echo "{t['root_partition']}: {root_part}"

# {t['mounting_root']} {root_part}...
echo "{t['mounting_root']} {root_part}..."
sudo mount {root_part} {self.mount_point}
if [ $? -ne 0 ]; then
    echo "{t['error_mount_root']} {root_part} en {self.mount_point}"
    exit 1
fi

echo "{t['root_mounted']}"
"""
            if boot_part:
                mount_script += f"""
# {t['creating_dir_boot']}
echo "{t['creating_dir_boot']}"
sudo mkdir -p {self.mount_point}/boot

echo "{t['mounting_boot']} {boot_part}..."
sudo mount {boot_part} {self.mount_point}/boot
if [ $? -ne 0 ]; then
    echo "{t['error_mount_boot']} {boot_part} en {self.mount_point}/boot"
    exit 1
fi
"""
            if efi_part:
                mount_script += f"""
# {t['creating_dir_efi']}
echo "{t['creating_dir_efi']}"
sudo mkdir -p {self.mount_point}/boot/efi

echo "{t['mounting_efi']} {efi_part}..."
sudo mount {efi_part} {self.mount_point}/boot/efi
if [ $? -ne 0 ]; then
    echo "{t['error_mount_efi']} {efi_part} en {self.mount_point}/boot/efi"
    exit 1
fi
"""
            
            mount_script += f"""
# {t['creating_dirs_bind']}
echo "{t['creating_dirs_bind']}"
sudo mkdir -p {self.mount_point}/dev
sudo mkdir -p {self.mount_point}/proc
sudo mkdir -p {self.mount_point}/sys
sudo mkdir -p {self.mount_point}/dev/pts

# {t['mounting_virtual_fs']}
echo "{t['mounting_virtual_fs']}"
sudo mount --bind /dev {self.mount_point}/dev
if [ $? -ne 0 ]; then
    echo "{t['error_mount_dev']} en {self.mount_point}/dev"
    exit 1
fi

sudo mount --bind /proc {self.mount_point}/proc
if [ $? -ne 0 ]; then
    echo "{t['error_mount_proc']} en {self.mount_point}/proc"
    exit 1
fi

sudo mount --bind /sys {self.mount_point}/sys
if [ $? -ne 0 ]; then
    echo "{t['error_mount_sys']} en {self.mount_point}/sys"
    exit 1
fi

sudo mount --bind /dev/pts {self.mount_point}/dev/pts
if [ $? -ne 0 ]; then
    echo "{t['error_mount_pts']} en {self.mount_point}/dev/pts"
    exit 1
fi

# Copiar resolv.conf para tener resolución DNS
sudo mkdir -p {self.mount_point}/etc
sudo cp /etc/resolv.conf {self.mount_point}/etc/resolv.conf 2>/dev/null || echo "No se pudo copiar resolv.conf"

# Verificar si es un sistema Linux válido
if [ ! -e "{self.mount_point}/bin/bash" ] && [ ! -e "{self.mount_point}/usr/bin/bash" ]; then
    echo "{t['error_no_shell']}"
    if [ -d "{self.mount_point}/bin" ]; then
        echo "{t['content_bin']}"
        ls -la {self.mount_point}/bin/
    fi
    if [ -d "{self.mount_point}/usr/bin" ]; then
        echo "{t['content_usr_bin']}"
        ls -la {self.mount_point}/usr/bin/ | grep -E "bash|sh"
    fi
    exit 1
fi

# {t['verification']}
echo "{t['verification']}"
ls -la {self.mount_point}
"""
            
            # Ejecutar script de montaje
            with open('/tmp/mount.sh', 'w') as f:
                f.write(mount_script)
            os.chmod('/tmp/mount.sh', 0o755)
            mount_result = subprocess.run(['bash', '/tmp/mount.sh'], capture_output=True, text=True)
            
            if mount_result.returncode != 0:
                raise Exception(f"Error al montar particiones: {mount_result.stderr or mount_result.stdout}")
            
            print("Resultado del montaje:")
            print(mount_result.stdout)
            
            # Verificar si es un sistema Linux válido antes de continuar
            is_valid_system = self._validate_mounted_system()
            if not is_valid_system:
                self.unmount_all()
                raise Exception("La partición seleccionada no contiene un sistema Linux válido o está dañada")
            
            # Script mejorado para chroot que se cierra correctamente con exit/Ctrl+D
            chroot_script = f"""#!/bin/bash

# Función de limpieza que se ejecuta al salir
cleanup_and_exit() {{
    echo ""
    echo "{t['chroot_separator']}"
    echo "{t['exited_chroot']}"
    echo "{t['unmounting']}"
    echo "{t['chroot_separator']}"
    
    # Desmontar todo al salir
    sudo umount -l {self.mount_point}/dev/pts 2>/dev/null || true
    sudo umount -l {self.mount_point}/dev 2>/dev/null || true
    sudo umount -l {self.mount_point}/proc 2>/dev/null || true
    sudo umount -l {self.mount_point}/sys 2>/dev/null || true

    if [ -d "{self.mount_point}/boot/efi" ] && mountpoint -q {self.mount_point}/boot/efi 2>/dev/null; then
        sudo umount {self.mount_point}/boot/efi 2>/dev/null || sudo umount -l {self.mount_point}/boot/efi 2>/dev/null || true
    fi

    if [ -d "{self.mount_point}/boot" ] && mountpoint -q {self.mount_point}/boot 2>/dev/null; then
        sudo umount {self.mount_point}/boot 2>/dev/null || sudo umount -l {self.mount_point}/boot 2>/dev/null || true
    fi

    sudo umount {self.mount_point} 2>/dev/null || sudo umount -l {self.mount_point} 2>/dev/null || true

    # Verificar si todos los sistemas de archivos fueron desmontados
    if mount | grep -q "{self.mount_point}"; then
        echo "{t['unmounting_warning']}"
        echo "{t['still_mounted']}"
        mount | grep "{self.mount_point}"
        echo "{t['restart_recommendation']}"
    else
        echo "{t['unmounted_successfully']}"
    fi

    # Preguntar si se desea eliminar el directorio de montaje
    echo -n "{t['remove_mount_dir']} {self.mount_point}? [s/N]: "
    read -r response
    if [[ "$response" =~ ^([sS][iI]|[sS])$ ]]; then
        sudo rm -rf {self.mount_point} && echo "{t['mount_dir_removed']}" || echo "{t['mount_dir_error']} {self.mount_point}"
    fi

    echo "{t['process_finished']}"
    exit 0
}}

# Configurar manejo de señales para limpieza automática
trap cleanup_and_exit EXIT SIGTERM SIGINT

# Verificar que el punto de montaje existe
if [ ! -d "{self.mount_point}" ]; then
    echo "{t['error_create_mount']} {self.mount_point}"
    exit 1
fi

# {t['content_mounted']}
echo "{t['content_mounted']}"
ls -la {self.mount_point}

# Detectar el shell disponible
if [ -e "{self.mount_point}/bin/bash" ]; then
    SHELL_PATH="/bin/bash"
elif [ -e "{self.mount_point}/usr/bin/bash" ]; then
    SHELL_PATH="/usr/bin/bash"
elif [ -e "{self.mount_point}/bin/sh" ]; then
    SHELL_PATH="/bin/sh"
elif [ -e "{self.mount_point}/usr/bin/sh" ]; then
    SHELL_PATH="/usr/bin/sh"
else
    echo "{t['error_no_shell']}"
    exit 1
fi

echo "{t['using_shell']}: $SHELL_PATH"
echo "{t['starting_chroot']}"

# Configurar la terminal para un mejor aspecto en el chroot
export TERM=xterm-256color

echo "{t['chroot_separator']}"
echo "  {t['chroot_header']}"
echo "{t['chroot_separator']}"
echo "{t['chroot_description']}"
echo "{t['chroot_help']}"
echo "{t['chroot_help2']}"
echo ""
echo "{t['chroot_exit']}"
echo "{t['chroot_separator']}"

# Crear un script interno para el chroot que configure el PS1 y mantenga el entorno
cat > /tmp/chroot_inner.sh << 'INNER_EOF'
#!/bin/bash
# Configurar prompt para chroot
export PS1="\[\e[1;31m\](chroot) \[\e[1;34m\]\w \[\e[0m\]\$ "
export TERM=xterm-256color

# Ejecutar el shell interactivo
exec "$@"
INNER_EOF

chmod +x /tmp/chroot_inner.sh

# Entrar al chroot con el shell detectado usando exec para reemplazar el proceso
# Esto hace que cuando el usuario haga exit o Ctrl+D, termine completamente
exec sudo chroot {self.mount_point} /bin/bash -c "
export PS1='\\[\\e[1;31m\\](chroot) \\[\\e[1;34m\\]\\w \\[\\e[0m\\]\\$ '
export TERM=xterm-256color
exec $SHELL_PATH
"
"""
            
            with open('/tmp/chroot.sh', 'w') as f:
                f.write(chroot_script)
            os.chmod('/tmp/chroot.sh', 0o755)
            
            # Usar terminal que se cierre automáticamente al terminar el comando
            terminal_title = STRINGS[self.current_lang]['chroot']['title']
            
            # Intentar diferentes terminales en orden de preferencia
            terminals_to_try = [
                # Konsole con configuración para cierre automático
                ['konsole', '--nofork', '--hold', 'off', 
                 '--title', f'Soplos {terminal_title}', 
                 '-e', 'bash', '/tmp/chroot.sh'],
                
                # xterm con configuración para cierre automático  
                ['xterm', '-title', f'Soplos {terminal_title}',
                 '-e', 'bash', '/tmp/chroot.sh'],
                
                # gnome-terminal
                ['gnome-terminal', '--title', f'Soplos {terminal_title}',
                 '--', 'bash', '/tmp/chroot.sh'],
                
                # xfce4-terminal
                ['xfce4-terminal', '--title', f'Soplos {terminal_title}',
                 '-e', 'bash', '/tmp/chroot.sh'],
                
                # Fallback genérico
                ['x-terminal-emulator', '-e', 'bash', '/tmp/chroot.sh']
            ]
            
            # Intentar ejecutar el primer terminal que esté disponible
            terminal_launched = False
            for terminal_cmd in terminals_to_try:
                try:
                    # Verificar si el comando existe
                    subprocess.run(['which', terminal_cmd[0]], 
                                 capture_output=True, check=True)
                    # Si existe, intentar ejecutarlo
                    subprocess.Popen(terminal_cmd, start_new_session=True)
                    terminal_launched = True
                    break
                except (subprocess.CalledProcessError, FileNotFoundError):
                    continue
            
            if not terminal_launched:
                # Si no se pudo lanzar ningún terminal, mostrar error
                self.logger.error("No se encontró ningún terminal disponible")
                raise Exception("No se pudo abrir un terminal para el entorno chroot")
        
        except Exception as e:
            # Asegurar limpieza si algo sale mal
            self.unmount_all()
            raise e
