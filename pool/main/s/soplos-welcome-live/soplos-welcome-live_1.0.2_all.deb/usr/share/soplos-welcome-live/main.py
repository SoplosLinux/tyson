#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# Configurar variables de entorno antes de importar GTK
import os
import locale
import sys
import shutil
import subprocess
import json
import time

# Configurar locale antes de importar GTK para evitar advertencias
try:
    locale_set = False
    # Intentar establecer el locale del sistema
    current_locale = os.getenv('LANG', 'en_US.UTF-8')
    try:
        locale.setlocale(locale.LC_ALL, '')
        locale_set = True
    except locale.Error:
        pass
        
    # Si falla, intentar con 'C.UTF-8' primero, o 'en_US.UTF-8' como respaldo
    if not locale_set:
        try:
            locale.setlocale(locale.LC_ALL, 'C.UTF-8')
        except locale.Error:
            try:
                locale.setlocale(locale.LC_ALL, 'en_US.UTF-8')
            except locale.Error:
                # Si todo falla, usar el locale 'C' como último recurso
                locale.setlocale(locale.LC_ALL, 'C')
except:
    pass

# Otras variables de entorno necesarias para GTK
os.environ['NO_AT_BRIDGE'] = '1'
os.environ['GTK_MODULES'] = ''
os.environ['DBUS_SESSION_BUS_ADDRESS'] = ''

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GLib, Gio
from ui.main_window import MainWindow
from config.strings import STRINGS
from config.paths import ICON_PATH
from utils.desktop_detector import load_language_preference, get_session_type
from utils.session_manager import session_manager  # Asegurarse de que la importación sea correcta
from utils.xdg_helper import xdg_manager  # Añadir el nuevo módulo

def clean_pycache():
    """Limpia todos los archivos __pycache__ del proyecto"""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    for root, dirs, files in os.walk(base_dir):
        if '__pycache__' in dirs:
            shutil.rmtree(os.path.join(root, '__pycache__'))

def get_system_locale():
    """Obtiene el locale del sistema"""
    # Primero intentar leer de locale.conf
    if os.path.exists('/etc/locale.conf'):
        try:
            with open('/etc/locale.conf', 'r') as f:
                for line in f:
                    if line.startswith('LANG='):
                        return line.split('=')[1].strip().strip('"')
        except:
            pass
    
    # Si no existe o falla, usar la variable LANG o default en_US.UTF-8
    return os.getenv('LANG', 'en_US.UTF-8')

def get_language_code():
    """Obtiene el código de idioma del sistema y devuelve uno válido"""
    current_locale = get_system_locale()
    
    # Si es C.UTF-8 o similar, usar inglés por defecto
    if current_locale.startswith('C.') or current_locale == 'C':
        return 'en'
    
    # Obtener el código de idioma (primeras dos letras)
    lang_code = current_locale.split('_')[0].lower()
    
    # Verificar si el código existe en STRINGS, si no, usar inglés
    return lang_code if lang_code in STRINGS else 'en'

def check_environment():
    """Verifica y configura el entorno necesario"""
    # Verificar usuario
    if os.getenv('USER') != 'liveuser':
        print("Warning: No se está ejecutando como liveuser")
    
    # Asegurarse de que el autologin esté configurado
    try:
        username = os.environ.get('USER', 'liveuser')
        session_manager.ensure_autologin(username)
    except Exception as e:
        print(f"Error configurando autologin: {e}")
    
    # Detectar tipo de sesión (X11 o Wayland)
    session_type = get_session_type()
    print(f"Tipo de sesión detectado: {session_type}")
    
    # Verificar si estamos iniciando después de un cambio de idioma
    if os.path.exists('/tmp/soplos_welcome_restart_state.json'):
        try:
            with open('/tmp/soplos_welcome_restart_state.json', 'r') as f:
                restart_state = json.load(f)
            
            # Si se reinició recientemente y el autostart estaba habilitado
            if restart_state.get('restarted') and restart_state.get('autostart_enabled'):
                print("Detectado reinicio con autostart habilitado")
                # Verificar si el archivo de autostart existe y crearlo si no
                from utils.autostart import AutostartManager
                autostart_manager = AutostartManager()
                if not autostart_manager.is_enabled():
                    print("Restaurando configuración de autostart")
                    autostart_manager.enable()
        except Exception as e:
            print(f"Error verificando estado de reinicio: {e}")
    
    # Verificar variables críticas según el tipo de sesión
    if session_type == 'wayland':
        required_vars = {
            'WAYLAND_DISPLAY': os.getenv('WAYLAND_DISPLAY', 'wayland-0'),
            'XDG_RUNTIME_DIR': f"/run/user/{os.getuid()}",
            'XDG_SESSION_TYPE': 'wayland',
            'LANG': os.getenv('LANG', 'en_US.UTF-8')
        }
    else:  # x11 por defecto
        required_vars = {
            'DISPLAY': ':0',
            'XAUTHORITY': os.path.expanduser('~/.Xauthority'),
            'XDG_RUNTIME_DIR': f"/run/user/{os.getuid()}",
            'XDG_SESSION_TYPE': 'x11',
            'LANG': os.getenv('LANG', 'en_US.UTF-8')
        }
    
    # Establecer variables faltantes
    for var, default in required_vars.items():
        if not os.getenv(var):
            os.environ[var] = default
            print(f"Estableciendo {var}={default}")
    
    # Verificar si es la primera ejecución para evitar reinicios automáticos no deseados
    if not os.path.exists('/tmp/soplos_welcome_first_run_complete'):
        print("Primera ejecución detectada, creando marcador...")
        with open('/tmp/soplos_welcome_first_run_complete', 'w') as f:
            f.write(str(time.time()))
        # Eliminar cualquier estado de reinicio anterior
        if os.path.exists('/tmp/soplos_welcome_restart_state.json'):
            os.unlink('/tmp/soplos_welcome_restart_state.json')

def diagnose_locale():
    """Diagnostica la configuración de locale del sistema"""
    print("\n=== Diagnóstico de Locale ===")
    
    # 1. Variable LANG
    print(f"LANG={os.getenv('LANG', 'no definido')}")
    
    # 2. Contenido de /etc/default/locale
    try:
        with open('/etc/default/locale', 'r') as f:
            print("\n/etc/default/locale:")
            print(f.read().strip())
    except:
        print("\n/etc/default/locale: no existe o no es accesible")
    
    # 3. Locales generados
    try:
        output = subprocess.check_output(['locale', '-a'], text=True)
        print("\nLocales disponibles:")
        print(output.strip())
    except:
        print("\nError al obtener locales disponibles")
    
    # 4. Estado actual de locale
    try:
        output = subprocess.check_output(['locale'], text=True)
        print("\nEstado actual de locale:")
        print(output.strip())
    except:
        print("\nError al obtener estado de locale")
    
    print("\n==========================")

def set_app_icon():
    """Establece el icono de la aplicación silenciosamente"""
    try:
        if os.path.exists(ICON_PATH):
            Gtk.Window.set_default_icon_from_file(ICON_PATH)
        else:
            Gtk.Window.set_default_icon_name("system-software-install")
    except:
        Gtk.Window.set_default_icon_name("system-software-install")

class SoplosWelcomeLive(Gtk.Application):
    def __init__(self):
        super().__init__(application_id="com.soplos.welcomelive",
                        flags=Gio.ApplicationFlags.FLAGS_NONE)
        self.window = None

    def do_activate(self):
        clean_pycache()  # Limpiar al iniciar
        set_app_icon()   # Establecer icono por defecto
        if not self.window:
            # Obtener el idioma guardado o detectado
            lang_code = load_language_preference()
            if not lang_code or lang_code not in STRINGS:
                lang_code = get_language_code()
            
            self.window = MainWindow(lang_code)
            self.window.set_application(self)
            
            # Establecer icono usando el icon theme primero
            try:
                icon_theme = Gtk.IconTheme.get_default()
                icon = icon_theme.load_icon("soplos-welcome-live", 128, 0)
                self.window.set_icon(icon)
            except:
                # Fallback a archivo local
                if os.path.exists(ICON_PATH):
                    self.window.set_icon_from_file(ICON_PATH)

            self.window.connect("destroy", lambda x: self.on_quit())
        self.window.show_all()

    def on_quit(self):
        """Limpia la caché y cierra la aplicación"""
        clean_pycache()  # Limpiar al cerrar
        
        # Limpieza adicional de archivos temporales que podríamos haber creado
        temp_files = [
            '/tmp/autologin.conf',
            '/tmp/sddm_autologin.conf',
            '/tmp/sddm_autologin_append'
        ]
        
        for temp_file in temp_files:
            if os.path.exists(temp_file):
                try:
                    os.unlink(temp_file)
                except:
                    pass
                
        self.quit()

def main():
    # Verificar y configurar el entorno antes de iniciar
    check_environment()
    
    app = SoplosWelcomeLive()
    app.run(sys.argv)

if __name__ == "__main__":
    main()