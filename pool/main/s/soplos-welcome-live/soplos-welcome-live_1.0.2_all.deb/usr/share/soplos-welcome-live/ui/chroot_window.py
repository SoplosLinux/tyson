import gi
import os
import subprocess
import shutil
import sys

# Añadir el directorio raíz al path de Python
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib
from core.chroot_operations import SystemOperations
from config.strings import STRINGS  # Cambiar la importación

# Desactivar warnings de accesibilidad
os.environ['NO_AT_BRIDGE'] = '1'

class ChRootWindow(Gtk.Window):
    def __init__(self):
        # Limpiar pycache antes de inicializar
        self.clean_pycache()
        
        # Obtener idioma del sistema de manera más robusta
        self.update_current_language()
        
        Gtk.Window.__init__(self, title=STRINGS[self.current_lang]['chroot']['title'])
        self.set_default_size(600, 400)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_border_width(10)
        
        self.sys_ops = SystemOperations()
        
        # Sincronizar idioma con sys_ops
        self.sys_ops.current_lang = self.current_lang
        
        # Contenedor principal
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(main_box)
        
        # Etiqueta de título
        title_label = Gtk.Label()
        title_label.set_markup(f"<span size='large' weight='bold'>{STRINGS[self.current_lang]['chroot']['select_disk']}</span>")
        main_box.pack_start(title_label, False, False, 10)
        
        # Lista de discos
        scrolled = Gtk.ScrolledWindow()
        scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        main_box.pack_start(scrolled, True, True, 0)
        
        self.disks_store = Gtk.ListStore(str, str, str)  # Dispositivo, Tamaño, Modelo
        self.disks_view = Gtk.TreeView(model=self.disks_store)
        
        # Columnas
        columns = [
            (STRINGS[self.current_lang]['labels']['device'], 0),
            (STRINGS[self.current_lang]['labels']['size'], 1),
            (STRINGS[self.current_lang]['labels']['model'], 2)
        ]
        
        for title, col_id in columns:
            renderer = Gtk.CellRendererText()
            column = Gtk.TreeViewColumn(title, renderer, text=col_id)
            self.disks_view.append_column(column)
        
        scrolled.add(self.disks_view)
        
        # Botón GParted
        gparted_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['open_gparted'])
        gparted_button.set_use_underline(True)  # Habilitar aceleradores
        gparted_button.connect("clicked", self.on_gparted_clicked)
        main_box.pack_start(gparted_button, False, False, 0)
        
        # Botones inferiores
        button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        main_box.pack_start(button_box, False, False, 0)
        
        close_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['close'])
        close_button.set_use_underline(True)  # Habilitar aceleradores
        close_button.connect("clicked", self.on_close_clicked)
        button_box.pack_start(close_button, True, True, 0)
        
        next_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['next'])
        next_button.set_use_underline(True)  # Habilitar aceleradores
        next_button.connect("clicked", self.on_next_clicked)
        button_box.pack_start(next_button, True, True, 0)
        
        # Cargar discos
        self.load_disks()
    
    def update_current_language(self):
        """Actualiza el idioma actual desde las variables de entorno de manera robusta"""
        try:
            current_locale = os.getenv('LANG', 'en_US.UTF-8')
            new_lang = current_locale.split('_')[0]
            
            # Lista de idiomas válidos
            valid_languages = ['es', 'en', 'pt', 'fr', 'de', 'it', 'ro', 'ru']
            
            if new_lang in valid_languages and new_lang in STRINGS:
                self.current_lang = new_lang
            else:
                # Fallback a inglés si el idioma no está disponible
                self.current_lang = 'en'
                
            print(f"ChRootWindow: Idioma detectado/establecido: {self.current_lang}")
                
        except Exception as e:
            print(f"Error detectando idioma: {e}")
            self.current_lang = 'en'  # Fallback seguro

    def load_disks(self):
        """Carga la lista de discos con manejo robusto de errores"""
        try:
            self.disks_store.clear()
            
            # Actualizar idioma antes de cargar
            self.update_current_language()
            self.sys_ops.update_current_language()
            
            disks = self.sys_ops.get_disks()
            
            if not disks:
                self.show_error(
                    STRINGS[self.current_lang]['dialog']['error'],
                    "No se encontraron discos en el sistema"
                )
                return
            
            for device, size, model in disks:
                self.disks_store.append([device, size, model])
                
            self.sys_ops.logger.info(f"Cargados {len(disks)} discos correctamente")
            
        except Exception as e:
            error_msg = str(e)
            self.sys_ops.logger.error(f"Error cargando discos: {error_msg}")
            self.show_error(
                STRINGS[self.current_lang]['dialog']['error'],
                f"{STRINGS[self.current_lang]['messages']['error_loading_disks']}\n\nDetalle: {error_msg}"
            )

    def on_gparted_clicked(self, button):
        """Ejecuta GParted"""
        try:
            # Ejecutar GParted de forma directa con pkexec
            subprocess.Popen(['pkexec', '/usr/sbin/gparted'], 
                           stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL)
        except Exception as e:
            self.show_error("Error", str(e))
    
    def on_next_clicked(self, button):
        """Procede al siguiente paso con validación mejorada"""
        try:
            # Actualizar idioma por si cambió
            self.update_current_language()
            # También actualizar el idioma en sys_ops
            self.sys_ops.update_current_language()
            
            selection = self.disks_view.get_selection()
            model, iter = selection.get_selected()
            
            # Error messages
            if iter is None:
                self.show_error(
                    STRINGS[self.current_lang]['dialog']['error'],
                    STRINGS[self.current_lang]['dialog']['select_disk']
                )
                return
            
            selected_disk = model[iter][0]
            self.sys_ops.logger.info(f"Disco seleccionado: {selected_disk}")
            
            # Verificar que el disco aún existe y es accesible
            if not os.path.exists(selected_disk):
                self.show_error(
                    STRINGS[self.current_lang]['dialog']['error'],
                    f"El disco seleccionado ya no está disponible: {selected_disk}"
                )
                # Recargar la lista de discos
                self.load_disks()
                return
            
            try:
                # Obtener particiones del disco con timeout
                partitions = self.sys_ops.get_disk_partitions(selected_disk)
                
                if not partitions:
                    self.show_error(
                        STRINGS[self.current_lang]['dialog']['error'],
                        STRINGS[self.current_lang]['dialog']['no_partitions']
                    )
                    return
                
                # Mostrar diálogo de selección de particiones
                self.show_partitions_dialog(partitions)
                
            except Exception as e:
                error_msg = str(e)
                self.sys_ops.logger.error(f"Error obteniendo particiones: {error_msg}")
                self.show_error(
                    STRINGS[self.current_lang]['dialog']['error'],
                    f"{STRINGS[self.current_lang]['messages']['error_loading_partitions']}\n\nDetalle: {error_msg}"
                )
                
        except Exception as e:
            self.sys_ops.logger.error(f"Error inesperado en on_next_clicked: {e}")
            self.show_error(
                STRINGS[self.current_lang]['dialog']['error'],
                f"Error inesperado: {str(e)}"
            )

    def show_partitions_dialog(self, partitions):
        """Muestra diálogo para seleccionar particiones"""
        dialog = Gtk.Dialog(
            title=STRINGS[self.current_lang]['chroot']['select_partitions'],
            parent=self,
            flags=0,
            buttons=(
                STRINGS[self.current_lang]['buttons']['cancel'], Gtk.ResponseType.CANCEL,
                STRINGS[self.current_lang]['buttons']['mount'], Gtk.ResponseType.OK
            )
        )
        dialog.set_default_size(400, 300)
        
        # Habilitar aceleradores en los botones del diálogo
        for button in dialog.get_action_area().get_children():
            button.set_use_underline(True)
        
        box = dialog.get_content_area()
        box.set_spacing(10)
        box.set_border_width(10)
        
        if not partitions:
            label = Gtk.Label(label=STRINGS[self.current_lang]['dialog']['no_partitions'])
            box.pack_start(label, False, False, 0)
            box.show_all()
            dialog.run()
            dialog.destroy()
            return
            
        label = Gtk.Label(label=STRINGS[self.current_lang]['dialog']['partition_header'])
        box.pack_start(label, False, False, 0)
        
        # Lista de particiones
        grid = Gtk.Grid()
        grid.set_column_spacing(10)
        grid.set_row_spacing(5)
        
        # Crear los encabezados
        headers = [
            STRINGS[self.current_lang]['labels']['mountpoint'],
            STRINGS[self.current_lang]['labels']['device'],
            STRINGS[self.current_lang]['labels']['size'],
            STRINGS[self.current_lang]['labels']['filesystem']
        ]
        for i, header in enumerate(headers):
            label = Gtk.Label(label=header)
            label.set_markup(f"<b>{header}</b>")
            grid.attach(label, i, 0, 1, 1)
        
        # Crear las filas de particiones
        mount_points = ['/', '/boot', '/boot/efi', '/home']
        self.partition_combos = {}
        
        for i, mount in enumerate(mount_points, 1):
            # Etiqueta del punto de montaje
            mount_label = Gtk.Label(label=mount)
            mount_label.set_halign(Gtk.Align.START)
            grid.attach(mount_label, 0, i, 1, 1)
            
            # Combo para seleccionar partición
            combo = Gtk.ComboBoxText()
            combo.append_text(STRINGS[self.current_lang]['labels']['select_option'])
            for part in partitions:
                text = f"{part['device']} ({part['size']} - {part['fstype']})"
                combo.append_text(text)
            combo.set_active(0)
            
            # Si hay una sugerencia, seleccionarla
            for j, part in enumerate(partitions, 1):
                if part.get('suggested_mount') == mount:
                    combo.set_active(j)
                    break
            
            self.partition_combos[mount] = combo
            grid.attach(combo, 1, i, 3, 1)
        
        box.pack_start(grid, True, True, 0)
        box.show_all()
        
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            self.process_selected_partitions()
        
        dialog.destroy()
    
    def process_selected_partitions(self):
        """Procesa las particiones seleccionadas y ejecuta el chroot con validación robusta"""
        try:
            # Actualizar idioma por si cambió
            self.update_current_language()
            self.sys_ops.update_current_language()
            
            mount_points = {}
            for mount, combo in self.partition_combos.items():
                device = combo.get_active_text()
                if device and device != STRINGS[self.current_lang]['labels']['select_option']:
                    device = device.split()[0]  # Obtener solo el dispositivo
                    
                    # Validar que el dispositivo existe
                    if not os.path.exists(device):
                        self.show_error(
                            STRINGS[self.current_lang]['dialog']['error'],
                            f"La partición {device} ya no está disponible"
                        )
                        return
                    
                    mount_points[mount] = device

            if '/' not in mount_points:
                self.show_error(
                    STRINGS[self.current_lang]['dialog']['error'],
                    STRINGS[self.current_lang]['dialog']['select_root']
                )
                return

            # Validar que todas las particiones seleccionadas son diferentes
            devices = list(mount_points.values())
            if len(devices) != len(set(devices)):
                self.show_error(
                    STRINGS[self.current_lang]['dialog']['error'],
                    "No se puede usar la misma partición para múltiples puntos de montaje"
                )
                return

            # Mostrar un diálogo de progreso
            self.show_progress_dialog(mount_points)
            
        except Exception as e:
            self.sys_ops.logger.error(f"Error procesando particiones: {e}")
            self.show_error(
                STRINGS[self.current_lang]['dialog']['error'], 
                f"Error procesando particiones: {str(e)}"
            )

    def show_progress_dialog(self, mount_points):
        """Muestra un diálogo de progreso mientras se monta y prepara el chroot"""
        dialog = Gtk.Dialog(
            title=STRINGS[self.current_lang]['dialog'].get('mounting', "Montando particiones"),
            parent=self,
            flags=0,
            buttons=(
                STRINGS[self.current_lang]['buttons']['close'], Gtk.ResponseType.CLOSE,
            )
        )
        dialog.set_default_size(400, 100)
        dialog.set_modal(True)
        
        # Habilitar aceleradores en los botones del diálogo
        for button in dialog.get_action_area().get_children():
            button.set_use_underline(True)
        
        box = dialog.get_content_area()
        box.set_spacing(10)
        box.set_border_width(10)
        
        label = Gtk.Label(label=STRINGS[self.current_lang]['messages'].get(
            'mounting_partitions', "Montando particiones y preparando entorno chroot..."))
        box.pack_start(label, False, False, 0)
        
        progress_bar = Gtk.ProgressBar()
        progress_bar.set_fraction(0.0)
        box.pack_start(progress_bar, False, False, 5)
        
        status_label = Gtk.Label(label="")
        box.pack_start(status_label, False, False, 0)
        
        box.show_all()
        
        # Actualizar progreso y ejecutar chroot
        def update_progress():
            try:
                # Montar particiones y ejecutar chroot
                status_label.set_text("Preparando particiones...")
                progress_bar.set_fraction(0.3)
                while Gtk.events_pending():
                    Gtk.main_iteration()
                
                progress_bar.set_fraction(0.5)
                status_label.set_text("Montando sistemas de archivos...")
                while Gtk.events_pending():
                    Gtk.main_iteration()
                
                self.sys_ops.mount_and_chroot(
                    root_part=mount_points['/'],
                    boot_part=mount_points.get('/boot'),
                    efi_part=mount_points.get('/boot/efi')
                )
                
                progress_bar.set_fraction(1.0)
                status_label.set_text("Chroot iniciado correctamente")
                
                # Cerrar el diálogo automáticamente después de 2 segundos
                GLib.timeout_add(2000, dialog.response, Gtk.ResponseType.CLOSE)
                
            except Exception as e:
                progress_bar.set_fraction(0.0)
                status_label.set_markup(f"<span color='red'>Error: {str(e)}</span>")
                
            return False
        
        # Iniciar la tarea después de mostrar el diálogo
        GLib.idle_add(update_progress)
        
        # Ejecutar el diálogo
        dialog.run()
        dialog.destroy()
    
    def on_close_clicked(self, button):
        """Cierra la ventana con limpieza segura"""
        try:
            # Asegurar que cualquier operación pendiente se limpie
            self.sys_ops.unmount_all()
            self.clean_pycache()  # Limpiar al cerrar
            self.destroy()
        except Exception as e:
            self.sys_ops.logger.error(f"Error al cerrar ventana: {e}")
            self.destroy()  # Cerrar de todos modos
    
    def show_error(self, title, message):
        """Muestra un diálogo de error"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=STRINGS[self.current_lang]['dialog']['error']
        )
        dialog.format_secondary_text(message)
        dialog.run()
        dialog.destroy()
    
    def clean_pycache(self):
        """Limpia todos los archivos __pycache__ del proyecto"""
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        for root, dirs, files in os.walk(base_dir):
            if '__pycache__' in dirs:
                shutil.rmtree(os.path.join(root, '__pycache__'))
