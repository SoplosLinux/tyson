#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import subprocess
import json
import time

def get_desktop_environment():
    """Detecta el entorno de escritorio actual y tipo de sesión"""
    desktop = os.getenv('XDG_CURRENT_DESKTOP', '').lower()
    session = os.getenv('DESKTOP_SESSION', '').lower()
    session_type = os.getenv('XDG_SESSION_TYPE', '').lower()
    
    # Determinar el tipo de sesión (wayland o x11)
    if not session_type:
        # Intentar detectar por variables alternativas
        if os.getenv('WAYLAND_DISPLAY'):
            session_type = 'wayland'
        elif os.getenv('DISPLAY'):
            session_type = 'x11'
        else:
            session_type = 'x11'  # Default a X11 si no se detecta
    
    # Para esta versión, solo nos enfocamos en KDE
    is_kde = 'kde' in desktop or 'plasma' in desktop or 'kde' in session
    
    return 'kde' if is_kde else 'unknown'

def get_session_type():
    """Detecta si estamos en una sesión Wayland o X11"""
    session_type = os.getenv('XDG_SESSION_TYPE', '').lower()
    
    if not session_type:
        if os.getenv('WAYLAND_DISPLAY'):
            return 'wayland'
        elif os.getenv('DISPLAY'):
            return 'x11'
        else:
            return 'x11'  # Default a X11 si no se puede determinar
    
    return session_type

def save_language_preference(lang_code):
    """Guarda la preferencia de idioma del usuario"""
    config_dir = os.path.expanduser('~/.config/soplos-welcome-live')
    os.makedirs(config_dir, exist_ok=True)
    
    with open(os.path.join(config_dir, 'language'), 'w') as f:
        f.write(lang_code)

def load_language_preference():
    """Carga la preferencia de idioma del usuario"""
    config_file = os.path.expanduser('~/.config/soplos-welcome-live/language')
    if os.path.exists(config_file):
        with open(config_file, 'r') as f:
            lang_code = f.read().strip()
            # La validación del código de idioma se hará en el caller
            return lang_code
    return None

def get_kde_version():
    """
    Obtiene la versión de KDE/Plasma si está disponible
    
    Returns:
        str: Versión de KDE Plasma o None si no es KDE o no se puede determinar
    """
    try:
        output = subprocess.check_output(['plasmashell', '--version'], text=True).strip()
        version = output.split(' ')[-1] if ' ' in output else output
        return version
    except Exception:
        return None

def backup_kde_theme_config():
    """Guarda la configuración actual de temas de KDE"""
    try:
        config_dir = os.path.expanduser('~/.config/soplos-welcome-live')
        os.makedirs(config_dir, exist_ok=True)
        theme_config = {}
        
        # Obtener tema actual
        try:
            theme_config['color_scheme'] = subprocess.check_output([
                'kreadconfig5', '--file', 'kdeglobals', 
                '--group', 'General', '--key', 'ColorScheme'
            ], text=True).strip()
        except:
            pass
            
        # Obtener tema de iconos
        try:
            theme_config['icon_theme'] = subprocess.check_output([
                'kreadconfig5', '--file', 'kdeglobals',
                '--group', 'Icons', '--key', 'Theme'
            ], text=True).strip()
        except:
            pass
            
        # Obtener tema de widget
        try:
            theme_config['widget_style'] = subprocess.check_output([
                'kreadconfig5', '--file', 'kdeglobals',
                '--group', 'KDE', '--key', 'widgetStyle'
            ], text=True).strip()
        except:
            pass
        
        # Guardar configuración
        with open(os.path.join(config_dir, 'theme_backup.json'), 'w') as f:
            json.dump(theme_config, f)
        
        return True
    except Exception as e:
        print(f"Error al hacer backup de la configuración de temas: {e}")
        return False

def restore_kde_theme_config():
    """Restaura la configuración de temas de KDE previamente guardada"""
    try:
        theme_file = os.path.expanduser('~/.config/soplos-welcome-live/theme_backup.json')
        if not os.path.exists(theme_file):
            return False
        
        with open(theme_file, 'r') as f:
            theme_config = json.load(f)
        
        # Restaurar tema de color
        if 'color_scheme' in theme_config and theme_config['color_scheme']:
            subprocess.run([
                'kwriteconfig5', '--file', 'kdeglobals',
                '--group', 'General', '--key', 'ColorScheme', theme_config['color_scheme']
            ], check=False)
        
        # Restaurar tema de iconos
        if 'icon_theme' in theme_config and theme_config['icon_theme']:
            subprocess.run([
                'kwriteconfig5', '--file', 'kdeglobals',
                '--group', 'Icons', '--key', 'Theme', theme_config['icon_theme']
            ], check=False)
        
        # Restaurar tema de widgets
        if 'widget_style' in theme_config and theme_config['widget_style']:
            subprocess.run([
                'kwriteconfig5', '--file', 'kdeglobals',
                '--group', 'KDE', '--key', 'widgetStyle', theme_config['widget_style']
            ], check=False)
        
        # Aplicar cambios recargando configuraciones
        subprocess.run([
            'qdbus', 'org.kde.KWin', '/KWin', 'reconfigure'
        ], check=False)
        
        subprocess.run([
            'qdbus', 'org.kde.plasma-desktop', '/MainApplication', 'reparseConfiguration'
        ], check=False)
        
        return True
    except Exception as e:
        print(f"Error al restaurar la configuración de temas: {e}")
        return False

def has_autologin_enabled():
    """Verifica si el autologin está activado en SDDM"""
    try:
        # Comprobar si existe configuración de autologin en SDDM
        sddm_conf_paths = [
            '/etc/sddm.conf',
            '/etc/sddm.conf.d/autologin.conf',
            '/usr/lib/sddm/sddm.conf.d/autologin.conf'
        ]
        
        for conf_path in sddm_conf_paths:
            if os.path.exists(conf_path):
                with open(conf_path, 'r') as f:
                    content = f.read()
                    if '[Autologin]' in content and 'User=' in content:
                        return True
        
        return False
    except Exception as e:
        print(f"Error verificando autologin: {e}")
        return False

def create_restart_script():
    """Crea un script para reiniciar SDDM preservando autologin y temas"""
    try:
        # Crear script de restauración
        script_content = """#!/bin/bash
# Script para reiniciar SDDM de forma segura

# 1. Verificar si existe autologin
AUTOLOGIN_ENABLED=false
AUTOLOGIN_USER=""

check_autologin() {
    local conf_file="$1"
    if [ -f "$conf_file" ]; then
        if grep -q "\\[Autologin\\]" "$conf_file" && grep -q "User=" "$conf_file"; then
            AUTOLOGIN_ENABLED=true
            AUTOLOGIN_USER=$(grep "User=" "$conf_file" | head -1 | cut -d= -f2)
            return 0
        fi
    fi
    return 1
}

# Revisar archivos de configuración de SDDM
check_autologin "/etc/sddm.conf" || \\
check_autologin "/etc/sddm.conf.d/autologin.conf" || \\
check_autologin "/usr/lib/sddm/sddm.conf.d/autologin.conf"

# 2. Restaurar configuración de autologin si es necesario
if [ "$AUTOLOGIN_ENABLED" = true ] && [ -n "$AUTOLOGIN_USER" ]; then
    echo "Autologin detectado para el usuario: $AUTOLOGIN_USER"
    
    # Aseguramos que la configuración se restaurará
    if [ ! -f "/etc/sddm.conf.d/autologin.conf" ]; then
        mkdir -p /etc/sddm.conf.d/
        cat > /etc/sddm.conf.d/autologin.conf << EOF
[Autologin]
User=$AUTOLOGIN_USER
Session=plasma.desktop
Relogin=true
EOF
    fi
fi

# 3. Reiniciar SDDM
systemctl restart sddm
"""
        
        script_path = '/tmp/restart_sddm_safely.sh'
        with open(script_path, 'w') as f:
            f.write(script_content)
        
        os.chmod(script_path, 0o755)
        return script_path
    except Exception as e:
        print(f"Error al crear script de reinicio: {e}")
        return None

def restart_sddm_safely():
    """Reinicia SDDM de manera segura preservando autologin y temas"""
    try:
        # 1. Hacer backup de la configuración de temas
        backup_kde_theme_config()
        
        # 2. Crear script de reinicio
        script_path = create_restart_script()
        if not script_path:
            raise Exception("Error al crear script de reinicio")
        
        # 3. Crear marca de reinicio para detectarlo después
        config_dir = os.path.expanduser('~/.config/soplos-welcome-live')
        os.makedirs(config_dir, exist_ok=True)
        
        restart_state = {
            'restarted': True,
            'time': time.time()
        }
        
        with open(os.path.join(config_dir, 'restart_state.json'), 'w') as f:
            json.dump(restart_state, f)
        
        # 4. Ejecutar el script con pkexec
        subprocess.run(['pkexec', script_path], check=True)
        
        return True
    except Exception as e:
        print(f"Error al reiniciar SDDM: {e}")
        return False

def update_kde_locale(locale):
    """Actualiza la configuración de locale en KDE"""
    try:
        # Configuración de locale en KDE
        subprocess.run([
            'kwriteconfig5', '--file', 'plasma-localerc',
            '--group', 'Translations',
            '--key', 'LANGUAGE', locale.split('.')[0]
        ], check=False)
        
        # Recargar la configuración
        subprocess.run([
            'qdbus', 'org.kde.klauncher', '/KLauncher', 'reparseConfiguration'
        ], check=False)
        
        subprocess.run([
            'qdbus', 'org.kde.plasma.session', '/MainApplication', 'refreshX11Connection'
        ], check=False)
    except Exception as e:
        print(f"Error al actualizar locale de KDE: {e}")
