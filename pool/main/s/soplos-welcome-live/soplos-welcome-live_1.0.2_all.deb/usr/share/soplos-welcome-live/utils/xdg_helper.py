#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import subprocess
import shutil
from utils.desktop_detector import get_session_type

class XDGDirectoriesManager:
    """Gestiona los directorios XDG de manera simple"""
    
    def __init__(self):
        self.home_dir = os.path.expanduser('~')
        self.config_dir = os.path.join(self.home_dir, '.config')
        self.user_dirs_path = os.path.join(self.config_dir, 'user-dirs.dirs')
        self.session_type = get_session_type()
    
    def update_directories(self, locale):
        """Renombra los directorios XDG según el locale proporcionado de forma más robusta"""
        try:
            lang_code = locale.split('_')[0]
            print(f"Actualizando directorios XDG para locale: {locale}")
            
            # 1. Configurar y aplicar variables de entorno antes de ejecutar xdg-user-dirs-update
            env = os.environ.copy()
            env['LANG'] = locale
            env['LC_ALL'] = locale
            env['LANGUAGE'] = locale.split('_')[0]
            os.environ['LANG'] = locale  # También establecerla en el entorno actual
            os.environ['LC_ALL'] = locale
            os.environ['LANGUAGE'] = locale.split('_')[0]
            
            # 2. Primero realizar backup de configuración actual en caso de error
            user_dirs_backup = "/tmp/user-dirs.dirs.backup"
            if os.path.exists(self.user_dirs_path):
                shutil.copy2(self.user_dirs_path, user_dirs_backup)
                print("Backup de user-dirs.dirs creado")
            
            # 3. Eliminar el archivo user-dirs.dirs existente para forzar regeneración completa
            if os.path.exists(self.user_dirs_path):
                os.unlink(self.user_dirs_path)
                print("Archivo user-dirs.dirs eliminado para regeneración")
            
            # 4. Regenerar user-dirs.dirs explícitamente para el nuevo locale
            print("Ejecutando xdg-user-dirs-update --force...")
            update_result = subprocess.run(['xdg-user-dirs-update', '--force'], 
                                          env=env, capture_output=True, text=True)
            print(f"Resultado: {update_result.stdout}")
            print(f"Errores: {update_result.stderr}")
            
            # 5. Verificar si se generó correctamente
            if not os.path.exists(self.user_dirs_path):
                print("Error: No se ha creado user-dirs.dirs")
                # Intentar recuperar del backup
                if os.path.exists(user_dirs_backup):
                    shutil.copy2(user_dirs_backup, self.user_dirs_path)
                    print("Restaurado desde backup")
            
            # 6. Actualizar también la configuración de GTK si existe
            if shutil.which('xdg-user-dirs-gtk-update'):
                print("Actualizando configuración GTK...")
                subprocess.run(['xdg-user-dirs-gtk-update', '--force'], 
                              env=env, check=False)
            
            # 7. Renombrar físicamente los directorios si es necesario
            # (El método existente ya es adecuado)
            self._rename_physical_directories(locale)
            
            # 8. Actualizar entorno de escritorio para que reconozca los cambios
            print("Actualizando referencias de directorios en el entorno de escritorio...")
            self._update_kde_directory_references(lang_code)
            
            # 9. Ejecutar un comando adicional para forzar la actualización en entorno gráfico
            subprocess.run(['xdg-user-dirs-update', '--force'], check=False)
            
            # Mostrar contenido del archivo generado para diagnóstico
            if os.path.exists(self.user_dirs_path):
                with open(self.user_dirs_path, 'r') as f:
                    print(f"Contenido de user-dirs.dirs:\n{f.read()}")
            
            return True
        except Exception as e:
            print(f"Error actualizando directorios XDG: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _generate_xdg_config(self, locale):
        """Genera configuración de directorios XDG según el locale"""
        lang_code = locale.split('_')[0]
        
        # Mapeo de directorios según idioma
        dir_names = {
            'es': {
                'DESKTOP': 'Escritorio',
                'DOWNLOAD': 'Descargas',
                'DOCUMENTS': 'Documentos',
                'MUSIC': 'Música',
                'PICTURES': 'Imágenes',
                'VIDEOS': 'Vídeos',
                'PUBLICSHARE': 'Público',
                'TEMPLATES': 'Plantillas'
            },
            'en': {
                'DESKTOP': 'Desktop',
                'DOWNLOAD': 'Downloads',
                'DOCUMENTS': 'Documents',
                'MUSIC': 'Music',
                'PICTURES': 'Pictures',
                'VIDEOS': 'Videos',
                'PUBLICSHARE': 'Public',
                'TEMPLATES': 'Templates'
            },
            'fr': {
                'DESKTOP': 'Bureau',
                'DOWNLOAD': 'Téléchargements',
                'DOCUMENTS': 'Documents',
                'MUSIC': 'Musique',
                'PICTURES': 'Images',
                'VIDEOS': 'Vidéos',
                'PUBLICSHARE': 'Public',
                'TEMPLATES': 'Modèles'
            },
            'de': {
                'DESKTOP': 'Schreibtisch',
                'DOWNLOAD': 'Downloads',
                'DOCUMENTS': 'Dokumente',
                'MUSIC': 'Musik',
                'PICTURES': 'Bilder',
                'VIDEOS': 'Videos',
                'PUBLICSHARE': 'Öffentlich',
                'TEMPLATES': 'Vorlagen'
            }
        }
        
        if lang_code not in dir_names:
            return None
        
        config_content = "# This file is written by xdg-user-dirs-update\n"
        config_content += "# If you want to change or add directories, just edit the line you're\n"
        config_content += "# interested in. All local changes will be retained on the next run.\n"
        config_content += "# Format is XDG_xxx_DIR=\"$HOME/yyy\", where yyy is a shell-escaped\n"
        config_content += "# homedir-relative path, or XDG_xxx_DIR=\"/yyy\", where /yyy is an\n"
        config_content += "# absolute path. No other format is supported.\n\n"
        
        for xdg_name, local_name in dir_names[lang_code].items():
            config_content += f'XDG_{xdg_name}_DIR="$HOME/{local_name}"\n'
        
        return config_content
    
    def _rename_physical_directories(self, locale):
        """Renombra físicamente los directorios existentes sin duplicarlos"""
        try:
            # Extraer el código de idioma del locale
            lang_code = locale.split('_')[0]
            print(f"Renombrando directorios para el idioma: {lang_code}")
            
            # Mapeo de nombres para cada idioma
            directory_names = {
                'es': {
                    'Desktop': 'Escritorio',
                    'Downloads': 'Descargas',
                    'Documents': 'Documentos',
                    'Music': 'Música',
                    'Pictures': 'Imágenes',
                    'Videos': 'Vídeos',
                    'Public': 'Público',
                    'Templates': 'Plantillas'
                },
                'en': {
                    'Escritorio': 'Desktop',
                    'Descargas': 'Downloads',
                    'Documentos': 'Documents',
                    'Música': 'Music',
                    'Imágenes': 'Pictures',
                    'Vídeos': 'Videos',
                    'Público': 'Public',
                    'Plantillas': 'Templates'
                },
                'fr': {
                    'Desktop': 'Bureau',
                    'Downloads': 'Téléchargements',
                    'Documents': 'Documents',
                    'Music': 'Musique',
                    'Pictures': 'Images',
                    'Videos': 'Vidéos',
                    'Public': 'Public',
                    'Templates': 'Modèles'
                },
                'de': {
                    'Desktop': 'Schreibtisch',
                    'Downloads': 'Downloads',
                    'Documents': 'Dokumente',
                    'Music': 'Musik',
                    'Pictures': 'Bilder',
                    'Videos': 'Videos',
                    'Public': 'Öffentlich',
                    'Templates': 'Vorlagen'
                },
                'it': {
                    'Desktop': 'Scrivania',
                    'Downloads': 'Scaricati',
                    'Documents': 'Documenti',
                    'Music': 'Musica',
                    'Pictures': 'Immagini',
                    'Videos': 'Video',
                    'Public': 'Pubblici',
                    'Templates': 'Modelli'
                },
                'pt': {
                    'Desktop': 'Área de Trabalho',
                    'Downloads': 'Transferências',
                    'Documents': 'Documentos',
                    'Music': 'Música',
                    'Pictures': 'Imagens',
                    'Videos': 'Vídeos',
                    'Public': 'Público',
                    'Templates': 'Modelos'
                },
                'ru': {
                    'Desktop': 'Рабочий стол',
                    'Downloads': 'Загрузки',
                    'Documents': 'Документы',
                    'Music': 'Музыка',
                    'Pictures': 'Изображения',
                    'Videos': 'Видео',
                    'Public': 'Общедоступные',
                    'Templates': 'Шаблоны'
                },
                'ro': {
                    'Desktop': 'Desktop',
                    'Downloads': 'Descărcări',
                    'Documents': 'Documente',
                    'Music': 'Muzică',
                    'Pictures': 'Poze',
                    'Videos': 'Videoclipuri',
                    'Public': 'Public',
                    'Templates': 'Șabloane'
                }
            }
            
            # Si no hay mapeo para el idioma, no hacer nada
            if lang_code not in directory_names:
                print(f"No hay mapeo de directorios para el idioma: {lang_code}")
                return
            
            # Para cada par de directorios (origen -> destino)
            for src_name, dst_name in directory_names[lang_code].items():
                src_path = os.path.join(self.home_dir, src_name)
                dst_path = os.path.join(self.home_dir, dst_name)
                
                # CASO 1: Ambos existen - migrar el contenido y eliminar el original
                if os.path.exists(src_path) and os.path.exists(dst_path):
                    print(f"Ambos directorios existen. Migrando contenido: {src_path} → {dst_path}")
                    # Migrar todos los archivos de src a dst
                    try:
                        for item in os.listdir(src_path):
                            item_src = os.path.join(src_path, item)
                            item_dst = os.path.join(dst_path, item)
                            
                            # Si es un directorio, usar copytree
                            if os.path.isdir(item_src):
                                if not os.path.exists(item_dst):
                                    shutil.copytree(item_src, item_dst)
                                else:
                                    # Si ya existe, fusionar recursivamente
                                    for subitem in os.listdir(item_src):
                                        sub_src = os.path.join(item_src, subitem)
                                        sub_dst = os.path.join(item_dst, subitem)
                                        if os.path.isdir(sub_src):
                                            if not os.path.exists(sub_dst):
                                                shutil.copytree(sub_src, sub_dst)
                                        elif not os.path.exists(sub_dst):
                                            shutil.copy2(sub_src, sub_dst)
                            # Si es un archivo, usar copy2 para preservar metadatos
                            elif not os.path.exists(item_dst):
                                shutil.copy2(item_src, item_dst)
                        
                        # Eliminar el directorio origen después de migrar todo
                        shutil.rmtree(src_path)
                        print(f"Contenido migrado y directorio {src_path} eliminado")
                    except Exception as e:
                        print(f"Error consolidando directorios: {e}")
                
                # CASO 2: Solo existe el origen - renombrar directamente
                elif os.path.exists(src_path) and not os.path.exists(dst_path):
                    print(f"Renombrando: {src_path} → {dst_path}")
                    try:
                        # Crear el directorio padre si es necesario
                        parent_dir = os.path.dirname(dst_path)
                        if not os.path.exists(parent_dir):
                            os.makedirs(parent_dir, exist_ok=True)
                        # Renombrar el directorio
                        os.rename(src_path, dst_path)
                    except Exception as e:
                        print(f"Error renombrando {src_path}: {e}")
                
                # CASO 3: Solo existe el destino - no hacer nada
                elif os.path.exists(dst_path):
                    print(f"El directorio destino {dst_path} ya existe, se mantiene")
                
                # CASO 4: Ninguno existe - no crear directorios automáticamente
                else:
                    print(f"Ningún directorio existe: {src_path} ni {dst_path}")

            # Actualizar el ambiente de escritorio específicamente para el directorio Desktop/Escritorio
            self._update_kde_directory_references(lang_code)
            
        except Exception as e:
            print(f"Error general en renombrado de directorios: {e}")
            import traceback
            traceback.print_exc()
    
    def _update_kde_directory_references(self, lang_code):
        """Actualiza las referencias a directorios en KDE"""
        try:
            # Actualizar referencias en Plasma
            subprocess.run([
                'kwriteconfig5', '--file', 'dolphinrc',
                '--group', 'General', '--key', 'HomeUrl',
                f'file://{self.home_dir}'
            ], check=False)
            
            # Actualizar escritorio para que muestre los iconos
            desktop_path = os.path.join(self.home_dir, 'Desktop')
            if lang_code == 'es':
                desktop_path = os.path.join(self.home_dir, 'Escritorio')
            elif lang_code == 'pt':
                desktop_path = os.path.join(self.home_dir, 'Área de Trabalho')
            elif lang_code == 'fr':
                desktop_path = os.path.join(self.home_dir, 'Bureau')
            elif lang_code == 'de':
                desktop_path = os.path.join(self.home_dir, 'Schreibtisch')
            elif lang_code == 'it':
                desktop_path = os.path.join(self.home_dir, 'Scrivania')
            
            # Actualizar configuración de plasma para el escritorio
            subprocess.run([
                'kwriteconfig5', '--file', 'plasma-org.kde.plasma.desktop-appletsrc',
                '--group', 'Containments', '--group', '1', '--group', 'General',
                '--key', 'url', f'file://{desktop_path}'
            ], check=False)
            
            # Forzar refresco del plasma shell
            subprocess.run(['qdbus', 'org.kde.plasmashell', '/PlasmaShell', 
                           'org.kde.PlasmaShell.evaluateScript', 
                           'refreshCurrentShell()'], check=False)
        except Exception as e:
            print(f"Error actualizando referencias KDE: {e}")

# Instancia global para uso directo
xdg_manager = XDGDirectoriesManager()
