#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import subprocess
import json
import time
import shutil
import logging

class XDGDirectoriesManager:
    """Gestiona los directorios XDG de manera compatible con todos los idiomas"""
    
    def __init__(self):
        self.home_dir = os.path.expanduser('~')
        self.user_dirs_path = os.path.join(self.home_dir, '.config/user-dirs.dirs')
        self.logger = logging.getLogger(__name__)
    
    def update_directories(self, locale):
        """Actualiza los directorios XDG según el locale proporcionado"""
        try:
            # 1. Hacer backup del archivo original
            if os.path.exists(self.user_dirs_path):
                backup_path = f"{self.user_dirs_path}.backup"
                shutil.copy2(self.user_dirs_path, backup_path)
                print(f"Backup creado en {backup_path}")
            
            # 2. Leer la configuración actual
            current_dirs = self._read_user_dirs()
            print(f"Configuración actual: {json.dumps(current_dirs, indent=2)}")
            
            # 3. Usar xdg-user-dirs-update para generar nuevos directorios
            print(f"Actualizando directorios con locale {locale}")
            env = os.environ.copy()
            env['LANG'] = locale
            env['LC_ALL'] = locale
            
            # Llamar al comando dos veces con --force para asegurar la actualización
            subprocess.run(['xdg-user-dirs-update', '--force'], env=env, check=False)
            time.sleep(1)  # Dar tiempo al sistema para procesar
            subprocess.run(['xdg-user-dirs-update'], env=env, check=False)
            
            # 4. Leer la configuración actualizada
            new_dirs = self._read_user_dirs()
            print(f"Nueva configuración: {json.dumps(new_dirs, indent=2)}")
            
            # 5. Realizar la migración de archivos si es necesario
            self._migrate_contents(current_dirs, new_dirs)
            
            # 6. Asegurar que los cambios se muestren en el sistema de archivos
            self._update_desktop_environment()
            
            # 7. Manejar el caso específico de la papelera
            self._update_trash_icon(locale)
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error actualizando directorios XDG: {e}")
            # Intentar restaurar el backup si algo salió mal
            if os.path.exists(f"{self.user_dirs_path}.backup"):
                shutil.copy2(f"{self.user_dirs_path}.backup", self.user_dirs_path)
            return False
    
    def _read_user_dirs(self):
        """Lee la configuración de directorios XDG"""
        dirs = {}
        if os.path.exists(self.user_dirs_path):
            try:
                with open(self.user_dirs_path, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if line.startswith('XDG_') and '=' in line:
                            key, value = line.split('=', 1)
                            # Limpiar las comillas y $HOME/
                            value = value.strip('"\'').replace('$HOME/', '')
                            dirs[key] = value
            except Exception as e:
                self.logger.error(f"Error leyendo {self.user_dirs_path}: {e}")
        return dirs
    
    def _migrate_contents(self, old_dirs, new_dirs):
        """Migra el contenido entre los directorios antiguos y nuevos"""
        changed_dirs = []
        
        # Identificar directorios que han cambiado
        for key, old_path in old_dirs.items():
            if key in new_dirs and old_path != new_dirs[key]:
                old_full_path = os.path.join(self.home_dir, old_path)
                new_full_path = os.path.join(self.home_dir, new_dirs[key])
                
                if os.path.exists(old_full_path) and os.path.isdir(old_full_path):
                    changed_dirs.append((key, old_full_path, new_full_path))
        
        # Migrar los directorios cambiados
        for key, old_path, new_path in changed_dirs:
            print(f"Migrando {key}: {old_path} -> {new_path}")
            
            # Crear directorio nuevo si no existe
            os.makedirs(new_path, exist_ok=True)
            
            try:
                # Mover contenido (no el directorio en sí)
                for item in os.listdir(old_path):
                    src = os.path.join(old_path, item)
                    dst = os.path.join(new_path, item)
                    
                    # Si el destino ya existe, añadir sufijo
                    if os.path.exists(dst):
                        name, ext = os.path.splitext(item)
                        dst = os.path.join(new_path, f"{name}_{int(time.time())}{ext}")
                    
                    # Mover el archivo/directorio
                    if os.path.isdir(src):
                        shutil.copytree(src, dst)
                        shutil.rmtree(src)
                    else:
                        shutil.copy2(src, dst)
                        os.unlink(src)
                
                # Eliminar directorio antiguo si está vacío
                if not os.listdir(old_path):
                    os.rmdir(old_path)
            except Exception as e:
                self.logger.error(f"Error migrando {old_path} -> {new_path}: {e}")
    
    def _update_desktop_environment(self):
        """Notifica al entorno de escritorio sobre los cambios"""
        try:
            # Para KDE/Plasma
            subprocess.run(['kbuildsycoca5'], check=False)
            subprocess.run(['kbuildsycoca6'], check=False)  # Plasma 6
            
            # Refrescar escritorio
            subprocess.run(['qdbus', 'org.kde.plasmashell', '/PlasmaShell', 
                          'evaluateScript', 'refreshCurrentShell()'], check=False)
        except Exception as e:
            self.logger.error(f"Error actualizando entorno de escritorio: {e}")
    
    def _update_trash_icon(self, locale):
        """Actualiza el icono de la papelera según el idioma"""
        try:
            # Mapeo de nombres de la papelera según idioma
            trash_names = {
                'es_ES': 'Papelera',
                'en_US': 'Trash',
                'pt_PT': 'Lixeira',
                'fr_FR': 'Corbeille',
                'de_DE': 'Papierkorb',
                'it_IT': 'Cestino',
                'ru_RU': 'Корзина',
                'ro_RO': 'Coș de gunoi'
            }
            
            # Obtener código de idioma base
            lang_code = locale.split('_')[0]
            
            # Buscar el desktop dir actual
            new_dirs = self._read_user_dirs()
            if 'XDG_DESKTOP_DIR' in new_dirs:
                desktop_path = os.path.join(self.home_dir, new_dirs['XDG_DESKTOP_DIR'])
                
                # Buscar archivos .desktop de la papelera
                trash_files = []
                if os.path.exists(desktop_path):
                    for item in os.listdir(desktop_path):
                        if item.endswith('.desktop') and ('trash' in item.lower() or 
                                                         'papelera' in item.lower() or
                                                         'lixeira' in item.lower()):
                            trash_files.append(os.path.join(desktop_path, item))
                
                # Por cada archivo de la papelera, actualizar el nombre
                for trash_file in trash_files:
                    print(f"Actualizando archivo de papelera: {trash_file}")
                    
                    # Leer contenido
                    with open(trash_file, 'r') as f:
                        content = f.read()
                    
                    # Encontrar la traducción correcta
                    trash_name = None
                    # Buscar coincidencia exacta primero
                    if locale in trash_names:
                        trash_name = trash_names[locale]
                    # Si no hay coincidencia exacta, usar el código de idioma
                    elif lang_code in trash_names:
                        for loc, name in trash_names.items():
                            if loc.startswith(lang_code):
                                trash_name = name
                                break
                    
                    # Si aún no tenemos traducción, usar inglés
                    if not trash_name:
                        trash_name = trash_names.get('en_US', 'Trash')
                    
                    # Reemplazar línea Name= con la traducción correcta
                    new_content = []
                    for line in content.split('\n'):
                        if line.startswith('Name='):
                            new_content.append(f"Name={trash_name}")
                        else:
                            new_content.append(line)
                    
                    # Guardar el archivo actualizado
                    with open(trash_file, 'w') as f:
                        f.write('\n'.join(new_content))
                    
                    print(f"Papelera actualizada a: {trash_name}")
        except Exception as e:
            self.logger.error(f"Error actualizando icono de papelera: {e}")

# Instancia global para uso directo
xdg_manager = XDGDirectoriesManager()
