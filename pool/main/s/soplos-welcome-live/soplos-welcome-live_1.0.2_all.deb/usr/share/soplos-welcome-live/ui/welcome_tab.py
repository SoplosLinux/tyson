import gi
import webbrowser
import subprocess
import os
import sys

# Añadir el directorio raíz al path de Python
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GdkPixbuf
from config.strings import STRINGS  # Cambiar la importación
from config.paths import SLIDE_PATH  # Añadir importación de SLIDE_PATH

# Diccionario de idiomas y sus configuraciones
LANGUAGES = {
    'Español': {'locale': 'es_ES.UTF-8', 'layout': 'es'},
    'English': {'locale': 'en_US.UTF-8', 'layout': 'us'},
    'Português': {'locale': 'pt_PT.UTF-8', 'layout': 'pt'},
    'Français': {'locale': 'fr_FR.UTF-8', 'layout': 'fr'},
    'Deutsch': {'locale': 'de_DE.UTF-8', 'layout': 'de'},
    'Italiano': {'locale': 'it_IT.UTF-8', 'layout': 'it'},
    'Română': {'locale': 'ro_RO.UTF-8', 'layout': 'ro'},
    'Русский': {'locale': 'ru_RU.UTF-8', 'layout': 'ru'}
}

class WelcomeTab(Gtk.ScrolledWindow):
    def __init__(self, parent_window):
        Gtk.ScrolledWindow.__init__(self)
        self.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        self.parent_window = parent_window  # Guardamos referencia a la ventana principal
        
        self._init_ui()
    
    def _init_ui(self):
        # Crear contenedor principal
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(main_box)
        
        # Información del sistema Live
        info_frame = Gtk.Frame()
        info_frame.set_label(STRINGS[self.parent_window.current_lang]['live_iso']['title'])
        main_box.pack_start(info_frame, False, False, 10)
        
        info_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        info_box.set_border_width(10)
        info_frame.add(info_box)
        
        # Descripción del Live ISO
        desc_label = Gtk.Label()
        desc_label.set_text(STRINGS[self.parent_window.current_lang]['live_iso']['description'])
        desc_label.set_line_wrap(True)
        desc_label.set_justify(Gtk.Justification.CENTER)
        info_box.pack_start(desc_label, False, False, 0)
        
        # Imagen de slide si existe
        try:
            if os.path.exists(SLIDE_PATH):
                pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(SLIDE_PATH, 400, 300, True)
                image = Gtk.Image.new_from_pixbuf(pixbuf)
                info_box.pack_start(image, True, True, 10)
        except Exception as e:
            print(f"Error cargando imagen de slide: {e}")

    def on_language_changed(self, combo):
        # Este método se llama desde la ventana principal
        # Aquí se puede actualizar el contenido según el idioma
        pass
