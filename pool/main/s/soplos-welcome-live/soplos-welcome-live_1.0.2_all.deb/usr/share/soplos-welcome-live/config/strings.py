STRINGS = {
    'es': {
        'welcome': 'Soplos Linux',
        'welcome_desc': '¡La distribución Linux hecha para ti!',
        'version': 'Tyron Live 2023.2',
        'buttons': {
            'exit': '_Salir',
            'website': 'Sitio Web',
            'forums': 'Foros',
            'wiki': 'Wiki',
            'donate': 'Donar',
            'install': 'Instalar Soplos _Linux',
            'chroot': 'Recuperar sistema con _CHROOT',
            'open_gparted': 'Abrir _GParted',
            'close': '_Cerrar',
            'next': '_Siguiente',
            'cancel': '_Cancelar',
            'mount': '_Montar'
        },
        'dialog': {
            'exit_title': '¿Está seguro que desea salir?',
            'exit_desc': 'Se cerrará el programa de bienvenida.',
            'error': 'Error',
            'select_disk': 'Por favor, seleccione un disco',
            'select_root': 'Debe seleccionar una partición raíz (/)',
            'no_partitions': 'No se encontraron particiones en este disco',
            'partition_header': 'Seleccione las particiones a montar:',
            'mounting': 'Montando particiones',
            'invalid_partition': 'Partición no válida',
            'invalid_partition_desc': 'La partición seleccionada no contiene un sistema Linux válido o está dañada.',
            'mount_error': 'Error de montaje',
            'mount_error_desc': 'No se pudieron montar las particiones seleccionadas.'
        },
        'locale': {
            'error_generating': 'Error al generar los locales:',
            'error_updating': 'Error al establecer el locale predeterminado:',
            'error_restart': 'Error al reiniciar SDDM',
            'not_found_locale_gen': 'No se encuentra el comando locale-gen.\nPor favor, instale el paquete locales.',
            'not_found_update_locale': 'No se encuentra update-locale',
            'restart_session_title': 'Cambios aplicados',
            'restart_session_desc': 'Para que todos los cambios tengan efecto completamente, se recomienda cerrar sesión y volver a iniciarla.'
        },
        'chroot': {
            'title': 'Recuperación CHROOT',
            'select_disk': 'Seleccione el disco del sistema',
            'open_gparted': 'Abrir GParted',
            'select_partitions': 'Seleccionar particiones',
            'mount': 'Montar',
            'cancel': 'Cancelar',
            'terminal_title': 'Entorno CHROOT de Recuperación de Soplos Linux',
            'welcome_message': 'Has ingresado en un entorno chroot para recuperar tu sistema.',
            'instructions': 'Puedes ejecutar comandos como actualizaciones, reinstalar\nel gestor de arranque o cualquier otra reparación.',
            'exit_message': 'Para salir del entorno chroot, escribe \'exit\' o presiona Ctrl+D.',
            'mounting_partitions': 'Montando particiones...',
            'mounting_root': 'Montando partición raíz',
            'mounting_boot': 'Montando partición /boot',
            'mounting_efi': 'Montando partición EFI',
            'mounting_virtual': 'Montando sistemas de archivos virtuales',
            'exit_chroot': 'Has salido del entorno chroot.',
            'unmounting': 'Se procederá a desmontar todas las particiones...',
            'unmount_complete': 'Todas las particiones fueron desmontadas correctamente.',
            'cleanup_question': '¿Desea eliminar el directorio de montaje {mount_point}? [s/N]: ',
            'process_complete': 'Proceso de chroot finalizado.'
        },
        'autostart': 'Mostrar al inicio:',
        'labels': {
            'language': 'Idioma:',
            'show_startup': 'Mostrar al inicio:',
            'device': 'Dispositivo',
            'size': 'Tamaño',
            'model': 'Modelo',
            'filesystem': 'Sistema de archivos',
            'mountpoint': 'Punto de montaje',
            'select_option': '-- Seleccionar --',
            'numlockx': 'Activar teclado numérico:'
        },
        'live_iso': {
            'title': 'Live ISO',
            'description': 'Esta versión Live te permite probar Soplos Linux\nsin necesidad de instalar nada en tu ordenador.\nCuando estés listo, usa el botón naranja para instalarlo.'
        },
        'thanks': '¡Gracias por probar Soplos Linux!',
        'messages': {
            'selected_disk': 'Disco seleccionado: {}',
            'error_loading_disks': 'Error al cargar discos',
            'error_loading_partitions': 'Error al obtener particiones',
            'error_mounting': 'Error al montar particiones'
        },
        'progress': {
            'configuring': 'Configurando el sistema...',
            'restarting': 'Reiniciando sesión automáticamente...'
        }
    },
    'en': {
        'welcome': 'Soplos Linux',
        'welcome_desc': 'The Linux distribution made for you!',
        'version': 'Tyron Live 2023.2',
        'buttons': {
            'exit': '_Exit',
            'website': 'Website',
            'forums': 'Forums',
            'wiki': 'Wiki',
            'donate': 'Donate',
            'install': 'Install Soplos _Linux',
            'chroot': 'Recover system with _CHROOT',
            'open_gparted': 'Open _GParted',
            'close': '_Close',
            'next': '_Next',
            'cancel': '_Cancel',
            'mount': '_Mount'
        },
        'dialog': {
            'exit_title': 'Are you sure you want to exit?',
            'exit_desc': 'The welcome program will close.',
            'error': 'Error',
            'select_disk': 'Please select a disk',
            'select_root': 'You must select a root partition (/)',
            'no_partitions': 'No partitions found on this disk',
            'partition_header': 'Select the partitions to mount:',
            'mounting': 'Mounting partitions',
            'invalid_partition': 'Invalid partition',
            'invalid_partition_desc': 'The selected partition does not contain a valid Linux system or is damaged.',
            'mount_error': 'Mount error',
            'mount_error_desc': 'Could not mount the selected partitions.'
        },
        'locale': {
            'error_generating': 'Error generating locales:',
            'error_updating': 'Error setting default locale:',
            'error_restart': 'Error restarting SDDM',
            'not_found_locale_gen': 'locale-gen command not found.\nPlease install locales package.',
            'not_found_update_locale': 'update-locale not found',
            'restart_session_title': 'Changes applied',
            'restart_session_desc': 'For all changes to take full effect, it is recommended to log out and log back in.'
        },
        'chroot': {
            'title': 'CHROOT Recovery',
            'select_disk': 'Select system disk',
            'open_gparted': 'Open GParted',
            'select_partitions': 'Select partitions',
            'mount': 'Mount',
            'cancel': 'Cancel',
            'terminal_title': 'Soplos Linux CHROOT Recovery Environment',
            'welcome_message': 'You have entered a chroot environment to recover your system.',
            'instructions': 'You can run commands like updates, reinstall\nthe boot manager or any other repair.',
            'exit_message': 'To exit the chroot environment, type \'exit\' or press Ctrl+D.',
            'mounting_partitions': 'Mounting partitions...',
            'mounting_root': 'Mounting root partition',
            'mounting_boot': 'Mounting /boot partition',
            'mounting_efi': 'Mounting EFI partition',
            'mounting_virtual': 'Mounting virtual filesystems',
            'exit_chroot': 'You have exited the chroot environment.',
            'unmounting': 'Proceeding to unmount all partitions...',
            'unmount_complete': 'All partitions were unmounted correctly.',
            'cleanup_question': 'Do you want to remove the mount directory {mount_point}? [y/N]: ',
            'process_complete': 'Chroot process completed.'
        },
        'autostart': 'Show at startup:',
        'labels': {
            'language': 'Language:',
            'show_startup': 'Show at startup:',
            'device': 'Device',
            'size': 'Size',
            'model': 'Model',
            'filesystem': 'Filesystem',
            'mountpoint': 'Mountpoint',
            'select_option': '-- Select --',
            'numlockx': 'Enable numeric keypad:'
        },
        'live_iso': {
            'title': 'Live ISO',
            'description': 'This Live version allows you to try Soplos Linux\nwithout installing anything on your computer.\nWhen you are ready, use the orange button to install it.'
        },
        'thanks': 'Thanks for trying Soplos Linux!',
        'messages': {
            'selected_disk': 'Selected disk: {}',
            'error_loading_disks': 'Error loading disks',
            'error_loading_partitions': 'Error getting partitions',
            'error_mounting': 'Error mounting partitions'
        },
        'progress': {
            'configuring': 'Configuring system...',
            'restarting': 'Restarting session automatically...'
        }
    },
    'pt': {
        'welcome': 'Soplos Linux',
        'welcome_desc': 'A distribuição Linux feita para você!',
        'version': 'Tyron Live 2023.2',
        'buttons': {
            'exit': '_Sair',
            'website': 'Site',
            'forums': 'Fóruns',
            'wiki': 'Wiki',
            'donate': 'Doar',
            'install': 'Instalar Soplos _Linux',
            'chroot': 'Recuperar sistema com _CHROOT',
            'open_gparted': 'Abrir _GParted',
            'close': '_Fechar',
            'next': '_Próximo',
            'cancel': '_Cancelar',
            'mount': '_Montar'
        },
        'dialog': {
            'exit_title': 'Tem certeza que deseja sair?',
            'exit_desc': 'O programa de boas-vindas será fechado.',
            'error': 'Erro',
            'select_disk': 'Por favor, selecione um disco',
            'select_root': 'Você deve selecionar uma partição raiz (/)',
            'no_partitions': 'Nenhuma partição encontrada neste disco',
            'partition_header': 'Selecione as partições a serem montadas:',
            'mounting': 'Montando particiones',
            'invalid_partition': 'Partição não válida',
            'invalid_partition_desc': 'A partição selecionada não contém um sistema Linux válido ou está danificada.',
            'mount_error': 'Erro de montagem',
            'mount_error_desc': 'Não foi possível montar as partições selecionadas.'
        },
        'locale': {
            'error_generating': 'Erro ao gerar locales:',
            'error_updating': 'Erro ao definir o locale padrão:',
            'error_restart': 'Erro ao reiniciar o SDDM',
            'not_found_locale_gen': 'Comando locale-gen não encontrado.\nPor favor, instale o pacote locales.',
            'not_found_update_locale': 'update-locale não encontrado',
            'restart_session_title': 'Alterações aplicadas',
            'restart_session_desc': 'Para que todas as alterações tenham efeito total, é recomendável sair e entrar novamente.'
        },
        'chroot': {
            'title': 'Recuperação CHROOT',
            'select_disk': 'Selecione o disco do sistema',
            'open_gparted': 'Abrir GParted',
            'select_partitions': 'Selecionar partições',
            'mount': 'Montar',
            'cancel': 'Cancelar',
            'terminal_title': 'Ambiente de Recuperação CHROOT Soplos Linux',
            'welcome_message': 'Você entrou em um ambiente chroot para recuperar seu sistema.',
            'instructions': 'Você pode executar comandos como atualizações, reinstalar\no gerenciador de inicialização ou qualquer outro reparo.',
            'exit_message': 'Para sair do ambiente chroot, digite \'exit\' ou pressione Ctrl+D.',
            'mounting_partitions': 'Montando particiones...',
            'mounting_root': 'Montando partição raiz',
            'mounting_boot': 'Montando partição /boot',
            'mounting_efi': 'Montando partição EFI',
            'mounting_virtual': 'Montando sistemas de arquivos virtuais',
            'exit_chroot': 'Você saiu do ambiente chroot.',
            'unmounting': 'Procedendo para desmontar todas as partições...',
            'unmount_complete': 'Todas as partições foram desmontadas corretamente.',
            'cleanup_question': 'Deseja remover o diretório de montagem {mount_point}? [s/N]: ',
            'process_complete': 'Processo de chroot concluído.'
        },
        'autostart': 'Mostrar na inicialização:',
        'labels': {
            'language': 'Idioma:',
            'show_startup': 'Mostrar na inicialização:',
            'device': 'Dispositivo',
            'size': 'Tamanho',
            'model': 'Modelo',
            'filesystem': 'Sistema de arquivos',
            'mountpoint': 'Ponto de montagem',
            'select_option': '-- Selecionar --',
            'numlockx': 'Ativar teclado numérico:'
        },
        'live_iso': {
            'title': 'Live ISO',
            'description': 'Esta versão Live permite que você experimente o Soplos Linux\nsem instalar nada no seu computador.\nQuando estiver pronto, use o botão laranja para instalá-lo.'
        },
        'thanks': 'Obrigado por experimentar o Soplos Linux!',
        'messages': {
            'selected_disk': 'Disco selecionado: {}',
            'error_loading_disks': 'Erro ao carregar discos',
            'error_loading_partitions': 'Erro ao obter partições',
            'error_mounting': 'Erro ao montar partições'
        },
        'progress': {
            'configuring': 'Configurando o sistema...',
            'restarting': 'Reiniciando sessão automaticamente...'
        }
    },
    'fr': {
        'welcome': 'Soplos Linux',
        'welcome_desc': 'La distribution Linux faite pour vous !',
        'version': 'Tyron Live 2023.2',
        'buttons': {
            'exit': '_Quitter',
            'website': 'Site Web',
            'forums': 'Forums',
            'wiki': 'Wiki',
            'donate': 'Faire un don',
            'install': 'Installer Soplos _Linux',
            'chroot': 'Récupérer le système avec _CHROOT',
            'open_gparted': 'Ouvrir _GParted',
            'close': '_Fermer',
            'next': '_Suivant',
            'cancel': '_Annuler',
            'mount': '_Monter'
        },
        'dialog': {
            'exit_title': 'Êtes-vous sûr de vouloir quitter ?',
            'exit_desc': 'Le programme de bienvenue se fermera.',
            'error': 'Erreur',
            'select_disk': 'Veuillez sélectionner un disque',
            'select_root': 'Vous devez sélectionner une partition racine (/)',
            'no_partitions': 'Aucune partition trouvée sur ce disque',
            'partition_header': 'Sélectionnez les partitions à monter :',
            'mounting': 'Montando particiones',
            'invalid_partition': 'Partição não válida',
            'invalid_partition_desc': 'A partição selecionada não contém um sistema Linux válido ou está danificada.',
            'mount_error': 'Erro de montagem',
            'mount_error_desc': 'Não foi possível montar as partições selecionadas.'
        },
        'locale': {
            'error_generating': 'Erreur lors de la génération des locales :',
            'error_updating': 'Erreur lors de la définition de la locale par défaut :',
            'error_restart': 'Erreur lors du redémarrage de SDDM',
            'not_found_locale_gen': 'Commande locale-gen introuvable.\nVeuillez installer le paquet locales.',
            'not_found_update_locale': 'update-locale introuvable',
            'restart_session_title': 'Modifications appliquées',
            'restart_session_desc': 'Pour que toutes les modifications prennent pleinement effet, il est recommandé de se déconnecter et de se reconnecter.'
        },
        'chroot': {
            'title': 'Récupération CHROOT',
            'select_disk': 'Sélectionnez le disque système',
            'open_gparted': 'Ouvrir GParted',
            'select_partitions': 'Sélectionner les partitions',
            'mount': 'Monter',
            'cancel': 'Annuler',
            'terminal_title': 'Environnement de récupération CHROOT Soplos Linux',
            'welcome_message': 'Vous êtes entré dans un environnement chroot pour récupérer votre système.',
            'instructions': 'Vous pouvez exécuter des commandes telles que des mises à jour, réinstaller\nle gestionnaire de démarrage ou toute autre réparation.',
            'exit_message': 'Pour quitter l\'environnement chroot, tapez \'exit\' ou appuyez sur Ctrl+D.',
            'mounting_partitions': 'Montando particiones...',
            'mounting_root': 'Montage de la partition racine',
            'mounting_boot': 'Montage de la partition /boot',
            'mounting_efi': 'Montage de la partition EFI',
            'mounting_virtual': 'Montage des systèmes de fichiers virtuels',
            'exit_chroot': 'Vous avez quitté l\'environnement chroot.',
            'unmounting': 'Procédure de démontage de toutes les partitions...',
            'unmount_complete': 'Toutes les partitions ont été démontées correctement.',
            'cleanup_question': 'Voulez-vous supprimer le répertoire de montage {mount_point}? [o/N]: ',
            'process_complete': 'Processus de chroot terminé.'
        },
        'autostart': 'Afficher au démarrage:',
        'labels': {
            'language': 'Langue :',
            'show_startup': 'Afficher au démarrage :',
            'device': 'Appareil',
            'size': 'Taille',
            'model': 'Modèle',
            'filesystem': 'Système de fichiers',
            'mountpoint': 'Point de montage',
            'select_option': '-- Sélectionner --',
            'numlockx': 'Activer le pavé numérique:'
        },
        'live_iso': {
            'title': 'Live ISO',
            'description': 'Cette version Live vous permet d\'essayer Soplos Linux\nsans rien installer sur votre ordinateur.\nLorsque vous êtes prêt, utilisez le bouton orange pour l\'installer.'
        },
        'thanks': 'Merci d\'avoir essayé Soplos Linux!',
        'messages': {
            'selected_disk': 'Disque sélectionné: {}',
            'error_loading_disks': 'Erreur lors du chargement des disques',
            'error_loading_partitions': 'Erreur lors de l\'obtention des partitions',
            'error_mounting': 'Erreur lors du montage des partitions'
        },
        'progress': {
            'configuring': 'Configuration du système...',
            'restarting': 'Redémarrage automatique de la session...'
        }
    },
    'de': {
        'welcome': 'Soplos Linux',
        'welcome_desc': 'Die Linux-Distribution für Sie!',
        'version': 'Tyron Live 2023.2',
        'buttons': {
            'exit': '_Beenden',
            'website': 'Webseite',
            'forums': 'Foren',
            'wiki': 'Wiki',
            'donate': 'Spenden',
            'install': 'Soplos _Linux installieren',
            'chroot': 'System mit _CHROOT wiederherstellen',
            'open_gparted': '_GParted öffnen',
            'close': '_Schließen',
            'next': '_Weiter',
            'cancel': '_Abbrechen',
            'mount': '_Einbinden'
        },
        'dialog': {
            'exit_title': 'Sind Sie sicher, dass Sie beenden möchten?',
            'exit_desc': 'Das Willkommensprogramm wird geschlossen.',
            'error': 'Fehler',
            'select_disk': 'Bitte wählen Sie eine Festplatte aus',
            'select_root': 'Sie müssen eine Root-Partition (/) auswählen',
            'no_partitions': 'Keine Partitionen auf dieser Festplatte gefunden',
            'partition_header': 'Wählen Sie die zu mountenden Partitionen aus:',
            'mounting': 'Montando particiones',
            'invalid_partition': 'Partição não válida',
            'invalid_partition_desc': 'A partição selecionada não contém um sistema Linux válido ou está danificada.',
            'mount_error': 'Erro de montagem',
            'mount_error_desc': 'Não foi possível montar as partições selecionadas.'
        },
        'locale': {
            'error_generating': 'Fehler beim Generieren der Locales:',
            'error_updating': 'Fehler beim Setzen der Standard-Locale:',
            'error_restart': 'Fehler beim Neustart von SDDM',
            'not_found_locale_gen': 'locale-gen Befehl nicht gefunden.\nBitte installieren Sie das Paket locales.',
            'not_found_update_locale': 'update-locale nicht gefunden',
            'restart_session_title': 'Änderungen angewendet',
            'restart_session_desc': 'Damit alle Änderungen vollständig wirksam werden, wird empfohlen, sich abzumelden und erneut anzumelden.'
        },
        'chroot': {
            'title': 'CHROOT Wiederherstellung',
            'select_disk': 'Systemfestplatte auswählen',
            'open_gparted': 'GParted öffnen',
            'select_partitions': 'Partitionen auswählen',
            'mount': 'Einbinden',
            'cancel': 'Abbrechen',
            'terminal_title': 'Soplos Linux CHROOT-Wiederherstellungsumgebung',
            'welcome_message': 'Sie haben eine Chroot-Umgebung betreten, um Ihr System wiederherzustellen.',
            'instructions': 'Sie können Befehle wie Updates, Neuinstallation des Bootmanagers oder andere Reparaturen ausführen.',
            'exit_message': 'Um die Chroot-Umgebung zu verlassen, geben Sie \'exit\' ein oder drücken Sie Ctrl+D.',
            'mounting_partitions': 'Partitionen werden eingebunden...',
            'mounting_root': 'Einbinden der Root-Partition',
            'mounting_boot': 'Einbinden der /boot-Partition',
            'mounting_efi': 'Einbinden der EFI-Partition',
            'mounting_virtual': 'Einbinden virtueller Dateisysteme',
            'exit_chroot': 'Sie haben die Chroot-Umgebung verlassen.',
            'unmounting': 'Es wird versucht, alle Partitionen auszuhängen...',
            'unmount_complete': 'Alle Partitionen wurden erfolgreich ausgehängt.',
            'cleanup_question': 'Möchten Sie das Verzeichnis {mount_point} entfernen? [j/N]: ',
            'process_complete': 'Chroot-Prozess abgeschlossen.'
        },
        'autostart': 'Beim Start anzeigen:',
        'labels': {
            'language': 'Sprache:',
            'show_startup': 'Beim Start anzeigen:',
            'device': 'Gerät',
            'size': 'Größe',
            'model': 'Modell',
            'filesystem': 'Dateisystem',
            'mountpoint': 'Einhängepunkt',
            'select_option': '-- Auswählen --',
            'numlockx': 'Numerische Tastatur aktivieren:'
        },
        'live_iso': {
            'title': 'Live ISO',
            'description': 'Diese Live-Version ermöglicht es Ihnen, Soplos Linux\nzu testen, ohne etwas auf Ihrem Computer zu installieren.\nWenn Sie bereit sind, verwenden Sie die orangefarbene Schaltfläche, um es zu installieren.'
        },
        'thanks': 'Danke, dass Sie Soplos Linux ausprobiert haben!',
        'messages': {
            'selected_disk': 'Ausgewählte Festplatte: {}',
            'error_loading_disks': 'Fehler beim Laden der Festplatten',
            'error_loading_partitions': 'Fehler beim Abrufen der Partitionen',
            'error_mounting': 'Fehler beim Einbinden der Partitionen'
        },
        'progress': {
            'configuring': 'System wird konfiguriert...',
            'restarting': 'Sitzung wird automatisch neu gestartet...'
        }
    },
    'it': {
        'welcome': 'Soplos Linux',
        'welcome_desc': 'La distribuzione Linux fatta per te!',
        'version': 'Tyron Live 2023.2',
        'buttons': {
            'exit': '_Uscire',
            'website': 'Sito Web',
            'forums': 'Forum',
            'wiki': 'Wiki',
            'donate': 'Donare',
            'install': 'Installa Soplos _Linux',
            'chroot': 'Recupera sistema con _CHROOT',
            'open_gparted': 'Apri _GParted',
            'close': '_Chiudi',
            'next': '_Avanti',
            'cancel': '_Annulla',
            'mount': '_Monta'
        },
        'dialog': {
            'exit_title': 'Sei sicuro di voler uscire?',
            'exit_desc': 'Il programma di benvenuto verrà chiuso.',
            'error': 'Errore',
            'select_disk': 'Per favore, seleziona un disco',
            'select_root': 'Devi selezionare una partizione root (/)',
            'no_partitions': 'Nessuna partizione trovata su questo disco',
            'partition_header': 'Seleziona le partizioni da montare:',
            'mounting': 'Montando particiones',
            'invalid_partition': 'Partição não válida',
            'invalid_partition_desc': 'A partição selecionada não contém um sistema Linux válido ou está danificada.',
            'mount_error': 'Erro de montagem',
            'mount_error_desc': 'Não foi possível montar as partições selecionadas.'
        },
        'locale': {
            'error_generating': 'Errore durante la generazione delle locali:',
            'error_updating': 'Errore durante l\'impostazione della locale predefinita:',
            'error_restart': 'Errore durante il riavvio di SDDM',
            'not_found_locale_gen': 'Comando locale-gen non trovato.\nInstallare il pacchetto locales.',
            'not_found_update_locale': 'update-locale non trovato',
            'restart_session_title': 'Modifiche applicate',
            'restart_session_desc': 'Perché tutte le modifiche abbiano effetto completo, si consiglia di disconnettersi e riconnettersi.'
        },
        'chroot': {
            'title': 'Recupero CHROOT',
            'select_disk': 'Seleziona il disco di sistema',
            'open_gparted': 'Apri GParted',
            'select_partitions': 'Seleziona partizioni',
            'mount': 'Monta',
            'cancel': 'Annulla',
            'terminal_title': 'Ambiente di Recupero CHROOT Soplos Linux',
            'welcome_message': 'Sei entrato in un ambiente chroot per recuperare il tuo sistema.',
            'instructions': 'Puoi eseguire comandi come aggiornamenti, reinstallare\nil gestore di avvio o qualsiasi altra riparazione.',
            'exit_message': 'Per uscire dall\'ambiente chroot, digita \'exit\' o premi Ctrl+D.',
            'mounting_partitions': 'Montando particiones...',
            'mounting_root': 'Montando partizione radice',
            'mounting_boot': 'Montando partizione /boot',
            'mounting_efi': 'Montando partizione EFI',
            'mounting_virtual': 'Montando file system virtuali',
            'exit_chroot': 'Sei uscito dall\'ambiente chroot.',
            'unmounting': 'Procedendo a smontare tutte le partizioni...',
            'unmount_complete': 'Tutte le partizioni sono state smontate correttamente.',
            'cleanup_question': 'Vuoi rimuovere la directory di montaggio {mount_point}? [s/N]: ',
            'process_complete': 'Processo di chroot completato.'
        },
        'autostart': 'Mostra all\'avvio:',
        'labels': {
            'language': 'Lingua:',
            'show_startup': 'Mostra all\'avvio:',
            'device': 'Dispositivo',
            'size': 'Dimensione',
            'model': 'Modello',
            'filesystem': 'File system',
            'mountpoint': 'Punto di montaggio',
            'select_option': '-- Seleziona --',
            'numlockx': 'Attiva tastierino numerico:'
        },
        'live_iso': {
            'title': 'Live ISO',
            'description': 'Questa versione Live ti permette di provare Soplos Linux\nsenza installare nulla sul tuo computer.\nQuando sei pronto, usa il pulsante arancione per installarlo.'
        },
        'thanks': 'Grazie per aver provato Soplos Linux!',
        'messages': {
            'selected_disk': 'Disco selezionato: {}',
            'error_loading_disks': 'Errore durante il caricamento dei dischi',
            'error_loading_partitions': 'Errore durante l\'ottenimento delle partizioni',
            'error_mounting': 'Errore durante il montaggio delle partizioni'
        },
        'progress': {
            'configuring': 'Configurazione del sistema...',
            'restarting': 'Riavvio automatico della sessione...'
        }
    },
    'ro': {
        'welcome': 'Soplos Linux',
        'welcome_desc': 'Distribuția Linux făcută pentru tine!',
        'version': 'Tyron Live 2023.2',
        'buttons': {
            'exit': '_Ieșire',
            'website': 'Site Web',
            'forums': 'Forum',
            'wiki': 'Wiki',
            'donate': 'Donează',
            'install': 'Instalează Soplos _Linux',
            'chroot': 'Recuperează sistemul cu _CHROOT',
            'open_gparted': 'Deschide _GParted',
            'close': '_Închide',
            'next': '_Următorul',
            'cancel': '_Anulează',
            'mount': '_Montează'
        },
        'dialog': {
            'exit_title': 'Sigur doriți să ieșiți?',
            'exit_desc': 'Programul de bun venit se va închide.',
            'error': 'Eroare',
            'select_disk': 'Vă rugăm să selectați un disc',
            'select_root': 'Trebuie să selectați o partiție root (/)',
            'no_partitions': 'Nu s-au găsit partiții pe acest disc',
            'partition_header': 'Selectați partițiile de montat:',
            'mounting': 'Montando particiones',
            'invalid_partition': 'Partição não válida',
            'invalid_partition_desc': 'A partição selecionada não contém um sistema Linux válido ou está danificada.',
            'mount_error': 'Erro de montagem',
            'mount_error_desc': 'Não foi possível montar as partições selecionadas.'
        },
        'locale': {
            'error_generating': 'Eroare la generarea localelor:',
            'error_updating': 'Eroare la setarea localei implicite:',
            'error_restart': 'Eroare la repornirea SDDM',
            'not_found_locale_gen': 'Comanda locale-gen nu a fost găsită.\nVă rugăm să instalați pachetul locales.',
            'not_found_update_locale': 'update-locale nu a fost găsit',
            'restart_session_title': 'Modificări aplicate',
            'restart_session_desc': 'Pentru ca toate modificările să aibă efect complet, se recomandă să vă deconectați și să vă reconectați.'
        },
        'chroot': {
            'title': 'Recuperare CHROOT',
            'select_disk': 'Selectați discul sistem',
            'open_gparted': 'Deschide GParted',
            'select_partitions': 'Selectați partițiile',
            'mount': 'Montare',
            'cancel': 'Anulare',
            'terminal_title': 'Soplos Linux CHROOT - Mediu de recuperare',
            'welcome_message': 'Ați intrat într-un mediu chroot pentru a vă recupera sistemul.',
            'instructions': 'Puteți rula comenzi precum actualizări, reinstalare\nmanagerul de boot sau orice altă reparare.',
            'exit_message': 'Pentru a ieși din mediul chroot, tastați \'exit\' sau apăsați Ctrl+D.',
            'mounting_partitions': 'Montare partiții...',
            'mounting_root': 'Montare partiție rădăcină',
            'mounting_boot': 'Montare partiție /boot',
            'mounting_efi': 'Montare partiție EFI',
            'mounting_virtual': 'Montare sisteme de fișiere virtuale',
            'exit_chroot': 'Ați ieșit din mediul chroot.',
            'unmounting': 'Se procedează la demontarea tuturor partițiilor...',
            'unmount_complete': 'Toate partițiile au fost demontate corect.',
            'cleanup_question': 'Doriți să eliminați directorul de montare {mount_point}? [s/N]: ',
            'process_complete': 'Procesul de chroot s-a încheiat.'
        },
        'autostart': 'Arată la pornire:',
        'labels': {
            'language': 'Limbă:',
            'show_startup': 'Arată la pornire:',
            'device': 'Dispozitiv',
            'size': 'Dimensiune',
            'model': 'Model',
            'filesystem': 'Sistem de fișiere',
            'mountpoint': 'Punct de montare',
            'select_option': '-- Selectați --',
            'numlockx': 'Activare tastatură numerică:'
        },
        'live_iso': {
            'title': 'Live ISO',
            'description': 'Această versiune Live vă permite să încercați Soplos Linux\nfără a instala nimic pe computerul dvs.\nCând sunteți gata, utilizați butonul portocaliu pentru a-l instala.'
        },
        'thanks': 'Mulțumim că ați încercat Soplos Linux!',
        'messages': {
            'selected_disk': 'Disc selectat: {}',
            'error_loading_disks': 'Eroare la încărcarea discurilor',
            'error_loading_partitions': 'Eroare la obținerea partițiilor',
            'error_mounting': 'Eroare la montarea partițiilor'
        },
        'progress': {
            'configuring': 'Configurarea sistemului...',
            'restarting': 'Repornirea automată a sesiunii...'
        }
    },
    'ru': {
        'welcome': 'Soplos Linux',
        'welcome_desc': 'Дистрибутив Linux, созданный для вас!',
        'version': 'Tyron Live 2023.2',
        'buttons': {
            'exit': '_Выход',
            'website': 'Сайт',
            'forums': 'Форумы',
            'wiki': 'Вики',
            'donate': 'Поддержать',
            'install': 'Установить Soplos _Linux',
            'chroot': 'Восстановить систему с _CHROOT',
            'open_gparted': 'Открыть _GParted',
            'close': '_Закрыть',
            'next': '_Далее',
            'cancel': '_Отмена',
            'mount': '_Монтировать'
        },
        'dialog': {
            'exit_title': 'Вы уверены, что хотите выйти?',
            'exit_desc': 'Программа приветствия будет закрыта.',
            'error': 'Ошибка',
            'select_disk': 'Пожалуйста, выберите диск',
            'select_root': 'Вы должны выбрать корневой раздел (/)',
            'no_partitions': 'На этом диске не найдено разделов',
            'partition_header': 'Выберите разделы для монтирования:',
            'mounting': 'Montando particiones',
            'invalid_partition': 'Partição não válida',
            'invalid_partition_desc': 'A partição selecionada não contém um sistema Linux válido ou está danificada.',
            'mount_error': 'Erro de montagem',
            'mount_error_desc': 'Não foi possível montar as partições selecionadas.'
        },
        'locale': {
            'error_generating': 'Ошибка при генерации локалей:',
            'error_updating': 'Ошибка при установке локали по умолчанию:',
            'error_restart': 'Ошибка при перезапуске SDDM',
            'not_found_locale_gen': 'Команда locale-gen не найдена.\nПожалуйста, установите пакет locales.',
            'not_found_update_locale': 'update-locale не найден',
            'restart_session_title': 'Изменения применены',
            'restart_session_desc': 'Чтобы все изменения вступили в силу, рекомендуется выйти из системы и снова войти.'
        },
        'chroot': {
            'title': 'Восстановление CHROOT',
            'select_disk': 'Выберите системный диск',
            'open_gparted': 'Открыть GParted',
            'select_partitions': 'Выберите разделы',
            'mount': 'Монтировать',
            'cancel': 'Отмена',
            'terminal_title': 'Soplos Linux CHROOT - Среда восстановления',
            'welcome_message': 'Вы вошли в среду chroot для восстановления вашей системы.',
            'instructions': 'Вы можете выполнять команды, такие как обновления, переустановка\nменеджера загрузки или любое другое восстановление.',
            'exit_message': 'Чтобы выйти из среды chroot, введите \'exit\' или нажмите Ctrl+D.',
            'mounting_partitions': 'Монтирование разделов...',
            'mounting_root': 'Монтирование корневого раздела',
            'mounting_boot': 'Монтирование раздела /boot',
            'mounting_efi': 'Монтирование EFI-раздела',
            'mounting_virtual': 'Монтирование виртуальных файловых систем',
            'exit_chroot': 'Вы вышли из среды chroot.',
            'unmounting': 'Производится размонтирование всех разделов...',
            'unmount_complete': 'Все разделы были размонтированы корректно.',
            'cleanup_question': 'Вы хотите удалить каталог монтирования {mount_point}? [y/N]: ',
            'process_complete': 'Процесс chroot завершен.'
        },
        'autostart': 'Показывать при запуске:',
        'labels': {
            'language': 'Язык:',
            'show_startup': 'Показывать при запуске:',
            'device': 'Устройство',
            'size': 'Размер',
            'model': 'Модель',
            'filesystem': 'Файловая система',
            'mountpoint': 'Точка монтирования',
            'select_option': '-- Выбрать --',
            'numlockx': 'Включить цифровую клавиатуру:'
        },
        'live_iso': {
            'title': 'Live ISO',
            'description': 'Эта версия Live позволяет вам попробовать Soplos Linux\nбез установки чего-либо на ваш компьютер.\nКогда будете готовы, используйте оранжевую кнопку для установки.'
        },
        'thanks': 'Спасибо, что попробовали Soplos Linux!',
        'messages': {
            'selected_disk': 'Выбранный диск: {}',
            'error_loading_disks': 'Ошибка при загрузке дисков',
            'error_loading_partitions': 'Ошибка при получении разделов',
            'error_mounting': 'Ошибка при монтировании разделов'
        },
        'progress': {
            'configuring': 'Настройка системы...',
            'restarting': 'Автоматический перезапуск сессии...'
        }
    }
}
