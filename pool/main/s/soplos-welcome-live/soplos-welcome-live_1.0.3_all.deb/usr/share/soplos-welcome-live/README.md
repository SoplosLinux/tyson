# Soplos Welcome Live

[![License: GPL-3.0+](https://img.shields.io/badge/License-GPL--3.0%2B-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![Version](https://img.shields.io/badge/version-1.0.3-green.svg)]()

Pantalla de bienvenida para el entorno Live de Soplos Linux que ayuda a los usuarios a navegar por el sistema y realizar la instalación.

*Welcome screen for Soplos Linux Live Environment that helps users navigate the system and perform installation.*

## 📝 Descripción

Una aplicación de bienvenida para el entorno Live de Soplos Linux que ayuda a los usuarios a navegar por el sistema live e instalar Soplos Linux, ofreciendo múltiples herramientas de configuración y personalización.

## ✨ Características

- Integración con el Centro de Software
- Gestión de controladores
- Herramientas de personalización del sistema
- Instalación de software recomendado
- Soporte multilingüe (8 idiomas)
- Detección y configuración de hardware
- Configuración de locale y distribución de teclado
- Herramientas de recuperación CHROOT
- Integración con GParted para gestión de discos
- Control de inicio automático de la pantalla de bienvenida
- Toggle para activación de NumLock

## 📸 Capturas de pantalla

### Pantalla de bienvenida Live
![Pantalla de bienvenida](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-welcome-live/screenshots/screenshot1.png)

### Opciones de instalación
![Opciones de instalación](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-welcome-live/screenshots/screenshot2.png)

### Detección de hardware
![Detección de hardware](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-welcome-live/screenshots/screenshot3.png)

## 🔧 Instalación

```bash
sudo apt install soplos-welcome-live
```

## 🌐 Idiomas soportados

- Español
- Inglés
- Francés
- Portugués
- Alemán
- Italiano
- Ruso
- Rumano

## 📄 Licencia

Este proyecto está licenciado bajo [GPL-3.0+](https://www.gnu.org/licenses/gpl-3.0.html) (GNU General Public License versión 3 o posterior).

Esta licencia garantiza las siguientes libertades:
- La libertad de usar el programa para cualquier propósito
- La libertad de estudiar cómo funciona el programa y modificarlo
- La libertad de distribuir copias del programa
- La libertad de mejorar el programa y publicar esas mejoras

Cualquier trabajo derivado debe distribuirse bajo la misma licencia (GPL-3.0+).

Para más detalles, consulte el archivo LICENSE o visite [gnu.org/licenses/gpl-3.0](https://www.gnu.org/licenses/gpl-3.0.html).

## 👥 Desarrolladores

Desarrollado por [Equipo de Soplos Linux](https://soploslinux.com)

## 🔗 Enlaces

- [Página web](https://soploslinux.com)
- [Repositorio GitHub](https://github.com/SoplosLinux)
- [Reportar problemas](https://github.com/SoplosLinux/tyron/issues)
- [Contacto](mailto:info@soploslinux.com)

## 📦 Versiones

### v1.0.3 (27/01/2024)
- Versión inicial de lanzamiento
