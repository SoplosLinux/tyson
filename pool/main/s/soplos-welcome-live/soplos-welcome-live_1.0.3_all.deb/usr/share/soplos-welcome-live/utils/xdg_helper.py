#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import subprocess
import json
import time
import logging
import shutil

class XDGDirectoriesManager:
    """Gestiona los directorios XDG de manera compatible con todos los idiomas"""
    
    def __init__(self):
        self.home_dir = os.path.expanduser('~')
        self.user_dirs_path = os.path.join(self.home_dir, '.config/user-dirs.dirs')
        self.logger = logging.getLogger(__name__)
    
    def update_directories(self, locale):
        """Actualiza los directorios XDG según el locale proporcionado"""
        try:
            print(f"Actualizando directorios XDG para locale {locale}")
            
            # 1. Hacer backup del archivo original
            if os.path.exists(self.user_dirs_path):
                backup_path = f"{self.user_dirs_path}.backup-{int(time.time())}"
                shutil.copy2(self.user_dirs_path, backup_path)
                print(f"Backup creado en {backup_path}")
            
            # 2. Leer la configuración actual
            current_dirs = self._read_user_dirs()
            print(f"Configuración actual: {json.dumps(current_dirs, indent=2)}")
            
            # 3. USAR SOLO XDG-USER-DIRS-UPDATE - El método seguro y estándar
            env = os.environ.copy()
            env['LANG'] = locale
            env['LC_ALL'] = locale
            
            print("Ejecutando xdg-user-dirs-update para actualizar directorios...")
            result = subprocess.run(['xdg-user-dirs-update', '--force'], 
                                 env=env, check=False, capture_output=True, text=True)
            print(f"Resultado: {result.stdout}")
            print(f"Errores: {result.stderr}")
            
            # 4. Leer la nueva configuración
            new_dirs = self._read_user_dirs()
            print(f"Nueva configuración: {json.dumps(new_dirs, indent=2)}")
            
            # 5. Notificar al entorno de escritorio
            self._update_desktop_environment()
            
            # 6. No hacemos nada más - dejamos que el sistema maneje las carpetas
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error actualizando directorios XDG: {e}")
            return False
    
    def _read_user_dirs(self):
        """Lee la configuración de directorios XDG"""
        dirs = {}
        if os.path.exists(self.user_dirs_path):
            try:
                with open(self.user_dirs_path, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if line.startswith('XDG_') and '=' in line:
                            key, value = line.split('=', 1)
                            # Limpiar las comillas y $HOME/
                            value = value.strip('"\'').replace('$HOME/', '')
                            dirs[key] = value
            except Exception as e:
                self.logger.error(f"Error leyendo {self.user_dirs_path}: {e}")
        return dirs
    
    def _update_desktop_environment(self):
        """Notifica al entorno de escritorio sobre los cambios"""
        try:
            # Para KDE/Plasma
            subprocess.run(['kbuildsycoca5'], check=False)
            subprocess.run(['kbuildsycoca6'], check=False)  # Plasma 6
            
            # Refrescar escritorio (con mínima invasión)
            subprocess.run(['qdbus', 'org.kde.plasmashell', '/PlasmaShell', 
                          'evaluateScript', 'refreshCurrentShell()'], check=False)
        except Exception as e:
            self.logger.error(f"Error actualizando entorno de escritorio: {e}")

# Instancia global para uso directo
xdg_manager = XDGDirectoriesManager()
