import subprocess
import os
import json
import shutil
import logging
from config.strings import STRINGS

class SystemOperations:
    def __init__(self):
        self.mount_point = "/mnt/rescue"
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        # Obtener idioma del sistema
        current_locale = os.getenv('LANG', 'en_US.UTF-8')
        self.current_lang = current_locale.split('_')[0]

    def format_size(self, size):
        """Convierte tamaños en bytes a formato legible"""
        try:
            size = int(size)
            for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
                if size < 1024.0:
                    return f"{size:.1f} {unit}"
                size /= 1024.0
            return f"{size:.1f} TB"
        except:
            return "Desconocido"

    def get_disks(self):
        try:
            cmd = "lsblk -lnp -o NAME,SIZE,MODEL -d -I 8,259"
            output = subprocess.check_output(cmd.split()).decode()
            disks = []
            for line in output.splitlines():
                if line.strip():
                    parts = line.split()
                    device = parts[0]
                    size = parts[1]
                    model = ' '.join(parts[2:]) if len(parts) > 2 else STRINGS[self.current_lang]['labels']['device']
                    disks.append((device, size, model))
            return disks
        except Exception as e:
            self.logger.error(STRINGS[self.current_lang]['messages']['error_loading_disks'])
            return []

    def get_disk_partitions(self, disk_name):
        """Obtiene las particiones de un disco específico"""
        try:
            # Usar un comando más simple y directo
            cmd = ['lsblk', '-lnp', '-o', 'NAME,SIZE,FSTYPE,MOUNTPOINT', disk_name]
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode != 0:
                raise Exception(f"Error ejecutando lsblk: {result.stderr}")
            
            partitions = []
                
            for line in result.stdout.strip().split('\n'):
                parts = line.split()
                # Saltar líneas vacías o el disco principal
                if not parts or parts[0] == disk_name:
                    continue
                
                device = parts[0]
                size = parts[1]
                fstype = parts[2] if len(parts) > 2 else ''
                mount = parts[3] if len(parts) > 3 else ''
                
                # Sugerir punto de montaje
                suggested = None
                if fstype == 'vfat' or fstype == 'fat32':
                    suggested = '/boot/efi'
                elif fstype == 'ext4':
                    if mount == '/':
                        suggested = '/'
                    elif mount == '/boot':
                        suggested = '/boot'
                    elif mount == '/home':
                        suggested = '/home'
                    elif not any(p.get('suggested_mount') == '/' for p in partitions):
                        suggested = '/'
                    elif not any(p.get('suggested_mount') == '/boot' for p in partitions):
                        suggested = '/boot'
                    else:
                        suggested = '/home'
                
                partitions.append({
                    'device': device,
                    'size': size,
                    'fstype': fstype,
                    'mountpoint': mount,
                    'suggested_mount': suggested
                })
            
            return partitions
            
        except Exception as e:
            self.logger.error(f"Error obteniendo particiones: {str(e)}")
            raise

    def _suggest_mount_point(self, fs_type, label, current_mount):
        """Sugiere un punto de montaje basado en el sistema de archivos y etiqueta"""
        # Ignorar current_mount si contiene nuestro mount_point
        if current_mount and self.mount_point in current_mount:
            current_mount = None

        fs_type = (fs_type or '').lower()
        label = (label or '').lower()

        # Primero verificar por sistema de archivos y etiquetas
        if fs_type == 'swap':
            return None
        elif fs_type in ['vfat', 'fat32'] and ('efi' in label or 'esp' in label):
            return '/boot/efi'
        elif fs_type in ['ext4', 'btrfs', 'xfs']:
            if 'home' in label:
                return '/home'
            elif 'boot' in label:
                if 'efi' in label:
                    return '/boot/efi'
                return '/boot'
            elif 'root' in label:
                return '/'
            # Si no hay etiqueta pero es el único ext4, probablemente sea root
            return '/'

        return None

    def execute_chroot(self):
        """Ejecuta el chroot"""
        subprocess.run(['chroot', self.mount_point], check=True)

    def execute_gparted(self):
        """Ejecuta GParted usando la ruta absoluta"""
        try:
            subprocess.Popen(['pkexec', '/usr/sbin/gparted'])
        except Exception as e:
            print(f"Error ejecutando GParted: {e}")

    def mount_and_chroot(self, root_part, boot_part=None, efi_part=None):
        """Monta las particiones y ejecuta chroot"""
        try:
            # Script para montar todo
            mount_script = f"""#!/bin/bash
mkdir -p {self.mount_point}
mount {root_part} {self.mount_point}
"""
            if boot_part:
                mount_script += f"""
mkdir -p {self.mount_point}/boot
mount {boot_part} {self.mount_point}/boot
"""
            if efi_part:
                mount_script += f"""
mkdir -p {self.mount_point}/boot/efi
mount {efi_part} {self.mount_point}/boot/efi
"""
            
            mount_script += f"""
mount --bind /dev {self.mount_point}/dev
mount --bind /proc {self.mount_point}/proc
mount --bind /sys {self.mount_point}/sys
mount --bind /dev/pts {self.mount_point}/dev/pts
cp /etc/resolv.conf {self.mount_point}/etc/resolv.conf
"""
            
            # Ejecutar script de montaje
            with open('/tmp/mount.sh', 'w') as f:
                f.write(mount_script)
            os.chmod('/tmp/mount.sh', 0o755)
            os.system('sudo /tmp/mount.sh')
            
            # Script para chroot
            chroot_script = f"""#!/bin/bash
chroot {self.mount_point} /bin/bash
"""
            
            with open('/tmp/chroot.sh', 'w') as f:
                f.write(chroot_script)
            os.chmod('/tmp/chroot.sh', 0o755)
            
            # Usar directamente konsole, ya que estamos en KDE Plasma
            terminal_cmd = ['konsole', '--hold', '-e', 'sudo', '/tmp/chroot.sh']
            
            # Ejecutar chroot en konsole
            try:
                subprocess.Popen(terminal_cmd, start_new_session=True)
            except Exception as e:
                self.logger.error(f"Error al iniciar konsole: {e}")
                # Si falla, intentar con el único fallback que es xterm
                try:
                    subprocess.Popen(['xterm', '-e', 'sudo /tmp/chroot.sh'])
                except Exception as ex:
                    self.logger.error(f"Error también con xterm: {ex}")
                    raise
    
        except Exception as e:
            self.unmount_all()
            raise Exception(f"Error en montaje/chroot: {str(e)}")

    def unmount_all(self):
        """Desmonta todas las particiones con un solo comando"""
        try:
            command_script = (
                f'umount -l {self.mount_point}/dev 2>/dev/null || true && '
                f'umount -l {self.mount_point}/proc 2>/dev/null || true && '
                f'umount -l {self.mount_point}/sys 2>/dev/null || true && '
                f'umount -l {self.mount_point}/boot/efi 2>/dev/null || true && '
                f'umount -l {self.mount_point}/boot 2>/dev/null || true && '
                f'umount -l {self.mount_point} 2>/dev/null || true'
            )
            
            subprocess.run(['pkexec', 'bash', '-c', command_script], 
                         stdout=subprocess.DEVNULL, 
                         stderr=subprocess.DEVNULL)
            
        except Exception as e:
            print(f"Error al desmontar: {str(e)}")
