import os
import sys

# Añadir el directorio raíz al path de Python
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Este archivo puede estar vacío, solo necesitamos que exista
