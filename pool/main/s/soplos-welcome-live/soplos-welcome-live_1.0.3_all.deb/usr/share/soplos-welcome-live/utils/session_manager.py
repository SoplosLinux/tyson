#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import time
import subprocess
import shutil
from utils.desktop_detector import get_session_type

class SessionManager:
    """Gestor de sesión para manejar aspectos relacionados con la sesión de usuario"""
    
    def __init__(self):
        self.config_dir = os.path.expanduser('~/.config/soplos-welcome-live')
        os.makedirs(self.config_dir, exist_ok=True)
        self.restart_state_file = os.path.join(self.config_dir, 'restart_state.json')
        self.session_type = get_session_type()
        
    def mark_for_restart(self):
        """Marca la sesión para reinicio con timestamp"""
        restart_state = {
            'restarted': True,
            'time': time.time()
        }
        
        with open(self.restart_state_file, 'w') as f:
            json.dump(restart_state, f)
    
    def was_restarted(self):
        """Verifica si la sesión fue reiniciada recientemente"""
        if os.path.exists(self.restart_state_file):
            try:
                with open(self.restart_state_file, 'r') as f:
                    restart_state = json.load(f)
                
                # Si ha pasado menos de 60 segundos desde el reinicio
                if restart_state.get('restarted') and time.time() - restart_state.get('time', 0) < 60:
                    return True
            except:
                pass
        return False
    
    def clear_restart_state(self):
        """Limpia el estado de reinicio"""
        if os.path.exists(self.restart_state_file):
            os.remove(self.restart_state_file)
    
    def restore_theme_from_skel(self):
        """Restaura la configuración de tema desde /etc/skel"""
        try:
            # Restaurar archivos de configuración desde /etc/skel
            skel_config_files = [
                'kdeglobals',
                'plasma-org.kde.plasma.desktop-appletsrc',
                'plasmarc',
                'kxkbrc',  # Para configuración de teclado
                'baloofilerc'  # Para configuración de búsqueda
            ]
            
            home_dir = os.path.expanduser('~')
            
            for config_file in skel_config_files:
                skel_path = f"/etc/skel/.config/{config_file}"
                user_path = f"{home_dir}/.config/{config_file}"
                
                if os.path.exists(skel_path):
                    print(f"Copiando {skel_path} a {user_path}")
                    shutil.copy2(skel_path, user_path)
            
            # Forzar recarga de la configuración de KDE
            subprocess.run(['qdbus', 'org.kde.KWin', '/KWin', 'reconfigure'], check=False)
            subprocess.run(['qdbus', 'org.kde.plasmashell', '/PlasmaShell', 'evaluateScript', 
                        'refreshCurrentShell()'], check=False)
            
            return True
        except Exception as e:
            print(f"Error restaurando tema desde skel: {e}")
            return False
    
    def configure_system_locale(self, locale, layout):
        """Configura el locale y teclado a nivel de sistema"""
        try:
            # 1. Configurar locale en archivos del sistema
            system_locale_script = f"""#!/bin/bash
# Configurar locale a nivel de sistema
cat > /etc/locale.conf << EOF
LANG={locale}
LC_ADDRESS={locale}
LC_IDENTIFICATION={locale}
LC_MEASUREMENT={locale}
LC_MONETARY={locale}
LC_NAME={locale}
LC_NUMERIC={locale}
LC_PAPER={locale}
LC_TELEPHONE={locale}
LC_TIME={locale}
EOF
# Asegurar que el locale está generado
sed -i -E "s/^#\\s*({locale} UTF-8)$/\\1/" /etc/locale.gen
# Generar el locale específico en vez de todos los locales
locale-gen {locale}

# Configurar teclado para X11
mkdir -p /etc/X11/xorg.conf.d
cat > /etc/X11/xorg.conf.d/00-keyboard-layout.conf << EOF
Section "InputClass"
        Identifier "system-keyboard"
        MatchIsKeyboard "on"
        Option "XkbLayout" "{layout}"
EndSection
EOF

# Configurar teclado para Wayland
mkdir -p /etc/xdg
cat > /etc/xdg/keyboard << EOF
XKBLAYOUT={layout}
EOF

# Configurar teclado para console
localectl set-keymap {layout} || true
localectl set-x11-keymap {layout} || true

# Configuración VC para Linux console
echo "KEYMAP={layout}" > /etc/vconsole.conf
"""
            script_path = '/tmp/configure_system_locale.sh'
            with open(script_path, 'w') as f:
                f.write(system_locale_script)
            os.chmod(script_path, 0o755)
            
            # Ejecutar con sudo y añadir timeout para evitar bloqueos
            try:
                subprocess.run(['sudo', script_path], check=True, timeout=60)
            except subprocess.TimeoutExpired:
                print("Advertencia: El comando de configuración de locale excedió el tiempo de espera, pero puede haber funcionado parcialmente.")
                try:
                    subprocess.run(['pkexec', script_path], check=True, timeout=30)
                except subprocess.TimeoutExpired:
                    print("Error: No se pudo completar la configuración de locale en el tiempo asignado.")
                    return False
        
            # 2. Configurar variables de entorno actuales
            os.environ['LANG'] = locale
            os.environ['LC_ALL'] = locale
            
            # 3. Actualizar configuración de KDE para el usuario actual
            subprocess.run([
                'kwriteconfig5', '--file', 'plasma-localerc',
                '--group', 'Translations',
                '--key', 'LANGUAGE', locale.split('.')[0]
            ], check=False)
            
            # 4. Configurar distribución de teclado según tipo de sesión
            if self.session_type == 'wayland':
                # Configuración para Wayland
                subprocess.run([
                    'kwriteconfig5', '--file', 'kxkbrc',
                    '--group', 'Layout',
                    '--key', 'LayoutList', layout
                ], check=True)
                
                subprocess.run([
                    'kwriteconfig5', '--file', 'kxkbrc',
                    '--group', 'Layout',
                    '--key', 'Use', 'true'
                ], check=True)
                
                # Recargar usando qdbus si es posible
                subprocess.run([
                    'qdbus', 'org.kde.keyboard', '/Layouts', 'reset'
                ], check=False)
                
            else:
                # Configuración para X11
                try:
                    subprocess.run(['setxkbmap', layout], check=False)
                except:
                    pass
            
            return True
        except Exception as e:
            print(f"Error configurando locale del sistema: {e}")
            return False
    
    def ensure_autologin(self, username='liveuser'):
        """Asegura que el autologin está configurado de forma persistente"""
        try:
            # Crear script con múltiples formas de asegurar el autologin
            script = f"""#!/bin/bash
# Garantizar autologin para SDDM
mkdir -p /etc/sddm.conf.d/

# Crear archivo de configuración principal de autologin
cat > /etc/sddm.conf.d/autologin.conf << EOF
[Autologin]
User={username}
Session=plasma.desktop
Relogin=true
EOF

# También configurar en sddm.conf si existe
if [ -f /etc/sddm.conf ]; then
    # Reemplazar sección Autologin existente o añadirla si no existe
    if grep -q '\\[Autologin\\]' /etc/sddm.conf; then
        sed -i '/\\[Autologin\\]/,/\\[/{{s/User=.*/User={username}/;s/Session=.*/Session=plasma.desktop/;s/Relogin=.*/Relogin=true/}}' /etc/sddm.conf
    else
        cat >> /etc/sddm.conf << EOF

[Autologin]
User={username}
Session=plasma.desktop
Relogin=true
EOF
    fi
fi

# Asegurar que los archivos tienen permisos correctos
chmod 644 /etc/sddm.conf.d/autologin.conf
if [ -f /etc/sddm.conf ]; then
    chmod 644 /etc/sddm.conf
fi

# Configurar también loginctl
loginctl enable-linger {username}
"""
            script_path = '/tmp/ensure_autologin.sh'
            with open(script_path, 'w') as f:
                f.write(script)
            os.chmod(script_path, 0o755)
            
            # Ejecutar con privilegios administrativos
            try:
                subprocess.run(['sudo', script_path], check=True, timeout=10)
            except subprocess.TimeoutExpired:
                subprocess.run(['pkexec', script_path], check=True)
                
            os.remove(script_path)
            return True
        except Exception as e:
            print(f"Error asegurando autologin: {e}")
            return False
    
    def restart_sddm(self):
        """Reinicia SDDM de forma segura y directa asegurando el autologin"""
        try:
            # 1. Asegurar que autologin está configurado para este usuario
            username = os.environ.get('USER', 'liveuser')
            if not self.ensure_autologin(username):
                print("Advertencia: No se pudo asegurar el autologin")
            
            # 2. Marcar para reinicio
            self.mark_for_restart()
            
            # 3. Preservar el tipo de sesión actual (wayland o x11)
            session_type = get_session_type()
            
            # 4. Script para reinicio que verifica y fuerza autologin
            script = f"""#!/bin/bash
# Verificar autologin antes de reiniciar
if ! grep -q "\\[Autologin\\]" /etc/sddm.conf.d/autologin.conf 2>/dev/null; then
    echo "Error: No se encontró configuración de autologin"
    exit 1
fi

# Asegurar que se mantiene la sesión {session_type}
if [ "{session_type}" = "wayland" ]; then
    # Asegurar que se usa la sesión Wayland
    sed -i '/Session=/c\\Session=plasma.desktop' /etc/sddm.conf.d/autologin.conf
    if [ -f /etc/sddm.conf ]; then
        sed -i '/Session=/c\\Session=plasma.desktop' /etc/sddm.conf
    fi
fi

echo "Reiniciando SDDM con autologin configurado y sesión {session_type}..."
systemctl restart sddm
"""
            script_path = '/tmp/restart_sddm_force_autologin.sh'
            with open(script_path, 'w') as f:
                f.write(script)
            os.chmod(script_path, 0o755)
            
            # Ejecutar como superusuario
            print(f"Ejecutando reinicio de SDDM en sesión {session_type}...")
            try:
                subprocess.run(['sudo', script_path], check=True, timeout=5)
            except:
                subprocess.run(['pkexec', script_path], check=True)
                
            return True
        except Exception as e:
            print(f"Error crítico reiniciando SDDM: {e}")
            return False

# Instancia global
session_manager = SessionManager()
