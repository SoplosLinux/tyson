#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import time
import subprocess
import shutil
from utils.desktop_detector import get_session_type
from utils.autostart import AutostartManager  # Importar AutostartManager

class SessionManager:
    """Gestor de sesión para manejar aspectos relacionados con la sesión de usuario"""
    
    def __init__(self):
        # Añadir una verificación para ISO Live
        self.is_live_session = os.path.exists('/usr/bin/calamares') and os.environ.get('USER') == 'liveuser'
        if self.is_live_session:
            # En sesión live, usar /tmp para evitar escribir en el home
            self.config_dir = '/tmp/soplos-welcome-live'
            os.makedirs(self.config_dir, exist_ok=True)
            print(f"Usando directorio temporal para configuración: {self.config_dir}")
        else:
            self.config_dir = os.path.expanduser('~/.config/soplos-welcome-live')
            # Asegurar que el directorio existe antes de cualquier operación
            try:
                os.makedirs(self.config_dir, exist_ok=True)
            except Exception as e:
                print(f"Error creando directorio de configuración: {e}")
                # Intentar con una ubicación alternativa en /tmp si falla
                self.config_dir = '/tmp/soplos-welcome-live'
                os.makedirs(self.config_dir, exist_ok=True)
        
        self.restart_state_file = os.path.join(self.config_dir, 'restart_state.json')
        self.session_type = get_session_type()
        self.autostart_manager = AutostartManager()
        
        # Crear marcador de primer inicio para prevenir reinicio automático
        self.first_run_marker = os.path.join(self.config_dir, 'first_run_completed')
        if not os.path.exists(self.first_run_marker):
            try:
                with open(self.first_run_marker, 'w') as f:
                    f.write(str(time.time()))
                print("Primera ejecución marcada - se evitará el reinicio automático")
            except Exception as e:
                print(f"Error al crear marcador de primer inicio: {e}")
        
    def mark_for_restart(self):
        """Marca la sesión para reinicio con timestamp y estado del autostart"""
        restart_state = {
            'restarted': True,
            'time': time.time(),
            'need_locale_check': True,
            'autostart_enabled': self.autostart_manager.is_enabled(),  # Guardar estado de autostart
            'version': '2023.2'  # Añadir versión para evitar falsos positivos
        }
        
        with open(self.restart_state_file, 'w') as f:
            json.dump(restart_state, f)
        
        # También crear un archivo en el directorio /tmp para que persista después del reinicio
        try:
            with open('/tmp/soplos_welcome_restart_state.json', 'w') as f:
                json.dump(restart_state, f)
        except Exception as e:
            print(f"Error guardando estado en /tmp: {e}")
    
    def was_restarted(self):
        """Verifica si la sesión fue reiniciada recientemente"""
        # Verificar si es la primera ejecución
        if not os.path.exists('/tmp/soplos_restart_requested'):
            print("No hay solicitud explícita de reinicio, se evita reinicio automático")
            return False
        
        # Eliminar marcador de solicitud de reinicio para evitar ciclos
        try:
            os.unlink('/tmp/soplos_restart_requested')
        except:
            pass
        
        # Verificar estado de reinicio solo si fue solicitado explícitamente
        # Primero verificar el archivo estándar
        if os.path.exists(self.restart_state_file):
            try:
                with open(self.restart_state_file, 'r') as f:
                    restart_state = json.load(f)
                
                # Si ha pasado menos de 60 segundos desde el reinicio
                # Y la versión coincide (para evitar falsos positivos)
                if (restart_state.get('restarted') and 
                    time.time() - restart_state.get('time', 0) < 60 and
                    restart_state.get('version') == '2023.2'):
                    return True
            except:
                pass
                
        # Verificar el archivo en /tmp como respaldo
        try:
            if os.path.exists('/tmp/soplos_welcome_restart_state.json'):
                with open('/tmp/soplos_welcome_restart_state.json', 'r') as f:
                    restart_state = json.load(f)
                
                # Si ha pasado menos de 120 segundos desde el reinicio (más tiempo para /tmp)
                # Y la versión coincide (para evitar falsos positivos)
                if (restart_state.get('restarted') and 
                    time.time() - restart_state.get('time', 0) < 120 and
                    restart_state.get('version') == '2023.2'):
                    
                    # Restaurar el estado de autostart si era necesario
                    if restart_state.get('autostart_enabled', False):
                        print("Restaurando autostart después del reinicio...")
                        self.autostart_manager.enable()
                    
                    return True
        except Exception as e:
            print(f"Error verificando estado en /tmp: {e}")
        
        return False
    
    def clear_restart_state(self):
        """Limpia el estado de reinicio"""
        if os.path.exists(self.restart_state_file):
            os.remove(self.restart_state_file)
        
        # También limpiar el archivo en /tmp
        if os.path.exists('/tmp/soplos_welcome_restart_state.json'):
            try:
                os.remove('/tmp/soplos_welcome_restart_state.json')
            except:
                pass
    
    def verify_locale_applied(self):
        """Verifica que los cambios de locale se aplicaron correctamente"""
        try:
            locale_info_file = os.path.join(self.config_dir, 'locale_info.json')
            if os.path.exists(locale_info_file):
                with open(locale_info_file, 'r') as f:
                    locale_info = json.load(f)
                
                # Verificar si el locale actual coincide con el guardado
                current_locale = os.getenv('LANG', '')
                if locale_info.get('locale', '') != current_locale:
                    print(f"El locale actual ({current_locale}) no coincide con el guardado ({locale_info.get('locale')})")
                    # Forzar la recarga del locale
                    os.environ['LANG'] = locale_info.get('locale', '')
                    os.environ['LC_ALL'] = locale_info.get('locale', '')
                    
                    # Intentar establecer manualmente también si está en liveuser
                    if os.getenv('USER') == 'liveuser':
                        try:
                            subprocess.run([
                                'kwriteconfig5', '--file', 'plasma-localerc',
                                '--group', 'Translations',
                                '--key', 'LANGUAGE', locale_info.get('locale', '').split('.')[0]
                            ], check=False)
                        except:
                            pass
        except Exception as e:
            print(f"Error verificando aplicación de locale: {e}")
    
    def restore_theme_from_skel(self):
        """Restaura la configuración de tema desde /etc/skel"""
        try:
            # Restaurar archivos de configuración desde /etc/skel
            skel_config_files = [
                'kdeglobals',
                'plasma-org.kde.plasma.desktop-appletsrc',
                'plasmarc',
                'kxkbrc',  # Para configuración de teclado
                'baloofilerc',  # Para configuración de búsqueda
                'Trolltech.conf',  # Para tema de Qt
                'gtk-3.0/settings.ini',  # Configuración GTK3
                'gtk-4.0/settings.ini'   # Configuración GTK4
            ]
            
            home_dir = os.path.expanduser('~')
            user_config_dir = os.path.join(home_dir, '.config')
            skel_config_dir = '/etc/skel/.config'
            
            # Verificar que el directorio de configuración skel existe
            if not os.path.exists(skel_config_dir):
                print(f"El directorio {skel_config_dir} no existe")
                return False
            
            # Crear directorio de backup antes de modificar nada
            backup_dir = os.path.join(user_config_dir, 'soplos-welcome-live', 'theme-backup-old')
            os.makedirs(backup_dir, exist_ok=True)
            timestamp = time.strftime('%Y%m%d-%H%M%S')
            backup_target = os.path.join(backup_dir, f'backup-{timestamp}')
            os.makedirs(backup_target, exist_ok=True)
            
            for config_file in skel_config_files:
                # Verificar si es un archivo individual o un directorio
                skel_path = os.path.join(skel_config_dir, config_file)
                user_path = os.path.join(user_config_dir, config_file)
                
                # Si es un directorio (como gtk-3.0), asegurar que existe
                if '/' in config_file:
                    dir_name = os.path.dirname(user_path)
                    os.makedirs(dir_name, exist_ok=True)
                
                # Respaldar la configuración actual si existe
                if os.path.exists(user_path):
                    if os.path.isdir(user_path):
                        # Es un directorio, hacer backup del contenido
                        backup_dir_path = os.path.join(backup_target, config_file)
                        os.makedirs(os.path.dirname(backup_dir_path), exist_ok=True)
                        shutil.copytree(user_path, backup_dir_path, dirs_exist_ok=True)
                    else:
                        # Es un archivo, hacer backup simple
                        backup_file_path = os.path.join(backup_target, config_file)
                        os.makedirs(os.path.dirname(backup_file_path), exist_ok=True)
                        shutil.copy2(user_path, backup_file_path)
                
                # Copiar desde skel si existe el archivo/directorio
                if os.path.exists(skel_path):
                    # Crear el directorio padre si es necesario
                    parent_dir = os.path.dirname(user_path)
                    if parent_dir and not os.path.exists(parent_dir):
                        os.makedirs(parent_dir, exist_ok=True)
                    
                    # Copiar el archivo o directorio
                    if os.path.isdir(skel_path):
                        # Es un directorio, copiar recursivamente
                        shutil.copytree(skel_path, user_path, dirs_exist_ok=True)
                        print(f"Copiando directorio {skel_path} a {user_path}")
                    else:
                        # Es un archivo simple
                        shutil.copy2(skel_path, user_path)
                        print(f"Copiando archivo {skel_path} a {user_path}")
            
            # Forzar recarga de la configuración de KDE
            try:
                subprocess.run(['qdbus', 'org.kde.KWin', '/KWin', 'reconfigure'], check=False)
                subprocess.run(['qdbus', 'org.kde.plasmashell', '/PlasmaShell', 'evaluateScript', 
                            'refreshCurrentShell()'], check=False)
                
                # Recargar las configuraciones específicas de tema
                subprocess.run(['kwriteconfig5', '--file', 'kcminputrc', '--group', 'Mouse', 
                              '--key', 'cursorTheme', '--reload'], check=False)
                subprocess.run(['qdbus', 'org.kde.KGlobalSettings', '/KGlobalSettings', 
                              'notifyChange', '2', '0'], check=False)
            except Exception as e:
                print(f"Error al recargar configuración de KDE: {e}")
            
            return True
        except Exception as e:
            print(f"Error restaurando tema desde skel: {e}")
            return False
    
    def configure_system_locale(self, locale, layout):
        """Configura el locale y teclado a nivel de sistema"""
        try:
            # 1. Configurar locale en archivos del sistema
            system_locale_script = f"""#!/bin/bash
# Configurar locale a nivel de sistema - establecer en múltiples ubicaciones para máxima compatibilidad

# 1. Actualizar /etc/locale.conf
cat > /etc/locale.conf << EOF
LANG={locale}
LC_ADDRESS={locale}
LC_IDENTIFICATION={locale}
LC_MEASUREMENT={locale}
LC_MONETARY={locale}
LC_NAME={locale}
LC_NUMERIC={locale}
LC_PAPER={locale}
LC_TELEPHONE={locale}
LC_TIME={locale}
EOF

# 2. Actualizar también /etc/default/locale
cat > /etc/default/locale << EOF
LANG={locale}
LC_ALL={locale}
EOF

# 3. Establecer variables en /etc/environment
if grep -q "LANG=" /etc/environment; then
    sed -i "s/LANG=.*/LANG={locale}/" /etc/environment
else
    echo "LANG={locale}" >> /etc/environment
fi

if grep -q "LC_ALL=" /etc/environment; then
    sed -i "s/LC_ALL=.*/LC_ALL={locale}/" /etc/environment
else
    echo "LC_ALL={locale}" >> /etc/environment
fi

# 4. Asegurar que el locale está generado
if grep -q "^#{locale} UTF-8" /etc/locale.gen; then
    # Descomentamos el locale
    sed -i "s/^#{locale} UTF-8/{locale} UTF-8/" /etc/locale.gen
    # Generar el locale específico
    locale-gen {locale}
elif ! grep -q "^{locale} UTF-8" /etc/locale.gen; then
    # Si no existe, lo añadimos y generamos
    echo "{locale} UTF-8 UTF-8" >> /etc/locale.gen
    locale-gen {locale}
fi

# 5. Usar localectl para configurar el sistema
localectl set-locale LANG={locale} LC_ALL={locale}

# 6. Configurar teclado para Wayland
mkdir -p /etc/xdg
cat > /etc/xdg/keyboard << EOF
XKBLAYOUT={layout}
EOF

# 7. Configurar teclado a nivel de sistema
localectl set-keymap {layout} 2>/dev/null || true
localectl set-x11-keymap {layout} 2>/dev/null || true

# 8. Configuración para Linux console
echo "KEYMAP={layout}" > /etc/vconsole.conf

# 9. Configuración específica para SDDM (KDE)
if [ -d "/etc/sddm.conf.d" ]; then
    echo "[X11]" > /etc/sddm.conf.d/keyboard.conf
    echo "ServerArguments=-layout {layout}" >> /etc/sddm.conf.d/keyboard.conf
    
    echo "[General]" > /etc/sddm.conf.d/locale.conf
    echo "Language={locale}" >> /etc/sddm.conf.d/locale.conf
fi

# 10. Crear archivo para verificar configuración después del reinicio
echo "LOCALE_CONFIGURED={locale}" > /tmp/locale_configured
echo "LAYOUT_CONFIGURED={layout}" >> /tmp/locale_configured
"""
            script_path = '/tmp/configure_system_locale.sh'
            with open(script_path, 'w') as f:
                f.write(system_locale_script)
            os.chmod(script_path, 0o755)
            
            # Ejecutar con sudo y añadir timeout para evitar bloqueos
            try:
                subprocess.run(['sudo', '/bin/bash', script_path], check=True, timeout=60)
            except subprocess.TimeoutExpired:
                print("El script de configuración tardó demasiado, pero podría haber funcionado")
        
            # 2. Configurar variables de entorno actuales
            os.environ['LANG'] = locale
            os.environ['LC_ALL'] = locale
            
            # 3. Actualizar configuración de KDE para el usuario actual
            subprocess.run([
                'kwriteconfig5', '--file', 'plasma-localerc',
                '--group', 'Translations',
                '--key', 'LANGUAGE', locale.split('.')[0]
            ], check=False)
            
            # 4. Configurar distribución de teclado
            # Configuración para Wayland y X11
            subprocess.run([
                'kwriteconfig5', '--file', 'kxkbrc',
                '--group', 'Layout',
                '--key', 'LayoutList', layout
            ], check=True)
            
            subprocess.run([
                'kwriteconfig5', '--file', 'kxkbrc',
                '--group', 'Layout',
                '--key', 'Use', 'true'
            ], check=True)
            
            # Recargar usando qdbus si es posible
            subprocess.run([
                'qdbus', 'org.kde.keyboard', '/Layouts', 'reset'
            ], check=False)
                
            # Guardar información de locale para verificar después del reinicio
            with open(os.path.join(self.config_dir, 'locale_info.json'), 'w') as f:
                json.dump({'locale': locale, 'layout': layout, 'time': time.time()}, f)

            return True
        except Exception as e:
            print(f"Error configurando locale del sistema: {e}")
            return False
    
    def restart_sddm(self):
        """Reinicia SDDM de forma segura y directa asegurando el autologin"""
        try:
            # 1. Asegurar que autologin está configurado para este usuario
            username = os.environ.get('USER', 'liveuser')
            if not self.ensure_autologin(username):
                print("Error: No se pudo configurar autologin")
            
            # 2. Guardar el estado actual del autostart
            autostart_enabled = self.autostart_manager.is_enabled()
            
            # 3. Crear un script que restaure el autostart después del reinicio
            if autostart_enabled:
                print("Guardando estado de autostart habilitado para restauración después del reinicio")
            
            # 4. Marcar para reinicio
            self.mark_for_restart()
            
            # 5. Crear archivo para permitir el reinicio automático
            try:
                with open('/tmp/soplos_restart_requested', 'w') as f:
                    f.write(str(time.time()))
                print("Archivo de solicitud de reinicio creado correctamente")
            except Exception as e:
                print(f"Error creando archivo de solicitud de reinicio: {e}")
            
            # 6. Preservar el tipo de sesión actual (wayland o x11)
            session_type = get_session_type()
            
            # 7. Reiniciar SDDM
            print(f"Ejecutando reinicio de SDDM en sesión {session_type}...")
            subprocess.run(['sudo', 'systemctl', 'restart', 'sddm'], check=True)
            return True
        except Exception as e:
            print(f"Error crítico reiniciando SDDM: {e}")
            return False

    def ensure_autologin(self, username='liveuser'):
        """Asegura que el autologin está configurado de forma persistente"""
        try:
            # Crear directorio sddm.conf.d si no existe
            try:
                subprocess.run(['sudo', 'mkdir', '-p', '/etc/sddm.conf.d'], check=True)
            except:
                subprocess.run(['pkexec', 'mkdir', '-p', '/etc/sddm.conf.d'], check=True)
            
            # Contenido del archivo de configuración
            autologin_content = f"""[Autologin]
User={username}
Session=plasma.desktop
Relogin=true
"""
            # Usar echo directamente para crear el archivo 
            with open('/tmp/autologin.conf', 'w') as f:
                f.write(autologin_content)
            
            # Mover el archivo a su ubicación
            try:
                subprocess.run(['sudo', 'mv', '/tmp/autologin.conf', '/etc/sddm.conf.d/autologin.conf'], check=True)
                subprocess.run(['sudo', 'chmod', '644', '/etc/sddm.conf.d/autologin.conf'], check=True)
            except:
                try:
                    subprocess.run(['pkexec', 'mv', '/tmp/autologin.conf', '/etc/sddm.conf.d/autologin.conf'], check=True)
                    subprocess.run(['pkexec', 'chmod', '644', '/etc/sddm.conf.d/autologin.conf'], check=True)
                except:
                    # Último intento: usar echo con sudo directamente
                    subprocess.run(['sudo', 'bash', '-c', f'echo "{autologin_content}" > /etc/sddm.conf.d/autologin.conf'], check=False)
                    subprocess.run(['sudo', 'chmod', '644', '/etc/sddm.conf.d/autologin.conf'], check=False)
            
            # Configurar sddm.conf si existe
            if os.path.exists('/etc/sddm.conf'):
                with open('/tmp/sddm_autologin.conf', 'w') as f:
                    f.write(autologin_content)
                
                try:
                    # Si sddm.conf ya tiene sección Autologin, la reemplazaremos
                    if subprocess.run(['grep', '-q', '\\[Autologin\\]', '/etc/sddm.conf'], check=False).returncode == 0:
                        subprocess.run(['sudo', 'sed', '-i', 
                                      f'/\\[Autologin\\]/,/\\[/{{s/User=.*/User={username}/;s/Session=.*/Session=plasma.desktop/;s/Relogin=.*/Relogin=true/}}', 
                                      '/etc/sddm.conf'], check=False)
                    else:
                        # Añadir sección al final del archivo
                        with open('/tmp/sddm_autologin_append', 'w') as f:
                            f.write(f"\n{autologin_content}")
                        subprocess.run(['sudo', 'bash', '-c', 'cat /tmp/sddm_autologin_append >> /etc/sddm.conf'], check=False)
                        os.unlink('/tmp/sddm_autologin_append')
                except:
                    pass
            
            # Habilitar linger para el usuario
            try:
                subprocess.run(['sudo', 'loginctl', 'enable-linger', username], check=False)
            except:
                subprocess.run(['pkexec', 'loginctl', 'enable-linger', username], check=False)
            
            return True
        except Exception as e:
            print(f"Error asegurando autologin: {e}")
            return False

# Instancia global
session_manager = SessionManager()
