import os

# Obtener el directorio base
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Definir rutas de recursos
ASSETS_DIR = os.path.join(BASE_DIR, 'assets')
ICONS_DIR = os.path.join(ASSETS_DIR, 'icons')
SLIDES_DIR = os.path.join(ASSETS_DIR, 'slides')

# Rutas específicas
LOGO_PATH = os.path.join(ICONS_DIR, 'soplos-logo.png')
ICON_PATH = os.path.join(ICONS_DIR, 'com.soplos.welcomelive.png')
SLIDE_PATH = os.path.join(SLIDES_DIR, 'slide.png')

# Asegurar que todas las rutas exportadas estén disponibles
__all__ = ['BASE_DIR', 'ASSETS_DIR', 'ICONS_DIR', 'SLIDES_DIR',
           'LOGO_PATH', 'ICON_PATH', 'SLIDE_PATH']