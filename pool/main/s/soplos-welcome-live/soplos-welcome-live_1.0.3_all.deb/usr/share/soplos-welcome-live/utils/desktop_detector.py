#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import subprocess
import json
import time
import shutil

def get_desktop_environment():
    """Detecta el entorno de escritorio actual"""
    desktop = os.getenv('XDG_CURRENT_DESKTOP', '').lower()
    session = os.getenv('DESKTOP_SESSION', '').lower()
    
    # Para esta versión, solo nos enfocamos en KDE
    is_kde = 'kde' in desktop or 'plasma' in desktop or 'kde' in session
    
    return 'kde' if is_kde else 'unknown'

def get_session_type():
    """Detecta si la sesión es Wayland o X11 (siempre devuelve wayland en Soplos Live)"""
    # En Soplos Live, siempre usamos Wayland
    print("Soplos Live usa Wayland por defecto")
    return 'wayland'

def save_language_preference(lang_code):
    """Guarda la preferencia de idioma del usuario"""
    config_dir = os.path.expanduser('~/.config/soplos-welcome-live')
    os.makedirs(config_dir, exist_ok=True)
    
    with open(os.path.join(config_dir, 'language'), 'w') as f:
        f.write(lang_code)

def load_language_preference():
    """Carga la preferencia de idioma del usuario"""
    config_file = os.path.expanduser('~/.config/soplos-welcome-live/language')
    if os.path.exists(config_file):
        with open(config_file, 'r') as f:
            lang_code = f.read().strip()
            # La validación del código de idioma se hará en el caller
            return lang_code
    return None

def get_kde_version():
    """
    Obtiene la versión de KDE/Plasma si está disponible
    
    Returns:
        str: Versión de KDE Plasma o None si no se puede determinar
    """
    try:
        output = subprocess.check_output(['plasmashell', '--version'], text=True).strip()
        version = output.split(' ')[-1] if ' ' in output else output
        return version
    except Exception:
        return None

def has_autologin_enabled():
    """Verifica si el autologin está activado en SDDM"""
    try:
        # Comprobar si existe configuración de autologin en SDDM
        sddm_conf_paths = [
            '/etc/sddm.conf.d/autologin.conf',
            '/etc/sddm.conf',
            '/usr/lib/sddm/sddm.conf.d/autologin.conf'
        ]
        
        for conf_path in sddm_conf_paths:
            if os.path.exists(conf_path):
                with open(conf_path, 'r') as f:
                    content = f.read()
                    if '[Autologin]' in content and 'User=' in content:
                        # Extraer el usuario de autologin
                        for line in content.split('\n'):
                            if line.strip().startswith('User='):
                                user = line.strip().split('=')[1].strip()
                                if user:  # Si hay un usuario configurado
                                    return user
        
        return False
    except Exception as e:
        print(f"Error verificando autologin: {e}")
        return False

def update_kde_locale(locale):
    """Actualiza la configuración de locale en KDE"""
    try:
        # Configuración de locale en KDE
        subprocess.run([
            'kwriteconfig5', '--file', 'plasma-localerc',
            '--group', 'Translations',
            '--key', 'LANGUAGE', locale.split('.')[0]
        ], check=False)
        
        # Recargar la configuración
        subprocess.run([
            'qdbus', 'org.kde.klauncher', '/KLauncher', 'reparseConfiguration'
        ], check=False)
        
        subprocess.run([
            'qdbus', 'org.kde.plasma.session', '/MainApplication', 'refreshX11Connection'
        ], check=False)
    except Exception as e:
        print(f"Error al actualizar locale de KDE: {e}")

def backup_kde_theme_config():
    """Guarda una copia de seguridad de la configuración de tema KDE"""
    try:
        home_dir = os.path.expanduser('~')
        config_dir = os.path.join(home_dir, '.config')
        backup_dir = os.path.join(home_dir, '.config', 'soplos-welcome-live', 'theme-backup')
        
        # Crear directorio de backup si no existe
        os.makedirs(backup_dir, exist_ok=True)
        
        # Archivos a respaldar
        theme_files = [
            'kdeglobals',
            'plasma-org.kde.plasma.desktop-appletsrc',
            'plasmarc',
            'kxkbrc'
        ]
        
        # Crear backups
        for file in theme_files:
            src_path = os.path.join(config_dir, file)
            dst_path = os.path.join(backup_dir, file)
            if os.path.exists(src_path):
                shutil.copy2(src_path, dst_path)
                print(f"Respaldado {src_path} -> {dst_path}")
        
        return True
    except Exception as e:
        print(f"Error al respaldar configuración KDE: {e}")
        return False

def restore_kde_theme_config():
    """Restaura la configuración de tema KDE desde el backup"""
    try:
        home_dir = os.path.expanduser('~')
        config_dir = os.path.join(home_dir, '.config')
        backup_dir = os.path.join(home_dir, '.config', 'soplos-welcome-live', 'theme-backup')
        
        if not os.path.exists(backup_dir):
            print("No existe directorio de backup de temas")
            return False
        
        # Archivos a restaurar
        theme_files = [
            'kdeglobals',
            'plasma-org.kde.plasma.desktop-appletsrc',
            'plasmarc',
            'kxkbrc'
        ]
        
        # Restaurar desde backups
        for file in theme_files:
            src_path = os.path.join(backup_dir, file)
            dst_path = os.path.join(config_dir, file)
            if os.path.exists(src_path):
                shutil.copy2(src_path, dst_path)
                print(f"Restaurado {src_path} -> {dst_path}")
        
        # Recargar configuración
        try:
            subprocess.run(['qdbus', 'org.kde.KWin', '/KWin', 'reconfigure'], check=False)
            subprocess.run(['qdbus', 'org.kde.plasmashell', '/PlasmaShell', 'evaluateScript',
                        'refreshCurrentShell()'], check=False)
        except Exception as e:
            print(f"Error recargando configuración KDE: {e}")
        
        return True
    except Exception as e:
        print(f"Error al restaurar configuración KDE: {e}")
        return False

def get_kde_theme_config():
    """Obtiene la configuración actual de los temas KDE"""
    try:
        theme_config = {}
        home_dir = os.path.expanduser('~')
        config_dir = os.path.join(home_dir, '.config')
        
        # Leer la configuración del color scheme
        try:
            result = subprocess.check_output(
                ['kreadconfig5', '--file', 'kdeglobals', '--group', 'General', '--key', 'ColorScheme'],
                text=True
            ).strip()
            theme_config['ColorScheme'] = result
        except:
            pass
        
        # Leer la configuración del tema de iconos
        try:
            result = subprocess.check_output(
                ['kreadconfig5', '--file', 'kdeglobals', '--group', 'Icons', '--key', 'Theme'],
                text=True
            ).strip()
            theme_config['IconTheme'] = result
        except:
            pass
        
        # Leer la configuración del tema de plasma
        try:
            result = subprocess.check_output(
                ['kreadconfig5', '--file', 'plasmarc', '--group', 'Theme', '--key', 'name'],
                text=True
            ).strip()
            theme_config['PlasmaTheme'] = result
        except:
            pass
        
        # Leer la configuración del tema del cursor
        try:
            result = subprocess.check_output(
                ['kreadconfig5', '--file', 'kcminputrc', '--group', 'Mouse', '--key', 'cursorTheme'],
                text=True
            ).strip()
            theme_config['CursorTheme'] = result
        except:
            pass
        
        return theme_config
    except Exception as e:
        print(f"Error obteniendo configuración de tema: {e}")
        return {}

def apply_kde_theme_config(theme_config):
    """Aplica una configuración de tema guardada previamente"""
    try:
        if 'ColorScheme' in theme_config:
            subprocess.run([
                'kwriteconfig5', '--file', 'kdeglobals',
                '--group', 'General', '--key', 'ColorScheme', theme_config['ColorScheme']
            ], check=False)
        
        if 'IconTheme' in theme_config:
            subprocess.run([
                'kwriteconfig5', '--file', 'kdeglobals',
                '--group', 'Icons', '--key', 'Theme', theme_config['IconTheme']
            ], check=False)
        
        if 'PlasmaTheme' in theme_config:
            subprocess.run([
                'kwriteconfig5', '--file', 'plasmarc',
                '--group', 'Theme', '--key', 'name', theme_config['PlasmaTheme']
            ], check=False)
        
        if 'CursorTheme' in theme_config:
            subprocess.run([
                'kwriteconfig5', '--file', 'kcminputrc',
                '--group', 'Mouse', '--key', 'cursorTheme', theme_config['CursorTheme']
            ], check=False)
        
        # Recargar configuraciones
        subprocess.run(['qdbus', 'org.kde.KWin', '/KWin', 'reconfigure'], check=False)
        subprocess.run(['qdbus', 'org.kde.plasmashell', '/PlasmaShell', 'evaluateScript', 
                      'refreshCurrentShell()'], check=False)
        subprocess.run(['qdbus', 'org.kde.KGlobalSettings', '/KGlobalSettings', 
                      'notifyChange', '2', '0'], check=False)
        
        return True
    except Exception as e:
        print(f"Error aplicando configuración de tema: {e}")
        return False
