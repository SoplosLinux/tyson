#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import subprocess
import json
import time

def get_desktop_environment():
    """Detecta el entorno de escritorio actual"""
    desktop = os.getenv('XDG_CURRENT_DESKTOP', '').lower()
    session = os.getenv('DESKTOP_SESSION', '').lower()
    
    # Para esta versión, solo nos enfocamos en KDE
    is_kde = 'kde' in desktop or 'plasma' in desktop or 'kde' in session
    
    return 'kde' if is_kde else 'unknown'

def get_session_type():
    """Detecta si la sesión es Wayland o X11"""
    session_type = os.environ.get('XDG_SESSION_TYPE', '').lower()
    if session_type in ['wayland', 'x11']:
        return session_type
    
    # Verificar si hay variables específicas de Wayland
    if os.environ.get('WAYLAND_DISPLAY'):
        return 'wayland'
    
    # Verificar si hay variables específicas de X11
    if os.environ.get('DISPLAY'):
        return 'x11'
    
    # Por defecto en entorno live devolver wayland
    return 'wayland'

def save_language_preference(lang_code):
    """Guarda la preferencia de idioma del usuario"""
    config_dir = os.path.expanduser('~/.config/soplos-welcome-live')
    os.makedirs(config_dir, exist_ok=True)
    
    with open(os.path.join(config_dir, 'language'), 'w') as f:
        f.write(lang_code)

def load_language_preference():
    """Carga la preferencia de idioma del usuario"""
    config_file = os.path.expanduser('~/.config/soplos-welcome-live/language')
    if os.path.exists(config_file):
        with open(config_file, 'r') as f:
            lang_code = f.read().strip()
            # La validación del código de idioma se hará en el caller
            return lang_code
    return None

def get_kde_version():
    """
    Obtiene la versión de KDE/Plasma si está disponible
    
    Returns:
        str: Versión de KDE Plasma o None si no se puede determinar
    """
    try:
        output = subprocess.check_output(['plasmashell', '--version'], text=True).strip()
        version = output.split(' ')[-1] if ' ' in output else output
        return version
    except Exception:
        return None

def has_autologin_enabled():
    """Verifica si el autologin está activado en SDDM"""
    try:
        # Comprobar si existe configuración de autologin en SDDM
        sddm_conf_paths = [
            '/etc/sddm.conf.d/autologin.conf',
            '/etc/sddm.conf',
            '/usr/lib/sddm/sddm.conf.d/autologin.conf'
        ]
        
        for conf_path in sddm_conf_paths:
            if os.path.exists(conf_path):
                with open(conf_path, 'r') as f:
                    content = f.read()
                    if '[Autologin]' in content and 'User=' in content:
                        # Extraer el usuario de autologin
                        for line in content.split('\n'):
                            if line.strip().startswith('User='):
                                user = line.strip().split('=')[1].strip()
                                if user:  # Si hay un usuario configurado
                                    return user
        
        return False
    except Exception as e:
        print(f"Error verificando autologin: {e}")
        return False

def update_kde_locale(locale):
    """Actualiza la configuración de locale en KDE"""
    try:
        # Configuración de locale en KDE
        subprocess.run([
            'kwriteconfig5', '--file', 'plasma-localerc',
            '--group', 'Translations',
            '--key', 'LANGUAGE', locale.split('.')[0]
        ], check=False)
        
        # Recargar la configuración
        subprocess.run([
            'qdbus', 'org.kde.klauncher', '/KLauncher', 'reparseConfiguration'
        ], check=False)
        
        subprocess.run([
            'qdbus', 'org.kde.plasma.session', '/MainApplication', 'refreshX11Connection'
        ], check=False)
    except Exception as e:
        print(f"Error al actualizar locale de KDE: {e}")
