#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import subprocess
import shutil
from utils.desktop_detector import get_session_type

class XDGDirectoriesManager:
    """Gestiona los directorios XDG de manera simple"""
    
    def __init__(self):
        self.home_dir = os.path.expanduser('~')
        self.config_dir = os.path.join(self.home_dir, '.config')
        self.user_dirs_path = os.path.join(self.config_dir, 'user-dirs.dirs')
        self.session_type = get_session_type()
    
    def update_directories(self, locale):
        """Renombra los directorios XDG según el locale proporcionado de forma más robusta"""
        try:
            # 1. Aplicar variables de entorno
            env = os.environ.copy()
            env['LANG'] = locale
            env['LC_ALL'] = locale
            env['LANGUAGE'] = locale.split('_')[0]
            
            # 2. Generar configuración de directorios para el nuevo locale
            xdg_config_content = self._generate_xdg_config(locale)
            if xdg_config_content:
                with open(self.user_dirs_path, 'w') as f:
                    f.write(xdg_config_content)
            
            # 3. Forzar regeneración de user-dirs.dirs con el nuevo locale
            subprocess.run(['xdg-user-dirs-update', '--force'], 
                          env=env, check=True)
            
            # 4. Actualizar también la configuración de GTK si existe
            if shutil.which('xdg-user-dirs-gtk-update'):
                subprocess.run(['xdg-user-dirs-gtk-update', '--force'], 
                              env=env, check=True)
            
            # 5. Renombrar físicamente los directorios si es necesario
            self._rename_physical_directories(locale)
            
            # 6. Actualizar entorno de escritorio
            self._update_desktop_environment()
            
            return True
        except Exception as e:
            print(f"Error actualizando directorios XDG: {e}")
            return False
    
    def _generate_xdg_config(self, locale):
        """Genera configuración de directorios XDG según el locale"""
        lang_code = locale.split('_')[0]
        
        # Mapeo de directorios según idioma
        dir_names = {
            'es': {
                'DESKTOP': 'Escritorio',
                'DOWNLOAD': 'Descargas',
                'DOCUMENTS': 'Documentos',
                'MUSIC': 'Música',
                'PICTURES': 'Imágenes',
                'VIDEOS': 'Vídeos',
                'PUBLICSHARE': 'Público',
                'TEMPLATES': 'Plantillas'
            },
            'en': {
                'DESKTOP': 'Desktop',
                'DOWNLOAD': 'Downloads',
                'DOCUMENTS': 'Documents',
                'MUSIC': 'Music',
                'PICTURES': 'Pictures',
                'VIDEOS': 'Videos',
                'PUBLICSHARE': 'Public',
                'TEMPLATES': 'Templates'
            },
            'fr': {
                'DESKTOP': 'Bureau',
                'DOWNLOAD': 'Téléchargements',
                'DOCUMENTS': 'Documents',
                'MUSIC': 'Musique',
                'PICTURES': 'Images',
                'VIDEOS': 'Vidéos',
                'PUBLICSHARE': 'Public',
                'TEMPLATES': 'Modèles'
            },
            'de': {
                'DESKTOP': 'Schreibtisch',
                'DOWNLOAD': 'Downloads',
                'DOCUMENTS': 'Dokumente',
                'MUSIC': 'Musik',
                'PICTURES': 'Bilder',
                'VIDEOS': 'Videos',
                'PUBLICSHARE': 'Öffentlich',
                'TEMPLATES': 'Vorlagen'
            }
        }
        
        if lang_code not in dir_names:
            return None
        
        config_content = "# This file is written by xdg-user-dirs-update\n"
        config_content += "# If you want to change or add directories, just edit the line you're\n"
        config_content += "# interested in. All local changes will be retained on the next run.\n"
        config_content += "# Format is XDG_xxx_DIR=\"$HOME/yyy\", where yyy is a shell-escaped\n"
        config_content += "# homedir-relative path, or XDG_xxx_DIR=\"/yyy\", where /yyy is an\n"
        config_content += "# absolute path. No other format is supported.\n\n"
        
        for xdg_name, local_name in dir_names[lang_code].items():
            config_content += f'XDG_{xdg_name}_DIR="$HOME/{local_name}"\n'
        
        return config_content
    
    def _rename_physical_directories(self, locale):
        """Renombra físicamente los directorios existentes"""
        try:
            # Solo renombrar si estamos en una sesión live para evitar pérdida de datos
            if os.environ.get('USER') != 'liveuser':
                return
            
            lang_code = locale.split('_')[0]
            
            # Mapeo de nombres anteriores a nuevos
            rename_map = {
                'es': {
                    'Desktop': 'Escritorio',
                    'Downloads': 'Descargas',
                    'Documents': 'Documentos',
                    'Music': 'Música',
                    'Pictures': 'Imágenes',
                    'Videos': 'Vídeos',
                    'Public': 'Público',
                    'Templates': 'Plantillas'
                }
            }
            
            if lang_code in rename_map:
                for old_name, new_name in rename_map[lang_code].items():
                    old_path = os.path.join(self.home_dir, old_name)
                    new_path = os.path.join(self.home_dir, new_name)
                    
                    if os.path.exists(old_path) and not os.path.exists(new_path):
                        try:
                            os.rename(old_path, new_path)
                            print(f"Renombrado: {old_path} -> {new_path}")
                        except Exception as e:
                            print(f"Error renombrando {old_path}: {e}")
        except Exception as e:
            print(f"Error en renombrado físico: {e}")
    
    def _update_desktop_environment(self):
        """Actualiza el entorno de escritorio para reflejar los cambios"""
        try:
            if self.session_type == 'wayland':
                subprocess.run(['dbus-send', '--session', '--dest=org.kde.plasmashell',
                              '/PlasmaShell', 'org.kde.PlasmaShell.evaluateScript',
                              'string:refreshCurrentShell()'], check=False)
            
            # Forzar actualización de Dolphin/Konqueror
            subprocess.run(['qdbus', 'org.kde.klauncher5', '/KLauncher', 
                          'reparseConfiguration'], check=False)
            
        except Exception as e:
            print(f"Error actualizando entorno de escritorio: {e}")

# Instancia global para uso directo
xdg_manager = XDGDirectoriesManager()
