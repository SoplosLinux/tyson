#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import time
import subprocess
import shutil
from utils.desktop_detector import get_session_type
from utils.autostart import AutostartManager  # Importar AutostartManager

class SessionManager:
    """Gestor de sesión para manejar aspectos relacionados con la sesión de usuario"""
    
    def __init__(self):
        self.config_dir = os.path.expanduser('~/.config/soplos-welcome-live')
        # Asegurar que el directorio existe antes de cualquier operación
        try:
            os.makedirs(self.config_dir, exist_ok=True)
        except Exception as e:
            print(f"Error creando directorio de configuración: {e}")
            # Intentar con una ubicación alternativa en /tmp si falla
            self.config_dir = '/tmp/soplos-welcome-live'
            os.makedirs(self.config_dir, exist_ok=True)
        
        self.restart_state_file = os.path.join(self.config_dir, 'restart_state.json')
        self.session_type = get_session_type()
        self.autostart_manager = AutostartManager()
        
    def mark_for_restart(self):
        """Marca la sesión para reinicio con timestamp y estado del autostart"""
        restart_state = {
            'restarted': True,
            'time': time.time(),
            'need_locale_check': True,
            'autostart_enabled': self.autostart_manager.is_enabled()  # Guardar estado de autostart
        }
        
        with open(self.restart_state_file, 'w') as f:
            json.dump(restart_state, f)
        
        # También crear un archivo en el directorio /tmp para que persista después del reinicio
        try:
            with open('/tmp/soplos_welcome_restart_state.json', 'w') as f:
                json.dump(restart_state, f)
        except Exception as e:
            print(f"Error guardando estado en /tmp: {e}")
    
    def was_restarted(self):
        """Verifica si la sesión fue reiniciada recientemente"""
        # Primero verificar el archivo estándar
        if os.path.exists(self.restart_state_file):
            try:
                with open(self.restart_state_file, 'r') as f:
                    restart_state = json.load(f)
                
                # Si ha pasado menos de 60 segundos desde el reinicio
                if restart_state.get('restarted') and time.time() - restart_state.get('time', 0) < 60:
                    return True
            except:
                pass
                
        # Verificar el archivo en /tmp como respaldo
        try:
            if os.path.exists('/tmp/soplos_welcome_restart_state.json'):
                with open('/tmp/soplos_welcome_restart_state.json', 'r') as f:
                    restart_state = json.load(f)
                
                # Si ha pasado menos de 120 segundos desde el reinicio (más tiempo para /tmp)
                if restart_state.get('restarted') and time.time() - restart_state.get('time', 0) < 120:
                    
                    # Restaurar el estado de autostart si era necesario
                    if restart_state.get('autostart_enabled', False):
                        print("Restaurando autostart después del reinicio...")
                        self.autostart_manager.enable()
                    
                    return True
        except Exception as e:
            print(f"Error verificando estado en /tmp: {e}")
        
        return False
    
    def clear_restart_state(self):
        """Limpia el estado de reinicio"""
        if os.path.exists(self.restart_state_file):
            os.remove(self.restart_state_file)
        
        # También limpiar el archivo en /tmp
        if os.path.exists('/tmp/soplos_welcome_restart_state.json'):
            try:
                os.remove('/tmp/soplos_welcome_restart_state.json')
            except:
                pass
    
    def verify_locale_applied(self):
        """Verifica que los cambios de locale se aplicaron correctamente"""
        try:
            locale_info_file = os.path.join(self.config_dir, 'locale_info.json')
            if os.path.exists(locale_info_file):
                with open(locale_info_file, 'r') as f:
                    locale_info = json.load(f)
                
                # Verificar si el locale actual coincide con el guardado
                current_locale = os.getenv('LANG', '')
                if locale_info.get('locale', '') != current_locale:
                    print(f"El locale actual ({current_locale}) no coincide con el guardado ({locale_info.get('locale')})")
                    # Forzar la recarga del locale
                    os.environ['LANG'] = locale_info.get('locale', '')
                    os.environ['LC_ALL'] = locale_info.get('locale', '')
                    
                    # Intentar establecer manualmente también si está en liveuser
                    if os.getenv('USER') == 'liveuser':
                        try:
                            subprocess.run([
                                'kwriteconfig5', '--file', 'plasma-localerc',
                                '--group', 'Translations',
                                '--key', 'LANGUAGE', locale_info.get('locale', '').split('.')[0]
                            ], check=False)
                        except:
                            pass
        except Exception as e:
            print(f"Error verificando aplicación de locale: {e}")
    
    def restore_theme_from_skel(self):
        """Restaura la configuración de tema desde /etc/skel"""
        try:
            # Restaurar archivos de configuración desde /etc/skel
            skel_config_files = [
                'kdeglobals',
                'plasma-org.kde.plasma.desktop-appletsrc',
                'plasmarc',
                'kxkbrc',  # Para configuración de teclado
                'baloofilerc',  # Para configuración de búsqueda
                'Trolltech.conf',  # Para tema de Qt
                'gtk-3.0/settings.ini',  # Configuración GTK3
                'gtk-4.0/settings.ini'   # Configuración GTK4
            ]
            
            home_dir = os.path.expanduser('~')
            user_config_dir = os.path.join(home_dir, '.config')
            skel_config_dir = '/etc/skel/.config'
            
            # Verificar que el directorio de configuración skel existe
            if not os.path.exists(skel_config_dir):
                print(f"El directorio {skel_config_dir} no existe")
                return False
            
            # Crear directorio de backup antes de modificar nada
            backup_dir = os.path.join(user_config_dir, 'soplos-welcome-live', 'theme-backup-old')
            os.makedirs(backup_dir, exist_ok=True)
            timestamp = time.strftime('%Y%m%d-%H%M%S')
            backup_target = os.path.join(backup_dir, f'backup-{timestamp}')
            os.makedirs(backup_target, exist_ok=True)
            
            for config_file in skel_config_files:
                # Verificar si es un archivo individual o un directorio
                skel_path = os.path.join(skel_config_dir, config_file)
                user_path = os.path.join(user_config_dir, config_file)
                
                # Si es un directorio (como gtk-3.0), asegurar que existe
                if '/' in config_file:
                    dir_name = os.path.dirname(user_path)
                    os.makedirs(dir_name, exist_ok=True)
                
                # Respaldar la configuración actual si existe
                if os.path.exists(user_path):
                    if os.path.isdir(user_path):
                        # Es un directorio, hacer backup del contenido
                        backup_dir_path = os.path.join(backup_target, config_file)
                        os.makedirs(os.path.dirname(backup_dir_path), exist_ok=True)
                        shutil.copytree(user_path, backup_dir_path, dirs_exist_ok=True)
                    else:
                        # Es un archivo, hacer backup simple
                        backup_file_path = os.path.join(backup_target, config_file)
                        os.makedirs(os.path.dirname(backup_file_path), exist_ok=True)
                        shutil.copy2(user_path, backup_file_path)
                
                # Copiar desde skel si existe el archivo/directorio
                if os.path.exists(skel_path):
                    # Crear el directorio padre si es necesario
                    parent_dir = os.path.dirname(user_path)
                    if parent_dir and not os.path.exists(parent_dir):
                        os.makedirs(parent_dir, exist_ok=True)
                    
                    # Copiar el archivo o directorio
                    if os.path.isdir(skel_path):
                        # Es un directorio, copiar recursivamente
                        shutil.copytree(skel_path, user_path, dirs_exist_ok=True)
                        print(f"Copiando directorio {skel_path} a {user_path}")
                    else:
                        # Es un archivo simple
                        shutil.copy2(skel_path, user_path)
                        print(f"Copiando archivo {skel_path} a {user_path}")
            
            # Forzar recarga de la configuración de KDE
            try:
                subprocess.run(['qdbus', 'org.kde.KWin', '/KWin', 'reconfigure'], check=False)
                subprocess.run(['qdbus', 'org.kde.plasmashell', '/PlasmaShell', 'evaluateScript', 
                            'refreshCurrentShell()'], check=False)
                
                # Recargar las configuraciones específicas de tema
                subprocess.run(['kwriteconfig5', '--file', 'kcminputrc', '--group', 'Mouse', 
                              '--key', 'cursorTheme', '--reload'], check=False)
                subprocess.run(['qdbus', 'org.kde.KGlobalSettings', '/KGlobalSettings', 
                              'notifyChange', '2', '0'], check=False)
            except Exception as e:
                print(f"Error al recargar configuración de KDE: {e}")
            
            return True
        except Exception as e:
            print(f"Error restaurando tema desde skel: {e}")
            return False
    
    def configure_system_locale(self, locale, layout):
        """Configura el locale y teclado a nivel de sistema sin usar scripts"""
        try:
            # Definir contenido para locale.conf
            locale_conf_content = f"LANG={locale}\nLC_ALL={locale}\n"
            
            # Usar subprocess para escribir archivos con sudo
            subprocess.run(['sudo', 'bash', '-c', f'echo "{locale_conf_content}" > /etc/locale.conf'], check=True)
            
            # 2. Actualizar /etc/default/locale
            default_locale_content = f"""LANG={locale}
LC_ALL={locale}
"""
            subprocess.run(['sudo', 'bash', '-c', f'echo "{default_locale_content}" > /etc/default/locale'], check=True)
            
            # 3. Actualizar variables en /etc/environment
            # Primero leer el archivo actual
            try:
                env_content = subprocess.check_output(['sudo', 'cat', '/etc/environment'], text=True)
                # Modificar o agregar las variables de locale
                new_env_lines = []
                lang_set = lc_all_set = False
                
                for line in env_content.splitlines():
                    if line.startswith('LANG='):
                        new_env_lines.append(f'LANG={locale}')
                        lang_set = True
                    elif line.startswith('LC_ALL='):
                        new_env_lines.append(f'LC_ALL={locale}')
                        lc_all_set = True
                    else:
                        new_env_lines.append(line)
                
                if not lang_set:
                    new_env_lines.append(f'LANG={locale}')
                if not lc_all_set:
                    new_env_lines.append(f'LC_ALL={locale}')
                    
                # Escribir el archivo actualizado
                new_env_content = '\n'.join(new_env_lines) + '\n'
                subprocess.run(['sudo', 'bash', '-c', f'echo "{new_env_content}" > /etc/environment'], check=True)
            except:
                # Si falla la lectura, simplemente añadir las variables
                subprocess.run(['sudo', 'bash', '-c', f'echo "LANG={locale}" >> /etc/environment'], check=True)
                subprocess.run(['sudo', 'bash', '-c', f'echo "LC_ALL={locale}" >> /etc/environment'], check=True)
            
            # 4. Actualizar locale-gen si es necesario
            try:
                # Verificar si el locale ya está activo en locale.gen
                locale_gen_content = subprocess.check_output(['sudo', 'cat', '/etc/locale.gen'], text=True)
                locale_pattern = f'{locale} UTF-8'
                
                if f'#{locale_pattern}' in locale_gen_content:
                    # Descomentarlo
                    subprocess.run(['sudo', 'sed', '-i', f's/^#{locale_pattern}/{locale_pattern}/', '/etc/locale.gen'], check=True)
                    # Generar el locale
                    subprocess.run(['sudo', 'locale-gen', locale], check=True)
                elif locale_pattern not in locale_gen_content:
                    # Añadirlo y generarlo
                    subprocess.run(['sudo', 'bash', '-c', f'echo "{locale} UTF-8 UTF-8" >> /etc/locale.gen'], check=True)
                    subprocess.run(['sudo', 'locale-gen', locale], check=True)
            except:
                pass  # Si falla, continuar con el resto
            
            # 5. Usar localectl
            subprocess.run(['sudo', 'localectl', 'set-locale', f'LANG={locale}', f'LC_ALL={locale}'], check=False)
            
            # 6-8. Configurar teclado
            # Crear /etc/xdg/keyboard
            keyboard_content = f"XKBLAYOUT={layout}"
            subprocess.run(['sudo', 'mkdir', '-p', '/etc/xdg'], check=True)
            subprocess.run(['sudo', 'bash', '-c', f'echo "{keyboard_content}" > /etc/xdg/keyboard'], check=True)
            
            # Configurar teclado con localectl
            subprocess.run(['sudo', 'localectl', 'set-keymap', layout], check=False)
            subprocess.run(['sudo', 'localectl', 'set-x11-keymap', layout], check=False)
            
            # Configurar /etc/vconsole.conf
            subprocess.run(['sudo', 'bash', '-c', f'echo "KEYMAP={layout}" > /etc/vconsole.conf'], check=True)
            
            # 9. Configurar SDDM
            if os.path.exists('/etc/sddm.conf.d'):
                keyboard_conf_content = f"[X11]\nServerArguments=-layout {layout}"
                locale_conf_content = f"[General]\nLanguage={locale}"
                
                subprocess.run(['sudo', 'bash', '-c', f'echo "{keyboard_conf_content}" > /etc/sddm.conf.d/keyboard.conf'], check=True)
                subprocess.run(['sudo', 'bash', '-c', f'echo "{locale_conf_content}" > /etc/sddm.conf.d/locale.conf'], check=True)
            
            # 10. Marcar configuración establecida
            subprocess.run(['sudo', 'bash', '-c', f'echo "LOCALE_CONFIGURED={locale}" > /tmp/locale_configured'], check=True)
            subprocess.run(['sudo', 'bash', '-c', f'echo "LAYOUT_CONFIGURED={layout}" >> /tmp/locale_configured'], check=True)
            
            # Configurar variables de entorno actuales
            os.environ['LANG'] = locale
            os.environ['LC_ALL'] = locale
            
            # Configuración inmediata de KDE
            subprocess.run([
                'kwriteconfig5', '--file', 'plasma-localerc',
                '--group', 'Translations',
                '--key', 'LANGUAGE', locale.split('.')[0]
            ], check=False)
            
            # Configurar distribución de teclado
            subprocess.run([
                'kwriteconfig5', '--file', 'kxkbrc',
                '--group', 'Layout',
                '--key', 'LayoutList', layout
            ], check=True)
            
            subprocess.run([
                'kwriteconfig5', '--file', 'kxkbrc',
                '--group', 'Layout',
                '--key', 'Use', 'true'
            ], check=True)
            
            # Recargar teclado
            subprocess.run([
                'qdbus', 'org.kde.keyboard', '/Layouts', 'reset'
            ], check=False)
            
            # Guardar información de locale
            with open(os.path.join(self.config_dir, 'locale_info.json'), 'w') as f:
                json.dump({
                    'locale': locale,
                    'layout': layout,
                    'timestamp': time.time()
                }, f)

            return True
        except Exception as e:
            print(f"Error configurando locale del sistema: {e}")
            return False
    
    def ensure_autologin(self, username='liveuser'):
        """Asegura que el autologin está configurado de forma persistente"""
        try:
            # Crear directorio sddm.conf.d si no existe
            try:
                subprocess.run(['sudo', 'mkdir', '-p', '/etc/sddm.conf.d'], check=True)
            except:
                subprocess.run(['pkexec', 'mkdir', '-p', '/etc/sddm.conf.d'], check=True)
                
            # Contenido del archivo de configuración
            autologin_content = f"""[Autologin]
User={username}
Session=plasma.desktop
Relogin=true
"""
            # Usar echo directamente para crear el archivo 
            with open('/tmp/autologin.conf', 'w') as f:
                f.write(autologin_content)
                
            # Mover el archivo a su ubicación
            try:
                subprocess.run(['sudo', 'mv', '/tmp/autologin.conf', '/etc/sddm.conf.d/autologin.conf'], check=True)
                subprocess.run(['sudo', 'chmod', '644', '/etc/sddm.conf.d/autologin.conf'], check=True)
            except:
                subprocess.run(['pkexec', 'mv', '/tmp/autologin.conf', '/etc/sddm.conf.d/autologin.conf'], check=True)
                subprocess.run(['pkexec', 'chmod', '644', '/etc/sddm.conf.d/autologin.conf'], check=True)
                
            # Configurar sddm.conf si existe
            if os.path.exists('/etc/sddm.conf'):
                with open('/tmp/sddm_autologin.conf', 'w') as f:
                    f.write(autologin_content)
                
                try:
                    # Si sddm.conf ya tiene sección Autologin, la reemplazaremos
                    if subprocess.run(['grep', '-q', '\\[Autologin\\]', '/etc/sddm.conf'], check=False).returncode == 0:
                        subprocess.run(['sudo', 'sed', '-i', 
                                      f'/\\[Autologin\\]/,/\\[/{{s/User=.*/User={username}/;s/Session=.*/Session=plasma.desktop/;s/Relogin=.*/Relogin=true/}}', 
                                      '/etc/sddm.conf'], check=False)
                    else:
                        # Añadir sección al final del archivo
                        with open('/tmp/sddm_autologin_append', 'w') as f:
                            f.write(f"\n{autologin_content}")
                        subprocess.run(['sudo', 'bash', '-c', 'cat /tmp/sddm_autologin_append >> /etc/sddm.conf'], check=False)
                        os.unlink('/tmp/sddm_autologin_append')
                except:
                    pass
                    
            # Habilitar linger para el usuario
            try:
                subprocess.run(['sudo', 'loginctl', 'enable-linger', username], check=False)
            except:
                subprocess.run(['pkexec', 'loginctl', 'enable-linger', username], check=False)
                
            return True
        except Exception as e:
            print(f"Error asegurando autologin: {e}")
            return False
    
    def restart_sddm(self):
        """Reinicia SDDM de forma segura usando llamadas directas sin scripts externos"""
        try:
            # 1. Asegurar que autologin está configurado para este usuario
            username = os.environ.get('USER', 'liveuser')
            if not self.ensure_autologin(username):
                print("Advertencia: No se pudo asegurar el autologin")
            
            # 2. Guardar estado de autostart directamente
            autostart_enabled = self.autostart_manager.is_enabled()
            restart_state = {
                'restarted': True,
                'time': time.time(),
                'need_locale_check': True,
                'autostart_enabled': autostart_enabled
            }
            
            # Guardar estado en nuestros archivos JSON
            with open(self.restart_state_file, 'w') as f:
                json.dump(restart_state, f)
            
            with open('/tmp/soplos_welcome_restart_state.json', 'w') as f:
                json.dump(restart_state, f)
            
            # 3. Reiniciar SDDM directamente usando systemctl
            session_type = get_session_type()
            print(f"Ejecutando reinicio de SDDM en sesión {session_type}...")
            
            # Ejecutar systemctl restart sddm directamente con sudo o pkexec
            try:
                subprocess.run(['sudo', 'systemctl', 'restart', 'sddm'], check=True)
            except:
                subprocess.run(['pkexec', 'systemctl', 'restart', 'sddm'], check=True)
                
            return True
        except Exception as e:
            print(f"Error crítico reiniciando SDDM: {e}")
            return False

# Instancia global
session_manager = SessionManager()
