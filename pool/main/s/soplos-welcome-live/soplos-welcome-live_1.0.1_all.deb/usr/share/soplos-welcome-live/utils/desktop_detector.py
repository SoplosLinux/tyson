#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import subprocess

def get_desktop_environment():
    """Detecta el entorno de escritorio actual"""
    desktop = os.getenv('XDG_CURRENT_DESKTOP', '').lower()
    session = os.getenv('DESKTOP_SESSION', '').lower()
    
    if 'kde' in desktop or 'plasma' in desktop or 'kde' in session:
        return 'kde'
    elif 'xfce' in desktop or 'xfce' in session:
        return 'xfce'
    elif 'gnome' in desktop or 'gnome' in session:
        return 'gnome'
    else:
        return 'unknown'

def save_language_preference(lang_code):
    """Guarda la preferencia de idioma del usuario"""
    config_dir = os.path.expanduser('~/.config/soplos-welcome-live')
    os.makedirs(config_dir, exist_ok=True)
    
    with open(os.path.join(config_dir, 'language'), 'w') as f:
        f.write(lang_code)

def load_language_preference():
    """Carga la preferencia de idioma del usuario"""
    config_file = os.path.expanduser('~/.config/soplos-welcome-live/language')
    if os.path.exists(config_file):
        with open(config_file, 'r') as f:
            lang_code = f.read().strip()
            # La validación del código de idioma se hará en el caller
            return lang_code
    return None

def get_kde_version():
    """
    Obtiene la versión de KDE/Plasma si está disponible
    
    Returns:
        str: Versión de KDE Plasma o None si no es KDE o no se puede determinar
    """
    if get_desktop_environment() != 'kde':
        return None
    
    try:
        output = subprocess.check_output(['plasmashell', '--version'], text=True).strip()
        version = output.split(' ')[-1] if ' ' in output else output
        return version
    except Exception:
        return None


def update_desktop_environment(desktop_env, locale):
    """
    Actualiza la configuración del entorno de escritorio para el nuevo locale
    
    Args:
        desktop_env (str): Nombre del entorno de escritorio ('kde', 'xfce', etc.)
        locale (str): El nuevo locale a aplicar (ej. 'es_ES.UTF-8')
    """
    try:
        if desktop_env == 'kde':
            _update_kde_locale(locale)
        elif desktop_env == 'xfce':
            _update_xfce_locale(locale)
        # Añadir más entornos según sea necesario
    except Exception as e:
        print(f"Error actualizando entorno {desktop_env}: {e}")


def _update_kde_locale(locale):
    """Actualiza la configuración de locale en KDE"""
    try:
        # Configuración de locale en KDE
        subprocess.run([
            'kwriteconfig5', '--file', 'plasma-localerc',
            '--group', 'Translations',
            '--key', 'LANGUAGE', locale.split('.')[0]
        ], check=False)
        
        # Recargar la configuración
        subprocess.run([
            'qdbus', 'org.kde.klauncher', '/KLauncher', 'reparseConfiguration'
        ], check=False)
        
        subprocess.run([
            'qdbus', 'org.kde.plasma.session', '/MainApplication', 'refreshX11Connection'
        ], check=False)
    except Exception as e:
        print(f"Error al actualizar locale de KDE: {e}")


def _update_xfce_locale(locale):
    """Actualiza la configuración de locale en XFCE"""
    try:
        # En XFCE la configuración está en ~/.config/xfce4/xfconf/xfce-perchannel-xml/xsettings.xml
        # Este archivo debería actualizarse automáticamente al cambiar las variables de entorno
        pass
    except Exception as e:
        print(f"Error al actualizar locale de XFCE: {e}")
