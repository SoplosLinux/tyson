import gi
import os
import subprocess
import sys
import shutil
import json
import time

# Añadir el directorio raíz al path de Python
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GdkPixbuf, Gdk, GLib
from ui.welcome_tab import WelcomeTab
from config.paths import LOGO_PATH, ICON_PATH
from config.strings import STRINGS
from utils.autostart import AutostartManager
from ui.chroot_window import ChRootWindow
from utils.desktop_detector import (
    get_desktop_environment, 
    get_session_type,
    save_language_preference, 
    has_autologin_enabled,
    update_kde_locale
)
from utils.session_manager import session_manager  # Importar el nuevo session_manager
from utils.xdg_helper import xdg_manager  # Añadir importación

# Diccionario de idiomas y sus configuraciones
LANGUAGES = {
    'Español': {'locale': 'es_ES.UTF-8', 'layout': 'es'},
    'English': {'locale': 'en_US.UTF-8', 'layout': 'us'},
    'Português': {'locale': 'pt_PT.UTF-8', 'layout': 'pt'},
    'Français': {'locale': 'fr_FR.UTF-8', 'layout': 'fr'},
    'Deutsch': {'locale': 'de_DE.UTF-8', 'layout': 'de'},
    'Italiano': {'locale': 'it_IT.UTF-8', 'layout': 'it'},
    'Română': {'locale': 'ro_RO.UTF-8', 'layout': 'ro'},
    'Русский': {'locale': 'ru_RU.UTF-8', 'layout': 'ru'}
}

class MainWindow(Gtk.ApplicationWindow):
    def __init__(self, lang_code=None):
        super().__init__()
        
        # Establecer WM_CLASS para que coincida con el .desktop
        self.set_wmclass("com.soplos.welcomelive", "com.soplos.welcomelive")
        
        # Establecer el icono de la ventana explícitamente
        try:
            icon_theme = Gtk.IconTheme.get_default()
            try:
                icon = icon_theme.load_icon("com.soplos.welcomelive", 128, 0)
                self.set_icon(icon)
            except:
                # Fallback a ruta absoluta si falla la carga por nombre
                if os.path.exists(ICON_PATH):
                    self.set_icon_from_file(ICON_PATH)
        except Exception as e:
            print(f"Error al establecer el icono: {e}")
        
        app = Gtk.Application.get_default()
        Gtk.ApplicationWindow.__init__(self, application=app)
        self.set_title("Soplos Welcome Live")
        
        # Detectar el entorno de escritorio y tipo de sesión
        self.desktop_env = get_desktop_environment()
        self.session_type = get_session_type()
        print(f"Entorno de escritorio: {self.desktop_env}, Tipo de sesión: {self.session_type}")
        
        # Verificar si estamos iniciando después de un cambio de idioma
        self._check_restart_state()
        
        # Usar el idioma proporcionado o detectarlo si es None
        if lang_code and lang_code in STRINGS:
            self.current_lang = lang_code
        else:
            # Detectar el idioma actual del sistema de manera segura
            current_locale = os.getenv('LANG', 'en_US.UTF-8')
            # Si es C.UTF-8 o similar, usar inglés por defecto
            if current_locale.startswith('C.') or current_locale == 'C':
                self.current_lang = 'en'
            else:
                self.current_lang = current_locale.split('_')[0]
                # Si el idioma no existe en STRINGS, usar inglés
                if self.current_lang not in STRINGS:
                    self.current_lang = 'en'
        
        # Buscar el nombre del idioma en LANGUAGES
        current_language_name = None
        for name, config in LANGUAGES.items():
            if config['locale'].startswith(f"{self.current_lang}_"):
                current_language_name = name
                break
        
        if not current_language_name:
            # Si no se encontró un nombre, usar el primero que coincida con el código
            for name, config in LANGUAGES.items():
                if config['locale'].startswith(self.current_lang):
                    current_language_name = name
                    break
        
        self.set_title(STRINGS[self.current_lang]['welcome'])
        self.set_wmclass('soplos-welcome-live', 'soplos-welcome-live')
        
        self.set_border_width(10)
        
        self.set_default_size(800, 450)  # Aumentada la altura de 400 a 550
        self.set_position(Gtk.WindowPosition.CENTER)
        
        # Contenedor principal horizontal
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(main_box)
        
        # Sub-contenedor horizontal para logo y contenido
        content_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        main_box.pack_start(content_box, True, True, 0)

        # Panel izquierdo para logo (ahora va en content_box)
        left_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        left_panel.set_size_request(200, -1)
        content_box.pack_start(left_panel, False, False, 5)

        try:
            header_pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                filename=LOGO_PATH,
                width=150,
                height=150,
                preserve_aspect_ratio=True
            )
            logo_image = Gtk.Image.new_from_pixbuf(header_pixbuf)
            left_panel.pack_start(logo_image, False, False, 10)
        except Exception as e:
            print(f"Error al cargar el logo: {e}")
        
        welcome_label = Gtk.Label()
        welcome_label.set_markup(
            f"<span size='large' weight='bold'>{STRINGS[self.current_lang]['welcome']}</span>\n" +
            f"<span size='small'>{STRINGS[self.current_lang]['thanks']}</span>"
        )
        welcome_label.set_justify(Gtk.Justification.CENTER)
        welcome_label.set_line_wrap(True)
        left_panel.pack_start(welcome_label, False, False, 5)
        
        # Añadir espacio flexible que empujará el selector de idioma hacia abajo
        left_panel.pack_start(Gtk.Box(), True, True, 0)
        
        # Selector de idioma y autostart en el panel izquierdo
        controls_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        left_panel.pack_end(controls_box, False, False, 0)

        # Switch de autostart (eliminado switch de numlockx)
        autostart_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        autostart_label = Gtk.Label(label=STRINGS[self.current_lang]['labels']['show_startup'])
        autostart_box.pack_start(autostart_label, False, False, 0)
        
        self.autostart_switch = Gtk.Switch()
        self.autostart_manager = AutostartManager()
        self.autostart_switch.set_active(self.autostart_manager.is_enabled())
        self.autostart_switch.connect("notify::active", self.on_autostart_toggled)
        autostart_box.pack_end(self.autostart_switch, False, False, 0)
        
        controls_box.pack_start(autostart_box, False, False, 5)
        
        # Selector de idioma en el panel izquierdo, ahora se alineará con el botón de salida
        lang_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        lang_box.set_margin_bottom(5)  # Margen inferior para alinear con el botón de salida
        controls_box.pack_start(lang_box, False, False, 0)  # Usamos pack_end en lugar de pack_start
        
        lang_label = Gtk.Label(label=STRINGS[self.current_lang]['labels']['language'])
        lang_box.pack_start(lang_label, False, False, 0)
        
        self.lang_combo = Gtk.ComboBoxText()
        # Añadir idiomas y guardar el índice del idioma actual
        current_index = 0
        for i, (lang, config) in enumerate(LANGUAGES.items()):
            self.lang_combo.append_text(lang)
            if current_language_name and lang == current_language_name:
                current_index = i
        
        # Seleccionar el idioma actual por índice
        self.lang_combo.set_active(current_index)
        self.lang_combo.connect("changed", self.on_language_changed)
        lang_box.pack_start(self.lang_combo, True, True, 5)
        
        # Panel derecho (ahora va en content_box)
        right_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        content_box.pack_start(right_panel, True, True, 0)
        
        welcome_tab = WelcomeTab(self)
        right_panel.pack_start(welcome_tab, True, True, 0)
        
        # Panel inferior con botones
        button_panel = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        right_panel.pack_end(button_panel, False, False, 5)

        # Botones (mantener el orden existente)
        exit_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['exit'])
        exit_button.set_use_underline(True)
        exit_button.connect("clicked", self.on_exit_clicked)
        button_panel.pack_end(exit_button, False, False, 0)

        chroot_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['chroot'])
        chroot_button.set_use_underline(True)
        chroot_button.connect("clicked", self.on_chroot_clicked)
        button_panel.pack_end(chroot_button, False, False, 5)

        install_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['install'])
        install_button.set_use_underline(True)
        install_button.connect("clicked", self.on_install_clicked)
        install_button.get_style_context().add_class("install-button")
        button_panel.pack_end(install_button, False, False, 5)

        # Barra de progreso al final del main_box
        self.progress_bar = Gtk.ProgressBar()
        self.progress_bar.set_show_text(False)  # Inicialmente sin texto
        self.progress_bar.set_visible(False)
        main_box.pack_end(self.progress_bar, False, True, 0)

        # Añadir CSS para el botón de instalación
        css_provider = Gtk.CssProvider()
        css = b"""
            .install-button {
                background: #e95420;
                color: white;
                padding: 5px 10px;
                font-weight: bold;
            }
            .install-button:hover {
                background: #e9662b;
            }
        """
        css_provider.load_from_data(css)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(),
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
    
    def _check_restart_state(self):
        """Verifica si estamos iniciando después de un cambio de idioma"""
        # Verificar si es primer inicio de la aplicación y evitar acciones innecesarias
        first_run_file = os.path.join(session_manager.config_dir, 'first_run_completed')
        is_first_run = not os.path.exists(first_run_file)
        
        if is_first_run:
            print("Primer inicio detectado, omitiendo verificación de reinicio")
            try:
                # Marcar como primer inicio completado
                with open(first_run_file, 'w') as f:
                    f.write(str(time.time()))
                return
            except Exception as e:
                print(f"Error al marcar primer inicio: {e}")
        
        # Verificar reinicio normal solo si no es primer inicio
        if session_manager.was_restarted():
            print("Detectado reinicio por cambio de idioma, aplicando configuración...")
            
            # Verificar si el locale se aplicó correctamente
            session_manager.verify_locale_applied()
            
            # Restaurar únicamente configuración de teclado y locale, mantener el tema intacto
            success = session_manager.restore_theme_from_skel()
            if not success:
                print("Advertencia: No se pudo aplicar la configuración de teclado/locale")
                
            # Eliminar el archivo de estado
            session_manager.clear_restart_state()
    
    def on_language_changed(self, combo):
        lang_name = combo.get_active_text()
        lang_config = LANGUAGES[lang_name]
        
        # Obtener el código de idioma y locale completo
        lang_code = lang_config['locale'].split('_')[0]
        locale = lang_config['locale']
        layout = lang_config['layout']
        
        # Guardar la preferencia de idioma
        save_language_preference(lang_code)
        
        # Mostrar barra de progreso con texto
        self.progress_bar.set_visible(True)
        self.progress_bar.set_show_text(True)
        self.progress_bar.set_fraction(0.0)
        self.progress_bar.set_text(STRINGS[self.current_lang]['progress']['configuring'])
        
        try:
            # Actualizar la barra de progreso mientras se realizan las tareas
            self.progress_bar.set_fraction(0.2)
            while Gtk.events_pending():
                Gtk.main_iteration()
        
            # Cambiar el idioma actual para esta sesión inmediatamente
            os.environ['LANG'] = locale
            os.environ['LC_ALL'] = locale
            
            # 1. Configurar locale y teclado a nivel de sistema
            success = session_manager.configure_system_locale(locale, layout)
            if not success:
                raise Exception("Error configurando locale del sistema")
                
            self.progress_bar.set_fraction(0.6)
            while Gtk.events_pending():
                Gtk.main_iteration()
                
            # 2. Migrar directorios XDG según el nuevo locale usando xdg_manager
            xdg_manager.update_directories(locale)
            
            self.progress_bar.set_fraction(0.8)
            while Gtk.events_pending():
                Gtk.main_iteration()
                
            # 3. Asegurar que el autologin esté configurado antes del reinicio
            username = os.environ.get('USER', 'liveuser')
            session_manager.ensure_autologin(username)
            
            # 4. Preparar para reiniciar la sesión
            self.progress_bar.set_text(STRINGS[self.current_lang]['progress'].get(
                'restarting', "Reiniciando sesión..."))
            self.progress_bar.set_fraction(1.0)
            while Gtk.events_pending():
                Gtk.main_iteration()
                
            # 5. Reiniciar SDDM después de una breve pausa
            GLib.timeout_add(1500, self._restart_session)
            
        except Exception as e:
            self.progress_bar.set_visible(False)
            self.show_error_dialog(f"{STRINGS[self.current_lang]['locale']['error_generating']}\n{str(e)}")

    def reload_app_for_language(self, lang_code):
        """Recarga la aplicación con el nuevo idioma sin reiniciar SDDM"""
        self.progress_bar.set_visible(False)
        
        # Informar al usuario que los cambios se aplicaron
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text=STRINGS[lang_code]['locale']['restart_session_title']
        )
        dialog.format_secondary_text(STRINGS[lang_code]['locale']['restart_session_desc'])
        dialog.run()
        dialog.destroy()
        
        # Reiniciar la aplicación
        python = sys.executable
        os.execl(python, python, *sys.argv)
        
        return False  # Para que el timer no lo vuelva a ejecutar

    def _configure_system_locale_robust(self, locale, layout):
        """Configuración robusta de locale para ISO live"""
        try:
            # 1. Generar locale si no existe
            subprocess.run(['sudo', 'locale-gen', locale], check=True)
            
            # 2. Escribir en /etc/locale.conf con método robusto
            locale_content = f"""LANG={locale}
LC_ALL={locale}
LANGUAGE={locale.split('_')[0]}
"""
            with open('/tmp/locale.conf', 'w') as f:
                f.write(locale_content)
            subprocess.run(['sudo', 'mv', '/tmp/locale.conf', '/etc/locale.conf'], check=True)
            
            # 3. Configurar teclado para la sesión actual
            subprocess.run(['setxkbmap', layout], check=True)
            
            # 4. Configurar teclado permanente
            keyboard_conf = f"""Section "InputClass"
    Identifier "system-keyboard"
    MatchIsKeyboard "on"
    Option "XkbLayout" "{layout}"
EndSection
"""
            subprocess.run(['sudo', 'mkdir', '-p', '/etc/X11/xorg.conf.d'], check=True)
            with open('/tmp/00-keyboard.conf', 'w') as f:
                f.write(keyboard_conf)
            subprocess.run(['sudo', 'mv', '/tmp/00-keyboard.conf', '/etc/X11/xorg.conf.d/00-keyboard.conf'], check=True)
            
            # 5. Guardar información de locale para verificación posterior
            locale_info = {
                'locale': locale,
                'layout': layout,
                'timestamp': time.time()
            }
            locale_info_file = os.path.join(session_manager.config_dir, 'locale_info.json')
            with open(locale_info_file, 'w') as f:
                json.dump(locale_info, f)
            
            return True
        except Exception as e:
            print(f"Error en configuración robusta de locale: {e}")
            return False
    
    def _ensure_autologin_robust(self, username):
        """Configuración robusta de autologin para ISO live"""
        try:
            # 1. Crear configuración de autologin más específica
            autologin_content = f"""[Autologin]
User={username}
Session=plasma
Relogin=true

[General]
HaltCommand=/usr/bin/systemctl poweroff
RebootCommand=/usr/bin/systemctl reboot
"""
            
            # 2. Asegurar directorio de configuración SDDM
            subprocess.run(['sudo', 'mkdir', '-p', '/etc/sddm.conf.d'], check=True)
            
            # 3. Escribir configuración de autologin
            with open('/tmp/autologin.conf', 'w') as f:
                f.write(autologin_content)
            subprocess.run(['sudo', 'mv', '/tmp/autologin.conf', '/etc/sddm.conf.d/autologin.conf'], check=True)
            subprocess.run(['sudo', 'chmod', '644', '/etc/sddm.conf.d/autologin.conf'], check=True)
            
            # 4. Configurar también el archivo principal de SDDM si existe
            if os.path.exists('/etc/sddm.conf'):
                # Leer configuración actual
                try:
                    with open('/etc/sddm.conf', 'r') as f:
                        sddm_content = f.read()
                    
                    # Si no tiene sección Autologin, añadirla
                    if '[Autologin]' not in sddm_content:
                        sddm_content += f"\n\n{autologin_content}"
                    else:
                        # Reemplazar sección existente
                        lines = sddm_content.split('\n')
                        new_lines = []
                        in_autologin = False
                        
                        for line in lines:
                            if line.strip() == '[Autologin]':
                                in_autologin = True
                                new_lines.append(line)
                                new_lines.append(f'User={username}')
                                new_lines.append(f'Session=plasma')
                                new_lines.append(f'Relogin=true')
                            elif line.startswith('[') and line != '[Autologin]':
                                in_autologin = False
                                new_lines.append(line)
                            elif not in_autologin:
                                new_lines.append(line)
                        
                        sddm_content = '\n'.join(new_lines)
                    
                    with open('/tmp/sddm.conf', 'w') as f:
                        f.write(sddm_content)
                    subprocess.run(['sudo', 'mv', '/tmp/sddm.conf', '/etc/sddm.conf'], check=True)
                except Exception as e:
                    print(f"Error modificando /etc/sddm.conf: {e}")
            
            return True
        except Exception as e:
            print(f"Error configurando autologin robusto: {e}")
            return False

    def _restart_session_robust(self):
        """Reinicio robusto de la sesión"""
        try:
            # Crear script de reinicio que persista
            restart_script = f"""#!/bin/bash
echo "Reiniciando SDDM para aplicar cambios de idioma..."
systemctl restart sddm
"""
            with open('/tmp/restart_sddm.sh', 'w') as f:
                f.write(restart_script)
            os.chmod('/tmp/restart_sddm.sh', 0o755)
            
            # Ejecutar reinicio con sudo
            subprocess.run(['sudo', '/tmp/restart_sddm.sh'], check=True)
            return False
        except Exception as e:
            print(f"Error en reinicio robusto: {e}")
            return False

    def _migrate_xdg_dirs_safely(self, locale):
        """Delega la migración de directorios XDG al módulo especializado"""
        from utils.xdg_helper import xdg_manager
        return xdg_manager.update_directories(locale)
    
    def _restart_session(self):
        """Reinicia la sesión automáticamente con autologin forzado"""
        print("Reiniciando SDDM para aplicar cambios de idioma...")
        session_manager.restart_sddm()
        return False  # para que GLib.timeout_add no la llame de nuevo

    def _restore_kde_desktop_config(self):
        """Recarga la configuración del escritorio KDE de forma completa"""
        try:
            # Recargar configuración de KDE de forma más completa
            commands = [
                ['qdbus', 'org.kde.keyboard', '/Layouts', 'reset'],
                ['qdbus', 'org.kde.KWin', '/KWin', 'reconfigure'],
                ['qdbus', 'org.kde.plasmashell', '/PlasmaShell', 'evaluateScript', 'refreshCurrentShell()'],
                ['qdbus', 'org.kde.KGlobalSettings', '/KGlobalSettings', 'notifyChange', '0', '0']
            ]
            
            for cmd in commands:
                try:
                    subprocess.run(cmd, check=False)
                except Exception as e:
                    print(f"Error ejecutando {cmd}: {e}")
        except Exception as e:
            print(f"Error recargando configuración de KDE: {e}")
    
    def _hide_progress_bar(self):
        """Oculta la barra de progreso"""
        self.progress_bar.set_visible(False)
        return False  # para que GLib.timeout_add no la llame de nuevo
    
    def show_error_dialog(self, message):
        dialog = Gtk.MessageDialog(
            transient_for=self,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=message
        )
        dialog.run()
        dialog.destroy()

    def on_exit_clicked(self, widget):
        """Manejador para el botón de salida"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=STRINGS[self.current_lang]['dialog']['exit_title']
        )
        dialog.format_secondary_text(STRINGS[self.current_lang]['dialog']['exit_desc'])
        
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            app = self.get_application()
            if app:
                app.quit()
    
    def on_window_destroy(self, window):
        """Manejador para la señal destroy"""
        app = self.get_application()
        if app:
            app.quit()

    def on_chroot_clicked(self, button):
        """Abre la ventana de CHROOT"""
        os.environ['NO_AT_BRIDGE'] = '1'
        os.environ['GTK_MODULES'] = ''
        os.environ['DBUS_SESSION_BUS_ADDRESS'] = ''
        os.environ['XDG_RUNTIME_DIR'] = f"/run/user/{os.getuid()}"
        os.environ['DISPLAY'] = ':0'
        
        from ui.chroot_window import ChRootWindow
        chroot_window = ChRootWindow()
        chroot_window.show_all()

    def on_gparted_clicked(self, button):
        """Ejecuta GParted"""
        os.system('sudo gparted')  # Usar os.system directamente

    def on_install_clicked(self, button):
        """Ejecuta el instalador Calamares"""
        subprocess.Popen(['sudo', 'calamares'])  # Primero ejecutamos calamares
        GLib.timeout_add(1000, lambda: self.destroy())  # Luego destruimos la ventana después de 1 segundo

    def on_autostart_toggled(self, switch, gparam):
        """Maneja el cambio en el switch de autostart"""
        if switch.get_active():
            self.autostart_manager.enable()
        else:
            self.autostart_manager.disable()