import gi
import os
import subprocess
import sys
import shutil  # Agregar importación de shutil
import json
import time

# Añadir el directorio raíz al path de Python
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, GdkPixbuf, Gdk, GLib
from ui.welcome_tab import WelcomeTab
from config.paths import LOGO_PATH, ICON_PATH  # Añadir ICON_PATH a la importación
from config.strings import STRINGS  # Cambiar la importación
from utils.autostart import AutostartManager
from ui.chroot_window import ChRootWindow
from utils.desktop_detector import get_desktop_environment, save_language_preference  # Importar desde el nuevo módulo

# Diccionario de idiomas y sus configuraciones (movido desde welcome_tab.py)
LANGUAGES = {
    'Español': {'locale': 'es_ES.UTF-8', 'layout': 'es'},
    'English': {'locale': 'en_US.UTF-8', 'layout': 'us'},
    'Português': {'locale': 'pt_PT.UTF-8', 'layout': 'pt'},
    'Français': {'locale': 'fr_FR.UTF-8', 'layout': 'fr'},
    'Deutsch': {'locale': 'de_DE.UTF-8', 'layout': 'de'},
    'Italiano': {'locale': 'it_IT.UTF-8', 'layout': 'it'},
    'Română': {'locale': 'ro_RO.UTF-8', 'layout': 'ro'},
    'Русский': {'locale': 'ru_RU.UTF-8', 'layout': 'ru'}
}

class MainWindow(Gtk.ApplicationWindow):  # Cambiar de Gtk.Window a Gtk.ApplicationWindow
    def __init__(self, lang_code=None):
        super().__init__()
        
        # Establecer WM_CLASS para que coincida con el .desktop
        self.set_wmclass("com.soplos.welcomelive", "com.soplos.welcomelive")
        
        # Establecer el icono de la ventana explícitamente
        try:
            icon_theme = Gtk.IconTheme.get_default()
            try:
                icon = icon_theme.load_icon("com.soplos.welcomelive", 128, 0)
                self.set_icon(icon)
            except:
                # Fallback a ruta absoluta si falla la carga por nombre
                if os.path.exists(ICON_PATH):
                    self.set_icon_from_file(ICON_PATH)
        except Exception as e:
            print(f"Error al establecer el icono: {e}")
        
        app = Gtk.Application.get_default()
        Gtk.ApplicationWindow.__init__(self, application=app)
        self.set_title("Soplos Welcome Live")
        
        # Detectar el entorno de escritorio
        self.desktop_env = get_desktop_environment()
        print(f"Entorno de escritorio detectado: {self.desktop_env}")
        
        # Usar el idioma proporcionado o detectarlo si es None
        if lang_code and lang_code in STRINGS:
            self.current_lang = lang_code
        else:
            # Detectar el idioma actual del sistema de manera segura
            current_locale = os.getenv('LANG', 'en_US.UTF-8')
            # Si es C.UTF-8 o similar, usar inglés por defecto
            if current_locale.startswith('C.') or current_locale == 'C':
                self.current_lang = 'en'
            else:
                self.current_lang = current_locale.split('_')[0]
                # Si el idioma no existe en STRINGS, usar inglés
                if self.current_lang not in STRINGS:
                    self.current_lang = 'en'
        
        # Buscar el nombre del idioma en LANGUAGES
        current_language_name = None
        for name, config in LANGUAGES.items():
            if config['locale'].startswith(f"{self.current_lang}_"):
                current_language_name = name
                break
        
        if not current_language_name:
            # Si no se encontró un nombre, usar el primero que coincida con el código
            for name, config in LANGUAGES.items():
                if config['locale'].startswith(self.current_lang):
                    current_language_name = name
                    break
        
        self.set_title(STRINGS[self.current_lang]['welcome'])
        self.set_wmclass('soplos-welcome-live', 'soplos-welcome-live')
        
        self.set_border_width(10)
        
        self.set_default_size(800, 450)  # Aumentada la altura de 400 a 550
        self.set_position(Gtk.WindowPosition.CENTER)
        
        # Contenedor principal horizontal
        main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.add(main_box)
        
        # Sub-contenedor horizontal para logo y contenido
        content_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        main_box.pack_start(content_box, True, True, 0)

        # Panel izquierdo para logo (ahora va en content_box)
        left_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        left_panel.set_size_request(200, -1)
        content_box.pack_start(left_panel, False, False, 5)

        try:
            header_pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                filename=LOGO_PATH,
                width=150,
                height=150,
                preserve_aspect_ratio=True
            )
            logo_image = Gtk.Image.new_from_pixbuf(header_pixbuf)
            left_panel.pack_start(logo_image, False, False, 10)
        except Exception as e:
            print(f"Error al cargar el logo: {e}")
        
        welcome_label = Gtk.Label()
        welcome_label.set_markup(
            f"<span size='large' weight='bold'>{STRINGS[self.current_lang]['welcome']}</span>\n" +
            f"<span size='small'>{STRINGS[self.current_lang]['thanks']}</span>"
        )
        welcome_label.set_justify(Gtk.Justification.CENTER)
        welcome_label.set_line_wrap(True)
        left_panel.pack_start(welcome_label, False, False, 5)
        
        # Añadir espacio flexible que empujará el selector de idioma hacia abajo
        left_panel.pack_start(Gtk.Box(), True, True, 0)
        
        # Selector de idioma y autostart en el panel izquierdo
        controls_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
        left_panel.pack_end(controls_box, False, False, 0)

        # Switch de autostart (eliminado switch de numlockx)
        autostart_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        autostart_label = Gtk.Label(label=STRINGS[self.current_lang]['labels']['show_startup'])
        autostart_box.pack_start(autostart_label, False, False, 0)
        
        self.autostart_switch = Gtk.Switch()
        self.autostart_manager = AutostartManager()
        self.autostart_switch.set_active(self.autostart_manager.is_enabled())
        self.autostart_switch.connect("notify::active", self.on_autostart_toggled)
        autostart_box.pack_end(self.autostart_switch, False, False, 0)
        
        controls_box.pack_start(autostart_box, False, False, 5)
        
        # Selector de idioma en el panel izquierdo, ahora se alineará con el botón de salida
        lang_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=5)
        lang_box.set_margin_bottom(5)  # Margen inferior para alinear con el botón de salida
        controls_box.pack_start(lang_box, False, False, 0)  # Usamos pack_end en lugar de pack_start
        
        lang_label = Gtk.Label(label=STRINGS[self.current_lang]['labels']['language'])
        lang_box.pack_start(lang_label, False, False, 0)
        
        self.lang_combo = Gtk.ComboBoxText()
        # Añadir idiomas y guardar el índice del idioma actual
        current_index = 0
        for i, (lang, config) in enumerate(LANGUAGES.items()):
            self.lang_combo.append_text(lang)
            if current_language_name and lang == current_language_name:
                current_index = i
        
        # Seleccionar el idioma actual por índice
        self.lang_combo.set_active(current_index)
        self.lang_combo.connect("changed", self.on_language_changed)
        lang_box.pack_start(self.lang_combo, True, True, 5)
        
        # Panel derecho (ahora va en content_box)
        right_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        content_box.pack_start(right_panel, True, True, 0)
        
        welcome_tab = WelcomeTab(self)
        right_panel.pack_start(welcome_tab, True, True, 0)
        
        # Panel inferior con botones
        button_panel = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        right_panel.pack_end(button_panel, False, False, 5)

        # Botones (mantener el orden existente)
        exit_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['exit'])
        exit_button.set_use_underline(True)
        exit_button.connect("clicked", self.on_exit_clicked)
        button_panel.pack_end(exit_button, False, False, 0)

        chroot_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['chroot'])
        chroot_button.set_use_underline(True)
        chroot_button.connect("clicked", self.on_chroot_clicked)
        button_panel.pack_end(chroot_button, False, False, 5)

        install_button = Gtk.Button(label=STRINGS[self.current_lang]['buttons']['install'])
        install_button.set_use_underline(True)
        install_button.connect("clicked", self.on_install_clicked)
        install_button.get_style_context().add_class("install-button")
        button_panel.pack_end(install_button, False, False, 5)

        # Barra de progreso al final del main_box
        self.progress_bar = Gtk.ProgressBar()
        self.progress_bar.set_show_text(False)  # Inicialmente sin texto
        self.progress_bar.set_visible(False)
        main_box.pack_end(self.progress_bar, False, True, 0)

        # Añadir CSS para el botón de instalación
        css_provider = Gtk.CssProvider()
        css = b"""
            .install-button {
                background: #e95420;
                color: white;
                padding: 5px 10px;
                font-weight: bold;
            }
            .install-button:hover {
                background: #e9662b;
            }
        """
        css_provider.load_from_data(css)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(),
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
    
    def on_language_changed(self, combo):
        lang_name = combo.get_active_text()
        lang_config = LANGUAGES[lang_name]
        
        # Obtener el código de idioma de la configuración (ej. 'es' de 'es_ES.UTF-8')
        lang_code = lang_config['locale'].split('_')[0]
        
        # Guardar la preferencia de idioma
        save_language_preference(lang_code)
        
        # Mostrar barra de progreso con texto
        self.progress_bar.set_visible(True)
        self.progress_bar.set_show_text(True)  # Ahora mostramos el texto
        self.progress_bar.set_fraction(0.0)
        self.progress_bar.set_text(STRINGS[self.current_lang]['progress']['configuring'])
        
        try:
            # Actualizar la barra de progreso mientras se realizan las tareas
            self.progress_bar.set_fraction(0.2)
            while Gtk.events_pending():
                Gtk.main_iteration()

            # Usar las rutas correctas de Debian
            locale_gen = '/etc/locale.gen'
            locale_gen_cmd = '/usr/sbin/locale-gen'
            update_locale = '/usr/sbin/update-locale'
            
            if not os.path.exists(locale_gen_cmd):
                self.show_error_dialog(STRINGS[self.current_lang]['locale']['not_found_locale_gen'])
                return

            if not os.path.exists(update_locale):
                self.show_error_dialog(STRINGS[self.current_lang]['locale']['not_found_update_locale'])
                return

            # 1. Verificar si el locale ya está en locale.gen para evitar duplicados
            locale_line = f"{lang_config['locale']} UTF-8"
            locale_exists = False
            
            if os.path.exists(locale_gen):
                with open(locale_gen, 'r') as f:
                    locale_exists = any(line.strip() == locale_line or 
                                      line.strip() == f"# {locale_line}" for line in f)

            if not locale_exists:
                # Modificar el archivo locale.gen y regenerar locales
                subprocess.run(['pkexec', 'bash', '-c', f'echo "{locale_line}" >> {locale_gen}'], 
                             check=True, capture_output=True)

            self.progress_bar.set_fraction(0.4)
            while Gtk.events_pending():
                Gtk.main_iteration()

            subprocess.run(['pkexec', locale_gen_cmd], 
                         check=True, capture_output=True)

            self.progress_bar.set_fraction(0.6)
            while Gtk.events_pending():
                Gtk.main_iteration()

            # 2. Establecer TODAS las variables de entorno del locale
            locale_vars = [
                f"LANG={lang_config['locale']}",
                f"LC_ADDRESS={lang_config['locale']}",
                f"LC_IDENTIFICATION={lang_config['locale']}",
                f"LC_MEASUREMENT={lang_config['locale']}",
                f"LC_MONETARY={lang_config['locale']}",
                f"LC_NAME={lang_config['locale']}",
                f"LC_NUMERIC={lang_config['locale']}",
                f"LC_PAPER={lang_config['locale']}",
                f"LC_TELEPHONE={lang_config['locale']}",
                f"LC_TIME={lang_config['locale']}"
            ]
            
            # Actualizar las variables del sistema
            update_cmd = ['pkexec', update_locale] + locale_vars
            subprocess.run(update_cmd, check=True, capture_output=True)
            
            # 3. Configurar layout de teclado dependiendo del entorno de escritorio
            if self.desktop_env == 'kde':
                self._configure_kde_keyboard(lang_config['layout'])
            else:
                # Método estándar para otros entornos
                subprocess.run(['setxkbmap', lang_config['layout']], check=True)
                
                # Hacer el cambio permanente en X11
                xorg_conf = f"""Section "InputClass"
        Identifier "system-keyboard"
        MatchIsKeyboard "on"
        Option "XkbLayout" "{lang_config['layout']}"
EndSection"""
                
                # Crear directorio si no existe
                os.makedirs("/etc/X11/xorg.conf.d", exist_ok=True)
                
                # Escribir configuración
                subprocess.run(['pkexec', 'bash', '-c', 
                              f'echo \'{xorg_conf}\' > /etc/X11/xorg.conf.d/00-keyboard.conf'],
                             check=True, capture_output=True)

            self.progress_bar.set_fraction(0.75)
            while Gtk.events_pending():
                Gtk.main_iteration()

            # 4. Manejar directorios XDG de manera segura
            self._migrate_xdg_dirs_safely(lang_config['locale'])

            self.progress_bar.set_fraction(0.9)
            while Gtk.events_pending():
                Gtk.main_iteration()

            # 5. Mostrar un diálogo de información pidiendo reiniciar la sesión
            # para que todos los cambios surtan efecto completamente
            dialog = Gtk.MessageDialog(
                transient_for=self,
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.OK,
                text=STRINGS[self.current_lang]['locale']['restart_session_title']
                    if 'restart_session_title' in STRINGS[self.current_lang].get('locale', {})
                    else "Cambios aplicados"
            )
            dialog.format_secondary_text(
                STRINGS[self.current_lang]['locale']['restart_session_desc']
                if 'restart_session_desc' in STRINGS[self.current_lang].get('locale', {})
                else "Para que todos los cambios tengan efecto, se recomienda reiniciar la sesión"
            )
            dialog.run()
            dialog.destroy()

            # Finalmente mostramos que el proceso ha terminado
            self.progress_bar.set_fraction(1.0)
            while Gtk.events_pending():
                Gtk.main_iteration()

            # Ocultar la barra de progreso después de un tiempo
            GLib.timeout_add(2000, self._hide_progress_bar)

        except subprocess.CalledProcessError as e:
            self.progress_bar.set_visible(False)
            error_msg = e.stderr.decode() if e.stderr else str(e)
            self.show_error_dialog(f"{STRINGS[self.current_lang]['locale']['error_generating']}\n{error_msg}")
    
    def _configure_kde_keyboard(self, layout):
        """Configura el teclado específicamente para KDE"""
        try:
            # 1. Configurar el layout usando setxkbmap para la sesión actual
            subprocess.run(['setxkbmap', layout], check=True)
            
            # 2. Actualizar la configuración de KDE mediante kwriteconfig5
            subprocess.run([
                'kwriteconfig5', '--file', 'kxkbrc',
                '--group', 'Layout',
                '--key', 'LayoutList', layout
            ], check=True)
            
            subprocess.run([
                'kwriteconfig5', '--file', 'kxkbrc',
                '--group', 'Layout',
                '--key', 'Use', 'true'
            ], check=True)
            
            # 3. Reiniciar el servicio de teclado de KDE
            subprocess.run([
                'qdbus', 'org.kde.keyboard', '/Layouts', 'reset'
            ], check=False)  # No hacer check=True ya que puede fallar sin ser crítico
            
        except Exception as e:
            print(f"Error configurando teclado KDE: {e}")
            # Si falla, intentar con el método estándar
            subprocess.run(['setxkbmap', layout], check=True)
    
    def _migrate_xdg_dirs_safely(self, locale):
        """Migra las carpetas XDG de manera segura al cambiar el idioma"""
        try:
            # Directorio home del usuario
            home_dir = os.path.expanduser('~')
            user_dirs_file = os.path.join(home_dir, '.config/user-dirs.dirs')
            
            # Si no existe el archivo, no podemos hacer nada
            if not os.path.exists(user_dirs_file):
                return
            
            # 1. Hacer backup del archivo original de user-dirs
            backup_file = f"{user_dirs_file}.backup"
            shutil.copy2(user_dirs_file, backup_file)
            
            # 2. Leer las carpetas actuales
            old_dirs = {}
            with open(user_dirs_file, 'r') as f:
                for line in f:
                    if line.startswith('XDG_'):
                        parts = line.strip().split('=')
                        if len(parts) >= 2:
                            key = parts[0]
                            # Extraer el valor entre comillas y reemplazar $HOME/
                            value = parts[1].strip()
                            if value.startswith('"') and value.endswith('"'):
                                value = value[1:-1]
                            value = value.replace('$HOME/', '')
                            old_dirs[key] = value
            
            # Guardamos la ubicación actual para luego verificar
            print(f"Directorios actuales: {json.dumps(old_dirs, indent=2)}")
            
            # 3. Generar un script temporal que simule un entorno con el nuevo locale
            script_content = f'''#!/bin/bash
export LANG="{locale}"
export LC_ALL="{locale}"
xdg-user-dirs-update --force
'''
            script_path = '/tmp/update_xdg_dirs.sh'
            with open(script_path, 'w') as f:
                f.write(script_content)
            os.chmod(script_path, 0o755)
            
            # 4. Ejecutar el script y esperar a que termine
            subprocess.run([script_path], check=True)
            
            # 5. Leer las nuevas carpetas
            new_dirs = {}
            with open(user_dirs_file, 'r') as f:
                for line in f:
                    if line.startswith('XDG_'):
                        parts = line.strip().split('=')
                        if len(parts) >= 2:
                            key = parts[0]
                            value = parts[1].strip()
                            if value.startswith('"') and value.endswith('"'):
                                value = value[1:-1]
                            value = value.replace('$HOME/', '')
                            new_dirs[key] = value
            
            print(f"Nuevos directorios: {json.dumps(new_dirs, indent=2)}")
            
            # 6. Verificar si realmente hubo cambios
            changes_needed = False
            for key in set(old_dirs.keys()) & set(new_dirs.keys()):
                if old_dirs[key] != new_dirs[key]:
                    changes_needed = True
                    break
            
            if not changes_needed:
                print("No se detectaron cambios en las carpetas XDG")
                return
            
            # 7. Migrar los archivos de manera segura si hay cambios
            for key in old_dirs:
                if key not in new_dirs:
                    continue
                    
                old_path = os.path.join(home_dir, old_dirs[key])
                new_path = os.path.join(home_dir, new_dirs[key])
                
                # Verificamos si las carpetas son distintas
                if old_path != new_path:
                    print(f"Migrando {key}: {old_path} -> {new_path}")
                    
                    # Si la carpeta vieja existe
                    if os.path.exists(old_path) and os.path.isdir(old_path):
                        # Si la carpeta nueva no existe, simplemente la renombramos
                        if not os.path.exists(new_path):
                            try:
                                os.makedirs(os.path.dirname(new_path), exist_ok=True)
                                os.rename(old_path, new_path)
                                print(f"  Renombrado exitoso: {old_path} -> {new_path}")
                            except OSError as e:
                                print(f"  Error al renombrar: {e}")
                        else:
                            # Si la carpeta nueva ya existe, movemos el contenido
                            try:
                                for item in os.listdir(old_path):
                                    old_item_path = os.path.join(old_path, item)
                                    new_item_path = os.path.join(new_path, item)
                                    
                                    # Si el elemento destino ya existe, añadir un sufijo
                                    if os.path.exists(new_item_path):
                                        base, ext = os.path.splitext(item)
                                        new_item_path = os.path.join(new_path, f"{base}_old{ext}")
                                        
                                    # Mover el elemento
                                    if os.path.isdir(old_item_path):
                                        shutil.move(old_item_path, new_item_path)
                                    else:
                                        shutil.copy2(old_item_path, new_item_path)
                                        os.remove(old_item_path)
                                    
                                    print(f"  Movido: {old_item_path} -> {new_item_path}")
                                
                                # Intentar eliminar el directorio antiguo si está vacío
                                if not os.listdir(old_path):
                                    os.rmdir(old_path)
                                    print(f"  Eliminado directorio vacío: {old_path}")
                            except (OSError, shutil.Error) as e:
                                print(f"  Error al mover contenido: {e}")
            
            # 8. Ejecutar xdg-user-dirs-update para actualizar la configuración
            subprocess.run(['xdg-user-dirs-update'], check=True)
            
            # 9. Restaurar la configuración del escritorio según el entorno
            if self.desktop_env == 'kde':
                self._restore_kde_desktop_config()
            elif self.desktop_env == 'xfce':
                self._restore_xfce_desktop_config()
            
        except Exception as e:
            print(f"Error durante la migración de carpetas XDG: {e}")
            # Restaurar el backup si algo salió mal
            if os.path.exists(backup_file):
                shutil.copy2(backup_file, user_dirs_file)
    
    def _restore_kde_desktop_config(self):
        """Restaura la configuración de escritorio específica de KDE"""
        try:
            # Configurar iconos del escritorio en KDE
            subprocess.run([
                'kwriteconfig5', '--file', 'plasma-org.kde.plasma.desktop-appletsrc',
                '--group', 'Containments',
                '--key', 'showDesktopIcons', 'true'
            ], check=False)
            
            # Recargar la configuración
            subprocess.run([
                'qdbus', 'org.kde.plasmashell', '/PlasmaShell', 
                'org.kde.PlasmaShell.evaluateScript', 
                'refreshPlasmoid("org.kde.desktopcontainment")'
            ], check=False)
            
        except Exception as e:
            print(f"Error restaurando configuración de KDE: {e}")
    
    def _restore_xfce_desktop_config(self):
        """Restaura la configuración de escritorio específica de XFCE"""
        try:
            # Activar los iconos del escritorio
            subprocess.run([
                'xfconf-query',
                '--channel', 'xfce4-desktop',
                '--property', '/desktop-icons/style',
                '--set', '2'  # Mostrar iconos
            ], check=False)
            
            # Configurar qué iconos mostrar
            subprocess.run([
                'xfconf-query',
                '--channel', 'xfce4-desktop',
                '--property', '/desktop-icons/file-icons/show-filesystem',
                '--set', 'false'
            ], check=False)
            subprocess.run([
                'xfconf-query',
                '--channel', 'xfce4-desktop',
                '--property', '/desktop-icons/file-icons/show-home',
                '--set', 'true'  # Mostrar carpeta personal
            ], check=False)
            subprocess.run([
                'xfconf-query',
                '--channel', 'xfce4-desktop',
                '--property', '/desktop-icons/file-icons/show-trash',
                '--set', 'true'  # Mostrar papelera
            ], check=False)
            subprocess.run([
                'xfconf-query',
                '--channel', 'xfce4-desktop',
                '--property', '/desktop-icons/file-icons/show-removable',
                '--set', 'false'
            ], check=False)
            
        except Exception as e:
            print(f"Error restaurando configuración de XFCE: {e}")
    
    def _hide_progress_bar(self):
        """Oculta la barra de progreso"""
        self.progress_bar.set_visible(False)
        return False  # para que GLib.timeout_add no la llame de nuevo
    
    def show_error_dialog(self, message):
        dialog = Gtk.MessageDialog(
            transient_for=self,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.OK,
            text=message
        )
        dialog.run()
        dialog.destroy()

    def on_exit_clicked(self, widget):
        """Manejador para el botón de salida"""
        dialog = Gtk.MessageDialog(
            transient_for=self,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=STRINGS[self.current_lang]['dialog']['exit_title']
        )
        dialog.format_secondary_text(STRINGS[self.current_lang]['dialog']['exit_desc'])
        
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            app = self.get_application()
            if app:
                app.quit()
    
    def on_window_destroy(self, window):
        """Manejador para la señal destroy"""
        app = self.get_application()
        if app:
            app.quit()

    def on_chroot_clicked(self, button):
        """Abre la ventana de CHROOT"""
        os.environ['NO_AT_BRIDGE'] = '1'
        os.environ['GTK_MODULES'] = ''
        os.environ['DBUS_SESSION_BUS_ADDRESS'] = ''
        os.environ['XDG_RUNTIME_DIR'] = f"/run/user/{os.getuid()}"
        os.environ['DISPLAY'] = ':0'
        
        from ui.chroot_window import ChRootWindow
        chroot_window = ChRootWindow()
        chroot_window.show_all()

    def on_gparted_clicked(self, button):
        """Ejecuta GParted"""
        os.system('sudo gparted')  # Usar os.system directamente

    def on_install_clicked(self, button):
        """Ejecuta el instalador Calamares"""
        subprocess.Popen(['sudo', 'calamares'])  # Primero ejecutamos calamares
        GLib.timeout_add(1000, lambda: self.destroy())  # Luego destruimos la ventana después de 1 segundo

    def on_autostart_toggled(self, switch, gparam):
        """Maneja el cambio en el switch de autostart"""
        if switch.get_active():
            self.autostart_manager.enable()
        else:
            self.autostart_manager.disable()