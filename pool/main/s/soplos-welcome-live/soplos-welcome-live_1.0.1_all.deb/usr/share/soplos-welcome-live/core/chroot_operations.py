import subprocess
import os
import json
import shutil
import logging
from config.strings import STRINGS

class SystemOperations:
    def __init__(self):
        # Cambiar de /mnt/soplos_rescue a simplemente /mnt/chroot
        self.mount_point = "/mnt/chroot"
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        # Obtener idioma del sistema
        current_locale = os.getenv('LANG', 'en_US.UTF-8')
        self.current_lang = current_locale.split('_')[0]

    def format_size(self, size):
        """Convierte tamaños en bytes a formato legible"""
        try:
            size = int(size)
            for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
                if size < 1024.0:
                    return f"{size:.1f} {unit}"
                size /= 1024.0
            return f"{size:.1f} TB"
        except:
            return "Desconocido"

    def get_disks(self):
        try:
            cmd = "lsblk -lnp -o NAME,SIZE,MODEL -d -I 8,259"
            output = subprocess.check_output(cmd.split()).decode()
            disks = []
            for line in output.splitlines():
                if line.strip():
                    parts = line.split()
                    device = parts[0]
                    size = parts[1]
                    model = ' '.join(parts[2:]) if len(parts) > 2 else STRINGS[self.current_lang]['labels']['device']
                    disks.append((device, size, model))
            return disks
        except Exception as e:
            self.logger.error(STRINGS[self.current_lang]['messages']['error_loading_disks'])
            return []

    def get_disk_partitions(self, disk_name):
        """Obtiene las particiones de un disco específico"""
        try:
            # Usar un comando más simple y directo
            cmd = ['lsblk', '-lnp', '-o', 'NAME,SIZE,FSTYPE,MOUNTPOINT', disk_name]
            result = subprocess.run(cmd, capture_output=True, text=True)
            
            if result.returncode != 0:
                raise Exception(f"Error ejecutando lsblk: {result.stderr}")
            
            partitions = []
                
            for line in result.stdout.strip().split('\n'):
                parts = line.split()
                # Saltar líneas vacías o el disco principal
                if not parts or parts[0] == disk_name:
                    continue
                
                device = parts[0]
                size = parts[1]
                fstype = parts[2] if len(parts) > 2 else ''
                mount = parts[3] if len(parts) > 3 else ''
                
                # Sugerir punto de montaje
                suggested = None
                if fstype == 'vfat' or fstype == 'fat32':
                    suggested = '/boot/efi'
                elif fstype == 'ext4':
                    if mount == '/':
                        suggested = '/'
                    elif mount == '/boot':
                        suggested = '/boot'
                    elif mount == '/home':
                        suggested = '/home'
                    elif not any(p.get('suggested_mount') == '/' for p in partitions):
                        suggested = '/'
                    elif not any(p.get('suggested_mount') == '/boot' for p in partitions):
                        suggested = '/boot'
                    else:
                        suggested = '/home'
                
                partitions.append({
                    'device': device,
                    'size': size,
                    'fstype': fstype,
                    'mountpoint': mount,
                    'suggested_mount': suggested
                })
            
            return partitions
            
        except Exception as e:
            self.logger.error(f"Error obteniendo particiones: {str(e)}")
            raise

    def _suggest_mount_point(self, fs_type, label, current_mount):
        """Sugiere un punto de montaje basado en el sistema de archivos y etiqueta"""
        # Ignorar current_mount si contiene nuestro mount_point
        if current_mount and self.mount_point in current_mount:
            current_mount = None

        fs_type = (fs_type or '').lower()
        label = (label or '').lower()

        # Primero verificar por sistema de archivos y etiquetas
        if fs_type == 'swap':
            return None
        elif fs_type in ['vfat', 'fat32'] and ('efi' in label or 'esp' in label):
            return '/boot/efi'
        elif fs_type in ['ext4', 'btrfs', 'xfs']:
            if 'home' in label:
                return '/home'
            elif 'boot' in label:
                if 'efi' in label:
                    return '/boot/efi'
                return '/boot'
            elif 'root' in label:
                return '/'
            # Si no hay etiqueta pero es el único ext4, probablemente sea root
            return '/'

        return None

    def execute_chroot(self):
        """Ejecuta el chroot"""
        subprocess.run(['chroot', self.mount_point], check=True)

    def execute_gparted(self):
        """Ejecuta GParted usando la ruta absoluta"""
        try:
            subprocess.Popen(['pkexec', '/usr/sbin/gparted'])
        except Exception as e:
            print(f"Error ejecutando GParted: {e}")

    def _validate_mounted_system(self):
        """Verifica si el sistema montado es un Linux válido
        
        Retorna:
            bool: True si el sistema parece un Linux válido, False en caso contrario
        """
        # Verificar directorios y archivos esenciales que deberían existir en un sistema Linux
        essential_paths = [
            '/bin', '/usr/bin', '/lib', '/usr/lib', 
            '/etc/fstab', '/etc/passwd', '/etc/shadow'
        ]
        
        # Al menos un shell debe existir
        shell_paths = ['/bin/bash', '/bin/sh', '/usr/bin/bash', '/usr/bin/sh']
        
        # Verificar directorios esenciales
        essential_found = 0
        for path in essential_paths:
            full_path = os.path.join(self.mount_point, path.lstrip('/'))
            if os.path.exists(full_path):
                essential_found += 1
        
        # Verificar si hay al menos un shell 
        shell_found = False
        for shell in shell_paths:
            full_path = os.path.join(self.mount_point, shell.lstrip('/'))
            if os.path.exists(full_path):
                shell_found = True
                break
        
        # Consideramos válido si hay al menos 3 directorios/archivos esenciales y un shell
        return essential_found >= 3 and shell_found

    def unmount_all(self):
        """Desmonta todas las particiones y sistemas de archivos virtuales"""
        try:
            # Crear un script para desmontar todo de manera segura
            unmount_script = f"""#!/bin/bash
# Función para desmontar un punto de montaje de manera segura
safe_umount() {{
    local mount_point="$1"
    if mount | grep -q " on $mount_point "; then
        echo "Desmontando $mount_point..."
        umount -l "$mount_point" || umount -f "$mount_point" || true
    fi
}}

# Desmontar sistemas de archivos virtuales en orden inverso
safe_umount {self.mount_point}/dev/pts
safe_umount {self.mount_point}/dev
safe_umount {self.mount_point}/proc
safe_umount {self.mount_point}/sys
safe_umount {self.mount_point}/boot/efi
safe_umount {self.mount_point}/boot
safe_umount {self.mount_point}

echo "Desmontaje completado"
"""
            # Ejecutar el script de desmontaje
            with open('/tmp/unmount.sh', 'w') as f:
                f.write(unmount_script)
            os.chmod('/tmp/unmount.sh', 0o755)
            
            subprocess.run(['sudo', '/tmp/unmount.sh'], check=False)
            return True
        except Exception as e:
            self.logger.error(f"Error desmontando el sistema: {e}")
            return False

    def mount_and_chroot(self, root_part, boot_part=None, efi_part=None):
        """Monta las particiones y ejecuta chroot"""
        try:
            # Primero desmontar cualquier montaje anterior para evitar conflictos
            self.unmount_all()
            
            # Script para montar todo
            mount_script = f"""#!/bin/bash
# Crear punto de montaje con permisos adecuados
sudo rm -rf {self.mount_point} 2>/dev/null || true
sudo mkdir -p {self.mount_point}
sudo chmod 755 {self.mount_point}

# Verificar que el punto de montaje existe
if [ ! -d "{self.mount_point}" ]; then
    echo "ERROR: No se pudo crear el punto de montaje {self.mount_point}"
    exit 1
fi

# Limpiar cualquier montaje anterior
sudo umount -l {self.mount_point}/dev/pts 2>/dev/null || true
sudo umount -l {self.mount_point}/dev 2>/dev/null || true
sudo umount -l {self.mount_point}/proc 2>/dev/null || true
sudo umount -l {self.mount_point}/sys 2>/dev/null || true
sudo umount -l {self.mount_point}/boot/efi 2>/dev/null || true
sudo umount -l {self.mount_point}/boot 2>/dev/null || true
sudo umount -l {self.mount_point} 2>/dev/null || true

echo "Punto de montaje: {self.mount_point}"
echo "Partición raíz: {root_part}"

# Montar partición raíz
echo "Montando partición raíz {root_part}..."
sudo mount {root_part} {self.mount_point}
if [ $? -ne 0 ]; then
    echo "ERROR: No se pudo montar {root_part} en {self.mount_point}"
    exit 1
fi

echo "Partición raíz montada correctamente"
"""
            if boot_part:
                mount_script += f"""
# Crear directorio /boot
echo "Creando directorio {self.mount_point}/boot..."
sudo mkdir -p {self.mount_point}/boot

echo "Montando partición /boot {boot_part}..."
sudo mount {boot_part} {self.mount_point}/boot
if [ $? -ne 0 ]; then
    echo "ERROR: No se pudo montar {boot_part} en {self.mount_point}/boot"
    exit 1
fi
"""
            if efi_part:
                mount_script += f"""
# Crear directorio /boot/efi
echo "Creando directorio {self.mount_point}/boot/efi..."
sudo mkdir -p {self.mount_point}/boot/efi

echo "Montando partición EFI {efi_part}..."
sudo mount {efi_part} {self.mount_point}/boot/efi
if [ $? -ne 0 ]; then
    echo "ERROR: No se pudo montar {efi_part} en {self.mount_point}/boot/efi"
    exit 1
fi
"""
            
            mount_script += f"""
# Crear directorios para bind mounts
echo "Creando directorios para bind mounts..."
sudo mkdir -p {self.mount_point}/dev
sudo mkdir -p {self.mount_point}/proc
sudo mkdir -p {self.mount_point}/sys
sudo mkdir -p {self.mount_point}/dev/pts

# Montar sistemas de archivos virtuales
echo "Montando sistemas de archivos virtuales..."
sudo mount --bind /dev {self.mount_point}/dev
if [ $? -ne 0 ]; then
    echo "ERROR: No se pudo montar /dev en {self.mount_point}/dev"
    exit 1
fi

sudo mount --bind /proc {self.mount_point}/proc
if [ $? -ne 0 ]; then
    echo "ERROR: No se pudo montar /proc en {self.mount_point}/proc"
    exit 1
fi

sudo mount --bind /sys {self.mount_point}/sys
if [ $? -ne 0 ]; then
    echo "ERROR: No se pudo montar /sys en {self.mount_point}/sys"
    exit 1
fi

sudo mount --bind /dev/pts {self.mount_point}/dev/pts
if [ $? -ne 0 ]; then
    echo "ERROR: No se pudo montar /dev/pts en {self.mount_point}/dev/pts"
    exit 1
fi

# Copiar resolv.conf para tener resolución DNS
sudo mkdir -p {self.mount_point}/etc
sudo cp /etc/resolv.conf {self.mount_point}/etc/resolv.conf 2>/dev/null || echo "No se pudo copiar resolv.conf"

# Verificar si es un sistema Linux válido
if [ ! -e "{self.mount_point}/bin/bash" ] && [ ! -e "{self.mount_point}/usr/bin/bash" ]; then
    echo "ERROR: No se encontró un shell válido en el sistema montado"
    if [ -d "{self.mount_point}/bin" ]; then
        echo "Contenido de /bin:"
        ls -la {self.mount_point}/bin/
    fi
    if [ -d "{self.mount_point}/usr/bin" ]; then
        echo "Contenido de /usr/bin:"
        ls -la {self.mount_point}/usr/bin/ | grep -E "bash|sh"
    fi
    exit 1
fi

# Listar contenido montado para verificar
echo "VERIFICACIÓN DE MONTAJE:"
ls -la {self.mount_point}
"""
            
            # Ejecutar script de montaje
            with open('/tmp/mount.sh', 'w') as f:
                f.write(mount_script)
            os.chmod('/tmp/mount.sh', 0o755)
            mount_result = subprocess.run(['bash', '/tmp/mount.sh'], capture_output=True, text=True)
            
            if mount_result.returncode != 0:
                raise Exception(f"Error al montar particiones: {mount_result.stderr or mount_result.stdout}")
            
            print("Resultado del montaje:")
            print(mount_result.stdout)
            
            # Verificar si es un sistema Linux válido antes de continuar
            is_valid_system = self._validate_mounted_system()
            if not is_valid_system:
                self.unmount_all()
                raise Exception("La partición seleccionada no contiene un sistema Linux válido o está dañada")
            
            # Script para chroot con detección de shell
            chroot_script = f"""#!/bin/bash
# Verificar que el punto de montaje existe
if [ ! -d "{self.mount_point}" ]; then
    echo "ERROR: El punto de montaje {self.mount_point} no existe"
    exit 1
fi

# Listar contenido para verificar
echo "Contenido del punto de montaje:"
ls -la {self.mount_point}

# Detectar el shell disponible
if [ -e "{self.mount_point}/bin/bash" ]; then
    SHELL_PATH="/bin/bash"
elif [ -e "{self.mount_point}/usr/bin/bash" ]; then
    SHELL_PATH="/usr/bin/bash"
elif [ -e "{self.mount_point}/bin/sh" ]; then
    SHELL_PATH="/bin/sh"
elif [ -e "{self.mount_point}/usr/bin/sh" ]; then
    SHELL_PATH="/usr/bin/sh"
else
    echo "ERROR: No se encontró un shell válido en el sistema montado"
    exit 1
fi

echo "Usando shell: $SHELL_PATH"
echo "Iniciando entorno chroot..."

# Configurar la terminal para un mejor aspecto en el chroot
export TERM=xterm-256color
export PS1="\\[\\e[1;31m\\](chroot) \\[\\e[1;34m\\]\\w \\[\\e[0m\\]\\$ "

echo "===================================================="
echo "  ENTORNO CHROOT DE RECUPERACIÓN DE SOPLOS LINUX"
echo "===================================================="
echo "Has ingresado en un entorno chroot para recuperar tu sistema."
echo "Puedes ejecutar comandos como actualizaciones, reinstalar"
echo "el gestor de arranque o cualquier otra reparación."
echo ""
echo "Para salir del entorno chroot, escribe 'exit' o presiona Ctrl+D."
echo "===================================================="

# Entrar al chroot con el shell detectado
sudo chroot {self.mount_point} $SHELL_PATH

# Al salir del chroot
echo "===================================================="
echo "Has salido del entorno chroot."
echo "Se procederá a desmontar todas las particiones..."
echo "===================================================="

# Desmontar todo al salir
sudo umount -l {self.mount_point}/dev/pts 2>/dev/null || true
sudo umount -l {self.mount_point}/dev 2>/dev/null || true
sudo umount -l {self.mount_point}/proc 2>/dev/null || true
sudo umount -l {self.mount_point}/sys 2>/dev/null || true

if [ -d "{self.mount_point}/boot/efi" ] && mountpoint -q {self.mount_point}/boot/efi 2>/dev/null; then
    sudo umount {self.mount_point}/boot/efi 2>/dev/null || sudo umount -l {self.mount_point}/boot/efi 2>/dev/null || true
fi

if [ -d "{self.mount_point}/boot" ] && mountpoint -q {self.mount_point}/boot 2>/dev/null; then
    sudo umount {self.mount_point}/boot 2>/dev/null || sudo umount -l {self.mount_point}/boot 2>/dev/null || true
fi

sudo umount {self.mount_point} 2>/dev/null || sudo umount -l {self.mount_point} 2>/dev/null || true

# Verificar si todos los sistemas de archivos fueron desmontados
if mount | grep -q "{self.mount_point}"; then
    echo "ADVERTENCIA: Algunos puntos de montaje no pudieron ser desmontados."
    echo "Sistemas de archivos aún montados:"
    mount | grep "{self.mount_point}"
    echo "Puede ser necesario reiniciar el sistema para liberar estos recursos."
else
    echo "Todas las particiones fueron desmontadas correctamente."
fi

# Preguntar si se desea eliminar el directorio de montaje
read -p "¿Desea eliminar el directorio de montaje {self.mount_point}? [s/N]: " response
if [[ "$response" =~ ^([sS][iI]|[sS])$ ]]; then
    sudo rm -rf {self.mount_point} && echo "Directorio {self.mount_point} eliminado." || echo "No se pudo eliminar {self.mount_point}"
fi

echo "Proceso de chroot finalizado."
exit 0
"""
            
            with open('/tmp/chroot.sh', 'w') as f:
                f.write(chroot_script)
            os.chmod('/tmp/chroot.sh', 0o755)
            
            # Usar directamente konsole, ya que estamos en KDE Plasma
            terminal_cmd = ['konsole', '--hide-menubar', '--hide-tabbar', '--title', 'Soplos ChRoot Recovery', 
                           '--noclose', '-e', 'sudo', 'bash', '/tmp/chroot.sh']
            
            # Ejecutar chroot en konsole
            try:
                subprocess.Popen(terminal_cmd, start_new_session=True)
            except Exception as e:
                self.logger.error(f"Error al iniciar konsole: {e}")
                # Si falla, intentar con el único fallback que es xterm
                try:
                    subprocess.Popen(['xterm', '-title', 'Soplos ChRoot Recovery', '-e', 'sudo bash /tmp/chroot.sh'])
                except Exception as e:
                    self.logger.error(f"Error al iniciar xterm: {e}")
                    # Último recurso: terminal genérica
                    subprocess.Popen(['x-terminal-emulator', '-e', 'sudo bash /tmp/chroot.sh'])
        
        except Exception as e:
            # Asegurar limpieza si algo sale mal
            self.unmount_all()
            raise e
