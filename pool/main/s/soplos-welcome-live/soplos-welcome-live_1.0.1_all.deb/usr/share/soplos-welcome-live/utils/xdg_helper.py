#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import subprocess
import shutil
from utils.desktop_detector import get_session_type

class XDGDirectoriesManager:
    """Gestiona los directorios XDG de manera simple"""
    
    def __init__(self):
        self.home_dir = os.path.expanduser('~')
        self.config_dir = os.path.join(self.home_dir, '.config')
        self.user_dirs_path = os.path.join(self.config_dir, 'user-dirs.dirs')
        self.session_type = get_session_type()
    
    def update_directories(self, locale):
        """Renombra los directorios XDG según el locale proporcionado de forma más robusta"""
        try:
            # 1. Aplicar variables de entorno
            env = os.environ.copy()
            env['LANG'] = locale
            env['LC_ALL'] = locale
            env['LANGUAGE'] = locale.split('_')[0]
            
            # 2. Generar configuración de directorios para el nuevo locale
            xdg_config_content = self._generate_xdg_config(locale)
            if xdg_config_content:
                with open(self.user_dirs_path, 'w') as f:
                    f.write(xdg_config_content)
            
            # 3. Forzar regeneración de user-dirs.dirs con el nuevo locale
            subprocess.run(['xdg-user-dirs-update', '--force'], 
                          env=env, check=True)
            
            # 4. Actualizar también la configuración de GTK si existe
            if shutil.which('xdg-user-dirs-gtk-update'):
                subprocess.run(['xdg-user-dirs-gtk-update', '--force'], 
                              env=env, check=True)
            
            # 5. Renombrar físicamente los directorios si es necesario
            self._rename_physical_directories(locale)
            
            # 6. Actualizar entorno de escritorio
            self._update_desktop_environment()
            
            return True
        except Exception as e:
            print(f"Error actualizando directorios XDG: {e}")
            return False
    
    def _generate_xdg_config(self, locale):
        """Genera configuración de directorios XDG según el locale"""
        lang_code = locale.split('_')[0]
        
        # Mapeo de directorios según idioma
        dir_names = {
            'es': {
                'DESKTOP': 'Escritorio',
                'DOWNLOAD': 'Descargas',
                'DOCUMENTS': 'Documentos',
                'MUSIC': 'Música',
                'PICTURES': 'Imágenes',
                'VIDEOS': 'Vídeos',
                'PUBLICSHARE': 'Público',
                'TEMPLATES': 'Plantillas'
            },
            'en': {
                'DESKTOP': 'Desktop',
                'DOWNLOAD': 'Downloads',
                'DOCUMENTS': 'Documents',
                'MUSIC': 'Music',
                'PICTURES': 'Pictures',
                'VIDEOS': 'Videos',
                'PUBLICSHARE': 'Public',
                'TEMPLATES': 'Templates'
            },
            'fr': {
                'DESKTOP': 'Bureau',
                'DOWNLOAD': 'Téléchargements',
                'DOCUMENTS': 'Documents',
                'MUSIC': 'Musique',
                'PICTURES': 'Images',
                'VIDEOS': 'Vidéos',
                'PUBLICSHARE': 'Public',
                'TEMPLATES': 'Modèles'
            },
            'de': {
                'DESKTOP': 'Schreibtisch',
                'DOWNLOAD': 'Downloads',
                'DOCUMENTS': 'Dokumente',
                'MUSIC': 'Musik',
                'PICTURES': 'Bilder',
                'VIDEOS': 'Videos',
                'PUBLICSHARE': 'Öffentlich',
                'TEMPLATES': 'Vorlagen'
            }
        }
        
        if lang_code not in dir_names:
            return None
        
        config_content = "# This file is written by xdg-user-dirs-update\n"
        config_content += "# If you want to change or add directories, just edit the line you're\n"
        config_content += "# interested in. All local changes will be retained on the next run.\n"
        config_content += "# Format is XDG_xxx_DIR=\"$HOME/yyy\", where yyy is a shell-escaped\n"
        config_content += "# homedir-relative path, or XDG_xxx_DIR=\"/yyy\", where /yyy is an\n"
        config_content += "# absolute path. No other format is supported.\n\n"
        
        for xdg_name, local_name in dir_names[lang_code].items():
            config_content += f'XDG_{xdg_name}_DIR="$HOME/{local_name}"\n'
        
        return config_content
    
    def _rename_physical_directories(self, locale):
        """Renombra físicamente los directorios existentes"""
        try:
            # Extraer el código de idioma del locale
            lang_code = locale.split('_')[0]
            print(f"Renombrando directorios para el idioma: {lang_code}")
            
            # Mapeo de nombres ingleses a localizados
            directory_names = {
                'es': {
                    'Desktop': 'Escritorio',
                    'Downloads': 'Descargas',
                    'Documents': 'Documentos',
                    'Music': 'Música',
                    'Pictures': 'Imágenes',
                    'Videos': 'Vídeos',
                    'Public': 'Público',
                    'Templates': 'Plantillas'
                },
                'en': {
                    'Desktop': 'Desktop',
                    'Downloads': 'Downloads', 
                    'Documents': 'Documents',
                    'Music': 'Music',
                    'Pictures': 'Pictures',
                    'Videos': 'Videos',
                    'Public': 'Public',
                    'Templates': 'Templates'
                },
                'fr': {
                    'Desktop': 'Bureau',
                    'Downloads': 'Téléchargements',
                    'Documents': 'Documents',
                    'Music': 'Musique',
                    'Pictures': 'Images',
                    'Videos': 'Vidéos',
                    'Public': 'Public',
                    'Templates': 'Modèles'
                },
                'de': {
                    'Desktop': 'Schreibtisch',
                    'Downloads': 'Downloads',
                    'Documents': 'Dokumente',
                    'Music': 'Musik',
                    'Pictures': 'Bilder',
                    'Videos': 'Videos',
                    'Public': 'Öffentlich',
                    'Templates': 'Vorlagen'
                },
                'it': {
                    'Desktop': 'Scrivania',
                    'Downloads': 'Scaricati',
                    'Documents': 'Documenti',
                    'Music': 'Musica',
                    'Pictures': 'Immagini',
                    'Videos': 'Video',
                    'Public': 'Pubblici',
                    'Templates': 'Modelli'
                },
                'pt': {
                    'Desktop': 'Área de Trabalho',
                    'Downloads': 'Transferências',
                    'Documents': 'Documentos',
                    'Music': 'Música',
                    'Pictures': 'Imagens',
                    'Videos': 'Vídeos',
                    'Public': 'Público',
                    'Templates': 'Modelos'
                },
                'ru': {
                    'Desktop': 'Рабочий стол',
                    'Downloads': 'Загрузки',
                    'Documents': 'Документы',
                    'Music': 'Музыка',
                    'Pictures': 'Изображения',
                    'Videos': 'Видео',
                    'Public': 'Общедоступные',
                    'Templates': 'Шаблоны'
                },
                'ro': {
                    'Desktop': 'Desktop',
                    'Downloads': 'Descărcări',
                    'Documents': 'Documente',
                    'Music': 'Muzică',
                    'Pictures': 'Poze',
                    'Videos': 'Videoclipuri',
                    'Public': 'Public',
                    'Templates': 'Șabloane'
                }
            }
            
            # Si no hay mapeo para el idioma, no hacer nada
            if lang_code not in directory_names:
                print(f"No hay mapeo de directorios para el idioma: {lang_code}")
                return
            
            # RENOMBRAR EN AMBAS DIRECCIONES para asegurar que el renombrado sea correcto
            
            # 1. Intentar desde inglés al idioma local (p.ej. Desktop → Escritorio)
            for en_name, localized_name in directory_names[lang_code].items():
                en_path = os.path.join(self.home_dir, en_name)
                localized_path = os.path.join(self.home_dir, localized_name)
                
                if os.path.exists(en_path) and not os.path.exists(localized_path):
                    try:
                        print(f"Renombrando: {en_path} → {localized_path}")
                        os.rename(en_path, localized_path)
                    except Exception as e:
                        print(f"Error renombrando {en_path}: {e}")
            
            # 2. También intentar desde cualquier otro idioma al actual
            # Primero recopilar todos los nombres posibles de directorios en otros idiomas
            all_localized_names = {}
            for other_lang, name_map in directory_names.items():
                if other_lang != lang_code:  # Excluir el idioma actual
                    for en_name, other_name in name_map.items():
                        if en_name not in all_localized_names:
                            all_localized_names[en_name] = set()
                        all_localized_names[en_name].add(other_name)
            
            # Luego intentar renombrar desde cualquier nombre localizado al nombre en el idioma actual
            for en_name, other_names in all_localized_names.items():
                target_name = directory_names[lang_code][en_name]  # Nombre en el idioma objetivo
                for other_name in other_names:
                    other_path = os.path.join(self.home_dir, other_name)
                    target_path = os.path.join(self.home_dir, target_name)
                    
                    if os.path.exists(other_path) and not os.path.exists(target_path):
                        try:
                            print(f"Renombrando desde otro idioma: {other_path} → {target_path}")
                            os.rename(other_path, target_path)
                        except Exception as e:
                            print(f"Error renombrando {other_path}: {e}")
            
            # Crear directorios esenciales si no existen
            for en_name, localized_name in directory_names[lang_code].items():
                localized_path = os.path.join(self.home_dir, localized_name)
                if not os.path.exists(localized_path):
                    try:
                        os.makedirs(localized_path, exist_ok=True)
                        print(f"Creado directorio faltante: {localized_path}")
                    except Exception as e:
                        print(f"Error creando {localized_path}: {e}")
                        
        except Exception as e:
            print(f"Error general en renombrado de directorios: {e}")
    
    def _update_kde_directory_references(self, lang_code):
        """Actualiza las referencias a directorios en KDE"""
        try:
            # Actualizar referencias en Plasma
            subprocess.run([
                'kwriteconfig5', '--file', 'dolphinrc',
                '--group', 'General', '--key', 'HomeUrl',
                f'file://{self.home_dir}'
            ], check=False)
            
            # Actualizar escritorio para que muestre los iconos
            desktop_path = os.path.join(self.home_dir, 'Desktop')
            if lang_code == 'es':
                desktop_path = os.path.join(self.home_dir, 'Escritorio')
            elif lang_code == 'pt':
                desktop_path = os.path.join(self.home_dir, 'Área de Trabalho')
            elif lang_code == 'fr':
                desktop_path = os.path.join(self.home_dir, 'Bureau')
            elif lang_code == 'de':
                desktop_path = os.path.join(self.home_dir, 'Schreibtisch')
            elif lang_code == 'it':
                desktop_path = os.path.join(self.home_dir, 'Scrivania')
            
            # Actualizar configuración de plasma para el escritorio
            subprocess.run([
                'kwriteconfig5', '--file', 'plasma-org.kde.plasma.desktop-appletsrc',
                '--group', 'Containments', '--group', '1', '--group', 'General',
                '--key', 'url', f'file://{desktop_path}'
            ], check=False)
            
            # Forzar refresco del plasma shell
            subprocess.run(['qdbus', 'org.kde.plasmashell', '/PlasmaShell', 
                           'org.kde.PlasmaShell.evaluateScript', 
                           'refreshCurrentShell()'], check=False)
        except Exception as e:
            print(f"Error actualizando referencias KDE: {e}")

# Instancia global para uso directo
xdg_manager = XDGDirectoriesManager()
