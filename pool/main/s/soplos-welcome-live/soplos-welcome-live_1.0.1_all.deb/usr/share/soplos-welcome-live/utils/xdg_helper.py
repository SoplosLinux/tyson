#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import subprocess
import shutil
from utils.desktop_detector import get_session_type

class XDGDirectoriesManager:
    """Gestiona los directorios XDG de manera simple"""
    
    def __init__(self):
        self.home_dir = os.path.expanduser('~')
        self.config_dir = os.path.join(self.home_dir, '.config')
        self.user_dirs_path = os.path.join(self.config_dir, 'user-dirs.dirs')
        self.session_type = get_session_type()
    
    def update_directories(self, locale):
        """Actualiza los directorios XDG de forma simple y directa"""
        try:
            # 1. Configurar variables de entorno
            env = os.environ.copy()
            env['LANG'] = locale
            env['LC_ALL'] = locale
            
            # 2. Forzar actualización de directorios
            subprocess.run(['xdg-user-dirs-update', '--force'], 
                          env=env, check=True)
            
            # 3. Actualizar el entorno de escritorio
            if self.session_type == 'wayland':
                subprocess.run(['dbus-send', '--session', '--dest=org.kde.plasmashell',
                              '/PlasmaShell', 'org.kde.PlasmaShell.evaluateScript',
                              'string:refreshCurrentShell()'], check=False)
            
            return True
        except Exception as e:
            print(f"Error actualizando directorios XDG: {e}")
            return False

# Instancia global para uso directo
xdg_manager = XDGDirectoriesManager()
