from setuptools import setup, find_packages

setup(
    name="soplos-grub-editor",
    version="1.0.0",
    author="Soplos Team",
    author_email="info@soploslinux.com",
    description="Soplos GRUB Editor - Editor gráfico oficial para la configuración de GRUB",
    long_description=open('README.md').read(),
    long_description_content_type="text/markdown",
    url="https://github.com/soplos/soplos-grub-editor",  # Actualizar con la URL correcta
    packages=find_packages(),
    install_requires=[
        'PyGObject>=3.36.0',
        'pycairo>=1.16.2',
        'python-xlib>=0.27',
        'polib>=1.1.0',
        'dbus-python>=1.2.16',
        'Pillow>=8.0.0'
    ],
    package_data={
        'soplos_grub_editor': [
            'assets/icons/*',
            'assets/*.desktop',
            'translations/*.py',  # Cambiado de locale a translations
        ],
    },
    data_files=[
        ('share/applications', ['assets/com.soplos.grubeditor.desktop']),
        ('share/icons/hicolor/128x128/apps', ['assets/icons/com.soplos.grubeditor.png']),
    ],
    entry_points={
        'console_scripts': [
            'soplos-grub-editor=main:main',
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
        "Operating System :: POSIX :: Linux",
        "Environment :: X11 Applications :: GTK",
    ],
    python_requires='>=3.6',
)