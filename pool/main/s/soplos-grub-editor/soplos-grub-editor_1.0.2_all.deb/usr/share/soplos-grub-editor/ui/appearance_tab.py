#!/usr/bin/env python3
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GdkPixbuf, GLib
import os
import subprocess
import logging
from utils.font_utils import (
    convert_font_for_grub,
    list_installed_grub_fonts,
    set_grub_font,
    remove_grub_font,
    delete_font_file,
    GrubConfigManager,
    GRUB_FONT_KEY
)
from utils.theme_utils import (
    install_theme,
    set_grub_theme,
    list_installed_themes,
    remove_theme,
    disable_theme,
    GRUB_THEME_KEY,
    generate_theme_preview
)
# Cambiado: importar desde el directorio translations
from translations.strings import TRANSLATIONS

def get_system_language():
    lang = os.environ.get('LANG', 'en_US.UTF-8')
    return lang.split('_')[0]

LANG = get_system_language()
_ = lambda key: TRANSLATIONS.get(LANG, TRANSLATIONS['en']).get(key, TRANSLATIONS['en'][key])

# Configurar logging
logger = logging.getLogger(__name__)  # Añadir esta línea

class AppearanceTab:
    def __init__(self, parent):
        self.parent = parent
        self.grub_config = parent.grub_config
        
        # Contenedor para la pestaña
        self.content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.content.set_border_width(10)
        
        # Crear los widgets
        self._create_widgets()
        
        # Cargar la configuración actual
        self._load_config()
    
    def get_content(self):
        """Devolver el contenedor principal de esta pestaña"""
        # Crear un ScrolledWindow y agregar el contenido principal
        scrolled_window = Gtk.ScrolledWindow()
        scrolled_window.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scrolled_window.add(self.content)
        
        return scrolled_window
    
    def _create_widgets(self):
        """Crear los widgets de la pestaña"""
        # Primera sección: Apariencia Visual
        visual_frame = self.create_visual_section()
        
        # Segunda sección: Fuentes
        font_frame = self.create_font_section()
        
        # Agregar las secciones al contenedor principal
        self.content.pack_start(visual_frame, False, False, 0)
        self.content.pack_start(font_frame, False, False, 0)

    def create_visual_section(self):
        visual_frame = Gtk.Frame(label=_('theme_section'))
        main_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        main_box.set_border_width(10)

        # Panel izquierdo: Vista previa
        left_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        left_panel.set_size_request(350, -1)

        # Vista previa
        preview_frame = Gtk.Frame(label=_('preview_label'))
        preview_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        preview_box.set_border_width(10)
        
        self.preview_image = Gtk.Image()
        self.preview_image.set_size_request(320, 240)
        preview_box.pack_start(self.preview_image, False, False, 0)
        preview_frame.add(preview_box)
        left_panel.pack_start(preview_frame, False, False, 0)

        # Panel derecho: Controles
        right_panel = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)

        # Notebook para temas y fondos
        notebook = Gtk.Notebook()
        
        # Pestaña de Tema
        theme_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        theme_box.set_border_width(10)
        
        themes_label = Gtk.Label(label=_('theme_section'), xalign=0)
        theme_box.pack_start(themes_label, False, False, 0)
        
        self.theme_list_store = Gtk.ListStore(str, str)
        self.theme_list = Gtk.ComboBox.new_with_model(self.theme_list_store)
        renderer = Gtk.CellRendererText()
        self.theme_list.pack_start(renderer, True)
        self.theme_list.add_attribute(renderer, "text", 1)
        self.theme_list.connect("changed", self.on_theme_changed)
        theme_box.pack_start(self.theme_list, False, False, 0)
        
        # Botones de tema en dos filas
        theme_buttons = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        
        button_row1 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        self.install_theme_button = Gtk.Button(label=_('install_theme'))
        self.apply_theme_button = Gtk.Button(label=_('apply_button'))  # Cambiado a clave de traducción
        button_row1.pack_start(self.install_theme_button, True, True, 0)
        button_row1.pack_start(self.apply_theme_button, True, True, 0)
        
        button_row2 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        self.disable_theme_button = Gtk.Button(label=_('disable_theme'))
        self.remove_theme_button = Gtk.Button(label=_('remove_theme'))
        button_row2.pack_start(self.disable_theme_button, True, True, 0)
        button_row2.pack_start(self.remove_theme_button, True, True, 0)
        
        theme_buttons.pack_start(button_row1, False, False, 0)
        theme_buttons.pack_start(button_row2, False, False, 0)
        theme_box.pack_start(theme_buttons, False, False, 0)
        
        # Conectar señales de tema
        self.install_theme_button.connect("clicked", self.on_install_theme_clicked)
        self.apply_theme_button.connect("clicked", self.on_apply_theme_clicked)
        self.disable_theme_button.connect("clicked", self.on_disable_theme_clicked)
        self.remove_theme_button.connect("clicked", self.on_remove_theme_clicked)
        
        notebook.append_page(theme_box, Gtk.Label(label=_('theme_section')))

        # Pestaña de Fondo
        bg_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        bg_box.set_border_width(10)
        
        bg_button_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        self.bg_button = Gtk.Button(label=_('select_background'))
        self.bg_button.connect("clicked", self.on_bg_button_clicked)
        bg_button_box.pack_start(self.bg_button, True, True, 0)
        
        self.remove_bg_button = Gtk.Button(label=_('remove_background'))
        self.remove_bg_button.connect("clicked", self.on_remove_bg_clicked)
        bg_button_box.pack_start(self.remove_bg_button, True, True, 0)
        
        bg_box.pack_start(bg_button_box, False, False, 0)
        notebook.append_page(bg_box, Gtk.Label(label=_('background_section')))

        right_panel.pack_start(notebook, False, False, 0)

        # Sección de colores
        colors_frame = Gtk.Frame(label=_('colors_section'))
        colors_grid = Gtk.Grid(row_spacing=6, column_spacing=6)
        colors_grid.set_border_width(10)
        
        # Color del texto
        text_color_label = Gtk.Label(label=_('text_color'), xalign=0)
        self.text_color_button = Gtk.ColorButton()
        colors_grid.attach(text_color_label, 0, 0, 1, 1)
        colors_grid.attach(self.text_color_button, 1, 0, 1, 1)
        
        # Color del fondo
        bg_color_label = Gtk.Label(label=_('background_color'), xalign=0)
        self.bg_color_button = Gtk.ColorButton()
        colors_grid.attach(bg_color_label, 0, 1, 1, 1)
        colors_grid.attach(self.bg_color_button, 1, 1, 1, 1)
        
        # Color del texto marcado
        highlight_text_color_label = Gtk.Label(label=_('highlight_text_color'), xalign=0)
        self.highlight_text_color_button = Gtk.ColorButton()
        colors_grid.attach(highlight_text_color_label, 0, 2, 1, 1)
        colors_grid.attach(self.highlight_text_color_button, 1, 2, 1, 1)
        
        # Color del fondo marcado
        highlight_bg_color_label = Gtk.Label(label=_('highlight_background_color'), xalign=0)
        self.highlight_bg_color_button = Gtk.ColorButton()
        colors_grid.attach(highlight_bg_color_label, 0, 3, 1, 1)
        colors_grid.attach(self.highlight_bg_color_button, 1, 3, 1, 1)
        
        colors_frame.add(colors_grid)
        right_panel.pack_start(colors_frame, False, False, 10)

        # Añadir paneles al contenedor principal
        main_box.pack_start(left_panel, False, False, 0)
        main_box.pack_start(right_panel, True, True, 0)
        
        visual_frame.add(main_box)
        
        # Cargar temas instalados
        self.load_installed_themes()
        
        return visual_frame

    def on_theme_changed(self, combo):
        """Actualizar vista previa cuando se selecciona un tema"""
        iter = combo.get_active_iter()
        if iter is not None:
            theme_path = self.theme_list_store[iter][0]
            # Asegurarse de que el tema existe y tiene previsualización
            if os.path.exists(theme_path):
                preview_path = os.path.join(theme_path, "preview.png")
                if not os.path.exists(preview_path):
                    success, _ = generate_theme_preview(theme_path)
                    if not success:
                        logger.warning(f"No se pudo generar vista previa para {theme_path}")
                self.update_preview(theme_path)

    def update_preview(self, path):
        """Actualizar la vista previa con una imagen"""
        try:
            # Intentar cargar preview.png del tema
            if os.path.isdir(path):
                preview_path = os.path.join(path, "preview.png")
                if os.path.exists(preview_path):
                    try:
                        pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                            filename=preview_path,
                            width=320,
                            height=240,
                            preserve_aspect_ratio=True
                        )
                        self.preview_image.set_from_pixbuf(pixbuf)
                        return
                    except GLib.Error as e:
                        logging.error(f"Error al cargar preview del tema: {str(e)}")
            
            # Si es una imagen de fondo directa
            if os.path.isfile(path):
                try:
                    pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(
                        filename=path,
                        width=320,
                        height=240,
                        preserve_aspect_ratio=True
                    )
                    self.preview_image.set_from_pixbuf(pixbuf)
                    return
                except GLib.Error as e:
                    logging.error(f"Error al cargar imagen de fondo: {str(e)}")
                
            # Si no hay imagen para mostrar
            self.preview_image.clear()
            
        except Exception as e:
            logging.warning(f"Error al cargar vista previa: {str(e)}")
            self.preview_image.clear()

    def create_font_section(self):
        """Crear la sección de fuentes con funcionalidad mejorada"""
        font_frame = Gtk.Frame(label=_('font_section'))
        font_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        font_box.set_margin_top(10)
        font_box.set_margin_bottom(10)
        font_box.set_margin_start(10)
        font_box.set_margin_end(10)
        
        # Información sobre el método alternativo
        info_label = Gtk.Label()
        info_label.set_markup(f"<b>{_('font_help')}</b>")
        info_label.set_line_wrap(True)
        info_label.set_justify(Gtk.Justification.CENTER)
        font_box.pack_start(info_label, False, False, 0)
        
        # Sección para instalar nuevas fuentes
        install_frame = Gtk.Frame(label=_('install_font_button'))
        install_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        install_box.set_margin_top(6)
        install_box.set_margin_bottom(6)
        install_box.set_margin_start(10)
        install_box.set_margin_end(10)
        
        hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        
        self.font_path_entry = Gtk.Entry()
        self.font_path_entry.set_placeholder_text(_('font_select_help'))
        self.font_path_entry.set_editable(False)
        hbox.pack_start(self.font_path_entry, True, True, 0)
        
        # Añadir atajos de teclado a los botones
        browse_button = Gtk.Button(label="_" + _('browse_button'))
        browse_button.set_use_underline(True)
        browse_button.add_accelerator("clicked", self.parent.accel_group,
                                    ord('B'), Gdk.ModifierType.MOD1_MASK, 
                                    Gtk.AccelFlags.VISIBLE)
        browse_button.set_tooltip_text(_('shortcut_titles')['browse'])
        
        self.install_button = Gtk.Button(label="_" + _('install_font_button'))
        self.install_button.set_use_underline(True)
        self.install_button.add_accelerator("clicked", self.parent.accel_group,
                                    ord('I'), Gdk.ModifierType.MOD1_MASK, 
                                    Gtk.AccelFlags.VISIBLE)
        self.install_button.set_tooltip_text(_('shortcut_titles')['install'])
        
        browse_button.connect("clicked", self.on_browse_font_clicked)
        hbox.pack_start(browse_button, False, False, 0)
        
        install_box.pack_start(hbox, False, False, 0)
        
        # Selector de tamaño de fuente
        size_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        size_label = Gtk.Label(label=_('font_size'))
        size_box.pack_start(size_label, False, False, 0)
        
        self.font_size_adjustment = Gtk.Adjustment(16, 8, 48, 1, 2, 0)
        self.font_size_spin = Gtk.SpinButton()
        self.font_size_spin.set_adjustment(self.font_size_adjustment)
        size_box.pack_start(self.font_size_spin, False, False, 0)
        
        install_box.pack_start(size_box, False, False, 0)
        
        # Botón de instalación
        self.install_button.connect("clicked", self.on_install_font_clicked)
        self.install_button.set_sensitive(False)
        install_box.pack_start(self.install_button, False, False, 0)
        
        install_frame.add(install_box)
        font_box.pack_start(install_frame, False, False, 10)
        
        # Sección para seleccionar fuentes ya instaladas
        select_frame = Gtk.Frame(label=_('select_font'))
        select_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        select_box.set_margin_top(6)
        select_box.set_margin_bottom(6)
        select_box.set_margin_start(10)
        select_box.set_margin_end(10)

        # Lista de fuentes instaladas
        self.font_list_store = Gtk.ListStore(str)
        self.font_list = Gtk.ComboBox.new_with_model(self.font_list_store)
        renderer = Gtk.CellRendererText()
        self.font_list.pack_start(renderer, True)
        self.font_list.add_attribute(renderer, "text", 0)
        
        select_box.pack_start(self.font_list, False, False, 0)

        # Botón para aplicar la fuente seleccionada
        self.apply_font_button = Gtk.Button(label=_('apply_font_button'))
        self.apply_font_button.connect("clicked", self.on_apply_font_clicked)
        self.apply_font_button.set_sensitive(False)
        select_box.pack_start(self.apply_font_button, False, False, 0)

        # Botón para eliminar la fuente seleccionada
        self.remove_font_button = Gtk.Button(label=_('remove_font_button'))
        self.remove_font_button.connect("clicked", self.on_remove_font_clicked)
        self.remove_font_button.set_sensitive(False)
        select_box.pack_start(self.remove_font_button, False, False, 0)

        # Añadir botón para eliminar archivo de fuente
        self.delete_font_file_button = Gtk.Button(label=_('delete_font_file_button'))
        self.delete_font_file_button.connect("clicked", self.on_delete_font_file_clicked)
        self.delete_font_file_button.set_sensitive(False)
        select_box.pack_start(self.delete_font_file_button, False, False, 0)

        select_frame.add(select_box)
        font_box.pack_start(select_frame, False, False, 10)

        # Cargar las fuentes instaladas
        self.load_installed_fonts()

        font_frame.add(font_box)
        return font_frame

    def load_installed_fonts(self):
        """Cargar la lista de fuentes instaladas en GRUB"""
        try:
            self.font_list_store.clear()
            fonts = list_installed_grub_fonts()
            
            if not fonts:
                self.parent.show_info(_('no_font_installed'))
                self.apply_font_button.set_sensitive(False)
                self.remove_font_button.set_sensitive(False)
                self.delete_font_file_button.set_sensitive(False)
                return
            
            for font in fonts:
                self.font_list_store.append([font])
            
            self.font_list.set_active(0)
            self.apply_font_button.set_sensitive(True)
            self.remove_font_button.set_sensitive(True)
            self.delete_font_file_button.set_sensitive(True)
            
        except Exception as e:
            self.parent.show_error(_('font_load_error').format(str(e)))
            logging.error(_('font_load_error').format(e))

    def load_installed_themes(self):
        """Cargar la lista de temas instalados"""
        self.theme_list_store.clear()
        themes = list_installed_themes()
        
        for theme_path in themes:
            theme_name = os.path.basename(theme_path)
            self.theme_list_store.append([theme_path, theme_name])
            
        self.theme_list.set_active(0)
        self.update_theme_preview()
    
    def update_theme_preview(self):
        """Actualizar la vista previa del tema actual"""
        iter = self.theme_list.get_active_iter()
        if iter is not None:
            theme_path = self.theme_list_store[iter][0]
            self.update_preview(theme_path)

    def on_browse_font_clicked(self, widget):
        """Manejar el evento de seleccionar una fuente"""
        fonts_directory = "/usr/share/fonts"

        # Crear el diálogo de selección de archivos
        dialog = Gtk.FileChooserDialog(
            title=_('select_font_dialog'),
            transient_for=self.parent,
            action=Gtk.FileChooserAction.OPEN
        )
        dialog.add_buttons(
            _('cancel_button'), Gtk.ResponseType.CANCEL,
            _('open_button'), Gtk.ResponseType.OK
        )

        # Establecer la carpeta inicial del diálogo
        if os.path.exists(fonts_directory):
            dialog.set_current_folder(fonts_directory)

        # Filtros para tipos de fuente
        filter_font = Gtk.FileFilter()
        filter_font.set_name(_('font_filter'))
        filter_font.add_mime_type("font/ttf")
        filter_font.add_mime_type("font/otf")
        dialog.add_filter(filter_font)

        # Mostrar el diálogo y obtener la respuesta
        response = dialog.run()

        if response == Gtk.ResponseType.OK:
            # Obtener la ruta del archivo seleccionado
            font_path = dialog.get_filename()
            self.font_path_entry.set_text(font_path)
            self.install_button.set_sensitive(True)

        # Cerrar el diálogo
        dialog.destroy()

    def on_install_font_clicked(self, widget):
        """Manejar el evento de instalar una nueva fuente"""
        font_path = self.font_path_entry.get_text()
        size = self.font_size_spin.get_value_as_int()

        if not font_path or not os.path.exists(font_path):
            self.parent.show_error(_('invalid_font'))
            return

        success, result = convert_font_for_grub(font_path, size)
        if success:
            self.parent.show_info(_('font_installed').format(result))
            self.load_installed_fonts()
        else:
            self.parent.show_error(_('font_error').format(result))

    def on_apply_font_clicked(self, widget):
        """Manejar el evento de aplicar una fuente instalada"""
        tree_iter = self.font_list.get_active_iter()
        if tree_iter is None:
            return

        font_path = self.font_list_store[tree_iter][0]
        
        dialog = Gtk.MessageDialog(
            transient_for=self.parent,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=_('apply_font_confirm'),
            secondary_text=_('apply_font_message').format(os.path.basename(font_path))
        )
        
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            success, message = set_grub_font(font_path)
            if success:
                self.grub_config.load_config()
                self.parent.show_info(message)
            else:
                self.parent.show_error(message)

    def on_remove_font_clicked(self, widget):
        """Manejar el evento de eliminar la fuente seleccionada"""
        tree_iter = self.font_list.get_active_iter()
        if tree_iter is None:
            return

        font_path = self.font_list_store[tree_iter][0]
        
        # Validar existencia de fuente
        if not os.path.exists(font_path):
            self.parent.show_error(f"La fuente {font_path} no existe")
            return

        # Eliminar la fuente de GRUB
        success, message = remove_grub_font()
        if success:
            self.parent.show_info(message)
            self.load_installed_fonts()
        else:
            self.parent.show_error(message)

    def on_delete_font_file_clicked(self, widget):
        """Manejar el evento de eliminar el archivo de fuente"""
        tree_iter = self.font_list.get_active_iter()
        if tree_iter is None:
            return

        font_path = self.font_list_store[tree_iter][0]
        font_name = os.path.basename(font_path)

        # Confirmar antes de eliminar
        dialog = Gtk.MessageDialog(
            transient_for=self.parent,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.YES_NO,
            text=_('delete_font_confirm'),
            secondary_text=_('delete_font_warning').format(font_name)
        )
        
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            # Primero, asegurarse de que la fuente no esté en uso
            if GRUB_FONT_KEY in self.grub_config.config and \
               self.grub_config.config[GRUB_FONT_KEY] == font_path:
                # Eliminar la configuración de la fuente primero
                success, message = remove_grub_font(self.grub_config)
                if not success:
                    self.parent.show_error(f"Error al eliminar la configuración de la fuente: {message}")
                    return

            # Eliminar el archivo físico
            success, message = delete_font_file(font_path)
            if success:
                self.parent.show_info(message)
                self.load_installed_fonts()  # Recargar la lista de fuentes
            else:
                self.parent.show_error(message)

    def on_install_theme_clicked(self, widget):
        """Manejar el evento de instalar un nuevo tema"""
        dialog = Gtk.FileChooserDialog(
            title=_('select_theme_dialog'),
            parent=self.parent,
            action=Gtk.FileChooserAction.OPEN
        )
        dialog.add_buttons(
            _('cancel_button'), Gtk.ResponseType.CANCEL,
            _('open_button'), Gtk.ResponseType.OK
        )
        
        # Filtros para archivos de tema
        filter_theme = Gtk.FileFilter()
        filter_theme.set_name(_('theme_filter'))
        filter_theme.add_pattern("*.tar.gz")
        filter_theme.add_pattern("*.tgz")
        filter_theme.add_pattern("*.tar.xz")
        filter_theme.add_pattern("*.zip")
        dialog.add_filter(filter_theme)
        
        # Agregar un filtro para todos los archivos
        filter_all = Gtk.FileFilter()
        filter_all.set_name(_('all_files'))
        filter_all.add_pattern("*")
        dialog.add_filter(filter_all)
        
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            theme_path = dialog.get_filename()
            success, result = install_theme(theme_path)
            
            if success:
                self.parent.show_info(_('theme_installed'))
                self.load_installed_themes()
            else:
                self.parent.show_error(_('theme_error').format(result))
        
        dialog.destroy()

    def on_apply_theme_clicked(self, widget):
        """Manejar el evento de aplicar un tema"""
        iter = self.theme_list.get_active_iter()
        if iter is None:
            return
            
        theme_path = self.theme_list_store[iter][0]
        success, message = set_grub_theme(theme_path, self.grub_config)
        
        if success:
            # Actualizar vista previa después de aplicar el tema
            self.update_preview(theme_path)
            # Recargar la configuración para asegurarnos de que todo está sincronizado
            self.grub_config.load_config()
            self.parent.show_info(message)
            # Forzar actualización de la UI
            while Gtk.events_pending():
                Gtk.main_iteration()
        else:
            self.parent.show_error(message)

    def on_disable_theme_clicked(self, widget):
        """Manejar el evento de quitar/deshabilitar el tema actual"""
        dialog = Gtk.MessageDialog(
            transient_for=self.parent,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=_('disable_theme_confirm'),
            secondary_text=_('disable_theme_message')
        )
        
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            success, message = disable_theme(self.grub_config)
            if success:
                self.preview_image.clear()
                self.parent.show_info(message)
            else:
                self.parent.show_error(message)

    def on_remove_theme_clicked(self, widget):
        """Manejar el evento de eliminar un tema"""
        iter = self.theme_list.get_active_iter()
        if iter is None:
            return
            
        theme_path = self.theme_list_store[iter][0]
        theme_name = self.theme_list_store[iter][1]
        
        dialog = Gtk.MessageDialog(
            transient_for=self.parent,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=_('remove_theme_confirm').format(theme_name)
        )
        
        response = dialog.run()
        dialog.destroy()
        
        if response == Gtk.ResponseType.YES:
            # Si el tema está activo, eliminarlo de la configuración
            if GRUB_THEME_KEY in self.grub_config.config and \
               self.grub_config.config[GRUB_THEME_KEY] == theme_path:
                del self.grub_config.config[GRUB_THEME_KEY]
                self.grub_config.save_config()
            
            success, message = remove_theme(theme_path)
            if success:
                self.parent.show_info(message)
                self.load_installed_themes()
            else:
                self.parent.show_error(message)

    def on_remove_bg_clicked(self, widget):
        """Manejar el evento de quitar el fondo de pantalla"""
        try:
            if 'GRUB_BACKGROUND' in self.grub_config.config:
                # Buscar la línea de GRUB_BACKGROUND
                for i, line in enumerate(self.grub_config.config_lines):
                    stripped_line = line.strip()
                    # Si encontramos la línea sin comentar, la comentamos
                    if stripped_line.startswith('GRUB_BACKGROUND='):
                        self.grub_config.config_lines[i] = f"# {stripped_line} # Deshabilitado por Soplos GRUB Editor\n"
                        
                # Eliminar la configuración activa
                del self.grub_config.config['GRUB_BACKGROUND']
                
                # Limpiar la imagen mostrada
                self.preview_image.clear()  # Usar preview_image en lugar de bg_image
                
                # Guardar la configuración
                if self.grub_config.save_config():
                    self.parent.show_info(_('background_removed'))
                else:
                    self.parent.show_error(_('config_save_error'))
            else:
                self.parent.show_info(_('no_background_configured'))
                
        except Exception as e:
            logging.error(_('background_remove_error').format(str(e)))
            self.parent.show_error(_('background_remove_error').format(str(e)))

    def _load_config(self):
        """Cargar la configuración actual en los widgets"""
        try:
            config = self.grub_config.config
            
            # Priorizar la carga del tema activo
            if GRUB_THEME_KEY in config:
                theme_path = os.path.dirname(config[GRUB_THEME_KEY])
                if os.path.exists(theme_path):
                    # Actualizar lista de temas y seleccionar el activo
                    theme_name = os.path.basename(theme_path)
                    for i, row in enumerate(self.theme_list_store):
                        if row[1] == theme_name:
                            self.theme_list.set_active(i)
                            self.update_preview(theme_path)  # Actualizar vista previa aquí
                            break
                    return  # Si hay tema activo, no cargar el fondo
            
            # Si no hay tema activo, intentar cargar el fondo
            if 'GRUB_BACKGROUND' in config:
                bg_path = config['GRUB_BACKGROUND'].strip('"')  # Eliminar comillas si existen
                if os.path.exists(bg_path):
                    self.update_preview(bg_path)
            
            # Cargar colores desde custom.cfg
            custom_cfg_path = "/boot/grub/custom.cfg"
            if os.path.exists(custom_cfg_path):
                with open(custom_cfg_path, 'r') as f:
                    lines = f.readlines()
                    
                for line in lines:
                    line = line.strip()
                    if line.startswith('set color_normal='):
                        colors = line.split('=')[1]
                        fg, bg = colors.split('/')
                        # Configurar colores normales
                        rgba_fg = self._color_name_to_rgba(fg)
                        rgba_bg = self._color_name_to_rgba(bg)
                        if rgba_fg:
                            self.text_color_button.set_rgba(rgba_fg)
                        if rgba_bg:
                            self.bg_color_button.set_rgba(rgba_bg)
                            
                    elif line.startswith('set color_highlight='):
                        colors = line.split('=')[1]
                        fg, bg = colors.split('/')
                        # Configurar colores de resaltado
                        rgba_fg = self._color_name_to_rgba(fg)
                        rgba_bg = self._color_name_to_rgba(bg)
                        if rgba_fg:
                            self.highlight_text_color_button.set_rgba(rgba_fg)
                        if rgba_bg:
                            self.highlight_bg_color_button.set_rgba(rgba_bg)
                    
        except Exception as e:
            logging.error(f"Error al cargar la configuración: {str(e)}")

    def _color_name_to_rgba(self, color_name):
        """Convertir nombre de color a Gdk.RGBA"""
        color_map = {
            "black": (0, 0, 0),
            "white": (255, 255, 255),
            "red": (255, 0, 0),
            "green": (0, 255, 0),
            "blue": (0, 0, 255),
            "yellow": (255, 255, 0),
            "magenta": (255, 0, 255),
            "cyan": (0, 255, 255)
        }
        
        try:
            if color_name in color_map:
                r, g, b = color_map[color_name]
                return Gdk.RGBA(r/255.0, g/255.0, b/255.0, 1.0)
            return None
        except Exception as e:
            logging.error(f"Error al convertir color {color_name}: {str(e)}")
            return None
    
    def _parse_grub_color(self, color_str):
        """Convertir un color de GRUB a Gdk.RGBA"""
        try:
            fg, bg = color_str.split('/')
            r, g, b = [int(fg[i:i+2], 16) for i in range(0, 6, 2)]
            return Gdk.RGBA(r/255.0, g/255.0, b/255.0, 1.0)
        except Exception as e:
            print(f"Error al parsear el color: {str(e)}")
            return None
    
    def _format_grub_color(self, color):
        """Convertir un Gdk.RGBA a un color de GRUB"""
        # Mapear colores predefinidos
        color_map = {
            (0, 0, 0): "black",
            (255, 255, 255): "white",
            (255, 0, 0): "red",
            (0, 255, 0): "green",
            (0, 0, 255): "blue",
            (255, 255, 0): "yellow",
            (255, 0, 255): "magenta",
            (0, 255, 255): "cyan",
        }
        
        r = int(color.red * 255)
        g = int(color.green * 255)
        b = int(color.blue * 255)
        
        # Buscar el nombre del color más cercano
        closest_color = min(color_map.keys(), key=lambda c: (c[0] - r) ** 2 + (c[1] - g) ** 2 + (c[2] - b) ** 2)
        return color_map[closest_color]
    
    def on_bg_button_clicked(self, widget):
        """Manejar el evento de seleccionar una imagen de fondo"""
        dialog = Gtk.FileChooserDialog(
            title=_('select_background_dialog'),
            transient_for=self.parent,
            action=Gtk.FileChooserAction.OPEN
        )
        dialog.add_buttons(
            _('cancel_button'), Gtk.ResponseType.CANCEL,
            _('open_button'), Gtk.ResponseType.OK
        )
        
        # Filtros para tipos de imagen
        filter_image = Gtk.FileFilter()
        filter_image.set_name(_('image_filter'))
        filter_image.add_mime_type("image/png")
        filter_image.add_mime_type("image/jpeg")
        dialog.add_filter(filter_image)
        
        response = dialog.run()
        
        if response == Gtk.ResponseType.OK:
            bg_path = dialog.get_filename()
            try:
                # Actualizar vista previa
                self.update_preview(bg_path)
                
                # Comentar cualquier línea de tema activo
                new_lines = []
                for line in self.grub_config.config_lines:
                    if GRUB_THEME_KEY in line and not line.strip().startswith('#'):
                        new_lines.append(f"# {line.strip()} # Deshabilitado por fondo activo\n")
                        if GRUB_THEME_KEY in self.grub_config.config:
                            del self.grub_config.config[GRUB_THEME_KEY]
                    elif 'GRUB_BACKGROUND=' in line:
                        new_lines.append(f'GRUB_BACKGROUND="{bg_path}"\n')
                    else:
                        new_lines.append(line)
                
                self.grub_config.config_lines = new_lines
                self.grub_config.config['GRUB_BACKGROUND'] = bg_path
                
                if self.grub_config.save_config():
                    self.parent.show_info(_('background_applied'))
                else:
                    self.parent.show_error(_('config_save_error'))
            except Exception as e:
                self.parent.show_error(_('background_error').format(str(e)))
        
        dialog.destroy()

    def update_config(self):
        """Actualizar la configuración con los valores de los widgets"""
        # Convertir colores a formato GRUB
        text_color = self._format_grub_color(self.text_color_button.get_rgba())
        bg_color = self._format_grub_color(self.bg_color_button.get_rgba())
        highlight_text_color = self._format_grub_color(self.highlight_text_color_button.get_rgba())
        highlight_bg_color = self._format_grub_color(self.highlight_bg_color_button.get_rgba())
        
        # Validar que los colores no sean iguales
        if text_color == bg_color:
            self.parent.show_error(_('colors_cannot_be_same'))
            return
        
        if highlight_text_color == highlight_bg_color:
            self.parent.show_error(_('highlight_colors_cannot_be_same'))
            return
        
        # Crear el contenido de custom.cfg
        custom_cfg_content = [
            f"set color_normal={text_color}/{bg_color}",
            f"set color_highlight={highlight_text_color}/{highlight_bg_color}",
        ]
        
        # Guardar en custom.cfg
        self._save_custom_config(custom_cfg_content)
    
    def _save_custom_config(self, lines):
        """Guardar las líneas de configuración en /boot/grub/custom.cfg"""
        custom_cfg_path = "/boot/grub/custom.cfg"
        try:
            with open(custom_cfg_path, "w") as f:
                for line in lines:
                    f.write(line + "\n")
            self.parent.show_info(_('config_saved_successfully'))
        except Exception as e:
            self.parent.show_error(_('config_save_error_path').format(custom_cfg_path, str(e)))

    def save_config(self, backup=False):
        """
        Guardar configuración de GRUB con control de copias de seguridad
        """
        try:
            if backup:
                self.grub_config.create_backup()
            
            # Usar el GrubConfigManager en lugar de manipular el archivo directamente
            success = self.grub_config.save_config()
            
            if success:
                self.parent.show_info("Configuración guardada correctamente")
                return True
            else:
                self.parent.show_error("Error al guardar la configuración")
                return False
                
        except Exception as e:
            self.parent.show_error(f"Error al guardar la configuración: {str(e)}")
            logging.error(f"Error al guardar configuración de GRUB: {e}")
            return False

    def check_permissions(self):
        """Verificar permisos necesarios"""
        if os.geteuid() != 0:
            self.parent.show_error("Se requieren privilegios de administrador para modificar la configuración de GRUB")
            return False
        return True