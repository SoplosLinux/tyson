"""
Traduceri în română pentru Soplos GRUB Editor
"""

STRINGS = {
    # Titluri și anteturi
    'app_name': 'Soplos GRUB Editor',
    'general_tab': 'Setări generale',
    'entries_tab': 'Intrări de boot',
    'appearance_tab': 'Aspect',
    
    # Butoane comune
    'save_button': 'Salvare',
    'apply_button': 'Aplicare',
    'close_button': 'Închidere',
    'cancel_button': 'Anulare',
    'ok_button': 'OK',
    
    # Titluri de dialoguri
    'error_title': 'Eroare',
    'info_title': 'Informație',
    'warning_title': 'Avertisment',
    'confirm_title': 'Confirmare',
    'question_title': 'Întrebare',
    
    # Mesaje generale
    'changes_saved': 'Modificările au fost salvate cu succes',
    'changes_error': 'Eroare la salvarea modificărilor',
    'need_root': 'Sunt necesare privilegii de administrator',
    'confirm_exit': 'Sigur doriți să ieșiți?',
    'unsaved_changes': 'Modificările nesalvate vor fi pierdute.',
    
    # Fila Generale
    'timeout_label': 'Timeout (secunde):',
    'default_entry_label': 'Intrare implicită:',
    'resolution_label': 'Rezoluția ecranului:',
    'kernel_params_label': 'Parametrii kernelului:',
    'os_prober_label': 'Detectează alte sisteme de operare',
    'show_menu_label': 'Afișează meniul de boot',
    'recovery_label': 'Include opțiuni de recuperare',
    'advanced_options': 'Opțiuni avansate',
    'kernel_params_section': 'Parametrii kernelului',
    
    # Fila Aspect
    'theme_section': 'Temă',
    'font_section': 'Fonturi',
    'colors_section': 'Culori',
    'background_section': 'Fundal',
    'preview_label': 'Previzualizare',
    'install_theme': 'Instalează temă...',
    'remove_theme': 'Șterge temă',
    'disable_theme': 'Dezactivează temă',
    'select_font': 'Selectează font...',
    'remove_font': 'Șterge font',
    'font_size': 'Dimensiune font:',
    'text_color': 'Culoare text:',
    'background_color': 'Culoare fundal:',
    'select_background': 'Selectează fundal...',
    'remove_background': 'Șterge fundal',
    'highlight_text_color': 'Culoare text evidențiat:',
    'highlight_background_color': 'Culoare fundal evidențiat:',
    'apply_theme_button': 'Aplică temă',
    
    # Fila Intrări
    'add_entry': 'Adaugă intrare',
    'edit_entry': 'Editează intrare',
    'remove_entry': 'Șterge intrare',
    'entry_name': 'Nume:',
    'entry_type': 'Tip:',
    'entry_kernel': 'Kernel:',
    'entry_initrd': 'Initrd:',
    'entry_params': 'Parametri:',
    'entry_path': 'Cale',
    'entry_enabled': 'Activat',
    
    # Mesaje de stare
    'ready': 'Gata',
    'saving': 'Salvare...',
    'applying': 'Aplicare modificări...',
    'loading': 'Încărcare...',
    'updating': 'Actualizare GRUB...',
    'grub_updated': 'GRUB actualizat cu succes',
    
    # Dialoguri specifice
    'select_font_dialog': 'Selectează font',
    'select_theme_dialog': 'Selectează temă',
    'select_background_dialog': 'Selectează imagine de fundal',
    'font_filter': 'Fonturi',
    'theme_filter': 'Fișiere de temă',
    'image_filter': 'Imagini',
    'all_files': 'Toate fișierele',
    'open_button': 'Deschide',
    
    # Texte de rezoluție
    'resolution_disabled': 'Dezactivat',
    'resolution_auto': 'Automat',
    
    # Texte de intrări
    'last_selection': 'Ultima selecție',
    'default_entry_saved': 'Ultima selecție',
    
    # Ajutor și controale pentru fonturi
    'font_help': 'Această metodă evită problemele cu update-grub modificând direct configurația.',
    'font_select_help': 'Selectați un fișier de font TTF sau OTF',
    'browse_button': 'Răsfoire...',
    'install_font_button': 'Instalează font',
    'apply_font_button': 'Aplică fontul selectat',
    'remove_font_button': 'Șterge fontul selectat',
    'delete_font_file_button': 'Șterge fișier',
    
    # Avertismente și confirmări
    'delete_font_confirm': 'Sigur doriți să ștergeți acest font?',
    'delete_font_warning': 'Fișierul va fi șters: {}\nAceastă acțiune nu poate fi anulată.',
    'apply_font_confirm': 'Doriți să aplicați acest font?',
    'apply_font_message': 'Fontul va fi aplicat: {}',
    'remove_theme_confirm': 'Ștergeți tema \'{}\'?',
    'disable_theme_confirm': 'Doriți să eliminați tema curentă?',
    'disable_theme_message': 'Tema va fi dezactivată, dar nu va fi eliminată din sistem',
    'update_grub_title': 'Actualizare GRUB',
    'update_grub_message': 'update-grub va fi executat pentru a aplica modificările.',
    'apply_changes_title': 'Aplicați modificările?',
    'apply_changes_message': 'update-grub va fi executat pentru a aplica modificările.',
    
    # Mesaje de succes
    'font_installed': 'Font instalat cu succes în: {}',
    'font_removed': 'Font șters cu succes',
    'font_removed_successfully': 'Font șters cu succes',
    'font_deleted_successfully': 'Font șters cu succes',
    'font_applied_successfully': 'Font aplicat cu succes',
    'theme_installed': 'Temă instalată cu succes',
    'theme_applied': 'Temă aplicată cu succes',
    'grub_theme_applied': 'Tema GRUB aplicată cu succes',
    'background_applied': 'Fundal configurat cu succes',
    'background_removed': 'Fundal șters cu succes',
    'entry_added': 'Intrare adăugată cu succes',
    'entry_removed': 'Intrare ștearsă cu succes',
    'changes_applied': 'Modificări aplicate cu succes',
    'config_saved_successfully': 'Configurația a fost salvată cu succes în custom.cfg',
    
    # Mesaje de eroare
    'error_save': 'Eroare la salvarea configurației',
    'error_load': 'Eroare la încărcarea configurației',
    'error_apply': 'Eroare la aplicarea modificărilor',
    'error_update': 'Eroare la actualizarea GRUB',
    'error_permission': 'Eroare de permisiune',
    'error_missing_deps': 'Dependențe necesare lipsă',
    'invalid_font': 'Vă rugăm să selectați un fișier de font valid',
    'font_error': 'Eroare la instalarea fontului: {}',
    'theme_error': 'Eroare la instalarea temei: {}',
    'background_error': 'Eroare la încărcarea imaginii: {}',
    'entry_error': 'Eroare la adăugarea intrării: {}',
    'entry_add_error': 'Eroare la adăugarea intrării',
    'entry_name_kernel_required': 'Numele și kernelul sunt obligatorii',
    'entry_remove_error': 'Eroare la eliminarea intrării',
    'no_entry_selected': 'Nu a fost selectată nicio intrare',
    'no_font_installed': 'Nu există fonturi instalate în GRUB',
    'no_background_configured': 'Nu este configurat niciun fundal',
    'config_save_error': 'Eroare la salvarea configurației',
    'config_save_error_path': 'Eroare la salvarea configurației în {}: {}',
    'colors_cannot_be_same': 'Culoarea textului și culoarea fundalului nu pot fi identice.',
    'highlight_colors_cannot_be_same': 'Culoarea textului evidențiat și culoarea fundalului evidențiat nu pot fi identice.',
    
    # Erori specifice sistemului
    'pkexec_error': 'Eroare: Nu s-au putut obține privilegii de administrator.',
    'relaunch_error': 'Eroare la relansarea ca root: {}',
    'grub_config_not_found': 'Fișierul de configurare GRUB nu a fost găsit',
    'insufficient_permissions': 'Permisiuni insuficiente pentru accesarea configurației GRUB',
    'initialization_error': 'Eroare la inițializare: {}',
    'update_grub_error': 'Eroare la executarea update-grub: {}',
    'cache_cleanup_error': 'Eroare la curățarea cache-ului: {}',
    'background_remove_error': 'Eroare la eliminarea fundalului: {}',
    'font_load_error': 'Eroare la încărcarea fonturilor instalate: {}',
    
    # Confirmări de ieșire
    'confirm_exit_title': 'Sigur doriți să ieșiți?',
    'confirm_exit_message': 'Modificările nesalvate vor fi pierdute.',
    
    # Erori de fonturi
    'invalid_font_file': 'Fișierul nu este un font valid',
    'font_not_exists': 'Fontul {} nu există',
    'font_convert_error': 'Eroare la conversia fontului: {}',
    'font_install_error': 'Eroare la instalarea fontului: {}',
    'font_convert_exception': 'Eroare la conversia fontului: {}',
    'font_set_error': 'Eroare la setarea fontului: {}',
    'font_remove_error': 'Eroare la eliminarea fontului: {}',
    'font_file_not_exists': 'Fișierul fontului nu există',
    'font_not_in_grub_dir': 'Fontul nu este în directorul de fonturi GRUB',
    'only_pf2_files_allowed': 'Doar fișierele de font .pf2 pot fi șterse',
    'font_deleted': 'Font șters: {}',
    'font_delete_error': 'Eroare la ștergerea fontului: {}',
    'font_delete_exception': 'Eroare la ștergerea fontului: {}',
    
    # Comenzi rapide de la tastatură
    'shortcut_save': 'Ctrl+S',
    'shortcut_apply': 'Alt+A',
    'shortcut_close': 'Alt+C',
    'keyboard_shortcuts': 'Comenzi rapide de la tastatură',
    'shortcut_titles': {
        'save': 'Salvare (Ctrl+S)',
        'apply': 'Aplicare (Alt+A)',
        'close': 'Închidere (Alt+C)',
        'browse': 'Răsfoire (Alt+B)',
        'install': 'Instalare (Alt+I)',
        'remove': 'Ștergere (Alt+R)',
        'delete': 'Ștergere (Del)',
        'add': 'Adăugare (Alt+N)',
        'edit': 'Editare (Alt+E)'
    },
    
    # Stări ale sistemului
    'no_theme_selected': 'Nu este selectată nicio temă',
    'theme_preview_error': 'Eroare la generarea previzualizării temei',
    'grub_theme_disabled': 'Tema GRUB dezactivată',
    'custom_entry_saved': 'Intrare personalizată salvată',
    'system_entry': 'Intrare de sistem',
    'custom_entry': 'Intrare personalizată',
    'entries_loaded': 'Intrări încărcate: {}',
    'grub_config_loaded': 'Configurația GRUB încărcată',
    'backup_created': 'Backup creat',
    'backup_restored': 'Backup restaurat',
    'permission_denied': 'Permisiune refuzată',
    'file_not_found': 'Fișier negăsit',
    'invalid_configuration': 'Configurație nevalidă',
    'theme_installation_success': 'Temă instalată cu succes în: {}',
    'theme_removal_success': 'Temă eliminată cu succes',
    'operation_completed': 'Operațiune completă',
    'operation_failed': 'Operațiune eșuată',
    
    # Mesaje tehnice și de log (NOU)
    'log_levelname_message': '%(levelname)s: %(message)s',
    'icon_set_error': 'Eroare la setarea iconiței după nume: {}',
    'program_class_error': 'Eroare la setarea program_class: {}',
    'directory_cleaned': 'Director curățat: {}',
    'directory_clean_error': 'Eroare la curățarea {}: {}',
    
    # Mesaje din utils/theme_utils.py (NOU)
    'file_format_not_supported': 'Format de fișier nesuportat. Folosiți .tar.gz, .tgz, .tar.xz sau .zip',
    'theme_directory_invalid': 'Directorul temei nu conține theme.txt',
    'invalid_path': 'Calea specificată nu este validă',
    'theme_disabled_successfully': 'Tema dezactivată cu succes',
    'theme_preview_generation_error': 'Nu s-a putut genera previzualizarea: {}',
    'theme_txt_not_found': 'theme.txt nu a fost găsit',
    'theme_decompress_error': 'Eroare la decomprimarea temei: {}',
    'theme_preview_generation_failed': 'Nu s-a putut genera previzualizarea',
    
    # Mesaje din utils/system_utils.py (NOU)
    'font_path_not_exists': 'Fontul {} nu există',
    'font_convert_stderr': 'Eroare la conversia fontului: {}',
    'grub_config_updated': 'Configurația GRUB actualizată cu succes',
    
    # Mesaje din utils/font_utils.py (NOU)
    'config_module_deprecated': 'Modulul \'config\' este învechit. Folosiți \'app_paths\' în schimb.',
    'no_backup_to_restore': 'Nu există backup de restaurat',
    'config_restored_successfully': 'Configurația restaurată cu succes',
    
    # Comentarii de cod generat (NOU)
    'disabled_by_soplos_grub_editor': '# Dezactivat de Soplos GRUB Editor',
    'custom_grub_header': '#!/bin/sh\nexec tail -n +3 $0\n# Acest fișier furnizează intrări personalizate pentru GRUB\n\n',
}
