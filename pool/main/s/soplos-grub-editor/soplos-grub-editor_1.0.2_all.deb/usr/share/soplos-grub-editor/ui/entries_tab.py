#!/usr/bin/env python3
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk
import os
# Cambiado: importar desde el nuevo directorio translations
from translations.strings import TRANSLATIONS

def get_system_language():
    lang = os.environ.get('LANG', 'en_US.UTF-8')
    return lang.split('_')[0]

LANG = get_system_language()
_ = lambda key: TRANSLATIONS.get(LANG, TRANSLATIONS['en']).get(key, TRANSLATIONS['en'][key])

class EntriesTab:
    def __init__(self, parent):
        self.parent = parent
        self.grub_config = parent.grub_config
        
        # Contenedor para la pestaña
        self.content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        self.content.set_border_width(10)
        
        # Crear los widgets
        self._create_widgets()
        
        # Cargar las entradas de arranque
        self._load_entries()
    
    def get_content(self):
        """Devolver el contenedor principal de esta pestaña"""
        return self.content
    
    def _create_widgets(self):
        """Crear los widgets de la pestaña"""
        # Lista de entradas de arranque
        self.entries_list = Gtk.ListStore(int, str, str, str, bool)  # Añadir columna para índice
        
        self.treeview = Gtk.TreeView(model=self.entries_list)
        
        # Nueva columna para el índice
        renderer = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn("#", renderer, text=0)
        column.set_sort_column_id(0)
        self.treeview.append_column(column)
        
        # Columnas existentes (actualizar índices)
        renderer = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn(_('entry_name'), renderer, text=1)
        self.treeview.append_column(column)
        
        renderer = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn(_('entry_type'), renderer, text=2)
        self.treeview.append_column(column)
        
        renderer = Gtk.CellRendererText()
        column = Gtk.TreeViewColumn(_('entry_path'), renderer, text=3)
        self.treeview.append_column(column)
        
        renderer = Gtk.CellRendererToggle()
        renderer.connect("toggled", self.on_entry_toggled)
        column = Gtk.TreeViewColumn(_('entry_enabled'), renderer, active=4)
        self.treeview.append_column(column)
        
        # Scroll para la lista
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scroll.add(self.treeview)
        
        # Botones de acción
        button_box = Gtk.Box(spacing=6)
        
        # Añadir atajos de teclado a los botones de acción
        self.add_button = Gtk.Button(label="_" + _('add_entry'))
        self.add_button.set_use_underline(True)
        self.add_button.add_accelerator("clicked", self.parent.accel_group,
                                    ord('N'), Gdk.ModifierType.MOD1_MASK, 
                                    Gtk.AccelFlags.VISIBLE)
        self.add_button.set_tooltip_text(_('shortcut_titles')['add'])
        button_box.pack_start(self.add_button, False, False, 0)
        
        self.remove_button = Gtk.Button(label=_('remove_entry'))
        self.remove_button.connect("clicked", self.on_remove_clicked)
        button_box.pack_start(self.remove_button, False, False, 0)
        
        # Agregar todo al contenedor principal
        self.content.pack_start(scroll, True, True, 0)
        self.content.pack_start(button_box, False, False, 0)
    
    def _load_entries(self):
        """Cargar las entradas de arranque en la lista"""
        self.entries_list.clear()
        
        for idx, entry in enumerate(self.grub_config.entries):
            self.entries_list.append([
                idx,  # Índice numérico
                entry["name"],
                entry["type"],
                entry["path"],
                entry["enabled"]
            ])
    
    def on_entry_toggled(self, widget, path):
        """Manejar el evento de habilitar/deshabilitar una entrada"""
        iter = self.entries_list.get_iter(path)
        enabled = not self.entries_list.get_value(iter, 4)
        self.entries_list.set_value(iter, 4, enabled)
        
        # Actualizar la configuración
        entry_name = self.entries_list.get_value(iter, 1)
        for entry in self.grub_config.entries:
            if entry["name"] == entry_name:
                entry["enabled"] = enabled
                break
    
    def on_add_clicked(self, widget):
        """Manejar el evento de añadir una nueva entrada"""
        dialog = Gtk.Dialog(
            title=_('add_entry'),
            transient_for=self.parent,
            flags=0
        )
        dialog.add_buttons(
            _('cancel_button'), Gtk.ResponseType.CANCEL,
            _('ok_button'), Gtk.ResponseType.OK
        )
        
        # Campos del formulario
        grid = Gtk.Grid(row_spacing=6, column_spacing=6)
        grid.set_border_width(10)
        
        name_label = Gtk.Label(label=_('entry_name'))
        self.name_entry = Gtk.Entry()
        grid.attach(name_label, 0, 0, 1, 1)
        grid.attach(self.name_entry, 1, 0, 1, 1)
        
        kernel_label = Gtk.Label(label=_('entry_kernel'))
        self.kernel_entry = Gtk.Entry()
        grid.attach(kernel_label, 0, 1, 1, 1)
        grid.attach(self.kernel_entry, 1, 1, 1, 1)
        
        initrd_label = Gtk.Label(label=_('entry_initrd'))
        self.initrd_entry = Gtk.Entry()
        grid.attach(initrd_label, 0, 2, 1, 1)
        grid.attach(self.initrd_entry, 1, 2, 1, 1)
        
        params_label = Gtk.Label(label=_('entry_params'))
        self.params_entry = Gtk.Entry()
        grid.attach(params_label, 0, 3, 1, 1)
        grid.attach(self.params_entry, 1, 3, 1, 1)
        
        dialog.get_content_area().add(grid)
        dialog.show_all()
        
        response = dialog.run()
        
        if response == Gtk.ResponseType.OK:
            # Añadir la nueva entrada
            name = self.name_entry.get_text()
            kernel = self.kernel_entry.get_text()
            initrd = self.initrd_entry.get_text()
            params = self.params_entry.get_text()
            
            if name and kernel:
                if self.grub_config.add_custom_entry(name, kernel, initrd, params):
                    self._load_entries()
                    self.parent.set_status(_('entry_added'))
                else:
                    self.parent.show_error(_('entry_add_error'))
            else:
                self.parent.show_error(_('entry_name_kernel_required'))
        
        dialog.destroy()
    
    def on_remove_clicked(self, widget):
        """Manejar el evento de eliminar una entrada"""
        selection = self.treeview.get_selection()
        model, iter = selection.get_selected()
        
        if iter:
            entry_name = model.get_value(iter, 1)
            
            if self.grub_config.remove_custom_entry(entry_name):
                self._load_entries()
                self.parent.set_status(_('entry_removed'))
            else:
                self.parent.show_error(_('entry_remove_error'))
        else:
            self.parent.show_error(_('no_entry_selected'))