#!/usr/bin/env python3
"""
Setup script para Soplos GRUB Editor
"""

from setuptools import setup, find_packages
import os

# Leer README para la descripción larga
def read_file(filename):
    with open(os.path.join(os.path.dirname(__file__), filename), 'r', encoding='utf-8') as f:
        return f.read()

setup(
    name='soplos-grub-editor',
    version='1.0.2',
    description='Editor gráfico de GRUB para Soplos Linux',
    long_description=read_file('README.md'),
    long_description_content_type='text/markdown',
    author='Soplos Team',
    author_email='info@soploslinux.com',
    url='https://soploslinux.com',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'PyGObject>=3.36.0',
        'pycairo>=1.16.2',
        'python-xlib>=0.27',
        'polib>=1.1.0',
        'dbus-python>=1.2.16',
        'Pillow>=8.0.0',
    ],
    python_requires='>=3.8',
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Environment :: X11 Applications :: GTK',
        'Intended Audience :: End Users/Desktop',
        'License :: OSI Approved :: GNU General Public License v3 or later (GPLv3+)',
        'Operating System :: POSIX :: Linux',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Topic :: System :: Boot',
        'Topic :: System :: Systems Administration',
        'Topic :: Desktop Environment',
    ],
    entry_points={
        'console_scripts': [
            'soplos-grub-editor=main:main',
        ],
    },
    data_files=[
        ('share/applications', ['assets/com.soplos.grubeditor.desktop']),
        ('share/metainfo', ['debian/com.soplos.grubeditor.metainfo.xml']),
        ('share/icons/hicolor/scalable/apps', ['assets/com.soplos.grubeditor.svg']),
        ('share/soplos-grub-editor', [
            'main.py',
            'app_paths.py',
            'config.py',
        ]),
    ],
)