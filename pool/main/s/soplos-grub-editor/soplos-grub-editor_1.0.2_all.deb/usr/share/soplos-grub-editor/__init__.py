"""
Soplos GRUB Editor - Una herramienta gráfica para editar la configuración de GRUB2
"""

__version__ = '1.0.0'
__author__ = 'Soplos'
__license__ = 'GPL-3.0'