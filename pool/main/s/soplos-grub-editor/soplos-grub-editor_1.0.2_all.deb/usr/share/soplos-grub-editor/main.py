#!/usr/bin/env python3
import os
import sys
import logging
import shutil
import subprocess
from pathlib import Path

# Configurar el logging ANTES de importar GTK
logging.basicConfig(
    level=logging.ERROR,
    format='%(levelname)s: %(message)s'
)

# Función para FORZAR el tema del usuario ANTES de inicializar GTK
def force_user_theme():
    """FORZAR el tema del usuario copiando su configuración a root"""
    try:
        # Obtener datos del usuario original
        user_home = os.environ.get('USER_HOME')
        gtk_theme = os.environ.get('GTK_THEME')
        
        print(f"DEBUG: USER_HOME={user_home}, GTK_THEME={gtk_theme}")
        
        if user_home and gtk_theme:
            # FORZAR configuración GTK para root
            root_gtk3_dir = "/root/.config/gtk-3.0"
            os.makedirs(root_gtk3_dir, exist_ok=True)
            
            # Crear settings.ini para root con el tema del usuario
            settings_content = f"""[Settings]
gtk-theme-name={gtk_theme}
gtk-application-prefer-dark-theme={'true' if 'dark' in gtk_theme.lower() else 'false'}
gtk-icon-theme-name=Adwaita
gtk-font-name=Sans 10
"""
            
            with open(f"{root_gtk3_dir}/settings.ini", 'w') as f:
                f.write(settings_content)
            
            print(f"DEBUG: Configuración GTK de root forzada con tema: {gtk_theme}")
            
            # También copiar configuración KDE si existe
            if os.path.exists(f"{user_home}/.config/kdeglobals"):
                root_config_dir = "/root/.config"
                os.makedirs(root_config_dir, exist_ok=True)
                shutil.copy2(f"{user_home}/.config/kdeglobals", f"{root_config_dir}/kdeglobals")
                print(f"DEBUG: kdeglobals copiado desde usuario")
            
            return True
        
        print("DEBUG: No se pudo forzar tema - faltan variables")
        return False
        
    except Exception as e:
        print(f"DEBUG: Error forzando tema: {e}")
        return False

# FORZAR el tema ANTES de importar GTK
force_user_theme()

# Ahora sí, importar GTK con el tema ya configurado
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Gio

def limpiar_pycache():
    """Limpiar archivos __pycache__"""
    try:
        import shutil
        for root, dirs, files in os.walk('/usr/share/soplos-grub-editor'):
            for dir in dirs:
                if dir == '__pycache__':
                    cache_path = os.path.join(root, dir)
                    shutil.rmtree(cache_path)
                    print(f"DEBUG: Cache limpiado: {cache_path}")
    except Exception as e:
        print(f"DEBUG: Error limpiando cache: {e}")

def restore_root_kde_config():
    """Restaurar configuración original de root"""
    try:
        # Limpiar configuración temporal
        root_gtk3_settings = "/root/.config/gtk-3.0/settings.ini"
        if os.path.exists(root_gtk3_settings):
            os.remove(root_gtk3_settings)
            print("DEBUG: Configuración GTK temporal limpiada")
    except Exception as e:
        print(f"DEBUG: Error limpiando configuración temporal: {e}")

def main():
    """Función principal"""
    try:
        # Verificar permisos
        if os.geteuid() != 0:
            print("Error: Se requieren privilegios de root")
            return 1
        
        # Crear aplicación GTK
        app = Gtk.Application(application_id='com.soplos.grubeditor')
        
        def on_activate(app):
            # Importar la ventana principal
            from ui.main_window import GrubEditorWindow
            
            # Crear y mostrar la ventana
            window = GrubEditorWindow()
            window.set_application(app)
            window.show_all()
        
        app.connect('activate', on_activate)
        return app.run(sys.argv)
        
    except Exception as e:
        print(f"Error fatal: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())