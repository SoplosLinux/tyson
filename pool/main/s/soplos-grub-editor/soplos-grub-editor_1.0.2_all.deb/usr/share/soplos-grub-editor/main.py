#!/usr/bin/env python3
import os
import sys
import subprocess
import logging
import shutil
import atexit

# Importar desde el directorio translations ANTES de configurar logging
from translations.strings import TRANSLATIONS
from app_paths import ICON_PATH, LOGO_PATH

# Obtener el idioma del sistema y configurar traducción ANTES de usar _()
def get_system_language():
    lang = os.environ.get('LANG', 'en_US.UTF-8')
    return lang.split('_')[0]

# Configurar el sistema de traducción ANTES de cualquier uso
LANG = get_system_language()
_ = lambda key: TRANSLATIONS.get(LANG, TRANSLATIONS['en']).get(key, TRANSLATIONS['en'][key])

# Definir las constantes de identificación de manera consistente
APP_ID = "com.soplos.grubeditor"
# Obtener WMCLASS del entorno si está definido (prioridad sobre definición interna)
WMCLASS = os.environ.get('WMCLASS', APP_ID)

# Configurar el registro de errores DESPUÉS de tener traducciones disponibles
logging.basicConfig(
    level=logging.ERROR,
    format='%(levelname)s: %(message)s'
)

def detect_kde_theme():
    """Detectar el tema actual de KDE leyendo kdeglobals"""
    try:
        kde_config_path = os.path.expanduser("~/.config/kdeglobals")
        if not os.path.exists(kde_config_path):
            return None
            
        with open(kde_config_path, 'r') as f:
            content = f.read()
            
        # Buscar la configuración de ColorScheme
        for line in content.split('\n'):
            if line.strip().startswith('ColorScheme='):
                scheme = line.split('=')[1].strip()
                # Mapear esquemas de color de KDE a temas GTK
                if 'dark' in scheme.lower() or 'breeze-dark' in scheme.lower():
                    return 'Breeze-Dark'
                else:
                    return 'Breeze'
        
        # Si no se encuentra ColorScheme, intentar detectar por colores de fondo
        bg_color = None
        for line in content.split('\n'):
            if 'BackgroundNormal=' in line:
                bg_color = line.split('=')[1].strip()
                break
                
        if bg_color:
            # Parsear color RGB y determinar si es claro u oscuro
            try:
                if ',' in bg_color:
                    r, g, b = map(int, bg_color.split(',')[:3])
                    # Calcular luminancia usando la fórmula estándar
                    luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255
                    return 'Breeze-Dark' if luminance < 0.5 else 'Breeze'
            except:
                pass
                
        return 'Breeze'  # Fallback por defecto
    except Exception as e:
        logging.debug(f"Error detectando tema KDE: {e}")
        return None

def detect_gnome_theme():
    """Detectar el tema de GNOME usando gsettings"""
    try:
        result = subprocess.run(['gsettings', 'get', 'org.gnome.desktop.interface', 'gtk-theme'], 
                              capture_output=True, text=True)
        if result.returncode == 0:
            theme = result.stdout.strip().strip("'\"")
            return theme
    except:
        pass
    
    # Fallback: verificar si existe configuración de tema oscuro
    try:
        result = subprocess.run(['gsettings', 'get', 'org.gnome.desktop.interface', 'color-scheme'], 
                              capture_output=True, text=True)
        if result.returncode == 0 and 'dark' in result.stdout.lower():
            return 'Adwaita-dark'
    except:
        pass
    
    return None

def configure_environment():
    """Detecta y configura el entorno para coherencia de tema ANTES de inicializar GTK"""
    wayland_session = os.environ.get('XDG_SESSION_TYPE') == 'wayland'
    kde_desktop = 'kde' in os.environ.get('XDG_CURRENT_DESKTOP', '').lower()
    gnome_desktop = 'gnome' in os.environ.get('XDG_CURRENT_DESKTOP', '').lower()
    
    theme_name = None
    
    if kde_desktop:
        # Detectar tema KDE
        theme_name = detect_kde_theme()
        if theme_name:
            os.environ['GTK_THEME'] = theme_name
            logging.info(f"Aplicado tema GTK desde KDE: {theme_name}")
    
    elif gnome_desktop:
        # Detectar tema GNOME
        theme_name = detect_gnome_theme()
        if theme_name:
            os.environ['GTK_THEME'] = theme_name
            logging.info(f"Aplicado tema GTK desde GNOME: {theme_name}")
    
    # Configuraciones adicionales para Wayland
    if wayland_session:
        os.environ['GTK_USE_PORTAL'] = '1'
        # Forzar tema oscuro si se detecta preferencia del sistema
        if not theme_name:
            # Intentar detectar preferencia de tema oscuro del sistema
            try:
                with open('/proc/cmdline', 'r') as f:
                    cmdline = f.read()
                    if 'quiet splash' in cmdline:
                        # En muchos sistemas, el tema por defecto debería respetarse
                        pass
            except:
                pass

# IMPORTANTE: Configurar el entorno ANTES de importar GTK
configure_environment()

# Configuración para evitar conflictos con módulos estándar de Python
# Eliminar las rutas locales del path para priorizar módulos estándar
std_modules = ['locale', 'gettext']
for module in std_modules:
    if module in sys.modules:
        del sys.modules[module]

# Ahora importar GTK DESPUÉS de configurar el entorno
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GdkPixbuf, GLib, Gio, Gdk

# Variable global para evitar llamadas múltiples - MEJORADA
_app_identity_configured = False

def setup_application_identity():
    """Configurar la identidad de la aplicación una sola vez"""
    global _app_identity_configured
    
    # Verificar si ya se configuró para evitar llamadas múltiples
    if _app_identity_configured:
        return
    
    try:
        # Solo configurar si no se ha hecho antes
        if not GLib.get_prgname():
            GLib.set_prgname(APP_ID)
        
        if not GLib.get_application_name():
            GLib.set_application_name(APP_ID)
        
        # Establecer el icono predeterminado para todas las ventanas
        try:
            Gtk.Window.set_default_icon_name("com.soplos.grubeditor")
        except Exception as e:
            logging.warning(_('icon_set_error').format(e))

        # Configuración para asegurar que GDK use el WMCLASS correcto
        try:
            if hasattr(Gdk, 'set_program_class'):
                Gdk.set_program_class(WMCLASS)
        except Exception as e:
            logging.warning(_('program_class_error').format(e))
        
        _app_identity_configured = True
        
    except Exception as e:
        logging.error(f"Error configurando identidad de aplicación: {e}")

# Importar módulos de la aplicación
from ui.main_window import GrubEditorWindow

def relanzar_como_root():
    """Relanza la aplicación con permisos de root usando pkexec con variables de entorno necesarias."""
    try:
        env = os.environ.copy()
        xdg_runtime_dir = f"/run/user/{os.getuid()}"
        display = env.get('DISPLAY', ':0')
        xauthority = env.get('XAUTHORITY', os.path.expanduser('~/.Xauthority'))
        
        # Preparar variables de entorno para pkexec
        env_vars = [
            f"DISPLAY={display}", 
            f"XAUTHORITY={xauthority}",
            f"XDG_RUNTIME_DIR={xdg_runtime_dir}",
            f"WMCLASS={APP_ID}",
            "HOME=/root"
        ]
        
        # Añadir variables de tema si están configuradas
        if 'GTK_THEME' in env:
            env_vars.append(f"GTK_THEME={env['GTK_THEME']}")
        if 'GTK_USE_PORTAL' in env:
            env_vars.append(f"GTK_USE_PORTAL={env['GTK_USE_PORTAL']}")
        
        # Detectar tipo de sesión para transmitir
        session_type = env.get('XDG_SESSION_TYPE', '')
        current_desktop = env.get('XDG_CURRENT_DESKTOP', '')
        
        if session_type:
            env_vars.append(f"XDG_SESSION_TYPE={session_type}")
        if current_desktop:
            env_vars.append(f"XDG_CURRENT_DESKTOP={current_desktop}")
        
        cmd = ['pkexec', '--disable-internal-agent', 'env'] + env_vars + [
            sys.executable,
            sys.argv[0]
        ]
        
        subprocess.run(cmd, check=True)
        sys.exit(0)
    except subprocess.CalledProcessError:
        logging.error(_('pkexec_error'))
        sys.exit(1)
    except Exception as e:
        logging.error(_('relaunch_error').format(str(e)))
        sys.exit(1)

def limpiar_pycache():
    """Limpia todos los directorios __pycache__ en el proyecto."""
    try:
        # Obtener el directorio base actual del script
        if hasattr(sys, '_MEIPASS'):
            # Si está ejecutándose desde un ejecutable empaquetado
            directorio_base = sys._MEIPASS
        else:
            # Usar el directorio donde está ubicado este script
            directorio_base = os.path.dirname(os.path.abspath(__file__))
        
        # También limpiar en las ubicaciones de instalación comunes
        rutas_a_limpiar = [
            directorio_base,
            '/usr/local/bin/Tyson/soplos-grub-editor',
            '/usr/share/soplos-grub-editor',
            '/opt/soplos-grub-editor'
        ]
        
        for base_path in rutas_a_limpiar:
            if os.path.exists(base_path):
                for raiz, dirs, archivos in os.walk(base_path):
                    if '__pycache__' in dirs:
                        ruta_cache = os.path.join(raiz, '__pycache__')
                        try:
                            shutil.rmtree(ruta_cache)
                            logging.info(_('directory_cleaned').format(ruta_cache))
                        except Exception as e:
                            logging.error(_('directory_clean_error').format(ruta_cache, str(e)))
                            
    except Exception as e:
        logging.error(_('directory_clean_error').format('__pycache__', str(e)))

def main():
    """Función principal de la aplicación."""
    # Registrar la función de limpieza para que se ejecute al salir
    atexit.register(limpiar_pycache)
    
    # Verificar si se está ejecutando como root
    if os.geteuid() != 0:
        # Ya se configuró el entorno al inicio del archivo
        relanzar_como_root()
        return
    
    # Si ya somos root, configurar identidad de la aplicación ANTES de crear la aplicación GTK
    setup_application_identity()
        
    # Ignorar mensajes de advertencia del bus de accesibilidad
    os.environ['NO_AT_BRIDGE'] = '1'
    
    # Crear aplicación GTK con el ID específico
    app = Gtk.Application(
        application_id=APP_ID,
        flags=Gio.ApplicationFlags.FLAGS_NONE
    )

    def on_activate(app):
        # Aplicar configuraciones adicionales de tema después de que GTK esté inicializado
        settings = Gtk.Settings.get_default()
        if 'GTK_THEME' in os.environ:
            settings.set_property('gtk-theme-name', os.environ['GTK_THEME'])
            logging.info(f"Tema GTK configurado: {os.environ['GTK_THEME']}")
        
        win = GrubEditorWindow()
        app.add_window(win)
        
        # Conectar la función de limpieza al cierre de ventana
        win.connect('destroy', lambda w: limpiar_pycache())
        
        # Reemplazar el uso de set_wmclass (obsoleto) con una propiedad moderna
        # La propiedad role es más moderna que set_wmclass
        win.set_role(WMCLASS)
        
        # Establecer el icono del programa para el sistema - orden de prioridad:
        # 1. Por nombre (com.soplos.grubeditor)
        # 2. Por ruta absoluta en sistema (/usr/share/icons/...)
        # 3. Por ruta relativa (assets/icons/...)
        try:
            icon_theme = Gtk.IconTheme.get_default()
            try:
                icon = icon_theme.load_icon("com.soplos.grubeditor", 128, 0)
                win.set_icon(icon)
            except:
                # Fallback a la ruta absoluta si falla la carga por nombre
                icon_path = "/usr/share/icons/hicolor/128x128/apps/com.soplos.grubeditor.png"
                if os.path.exists(icon_path):
                    win.set_icon_from_file(icon_path)
                elif os.path.exists(ICON_PATH):
                    win.set_icon_from_file(ICON_PATH)
        except Exception as e:
            logging.error(f"Error al establecer icono: {e}")
        
        # Forzar actualización de propiedades de ventana antes de mostrar
        win.realize()
        
        # Ahora mostrar la ventana
        win.show_all()

    def on_shutdown(app):
        """Función que se ejecuta al cerrar la aplicación"""
        limpiar_pycache()

    app.connect('activate', on_activate)
    app.connect('shutdown', on_shutdown)
    
    try:
        return app.run(None)
    finally:
        # Asegurar que se limpie incluso si hay error
        limpiar_pycache()

if __name__ == "__main__":
    sys.exit(main())