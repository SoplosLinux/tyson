#!/usr/bin/env python3
import os
import sys
import subprocess
import logging
import shutil
import atexit
import gi

# Importar desde el directorio translations ANTES de configurar logging
from translations.strings import TRANSLATIONS
from app_paths import ICON_PATH, LOGO_PATH

# Obtener el idioma del sistema y configurar traducción ANTES de usar _()
def get_system_language():
    lang = os.environ.get('LANG', 'en_US.UTF-8')
    return lang.split('_')[0]

# Configurar el sistema de traducción ANTES de cualquier uso
LANG = get_system_language()
_ = lambda key: TRANSLATIONS.get(LANG, TRANSLATIONS['en']).get(key, TRANSLATIONS['en'][key])

# Definir las constantes de identificación de manera consistente
APP_ID = "com.soplos.grubeditor"
# Obtener WMCLASS del entorno si está definido (prioridad sobre definición interna)
WMCLASS = os.environ.get('WMCLASS', APP_ID)

# Configurar el registro de errores DESPUÉS de tener traducciones disponibles
logging.basicConfig(
    level=logging.ERROR,
    format='%(levelname)s: %(message)s'
)

# Configuración para evitar conflictos con módulos estándar de Python
# Eliminar las rutas locales del path para priorizar módulos estándar
std_modules = ['locale', 'gettext']
for module in std_modules:
    if module in sys.modules:
        del sys.modules[module]

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GdkPixbuf, GLib, Gio, Gdk

# Variable global para evitar llamadas múltiples - MEJORADA
_app_identity_configured = False

def setup_application_identity():
    """Configurar la identidad de la aplicación una sola vez"""
    global _app_identity_configured
    
    # Verificar si ya se configuró para evitar llamadas múltiples
    if _app_identity_configured:
        return
    
    try:
        # Solo configurar si no se ha hecho antes
        if not GLib.get_prgname():
            GLib.set_prgname(APP_ID)
        
        if not GLib.get_application_name():
            GLib.set_application_name(APP_ID)
        
        # Establecer el icono predeterminado para todas las ventanas
        try:
            Gtk.Window.set_default_icon_name("com.soplos.grubeditor")
        except Exception as e:
            logging.warning(_('icon_set_error').format(e))

        # Configuración para asegurar que GDK use el WMCLASS correcto
        try:
            if hasattr(Gdk, 'set_program_class'):
                Gdk.set_program_class(WMCLASS)
        except Exception as e:
            logging.warning(_('program_class_error').format(e))
        
        _app_identity_configured = True
        
    except Exception as e:
        logging.error(f"Error configurando identidad de aplicación: {e}")

# Importar módulos de la aplicación
from ui.main_window import GrubEditorWindow

def relanzar_como_root():
    """Relanza la aplicación con permisos de root usando pkexec con variables de entorno necesarias."""
    try:
        # Detectar y configurar tema ANTES del relanzamiento
        configure_environment()
        
        env = os.environ.copy()
        xdg_runtime_dir = f"/run/user/{os.getuid()}"
        display = env.get('DISPLAY', ':0')
        xauthority = env.get('XAUTHORITY', os.path.expanduser('~/.Xauthority'))
        
        # Preparar variables de entorno para pkexec
        env_vars = [
            f"DISPLAY={display}", 
            f"XAUTHORITY={xauthority}",
            f"XDG_RUNTIME_DIR={xdg_runtime_dir}",
            f"WMCLASS={APP_ID}",
            "HOME=/root"
        ]
        
        # Añadir variables de tema si están configuradas
        if 'GTK_THEME' in env:
            env_vars.append(f"GTK_THEME={env['GTK_THEME']}")
        if 'GTK_USE_PORTAL' in env:
            env_vars.append(f"GTK_USE_PORTAL={env['GTK_USE_PORTAL']}")
        
        # Detectar tipo de sesión para transmitir
        session_type = env.get('XDG_SESSION_TYPE', '')
        current_desktop = env.get('XDG_CURRENT_DESKTOP', '')
        
        if session_type:
            env_vars.append(f"XDG_SESSION_TYPE={session_type}")
        if current_desktop:
            env_vars.append(f"XDG_CURRENT_DESKTOP={current_desktop}")
        
        cmd = ['pkexec', '--disable-internal-agent', 'env'] + env_vars + [
            sys.executable,
            sys.argv[0]
        ]
        
        subprocess.run(cmd, check=True)
        sys.exit(0)
    except subprocess.CalledProcessError:
        logging.error(_('pkexec_error'))
        sys.exit(1)
    except Exception as e:
        logging.error(_('relaunch_error').format(str(e)))
        sys.exit(1)

def limpiar_pycache():
    """Limpia todos los directorios __pycache__ en el proyecto."""
    try:
        # Usar una ruta absoluta en lugar de __file__
        directorio_base = '/usr/local/bin/soplos-grub-editor'
        
        for raiz, dirs, archivos in os.walk(directorio_base):
            if '__pycache__' in dirs:
                ruta_cache = os.path.join(raiz, '__pycache__')
                try:
                    shutil.rmtree(ruta_cache)
                    logging.info(_('directory_cleaned').format(ruta_cache))
                except Exception as e:
                    logging.error(_('directory_clean_error').format(ruta_cache, str(e)))
    except Exception as e:
        logging.error(_('directory_clean_error').format('__pycache__', str(e)))

def detect_kde_theme():
    """Detectar el tema actual de KDE leyendo kdeglobals"""
    try:
        kde_config_path = os.path.expanduser("~/.config/kdeglobals")
        if not os.path.exists(kde_config_path):
            return None
            
        with open(kde_config_path, 'r') as f:
            content = f.read()
            
        # Buscar la configuración de ColorScheme
        for line in content.split('\n'):
            if line.strip().startswith('ColorScheme='):
                scheme = line.split('=')[1].strip()
                # Mapear esquemas de color de KDE a temas GTK
                if 'dark' in scheme.lower() or 'breeze-dark' in scheme.lower():
                    return 'Breeze-Dark'
                else:
                    return 'Breeze'
        
        # Si no se encuentra ColorScheme, intentar detectar por colores de fondo
        bg_color = None
        for line in content.split('\n'):
            if 'BackgroundNormal=' in line:
                bg_color = line.split('=')[1].strip()
                break
                
        if bg_color:
            # Parsear color RGB y determinar si es claro u oscuro
            try:
                if ',' in bg_color:
                    r, g, b = map(int, bg_color.split(',')[:3])
                    # Calcular luminancia usando la fórmula estándar
                    luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255
                    return 'Breeze-Dark' if luminance < 0.5 else 'Breeze'
            except:
                pass
                
        return 'Breeze'  # Fallback por defecto
    except Exception as e:
        logging.debug(f"Error detectando tema KDE: {e}")
        return None

def configure_environment():
    """Detecta y configura el entorno para coherencia de tema en Wayland/X11"""
    wayland_session = os.environ.get('XDG_SESSION_TYPE') == 'wayland'
    kde_desktop = 'kde' in os.environ.get('XDG_CURRENT_DESKTOP', '').lower()
    
    if wayland_session and kde_desktop:
        # En Wayland con KDE, aplicar configuración específica
        theme_name = detect_kde_theme()
        if theme_name:
            os.environ['GTK_THEME'] = theme_name
            logging.info(f"Aplicado tema GTK: {theme_name} para sesión Wayland+KDE")
        
        # Configurar portal para mejor integración
        os.environ['GTK_USE_PORTAL'] = '1'
        
    elif kde_desktop:
        # En X11 con KDE, aplicar tema si está disponible
        theme_name = detect_kde_theme()
        if theme_name:
            os.environ['GTK_THEME'] = theme_name
            logging.info(f"Aplicado tema GTK: {theme_name} para sesión KDE")

def main():
    """Función principal de la aplicación."""
    # Verificar si se está ejecutando como root
    if os.geteuid() != 0:
        # Configurar entorno ANTES de relanzar como root
        relanzar_como_root()  # Ahora configure_environment() se llama dentro
        return
    
    # Si ya somos root, aplicar configuración de entorno ANTES de GTK
    configure_environment()
    
    # Configurar identidad de la aplicación ANTES de crear la aplicación GTK
    setup_application_identity()
        
    # Ignorar mensajes de advertencia del bus de accesibilidad
    os.environ['NO_AT_BRIDGE'] = '1'
    
    # Crear aplicación GTK con el ID específico
    app = Gtk.Application(
        application_id=APP_ID,
        flags=Gio.ApplicationFlags.FLAGS_NONE
    )

    def on_activate(app):
        win = GrubEditorWindow()
        app.add_window(win)
        
        # Reemplazar el uso de set_wmclass (obsoleto) con una propiedad moderna
        # La propiedad role es más moderna que set_wmclass
        win.set_role(WMCLASS)
        
        # Establecer el icono del programa para el sistema - orden de prioridad:
        # 1. Por nombre (com.soplos.grubeditor)
        # 2. Por ruta absoluta en sistema (/usr/share/icons/...)
        # 3. Por ruta relativa (assets/icons/...)
        try:
            icon_theme = Gtk.IconTheme.get_default()
            try:
                icon = icon_theme.load_icon("com.soplos.grubeditor", 128, 0)
                win.set_icon(icon)
            except:
                # Fallback a la ruta absoluta si falla la carga por nombre
                icon_path = "/usr/share/icons/hicolor/128x128/apps/com.soplos.grubeditor.png"
                if os.path.exists(icon_path):
                    win.set_icon_from_file(icon_path)
                elif os.path.exists(ICON_PATH):
                    win.set_icon_from_file(ICON_PATH)
        except Exception as e:
            logging.error(f"Error al establecer icono: {e}")
        
        # Forzar actualización de propiedades de ventana antes de mostrar
        win.realize()
        
        # Ahora mostrar la ventana
        win.show_all()

    app.connect('activate', on_activate)
    return app.run(None)

if __name__ == "__main__":
    sys.exit(main())