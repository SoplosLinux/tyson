"""
Módulo de traducciones para Soplos GRUB Editor
"""

TRANSLATIONS = {
    'es': {
        # Títulos y encabezados
        'app_name': 'Soplos GRUB Editor',
        'general_tab': 'Configuración general',
        'entries_tab': 'Entradas de arranque',
        'appearance_tab': 'Apariencia',
        
        # Botones comunes
        'save_button': 'Guardar',
        'apply_button': 'Aplicar',
        'close_button': 'Cerrar',
        'cancel_button': 'Cancelar',
        'ok_button': 'Aceptar',
        
        # Títulos de diálogos
        'error_title': 'Error',
        'info_title': 'Información',
        'warning_title': 'Advertencia',
        'confirm_title': 'Confirmar',
        'question_title': 'Pregunta',
        
        # Mensajes generales
        'changes_saved': 'Cambios guardados correctamente',
        'changes_error': 'Error al guardar los cambios',
        'need_root': 'Se requieren privilegios de administrador',
        'confirm_exit': '¿Está seguro de que desea salir?',
        'unsaved_changes': 'Los cambios no guardados se perderán.',
        
        # Pestañas específicas
        ## General
        'timeout_label': 'Tiempo de espera (segundos):',
        'default_entry_label': 'Entrada predeterminada:',
        'resolution_label': 'Resolución de pantalla:',
        'kernel_params_label': 'Parámetros del kernel:',
        'os_prober_label': 'Detectar otros sistemas operativos',
        'show_menu_label': 'Mostrar menú de arranque',
        'recovery_label': 'Incluir opciones de recuperación',
        
        ## Apariencia
        'theme_section': 'Tema',
        'font_section': 'Fuentes',
        'colors_section': 'Colores',
        'background_section': 'Fondo',
        'preview_label': 'Vista previa',
        'install_theme': 'Instalar tema...',
        'remove_theme': 'Eliminar tema',
        'disable_theme': 'Desactivar tema',
        'select_font': 'Seleccionar fuente...',
        'remove_font': 'Eliminar fuente',
        'font_size': 'Tamaño de fuente:',
        'text_color': 'Color del texto:',
        'background_color': 'Color del fondo:',
        'select_background': 'Seleccionar fondo...',
        'remove_background': 'Quitar fondo',
        'highlight_text_color': 'Color del texto resaltado:',
        'highlight_background_color': 'Color del fondo resaltado:',
        'apply_theme_button': 'Aplicar tema',
        
        ## Entradas
        'add_entry': 'Añadir entrada',
        'edit_entry': 'Editar entrada',
        'remove_entry': 'Eliminar entrada',
        'entry_name': 'Nombre:',
        'entry_type': 'Tipo:',
        'entry_kernel': 'Kernel:',
        'entry_initrd': 'Initrd:',
        'entry_params': 'Parámetros:',
        
        # Mensajes de estado
        'ready': 'Listo',
        'saving': 'Guardando...',
        'applying': 'Aplicando cambios...',
        'loading': 'Cargando...',
        'updating': 'Actualizando GRUB...',
        
        # Mensajes de error
        'error_save': 'Error al guardar la configuración',
        'error_load': 'Error al cargar la configuración',
        'error_apply': 'Error al aplicar los cambios',
        'error_update': 'Error al actualizar GRUB',
        'error_permission': 'Error de permisos',
        'error_missing_deps': 'Faltan dependencias requeridas',
        
        # Nuevas claves
        'advanced_options': 'Opciones avanzadas',
        'kernel_params_section': 'Parámetros del kernel',
        'grub_updated': 'GRUB actualizado correctamente',
        
        # Diálogos específicos
        'select_font_dialog': 'Seleccionar fuente',
        'select_theme_dialog': 'Seleccionar tema',
        'select_background_dialog': 'Seleccionar imagen de fondo',
        'font_filter': 'Fuentes',
        'theme_filter': 'Archivos de tema',
        'image_filter': 'Imágenes',
        'all_files': 'Todos los archivos',
        
        # Textos de resolución
        'resolution_disabled': 'Desactivado',
        'resolution_auto': 'Automático',
        
        # Textos de entradas
        'default_entry_saved': 'Última selección',
        'entry_path': 'Ruta',
        'entry_enabled': 'Habilitado',
        
        # Advertencias y confirmaciones
        'delete_font_confirm': '¿Está seguro de que desea eliminar esta fuente?',
        'delete_font_warning': 'Se eliminará el archivo: {}\nEsta acción no se puede deshacer.',
        'apply_font_confirm': '¿Desea aplicar esta fuente?',
        'apply_font_message': 'Se aplicará la fuente: {}',
        'remove_theme_confirm': '¿Eliminar el tema \'{}\'?',
        'disable_theme_confirm': '¿Desea quitar el tema actual?',
        'disable_theme_message': 'El tema se deshabilitará pero no se eliminará del sistema',
        'update_grub_title': 'Actualizar GRUB',
        'update_grub_message': 'Se ejecutará update-grub para aplicar los cambios.',
        
        # Mensajes de éxito
        'font_installed': 'Fuente instalada correctamente en: {}',
        'font_removed': 'Fuente eliminada correctamente',
        'theme_installed': 'Tema instalado correctamente',
        'theme_applied': 'Tema aplicado correctamente',
        'background_applied': 'Fondo de pantalla configurado correctamente',
        'background_removed': 'Fondo de pantalla eliminado correctamente',
        'entry_added': 'Entrada añadida correctamente',
        'entry_removed': 'Entrada eliminada correctamente',
        
        # Mensajes de error
        'invalid_font': 'Por favor seleccione un archivo de fuente válido',
        'font_error': 'Error al instalar la fuente: {}',
        'theme_error': 'Error al instalar el tema: {}',
        'background_error': 'Error al cargar la imagen: {}',
        'entry_error': 'Error al añadir la entrada: {}',
        'no_font_installed': 'No hay fuentes instaladas en GRUB',
        
        # Atajos de teclado
        'shortcut_save': 'Ctrl+S',
        'shortcut_apply': 'Alt+A',
        'shortcut_close': 'Alt+C',
        
        # Textos de ayuda
        'font_help': 'Este método evita los problemas con update-grub modificando directamente la configuración.',
        'font_select_help': 'Seleccione un archivo de fuente TTF o OTF',
        'browse_button': 'Examinar...',
        'install_font_button': 'Instalar Fuente',
        'apply_font_button': 'Aplicar Fuente Seleccionada',
        'remove_font_button': 'Eliminar Fuente Seleccionada',
        'delete_font_file_button': 'Eliminar Archivo',
        
        # Atajos de teclado adicionales
        'keyboard_shortcuts': 'Atajos de teclado',
        'shortcut_titles': {
            'save': 'Guardar (Ctrl+S)',
            'apply': 'Aplicar (Alt+A)', 
            'close': 'Cerrar (Alt+C)',
            'browse': 'Examinar (Alt+B)',
            'install': 'Instalar (Alt+I)',
            'remove': 'Eliminar (Alt+R)',
            'delete': 'Eliminar (Supr)',
            'add': 'Añadir (Alt+N)',
            'edit': 'Editar (Alt+E)'
        }
    },
    'en': {
        # Titles and headers
        'app_name': 'Soplos GRUB Editor',
        'general_tab': 'General Settings',
        'entries_tab': 'Boot Entries',
        'appearance_tab': 'Appearance',
        
        # Common buttons
        'save_button': 'Save',
        'apply_button': 'Apply',
        'close_button': 'Close',
        'cancel_button': 'Cancel',
        'ok_button': 'OK',
        
        # Dialog titles
        'error_title': 'Error',
        'info_title': 'Information',
        'warning_title': 'Warning',
        'confirm_title': 'Confirm',
        'question_title': 'Question',
        
        # General messages
        'changes_saved': 'Changes saved successfully',
        'changes_error': 'Error saving changes',
        'need_root': 'Administrator privileges required',
        'confirm_exit': 'Are you sure you want to exit?',
        'unsaved_changes': 'Unsaved changes will be lost.',
        
        # Specific tabs
        ## General
        'timeout_label': 'Timeout (seconds):',
        'default_entry_label': 'Default entry:',
        'resolution_label': 'Screen resolution:',
        'kernel_params_label': 'Kernel parameters:',
        'os_prober_label': 'Detect other operating systems',
        'show_menu_label': 'Show boot menu',
        'recovery_label': 'Include recovery options',
        
        ## Appearance
        'theme_section': 'Theme',
        'font_section': 'Fonts',
        'colors_section': 'Colors',
        'background_section': 'Background',
        'preview_label': 'Preview',
        'install_theme': 'Install theme...',
        'remove_theme': 'Remove theme',
        'disable_theme': 'Disable theme',
        'select_font': 'Select font...',
        'remove_font': 'Remove font',
        'font_size': 'Font size:',
        'text_color': 'Text color:',
        'background_color': 'Background color:',
        'select_background': 'Select background...',
        'remove_background': 'Remove background',
        'highlight_text_color': 'Highlight text color:',
        'highlight_background_color': 'Highlight background color:',
        'apply_theme_button': 'Apply theme',
        
        ## Entries
        'add_entry': 'Add entry',
        'edit_entry': 'Edit entry',
        'remove_entry': 'Remove entry',
        'entry_name': 'Name:',
        'entry_type': 'Type:',
        'entry_kernel': 'Kernel:',
        'entry_initrd': 'Initrd:',
        'entry_params': 'Parameters:',
        
        # Status messages
        'ready': 'Ready',
        'saving': 'Saving...',
        'applying': 'Applying changes...',
        'loading': 'Loading...',
        'updating': 'Updating GRUB...',
        
        # Error messages
        'error_save': 'Error saving configuration',
        'error_load': 'Error loading configuration',
        'error_apply': 'Error applying changes',
        'error_update': 'Error updating GRUB',
        'error_permission': 'Permission error',
        'error_missing_deps': 'Missing required dependencies',
        
        # New keys
        'advanced_options': 'Advanced Options',
        'kernel_params_section': 'Kernel Parameters',
        'grub_updated': 'GRUB successfully updated',
        
        # Specific dialogs
        'select_font_dialog': 'Select Font',
        'select_theme_dialog': 'Select Theme',
        'select_background_dialog': 'Select Background Image',
        'font_filter': 'Fonts',
        'theme_filter': 'Theme Files',
        'image_filter': 'Images',
        'all_files': 'All Files',
        
        # Resolution texts
        'resolution_disabled': 'Disabled',
        'resolution_auto': 'Automatic',
        
        # Entry texts
        'default_entry_saved': 'Last Selection',
        'entry_path': 'Path',
        'entry_enabled': 'Enabled',
        
        # Warnings and confirmations
        'delete_font_confirm': 'Are you sure you want to delete this font?',
        'delete_font_warning': 'The file will be deleted: {}\nThis action cannot be undone.',
        'apply_font_confirm': 'Do you want to apply this font?',
        'apply_font_message': 'The font will be applied: {}',
        'remove_theme_confirm': 'Remove the theme \'{}\'?',
        'disable_theme_confirm': 'Do you want to remove the current theme?',
        'disable_theme_message': 'The theme will be disabled but not removed from the system',
        'update_grub_title': 'Update GRUB',
        'update_grub_message': 'update-grub will be executed to apply the changes.',
        
        # Success messages
        'font_installed': 'Font installed successfully at: {}',
        'font_removed': 'Font removed successfully',
        'theme_installed': 'Theme installed successfully',
        'theme_applied': 'Theme applied successfully',
        'background_applied': 'Background set successfully',
        'background_removed': 'Background removed successfully',
        'entry_added': 'Entry added successfully',
        'entry_removed': 'Entry removed successfully',
        
        # Error messages
        'invalid_font': 'Please select a valid font file',
        'font_error': 'Error installing the font: {}',
        'theme_error': 'Error installing the theme: {}',
        'background_error': 'Error loading the image: {}',
        'entry_error': 'Error adding the entry: {}',
        'no_font_installed': 'No fonts installed in GRUB',
        
        # Keyboard shortcuts
        'shortcut_save': 'Ctrl+S',
        'shortcut_apply': 'Alt+A',
        'shortcut_close': 'Alt+C',
        
        # Help texts
        'font_help': 'This method avoids issues with update-grub by directly modifying the configuration.',
        'font_select_help': 'Select a TTF or OTF font file',
        'browse_button': 'Browse...',
        'install_font_button': 'Install Font',
        'apply_font_button': 'Apply Selected Font',
        'remove_font_button': 'Remove Selected Font',
        'delete_font_file_button': 'Delete File',
        
        # Additional keyboard shortcuts
        'keyboard_shortcuts': 'Keyboard Shortcuts', 
        'shortcut_titles': {
            'save': 'Save (Ctrl+S)',
            'apply': 'Apply (Alt+A)',
            'close': 'Close (Alt+C)', 
            'browse': 'Browse (Alt+B)',
            'install': 'Install (Alt+I)',
            'remove': 'Remove (Alt+R)',
            'delete': 'Delete (Del)',
            'add': 'Add (Alt+N)',
            'edit': 'Edit (Alt+E)'
        }
    },
    'fr': {
        # Titres et en-têtes
        'app_name': 'Soplos GRUB Editor',
        'general_tab': 'Configuration générale',
        'entries_tab': 'Entrées de démarrage',
        'appearance_tab': 'Apparence',
        
        # Boutons communs
        'save_button': 'Enregistrer',
        'apply_button': 'Appliquer',
        'close_button': 'Fermer',
        'cancel_button': 'Annuler',
        'ok_button': 'OK',
        
        # Titres des dialogues
        'error_title': 'Erreur',
        'info_title': 'Information',
        'warning_title': 'Avertissement',
        'confirm_title': 'Confirmer',
        'question_title': 'Question',
        
        # Messages généraux
        'changes_saved': 'Modifications enregistrées avec succès',
        'changes_error': 'Erreur lors de l\'enregistrement',
        'need_root': 'Privilèges administrateur requis',
        'confirm_exit': 'Voulez-vous vraiment quitter ?',
        'unsaved_changes': 'Les modifications non sauvegardées seront perdues.',
        
        # Pestañas específicas
        ## General
        'timeout_label': 'Délai d\'attente (secondes) :',
        'default_entry_label': 'Entrée par défaut :',
        'resolution_label': 'Résolution de l\'écran :',
        'kernel_params_label': 'Paramètres du noyau :',
        'os_prober_label': 'Détecter d\'autres systèmes d\'exploitation',
        'show_menu_label': 'Afficher le menu de démarrage',
        'recovery_label': 'Inclure les options de récupération',
        
        ## Apariencia
        'theme_section': 'Thème',
        'font_section': 'Polices',
        'colors_section': 'Couleurs',
        'background_section': 'Arrière-plan',
        'preview_label': 'Aperçu',
        'install_theme': 'Installer le thème...',
        'remove_theme': 'Supprimer le thème',
        'disable_theme': 'Désactiver le thème',
        'select_font': 'Sélectionner la police...',
        'remove_font': 'Supprimer la police',
        'font_size': 'Taille de la police :',
        'text_color': 'Couleur du texte :',
        'background_color': 'Couleur de l\'arrière-plan :',
        'select_background': 'Sélectionner l\'arrière-plan...',
        'remove_background': 'Supprimer l\'arrière-plan',
        'highlight_text_color': 'Couleur du texte en surbrillance :',
        'highlight_background_color': 'Couleur de l\'arrière-plan en surbrillance :',
        'apply_theme_button': 'Appliquer le thème',
        
        ## Entradas
        'add_entry': 'Ajouter une entrée',
        'edit_entry': 'Modifier l\'entrée',
        'remove_entry': 'Supprimer l\'entrée',
        'entry_name': 'Nom :',
        'entry_type': 'Type :',
        'entry_kernel': 'Noyau :',
        'entry_initrd': 'Initrd :',
        'entry_params': 'Paramètres :',
        
        # Mensajes de estado
        'ready': 'Prêt',
        'saving': 'Enregistrement...',
        'applying': 'Application des modifications...',
        'loading': 'Chargement...',
        'updating': 'Mise à jour de GRUB...',
        
        # Mensajes de error
        'error_save': 'Erreur lors de l\'enregistrement de la configuration',
        'error_load': 'Erreur lors du chargement de la configuration',
        'error_apply': 'Erreur lors de l\'application des modifications',
        'error_update': 'Erreur lors de la mise à jour de GRUB',
        'error_permission': 'Erreur de permission',
        'error_missing_deps': 'Dépendances requises manquantes',
        
        # Nouvelles clés
        'advanced_options': 'Options avancées',
        'kernel_params_section': 'Paramètres du noyau',
        'grub_updated': 'GRUB mis à jour avec succès',
        
        # Dialogues spécifiques
        'select_font_dialog': 'Sélectionner la police',
        'select_theme_dialog': 'Sélectionner le thème',
        'select_background_dialog': 'Sélectionner l\'image de fond',
        'font_filter': 'Polices',
        'theme_filter': 'Fichiers de thème',
        'image_filter': 'Images',
        'all_files': 'Tous les fichiers',
        
        # Textes de résolution
        'resolution_disabled': 'Désactivé',
        'resolution_auto': 'Automatique',
        
        # Textes des entrées
        'default_entry_saved': 'Dernière sélection',
        'entry_path': 'Chemin',
        'entry_enabled': 'Activé',
        
        # Avertissements et confirmations
        'delete_font_confirm': 'Êtes-vous sûr de vouloir supprimer cette police ?',
        'delete_font_warning': 'Le fichier sera supprimé : {}\nCette action ne peut pas être annulée.',
        'apply_font_confirm': 'Voulez-vous appliquer cette police ?',
        'apply_font_message': 'La police sera appliquée : {}',
        'remove_theme_confirm': 'Supprimer le thème \'{}\' ?',
        'disable_theme_confirm': 'Voulez-vous supprimer le thème actuel ?',
        'disable_theme_message': 'Le thème sera désactivé mais ne sera pas supprimé du système',
        'update_grub_title': 'Mettre à jour GRUB',
        'update_grub_message': 'update-grub sera exécuté pour appliquer les modifications.',
        
        # Messages de succès
        'font_installed': 'Police installée avec succès à : {}',
        'font_removed': 'Police supprimée avec succès',
        'theme_installed': 'Thème installé avec succès',
        'theme_applied': 'Thème appliqué avec succès',
        'background_applied': 'Fond d\'écran configuré avec succès',
        'background_removed': 'Fond d\'écran supprimé avec succès',
        'entry_added': 'Entrée ajoutée avec succès',
        'entry_removed': 'Entrée supprimée avec succès',
        
        # Messages d\'erreur
        'invalid_font': 'Veuillez sélectionner un fichier de police valide',
        'font_error': 'Erreur lors de l\'installation de la police : {}',
        'theme_error': 'Erreur lors de l\'installation du thème : {}',
        'background_error': 'Erreur lors du chargement de l\'image : {}',
        'entry_error': 'Erreur lors de l\'ajout de l\'entrée : {}',
        'no_font_installed': 'Aucune police installée dans GRUB',
        
        # Raccourcis clavier
        'shortcut_save': 'Ctrl+S',
        'shortcut_apply': 'Alt+A',
        'shortcut_close': 'Alt+C',
        
        # Textes d\'aide
        'font_help': 'Cette méthode évite les problèmes avec update-grub en modifiant directement la configuration.',
        'font_select_help': 'Sélectionnez un fichier de police TTF ou OTF',
        'browse_button': 'Parcourir...',
        'install_font_button': 'Installer la police',
        'apply_font_button': 'Appliquer la police sélectionnée',
        'remove_font_button': 'Supprimer la police sélectionnée',
        'delete_font_file_button': 'Supprimer le fichier',
        
        # Raccourcis clavier supplémentaires
        'keyboard_shortcuts': 'Raccourcis clavier',
        'shortcut_titles': {
            'save': 'Enregistrer (Ctrl+S)',
            'apply': 'Appliquer (Alt+A)',
            'close': 'Fermer (Alt+C)',
            'browse': 'Parcourir (Alt+B)', 
            'install': 'Installer (Alt+I)',
            'remove': 'Supprimer (Alt+R)',
            'delete': 'Supprimer (Suppr)',
            'add': 'Ajouter (Alt+N)',
            'edit': 'Modifier (Alt+E)'
        }
    },
    'de': {
        # Titel und Überschriften
        'app_name': 'Soplos GRUB Editor',
        'general_tab': 'Allgemeine Einstellungen',
        'entries_tab': 'Boot-Einträge',
        'appearance_tab': 'Aussehen',
        
        # Gemeinsame Schaltflächen
        'save_button': 'Speichern',
        'apply_button': 'Anwenden',
        'close_button': 'Schließen',
        'cancel_button': 'Abbrechen',
        'ok_button': 'OK',
        
        # Dialogtitel
        'error_title': 'Fehler',
        'info_title': 'Information',
        'warning_title': 'Warnung',
        'confirm_title': 'Bestätigen',
        'question_title': 'Frage',
        
        # Allgemeine Nachrichten
        'changes_saved': 'Änderungen erfolgreich gespeichert',
        'changes_error': 'Fehler beim Speichern der Änderungen',
        'need_root': 'Administratorrechte erforderlich',
        'confirm_exit': 'Möchten Sie wirklich beenden?',
        'unsaved_changes': 'Nicht gespeicherte Änderungen gehen verloren.',
        
        # Spezifische Registerkarten
        ## Allgemein
        'timeout_label': 'Timeout (Sekunden):',
        'default_entry_label': 'Standard-Eintrag:',
        'resolution_label': 'Bildschirmauflösung:',
        'kernel_params_label': 'Kernel-Parameter:',
        'os_prober_label': 'Andere Betriebssysteme erkennen',
        'show_menu_label': 'Boot-Menü anzeigen',
        'recovery_label': 'Wiederherstellungsoptionen einbeziehen',
        
        ## Aussehen
        'theme_section': 'Thema',
        'font_section': 'Schriftarten',
        'colors_section': 'Farben',
        'background_section': 'Hintergrund',
        'preview_label': 'Vorschau',
        'install_theme': 'Thema installieren...',
        'remove_theme': 'Thema entfernen',
        'disable_theme': 'Thema deaktivieren',
        'select_font': 'Schriftart auswählen...',
        'remove_font': 'Schriftart entfernen',
        'font_size': 'Schriftgröße:',
        'text_color': 'Textfarbe:',
        'background_color': 'Hintergrundfarbe:',
        'select_background': 'Hintergrund auswählen...',
        'remove_background': 'Hintergrund entfernen',
        'highlight_text_color': 'Hervorhebungsfarbe des Textes:',
        'highlight_background_color': 'Hervorhebungsfarbe des Hintergrunds:',
        'apply_theme_button': 'Thema anwenden',
        
        ## Einträge
        'add_entry': 'Eintrag hinzufügen',
        'edit_entry': 'Eintrag bearbeiten',
        'remove_entry': 'Eintrag entfernen',
        'entry_name': 'Name:',
        'entry_type': 'Typ:',
        'entry_kernel': 'Kernel:',
        'entry_initrd': 'Initrd:',
        'entry_params': 'Parameter:',
        
        # Statusmeldungen
        'ready': 'Bereit',
        'saving': 'Speichern...',
        'applying': 'Änderungen anwenden...',
        'loading': 'Laden...',
        'updating': 'GRUB aktualisieren...',
        
        # Fehlermeldungen
        'error_save': 'Fehler beim Speichern der Konfiguration',
        'error_load': 'Fehler beim Laden der Konfiguration',
        'error_apply': 'Fehler beim Anwenden der Änderungen',
        'error_update': 'Fehler beim Aktualisieren von GRUB',
        'error_permission': 'Berechtigungsfehler',
        'error_missing_deps': 'Fehlende erforderliche Abhängigkeiten',
        
        # Neue Schlüssel
        'advanced_options': 'Erweiterte Optionen',
        'kernel_params_section': 'Kernel-Parameter',
        'grub_updated': 'GRUB erfolgreich aktualisiert',
        
        # Spezifische Dialoge
        'select_font_dialog': 'Schriftart auswählen',
        'select_theme_dialog': 'Thema auswählen',
        'select_background_dialog': 'Hintergrundbild auswählen',
        'font_filter': 'Schriftarten',
        'theme_filter': 'Themen-Dateien',
        'image_filter': 'Bilder',
        'all_files': 'Alle Dateien',
        
        # Auflösungstexte
        'resolution_disabled': 'Deaktiviert',
        'resolution_auto': 'Automatisch',
        
        # Eintragstexte
        'default_entry_saved': 'Letzte Auswahl',
        'entry_path': 'Pfad',
        'entry_enabled': 'Aktiviert',
        
        # Warnungen und Bestätigungen
        'delete_font_confirm': 'Möchten Sie diese Schriftart wirklich löschen?',
        'delete_font_warning': 'Die Datei wird gelöscht: {}\nDiese Aktion kann nicht rückgängig gemacht werden.',
        'apply_font_confirm': 'Möchten Sie diese Schriftart anwenden?',
        'apply_font_message': 'Die Schriftart wird angewendet: {}',
        'remove_theme_confirm': 'Das Thema \'{}\' entfernen?',
        'disable_theme_confirm': 'Möchten Sie das aktuelle Thema entfernen?',
        'disable_theme_message': 'Das Thema wird deaktiviert, aber nicht vom System entfernt',
        'update_grub_title': 'GRUB aktualisieren',
        'update_grub_message': 'update-grub wird ausgeführt, um die Änderungen anzuwenden.',
        
        # Erfolgsmeldungen
        'font_installed': 'Schriftart erfolgreich installiert unter: {}',
        'font_removed': 'Schriftart erfolgreich entfernt',
        'theme_installed': 'Thema erfolgreich installiert',
        'theme_applied': 'Thema erfolgreich angewendet',
        'background_applied': 'Hintergrund erfolgreich eingestellt',
        'background_removed': 'Hintergrund erfolgreich entfernt',
        'entry_added': 'Eintrag erfolgreich hinzugefügt',
        'entry_removed': 'Eintrag erfolgreich entfernt',
        
        # Fehlermeldungen
        'invalid_font': 'Bitte wählen Sie eine gültige Schriftartdatei aus',
        'font_error': 'Fehler bei der Installation der Schriftart: {}',
        'theme_error': 'Fehler bei der Installation des Themas: {}',
        'background_error': 'Fehler beim Laden des Bildes: {}',
        'entry_error': 'Fehler beim Hinzufügen des Eintrags: {}',
        'no_font_installed': 'Keine Schriftarten in GRUB installiert',
        
        # Tastenkombinationen
        'shortcut_save': 'Strg+S',
        'shortcut_apply': 'Alt+A',
        'shortcut_close': 'Alt+C',
        
        # Hilfetexte
        'font_help': 'Diese Methode vermeidet Probleme mit update-grub, indem die Konfiguration direkt geändert wird.',
        'font_select_help': 'Wählen Sie eine TTF- oder OTF-Schriftartdatei aus',
        'browse_button': 'Durchsuchen...',
        'install_font_button': 'Schriftart installieren',
        'apply_font_button': 'Ausgewählte Schriftart anwenden',
        'remove_font_button': 'Ausgewählte Schriftart entfernen',
        'delete_font_file_button': 'Datei löschen',
        
        # Zusätzliche Tastenkombinationen
        'keyboard_shortcuts': 'Tastenkombinationen',
        'shortcut_titles': {
            'save': 'Speichern (Strg+S)',
            'apply': 'Anwenden (Alt+A)',
            'close': 'Schließen (Alt+C)',
            'browse': 'Durchsuchen (Alt+B)',
            'install': 'Installieren (Alt+I)', 
            'remove': 'Entfernen (Alt+R)',
            'delete': 'Löschen (Entf)',
            'add': 'Hinzufügen (Alt+N)',
            'edit': 'Bearbeiten (Alt+E)'
        }
    },
    'pt': {
        # Títulos e cabeçalhos
        'app_name': 'Soplos GRUB Editor',
        'general_tab': 'Configurações Gerais',
        'entries_tab': 'Entradas de Inicialização',
        'appearance_tab': 'Aparência',
        
        # Botões comuns
        'save_button': 'Salvar',
        'apply_button': 'Aplicar',
        'close_button': 'Fechar',
        'cancel_button': 'Cancelar',
        'ok_button': 'OK',
        
        # Títulos de diálogos
        'error_title': 'Erro',
        'info_title': 'Informação',
        'warning_title': 'Aviso',
        'confirm_title': 'Confirmar',
        'question_title': 'Pergunta',
        
        # Mensagens gerais
        'changes_saved': 'Alterações salvas com sucesso',
        'changes_error': 'Erro ao salvar as alterações',
        'need_root': 'Privilégios de administrador necessários',
        'confirm_exit': 'Tem certeza de que deseja sair?',
        'unsaved_changes': 'As alterações não salvas serão perdidas.',
        
        # Abas específicas
        ## Geral
        'timeout_label': 'Tempo limite (segundos):',
        'default_entry_label': 'Entrada padrão:',
        'resolution_label': 'Resolução da tela:',
        'kernel_params_label': 'Parâmetros do kernel:',
        'os_prober_label': 'Detectar outros sistemas operacionais',
        'show_menu_label': 'Mostrar menu de inicialização',
        'recovery_label': 'Incluir opções de recuperação',
        
        ## Aparência
        'theme_section': 'Tema',
        'font_section': 'Fontes',
        'colors_section': 'Cores',
        'background_section': 'Fundo',
        'preview_label': 'Pré-visualização',
        'install_theme': 'Instalar tema...',
        'remove_theme': 'Remover tema',
        'disable_theme': 'Desativar tema',
        'select_font': 'Selecionar fonte...',
        'remove_font': 'Remover fonte',
        'font_size': 'Tamanho da fonte:',
        'text_color': 'Cor do texto:',
        'background_color': 'Cor do fundo:',
        'select_background': 'Selecionar fundo...',
        'remove_background': 'Remover fundo',
        'highlight_text_color': 'Cor do texto em destaque:',
        'highlight_background_color': 'Cor do fundo em destaque:',
        'apply_theme_button': 'Aplicar tema',
        
        ## Entradas
        'add_entry': 'Adicionar entrada',
        'edit_entry': 'Editar entrada',
        'remove_entry': 'Remover entrada',
        'entry_name': 'Nome:',
        'entry_type': 'Tipo:',
        'entry_kernel': 'Kernel:',
        'entry_initrd': 'Initrd:',
        'entry_params': 'Parâmetros:',
        
        # Mensagens de estado
        'ready': 'Pronto',
        'saving': 'Salvando...',
        'applying': 'Aplicando alterações...',
        'loading': 'Carregando...',
        'updating': 'Atualizando GRUB...',
        
        # Mensagens de erro
        'error_save': 'Erro ao salvar a configuração',
        'error_load': 'Erro ao carregar a configuração',
        'error_apply': 'Erro ao aplicar as alterações',
        'error_update': 'Erro ao atualizar o GRUB',
        'error_permission': 'Erro de permissão',
        'error_missing_deps': 'Dependências necessárias ausentes',
        
        # Novas chaves
        'advanced_options': 'Opções avançadas',
        'kernel_params_section': 'Parâmetros do kernel',
        'grub_updated': 'GRUB atualizado com sucesso',
        
        # Diálogos específicos
        'select_font_dialog': 'Selecionar fonte',
        'select_theme_dialog': 'Selecionar tema',
        'select_background_dialog': 'Selecionar imagem de fundo',
        'font_filter': 'Fontes',
        'theme_filter': 'Arquivos de tema',
        'image_filter': 'Imagens',
        'all_files': 'Todos os arquivos',
        
        # Textos de resolução
        'resolution_disabled': 'Desativado',
        'resolution_auto': 'Automático',
        
        # Textos de entradas
        'default_entry_saved': 'Última seleção',
        'entry_path': 'Caminho',
        'entry_enabled': 'Habilitado',
        
        # Avisos e confirmações
        'delete_font_confirm': 'Tem certeza de que deseja excluir esta fonte?',
        'delete_font_warning': 'O arquivo será excluído: {}\nEsta ação não pode ser desfeita.',
        'apply_font_confirm': 'Deseja aplicar esta fonte?',
        'apply_font_message': 'A fonte será aplicada: {}',
        'remove_theme_confirm': 'Remover o tema \'{}\'?',
        'disable_theme_confirm': 'Deseja remover o tema atual?',
        'disable_theme_message': 'O tema será desativado, mas não será removido do sistema',
        'update_grub_title': 'Atualizar GRUB',
        'update_grub_message': 'update-grub será executado para aplicar as alterações.',
        
        # Mensagens de sucesso
        'font_installed': 'Fonte instalada com sucesso em: {}',
        'font_removed': 'Fonte removida com sucesso',
        'theme_installed': 'Tema instalado com sucesso',
        'theme_applied': 'Tema aplicado com sucesso',
        'background_applied': 'Fundo configurado com sucesso',
        'background_removed': 'Fundo removido com sucesso',
        'entry_added': 'Entrada adicionada com sucesso',
        'entry_removed': 'Entrada removida com sucesso',
        
        # Mensagens de erro
        'invalid_font': 'Por favor, selecione um arquivo de fonte válido',
        'font_error': 'Erro ao instalar a fonte: {}',
        'theme_error': 'Erro ao instalar o tema: {}',
        'background_error': 'Erro ao carregar a imagem: {}',
        'entry_error': 'Erro ao adicionar a entrada: {}',
        'no_font_installed': 'Nenhuma fonte instalada no GRUB',
        
        # Atalhos de teclado
        'shortcut_save': 'Ctrl+S',
        'shortcut_apply': 'Alt+A',
        'shortcut_close': 'Alt+C',
        
        # Textos de ajuda
        'font_help': 'Este método evita problemas com update-grub, modificando diretamente a configuração.',
        'font_select_help': 'Selecione um arquivo de fonte TTF ou OTF',
        'browse_button': 'Procurar...',
        'install_font_button': 'Instalar fonte',
        'apply_font_button': 'Aplicar fonte selecionada',
        'remove_font_button': 'Remover fonte selecionada',
        'delete_font_file_button': 'Excluir arquivo',
        
        # Atalhos de teclado adicionais
        'keyboard_shortcuts': 'Atalhos de teclado',
        'shortcut_titles': {
            'save': 'Salvar (Ctrl+S)',
            'apply': 'Aplicar (Alt+A)',
            'close': 'Fechar (Alt+C)',
            'browse': 'Procurar (Alt+B)',
            'install': 'Instalar (Alt+I)',
            'remove': 'Remover (Alt+R)',
            'delete': 'Excluir (Del)',
            'add': 'Adicionar (Alt+N)',
            'edit': 'Editar (Alt+E)'
        }
    },
    'it': {
        # Titoli e intestazioni
        'app_name': 'Soplos GRUB Editor',
        'general_tab': 'Impostazioni generali',
        'entries_tab': 'Voci di avvio',
        'appearance_tab': 'Aspetto',
        
        # Pulsanti comuni
        'save_button': 'Salva',
        'apply_button': 'Applica',
        'close_button': 'Chiudi',
        'cancel_button': 'Annulla',
        'ok_button': 'OK',
        
        # Titoli dei dialoghi
        'error_title': 'Errore',
        'info_title': 'Informazione',
        'warning_title': 'Avviso',
        'confirm_title': 'Conferma',
        'question_title': 'Domanda',
        
        # Messaggi generali
        'changes_saved': 'Modifiche salvate con successo',
        'changes_error': 'Errore durante il salvataggio delle modifiche',
        'need_root': 'Privilegi di amministratore richiesti',
        'confirm_exit': 'Sei sicuro di voler uscire?',
        'unsaved_changes': 'Le modifiche non salvate andranno perse.',
        
        # Schede specifiche
        ## Generale
        'timeout_label': 'Timeout (secondi):',
        'default_entry_label': 'Voce predefinita:',
        'resolution_label': 'Risoluzione dello schermo:',
        'kernel_params_label': 'Parametri del kernel:',
        'os_prober_label': 'Rileva altri sistemi operativi',
        'show_menu_label': 'Mostra menu di avvio',
        'recovery_label': 'Includi opzioni di ripristino',
        
        ## Aspetto
        'theme_section': 'Tema',
        'font_section': 'Font',
        'colors_section': 'Colori',
        'background_section': 'Sfondo',
        'preview_label': 'Anteprima',
        'install_theme': 'Installa tema...',
        'remove_theme': 'Rimuovi tema',
        'disable_theme': 'Disabilita tema',
        'select_font': 'Seleziona font...',
        'remove_font': 'Rimuovi font',
        'font_size': 'Dimensione del font:',
        'text_color': 'Colore del testo:',
        'background_color': 'Colore dello sfondo:',
        'select_background': 'Seleziona sfondo...',
        'remove_background': 'Rimuovi sfondo',
        'highlight_text_color': 'Colore del testo evidenziato:',
        'highlight_background_color': 'Colore dello sfondo evidenziato:',
        'apply_theme_button': 'Applica tema',
        
        ## Voci
        'add_entry': 'Aggiungi voce',
        'edit_entry': 'Modifica voce',
        'remove_entry': 'Rimuovi voce',
        'entry_name': 'Nome:',
        'entry_type': 'Tipo:',
        'entry_kernel': 'Kernel:',
        'entry_initrd': 'Initrd:',
        'entry_params': 'Parametri:',
        
        # Messaggi di stato
        'ready': 'Pronto',
        'saving': 'Salvataggio...',
        'applying': 'Applicazione delle modifiche...',
        'loading': 'Caricamento...',
        'updating': 'Aggiornamento di GRUB...',
        
        # Messaggi di errore
        'error_save': 'Errore durante il salvataggio della configurazione',
        'error_load': 'Errore durante il caricamento della configurazione',
        'error_apply': 'Errore durante l\'applicazione delle modifiche',
        'error_update': 'Errore durante l\'aggiornamento di GRUB',
        'error_permission': 'Errore di autorizzazione',
        'error_missing_deps': 'Dipendenze richieste mancanti',
        
        # Nuove chiavi
        'advanced_options': 'Opzioni avanzate',
        'kernel_params_section': 'Parametri del kernel',
        'grub_updated': 'GRUB aggiornato correttamente',
        
        # Dialoghi specifici
        'select_font_dialog': 'Seleziona font',
        'select_theme_dialog': 'Seleziona tema',
        'select_background_dialog': 'Seleziona immagine di sfondo',
        'font_filter': 'Font',
        'theme_filter': 'File di tema',
        'image_filter': 'Immagini',
        'all_files': 'Tutti i file',
        
        # Testi di risoluzione
        'resolution_disabled': 'Disabilitato',
        'resolution_auto': 'Automatico',
        
        # Testi delle voci
        'default_entry_saved': 'Ultima selezione',
        'entry_path': 'Percorso',
        'entry_enabled': 'Abilitato',
        
        # Avvisi e conferme
        'delete_font_confirm': 'Sei sicuro di voler eliminare questo font?',
        'delete_font_warning': 'Il file verrà eliminato: {}\nQuesta azione non può essere annullata.',
        'apply_font_confirm': 'Vuoi applicare questo font?',
        'apply_font_message': 'Il font verrà applicato: {}',
        'remove_theme_confirm': 'Rimuovere il tema \'{}\'?',
        'disable_theme_confirm': 'Vuoi rimuovere il tema attuale?',
        'disable_theme_message': 'Il tema verrà disabilitato ma non rimosso dal sistema',
        'update_grub_title': 'Aggiorna GRUB',
        'update_grub_message': 'update-grub verrà eseguito per applicare le modifiche.',
        
        # Messaggi di successo
        'font_installed': 'Font installato con successo in: {}',
        'font_removed': 'Font rimosso con successo',
        'theme_installed': 'Tema installato con successo',
        'theme_applied': 'Tema applicato con successo',
        'background_applied': 'Sfondo configurato con successo',
        'background_removed': 'Sfondo rimosso con successo',
        'entry_added': 'Voce aggiunta con successo',
        'entry_removed': 'Voce rimossa con successo',
        
        # Messaggi di errore
        'invalid_font': 'Seleziona un file di font valido',
        'font_error': 'Errore durante l\'installazione del font: {}',
        'theme_error': 'Errore durante l\'installazione del tema: {}',
        'background_error': 'Errore durante il caricamento dell\'immagine: {}',
        'entry_error': 'Errore durante l\'aggiunta della voce: {}',
        'no_font_installed': 'Nessun font installato in GRUB',
        
        # Scorciatoie da tastiera
        'shortcut_save': 'Ctrl+S',
        'shortcut_apply': 'Alt+A',
        'shortcut_close': 'Alt+C',
        
        # Testi di aiuto
        'font_help': 'Questo metodo evita problemi con update-grub modificando direttamente la configurazione.',
        'font_select_help': 'Seleziona un file di font TTF o OTF',
        'browse_button': 'Sfoglia...',
        'install_font_button': 'Installa font',
        'apply_font_button': 'Applica font selezionato',
        'remove_font_button': 'Rimuovi font selezionato',
        'delete_font_file_button': 'Elimina file',
        
        # Scorciatoie da tastiera aggiuntive
        'keyboard_shortcuts': 'Scorciatoie da tastiera',
        'shortcut_titles': {
            'save': 'Salva (Ctrl+S)',
            'apply': 'Applica (Alt+A)',
            'close': 'Chiudi (Alt+C)',
            'browse': 'Sfoglia (Alt+B)',
            'install': 'Installa (Alt+I)',
            'remove': 'Rimuovi (Alt+R)',
            'delete': 'Elimina (Del)',
            'add': 'Aggiungi (Alt+N)',
            'edit': 'Modifica (Alt+E)'
        }
    },
    'ru': {
        # Заголовки и заголовки
        'app_name': 'Soplos GRUB Editor',
        'general_tab': 'Общие настройки',
        'entries_tab': 'Записи загрузки',
        'appearance_tab': 'Внешний вид',
        
        # Общие кнопки
        'save_button': 'Сохранить',
        'apply_button': 'Применить',
        'close_button': 'Закрыть',
        'cancel_button': 'Отмена',
        'ok_button': 'ОК',
        
        # Заголовки диалогов
        'error_title': 'Ошибка',
        'info_title': 'Информация',
        'warning_title': 'Предупреждение',
        'confirm_title': 'Подтвердить',
        'question_title': 'Вопрос',
        
        # Общие сообщения
        'changes_saved': 'Изменения успешно сохранены',
        'changes_error': 'Ошибка при сохранении изменений',
        'need_root': 'Требуются права администратора',
        'confirm_exit': 'Вы уверены, что хотите выйти?',
        'unsaved_changes': 'Несохраненные изменения будут потеряны.',
        
        # Специфические вкладки
        ## Общие
        'timeout_label': 'Тайм-аут (секунды):',
        'default_entry_label': 'Запись по умолчанию:',
        'resolution_label': 'Разрешение экрана:',
        'kernel_params_label': 'Параметры ядра:',
        'os_prober_label': 'Обнаружить другие операционные системы',
        'show_menu_label': 'Показать меню загрузки',
        'recovery_label': 'Включить параметры восстановления',
        
        ## Внешний вид
        'theme_section': 'Тема',
        'font_section': 'Шрифты',
        'colors_section': 'Цвета',
        'background_section': 'Фон',
        'preview_label': 'Предварительный просмотр',
        'install_theme': 'Установить тему...',
        'remove_theme': 'Удалить тему',
        'disable_theme': 'Отключить тему',
        'select_font': 'Выбрать шрифт...',
        'remove_font': 'Удалить шрифт',
        'font_size': 'Размер шрифта:',
        'text_color': 'Цвет текста:',
        'background_color': 'Цвет фона:',
        'select_background': 'Выбрать фон...',
        'remove_background': 'Удалить фон',
        'highlight_text_color': 'Цвет выделенного текста:',
        'highlight_background_color': 'Цвет выделенного фона:',
        'apply_theme_button': 'Применить тему',
        
        ## Записи
        'add_entry': 'Добавить запись',
        'edit_entry': 'Редактировать запись',
        'remove_entry': 'Удалить запись',
        'entry_name': 'Имя:',
        'entry_type': 'Тип:',
        'entry_kernel': 'Ядро:',
        'entry_initrd': 'Initrd:',
        'entry_params': 'Параметры:',
        
        # Сообщения о состоянии
        'ready': 'Готово',
        'saving': 'Сохранение...',
        'applying': 'Применение изменений...',
        'loading': 'Загрузка...',
        'updating': 'Обновление GRUB...',
        
        # Сообщения об ошибках
        'error_save': 'Ошибка при сохранении конфигурации',
        'error_load': 'Ошибка при загрузке конфигурации',
        'error_apply': 'Ошибка при применении изменений',
        'error_update': 'Ошибка при обновлении GRUB',
        'error_permission': 'Ошибка разрешения',
        'error_missing_deps': 'Отсутствуют необходимые зависимости',
        
        # Новые ключи
        'advanced_options': 'Расширенные параметры',
        'kernel_params_section': 'Параметры ядра',
        'grub_updated': 'GRUB успешно обновлен',
        
        # Специфические диалоги
        'select_font_dialog': 'Выбрать шрифт',
        'select_theme_dialog': 'Выбрать тему',
        'select_background_dialog': 'Выбрать фоновое изображение',
        'font_filter': 'Шрифты',
        'theme_filter': 'Файлы тем',
        'image_filter': 'Изображения',
        'all_files': 'Все файлы',
        
        # Тексты разрешения
        'resolution_disabled': 'Отключено',
        'resolution_auto': 'Автоматически',
        
        # Тексты записей
        'default_entry_saved': 'Последний выбор',
        'entry_path': 'Путь',
        'entry_enabled': 'Включено',
        
        # Предупреждения и подтверждения
        'delete_font_confirm': 'Вы уверены, что хотите удалить этот шрифт?',
        'delete_font_warning': 'Файл будет удален: {}\nЭто действие нельзя отменить.',
        'apply_font_confirm': 'Вы хотите применить этот шрифт?',
        'apply_font_message': 'Шрифт будет применен: {}',
        'remove_theme_confirm': 'Удалить тему \'{}\'?',
        'disable_theme_confirm': 'Вы хотите удалить текущую тему?',
        'disable_theme_message': 'Тема будет отключена, но не удалена из системы',
        'update_grub_title': 'Обновить GRUB',
        'update_grub_message': 'update-grub будет выполнен для применения изменений.',
        
        # Сообщения об успехе
        'font_installed': 'Шрифт успешно установлен в: {}',
        'font_removed': 'Шрифт успешно удален',
        'theme_installed': 'Тема успешно установлена',
        'theme_applied': 'Тема успешно применена',
        'background_applied': 'Фон успешно установлен',
        'background_removed': 'Фон успешно удален',
        'entry_added': 'Запись успешно добавлена',
        'entry_removed': 'Запись успешно удалена',
        
        # Сообщения об ошибках
        'invalid_font': 'Пожалуйста, выберите допустимый файл шрифта',
        'font_error': 'Ошибка при установке шрифта: {}',
        'theme_error': 'Ошибка при установке темы: {}',
        'background_error': 'Ошибка при загрузке изображения: {}',
        'entry_error': 'Ошибка при добавлении записи: {}',
        'no_font_installed': 'В GRUB не установлено шрифтов',
        
        # Горячие клавиши
        'shortcut_save': 'Ctrl+S',
        'shortcut_apply': 'Alt+A',
        'shortcut_close': 'Alt+C',
        
        # Тексты помощи
        'font_help': 'Этот метод избегает проблем с update-grub, напрямую изменяя конфигурацию.',
        'font_select_help': 'Выберите файл шрифта TTF или OTF',
        'browse_button': 'Обзор...',
        'install_font_button': 'Установить шрифт',
        'apply_font_button': 'Применить выбранный шрифт',
        'remove_font_button': 'Удалить выбранный шрифт',
        'delete_font_file_button': 'Удалить файл',
        
        # Дополнительные горячие клавиши
        'keyboard_shortcuts': 'Горячие клавиши',
        'shortcut_titles': {
            'save': 'Сохранить (Ctrl+S)',
            'apply': 'Применить (Alt+A)',
            'close': 'Закрыть (Alt+C)',
            'browse': 'Обзор (Alt+B)',
            'install': 'Установить (Alt+I)',
            'remove': 'Удалить (Alt+R)',
            'delete': 'Удалить (Del)',
            'add': 'Добавить (Alt+N)',
            'edit': 'Редактировать (Alt+E)'
        }
    },
    'ro': {
        # Titluri și anteturi
        'app_name': 'Soplos GRUB Editor',
        'general_tab': 'Setări generale',
        'entries_tab': 'Intrări de boot',
        'appearance_tab': 'Aspect',
        
        # Butoane comune
        'save_button': 'Salvare',
        'apply_button': 'Aplicare',
        'close_button': 'Închidere',
        'cancel_button': 'Anulare',
        'ok_button': 'OK',
        
        # Titluri de dialoguri
        'error_title': 'Eroare',
        'info_title': 'Informație',
        'warning_title': 'Avertisment',
        'confirm_title': 'Confirmare',
        'question_title': 'Întrebare',
        
        # Mesaje generale
        'changes_saved': 'Modificările au fost salvate cu succes',
        'changes_error': 'Eroare la salvarea modificărilor',
        'need_root': 'Sunt necesare privilegii de administrator',
        'confirm_exit': 'Sigur doriți să ieșiți?',
        'unsaved_changes': 'Modificările nesalvate vor fi pierdute.',
        
        # File specifice
        ## General
        'timeout_label': 'Timeout (secunde):',
        'default_entry_label': 'Intrare implicită:',
        'resolution_label': 'Rezoluția ecranului:',
        'kernel_params_label': 'Parametrii kernelului:',
        'os_prober_label': 'Detectează alte sisteme de operare',
        'show_menu_label': 'Afișează meniul de boot',
        'recovery_label': 'Include opțiuni de recuperare',
        
        ## Aspect
        'theme_section': 'Temă',
        'font_section': 'Fonturi',
        'colors_section': 'Culori',
        'background_section': 'Fundal',
        'preview_label': 'Previzualizare',
        'install_theme': 'Instalează temă...',
        'remove_theme': 'Șterge temă',
        'disable_theme': 'Dezactivează temă',
        'select_font': 'Selectează font...',
        'remove_font': 'Șterge font',
        'font_size': 'Dimensiune font:',
        'text_color': 'Culoare text:',
        'background_color': 'Culoare fundal:',
        'select_background': 'Selectează fundal...',
        'remove_background': 'Șterge fundal',
        'highlight_text_color': 'Culoare text evidențiat:',
        'highlight_background_color': 'Culoare fundal evidențiat:',
        'apply_theme_button': 'Aplică temă',
        
        ## Intrări
        'add_entry': 'Adaugă intrare',
        'edit_entry': 'Editează intrare',
        'remove_entry': 'Șterge intrare',
        'entry_name': 'Nume:',
        'entry_type': 'Tip:',
        'entry_kernel': 'Kernel:',
        'entry_initrd': 'Initrd:',
        'entry_params': 'Parametri:',
        
        # Mesaje de stare
        'ready': 'Gata',
        'saving': 'Salvare...',
        'applying': 'Aplicare modificări...',
        'loading': 'Încărcare...',
        'updating': 'Actualizare GRUB...',
        
        # Mesaje de eroare
        'error_save': 'Eroare la salvarea configurației',
        'error_load': 'Eroare la încărcarea configurației',
        'error_apply': 'Eroare la aplicarea modificărilor',
        'error_update': 'Eroare la actualizarea GRUB',
        'error_permission': 'Eroare de permisiune',
        'error_missing_deps': 'Dependențe necesare lipsă',
        
        # Chei noi
        'advanced_options': 'Opțiuni avansate',
        'kernel_params_section': 'Parametrii kernelului',
        'grub_updated': 'GRUB actualizat cu succes',
        
        # Dialoguri specifice
        'select_font_dialog': 'Selectează font',
        'select_theme_dialog': 'Selectează temă',
        'select_background_dialog': 'Selectează imagine de fundal',
        'font_filter': 'Fonturi',
        'theme_filter': 'Fișiere de temă',
        'image_filter': 'Imagini',
        'all_files': 'Toate fișierele',
        
        # Texte de rezoluție
        'resolution_disabled': 'Dezactivat',
        'resolution_auto': 'Automat',
        
        # Texte de intrări
        'default_entry_saved': 'Ultima selecție',
        'entry_path': 'Cale',
        'entry_enabled': 'Activat',
        
        # Avertismente și confirmări
        'delete_font_confirm': 'Sigur doriți să ștergeți acest font?',
        'delete_font_warning': 'Fișierul va fi șters: {}\nAceastă acțiune nu poate fi anulată.',
        'apply_font_confirm': 'Doriți să aplicați acest font?',
        'apply_font_message': 'Fontul va fi aplicat: {}',
        'remove_theme_confirm': 'Ștergeți tema \'{}\'?',
        'disable_theme_confirm': 'Doriți să eliminați tema curentă?',
        'disable_theme_message': 'Tema va fi dezactivată, dar nu va fi eliminată din sistem',
        'update_grub_title': 'Actualizare GRUB',
        'update_grub_message': 'update-grub va fi executat pentru a aplica modificările.',
        
        # Mesaje de succes
        'font_installed': 'Font instalat cu succes în: {}',
        'font_removed': 'Font șters cu succes',
        'theme_installed': 'Temă instalată cu succes',
        'theme_applied': 'Temă aplicată cu succes',
        'background_applied': 'Fundal configurat cu succes',
        'background_removed': 'Fundal șters cu succes',
        'entry_added': 'Intrare adăugată cu succes',
        'entry_removed': 'Intrare ștearsă cu succes',
        
        # Mesaje de eroare
        'invalid_font': 'Vă rugăm să selectați un fișier de font valid',
        'font_error': 'Eroare la instalarea fontului: {}',
        'theme_error': 'Eroare la instalarea temei: {}',
        'background_error': 'Eroare la încărcarea imaginii: {}',
        'entry_error': 'Eroare la adăugarea intrării: {}',
        'no_font_installed': 'Nu există fonturi instalate în GRUB',
        
        # Comenzi rapide de la tastatură
        'shortcut_save': 'Ctrl+S',
        'shortcut_apply': 'Alt+A',
        'shortcut_close': 'Alt+C',
        
        # Texte de ajutor
        'font_help': 'Această metodă evită problemele cu update-grub modificând direct configurația.',
        'font_select_help': 'Selectați un fișier de font TTF sau OTF',
        'browse_button': 'Răsfoire...',
        'install_font_button': 'Instalează font',
        'apply_font_button': 'Aplică fontul selectat',
        'remove_font_button': 'Șterge fontul selectat',
        'delete_font_file_button': 'Șterge fișier',
        
        # Comenzi rapide de la tastatură suplimentare
        'keyboard_shortcuts': 'Comenzi rapide de la tastatură',
        'shortcut_titles': {
            'save': 'Salvare (Ctrl+S)',
            'apply': 'Aplicare (Alt+A)',
            'close': 'Închidere (Alt+C)',
            'browse': 'Răsfoire (Alt+B)',
            'install': 'Instalare (Alt+I)',
            'remove': 'Ștergere (Alt+R)',
            'delete': 'Ștergere (Del)',
            'add': 'Adăugare (Alt+N)',
            'edit': 'Editare (Alt+E)'
        }
    }
}