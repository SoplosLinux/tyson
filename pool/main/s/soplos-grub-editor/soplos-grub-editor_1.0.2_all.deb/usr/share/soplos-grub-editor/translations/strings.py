"""
Sistema de traducciones mejorado para Soplos GRUB Editor
Carga dinámica de idiomas individuales
"""

import os
import logging
import sys

# Función para obtener el idioma del sistema
def get_system_language():
    """Detecta el idioma del sistema desde variables de entorno"""
    lang = os.environ.get('LANG', 'en_US.UTF-8')
    return lang.split('_')[0]

# Idiomas soportados
SUPPORTED_LANGUAGES = ['es', 'en', 'fr', 'pt', 'de', 'it', 'ru', 'ro']

def load_language(lang_code):
    """Carga dinámicamente las traducciones de un idioma específico"""
    try:
        # Verificar si el idioma está soportado
        if lang_code not in SUPPORTED_LANGUAGES:
            lang_code = 'en'  # Fallback a inglés
        
        # Intentar importar desde el directorio local primero
        try:
            # Añadir el directorio de locales al path
            locales_dir = os.path.join(os.path.dirname(__file__), 'locales')
            if locales_dir not in sys.path:
                sys.path.insert(0, locales_dir)
            
            # Importar el módulo específico del idioma
            module_name = lang_code
            module = __import__(module_name, fromlist=['STRINGS'])
            return module.STRINGS
        except ImportError:
            # Fallback: intentar la ruta completa
            module_name = f'translations.locales.{lang_code}'
            module = __import__(module_name, fromlist=['STRINGS'])
            return module.STRINGS
        
    except ImportError as e:
        logging.warning(f"No se pudo cargar el idioma {lang_code}: {e}")
        
        # Fallback a inglés si no es inglés el que falla
        if lang_code != 'en':
            try:
                return load_language('en')
            except:
                pass
        
        # Último recurso: traducciones mínimas hardcodeadas
        return {
            'app_name': 'Soplos GRUB Editor',
            'error_title': 'Error',
            'ready': 'Ready',
            'general_tab': 'General Settings',
            'entries_tab': 'Boot Entries', 
            'appearance_tab': 'Appearance',
            'save_button': 'Save',
            'apply_button': 'Apply',
            'close_button': 'Close',
            'cancel_button': 'Cancel',
            'ok_button': 'OK'
        }

# Detectar idioma del sistema y cargar traducciones
CURRENT_LANG = get_system_language()
if CURRENT_LANG not in SUPPORTED_LANGUAGES:
    CURRENT_LANG = 'en'  # Fallback a inglés

# Cargar solo las traducciones del idioma actual
CURRENT_TRANSLATIONS = load_language(CURRENT_LANG)

# Asegurar que el inglés siempre esté disponible como fallback
try:
    ENGLISH_TRANSLATIONS = load_language('en')
except:
    # Si falla cargar inglés, usar traducciones mínimas
    ENGLISH_TRANSLATIONS = {
        'app_name': 'Soplos GRUB Editor',
        'error_title': 'Error',
        'ready': 'Ready',
        'general_tab': 'General Settings',
        'entries_tab': 'Boot Entries',
        'appearance_tab': 'Appearance',
        'save_button': 'Save',
        'apply_button': 'Apply',
        'close_button': 'Close',
        'cancel_button': 'Cancel',
        'ok_button': 'OK'
    }

# Mantener la interfaz antigua para compatibilidad
TRANSLATIONS = {
    CURRENT_LANG: CURRENT_TRANSLATIONS,
    'en': ENGLISH_TRANSLATIONS  # Asegurar que inglés esté disponible
}

# Función de traducción mejorada con fallback robusto
def _(key, lang=None):
    """
    Función de traducción mejorada
    
    Args:
        key (str): Clave de traducción
        lang (str, optional): Idioma específico. Si no se especifica, usa el idioma del sistema
    
    Returns:
        str: Texto traducido o la clave si no se encuentra traducción
    """
    try:
        if lang and lang != CURRENT_LANG:
            # Cargar idioma específico si es diferente al actual
            if lang not in TRANSLATIONS:
                TRANSLATIONS[lang] = load_language(lang)
            translations = TRANSLATIONS[lang]
        else:
            translations = CURRENT_TRANSLATIONS
        
        # Buscar la traducción en el idioma solicitado
        if key in translations:
            return translations[key]
        
        # Fallback a inglés si no se encuentra
        if 'en' in TRANSLATIONS and key in TRANSLATIONS['en']:
            return TRANSLATIONS['en'][key]
        
        # Último fallback: retornar la clave
        return key
        
    except Exception as e:
        logging.warning(f"Error en traducción para '{key}': {e}")
        return key

# Función para cambiar idioma dinámicamente
def set_language(lang_code):
    """
    Cambia el idioma de la aplicación dinámicamente
    
    Args:
        lang_code (str): Código del idioma (es, en, fr, etc.)
    
    Returns:
        bool: True si el cambio fue exitoso, False si falló
    """
    global CURRENT_LANG, CURRENT_TRANSLATIONS, TRANSLATIONS
    
    try:
        if lang_code in SUPPORTED_LANGUAGES:
            CURRENT_LANG = lang_code
            CURRENT_TRANSLATIONS = load_language(lang_code)
            TRANSLATIONS[lang_code] = CURRENT_TRANSLATIONS
            return True
        else:
            logging.warning(f"Idioma no soportado: {lang_code}")
            return False
    except Exception as e:
        logging.error(f"Error al cambiar idioma a {lang_code}: {e}")
        return False

def get_available_languages():
    """
    Retorna la lista de idiomas disponibles
    
    Returns:
        dict: Diccionario con códigos de idioma y nombres nativos
    """
    return {
        'es': 'Español',
        'en': 'English', 
        'fr': 'Français',
        'pt': 'Português',
        'de': 'Deutsch',
        'it': 'Italiano',
        'ru': 'Русский',
        'ro': 'Română'
    }

# Función para precargar todos los idiomas (opcional)
def preload_all_languages():
    """
    Precarga todas las traducciones para uso sin latencia
    Solo usar si la memoria no es un problema
    """
    global TRANSLATIONS
    
    for lang in SUPPORTED_LANGUAGES:
        if lang not in TRANSLATIONS:
            TRANSLATIONS[lang] = load_language(lang)

# Información del sistema de traducciones
def get_translation_info():
    """
    Retorna información sobre el sistema de traducciones actual
    
    Returns:
        dict: Información del sistema de traducciones
    """
    return {
        'current_language': CURRENT_LANG,
        'supported_languages': SUPPORTED_LANGUAGES,
        'loaded_languages': list(TRANSLATIONS.keys()),
        'total_strings': len(CURRENT_TRANSLATIONS)
    }

# Exportar la función de traducción con el nombre tradicional
# para mantener compatibilidad con el código existente
__all__ = [
    'TRANSLATIONS', 
    'get_system_language', 
    '_', 
    'set_language', 
    'get_available_languages',
    'preload_all_languages',
    'get_translation_info',
    'SUPPORTED_LANGUAGES',
    'CURRENT_LANG'
]