# Soplos GRUB Editor

Una herramienta gráfica oficial de **Soplos Linux** para configurar y personalizar fácilmente el gestor de arranque GRUB2.

## 🌟 Características

- ✅ **Interfaz gráfica intuitiva** con GTK3
- ✅ **Internacionalización completa** - 8 idiomas soportados
- ✅ **Gestión de temas** GRUB personalizados
- ✅ **Configuración de fuentes** TTF/OTF → PF2
- ✅ **Personalización de colores** de texto y fondo
- ✅ **Gestión de entradas** de arranque personalizadas
- ✅ **Configuración de fondos** de pantalla
- ✅ **Configuración avanzada** del kernel
- ✅ **Detección automática** de otros SO
- ✅ **Copias de seguridad** automáticas
- ✅ **Método seguro** de actualización

## 🌍 Idiomas Soportados

| Idioma | Código | Estado |
|--------|--------|--------|
| 🇪🇸 Español | `es` | ✅ 100% |
| 🇺🇸 English | `en` | ✅ 100% |
| 🇫🇷 Français | `fr` | ✅ 100% |
| 🇵🇹 Português | `pt` | ✅ 100% |
| 🇩🇪 Deutsch | `de` | ✅ 100% |
| 🇮🇹 Italiano | `it` | ✅ 100% |
| 🇷🇺 Русский | `ru` | ✅ 100% |
| 🇷🇴 Română | `ro` | ✅ 100% |

## 📋 Requisitos del Sistema

### Dependencias Principales
- **Python 3.8+**
- **PyGObject >= 3.36.0**
- **GTK 3.0**
- **GRUB 2.x**

### Dependencias del Sistema
```bash
sudo apt install python3-gi python3-gi-cairo gir1.2-gtk-3.0
sudo apt install grub2-common pkexec imagemagick
sudo apt install python3-cairo python3-xlib python3-polib
sudo apt install python3-dbus python3-pil
```

### Dependencias Python
```bash
pip3 install -r requirements.txt
```

## 🚀 Instalación

### Desde el Repositorio de Soplos (Recomendado)
```bash
sudo apt update
sudo apt install soplos-grub-editor
```

### Instalación Manual
```bash
# Clonar el repositorio
git clone https://github.com/SoplosLinux/soplos-grub-editor.git
cd soplos-grub-editor

# Instalar dependencias
sudo apt install -f
pip3 install -r requirements.txt

# Instalar la aplicación
sudo python3 setup.py install

# Instalar archivos del sistema
sudo cp assets/com.soplos.grubeditor.desktop /usr/share/applications/
sudo cp assets/icons/com.soplos.grubeditor.png /usr/share/icons/hicolor/128x128/apps/
sudo cp debian/com.soplos.grubeditor.metainfo.xml /usr/share/metainfo/
sudo update-desktop-database
sudo gtk-update-icon-cache /usr/share/icons/hicolor/
```

## 🎮 Uso

### Iniciar la Aplicación
```bash
soplos-grub-editor
```

La aplicación solicitará automáticamente privilegios de administrador usando `pkexec`.

### Atajos de Teclado
- **Ctrl+S**: Guardar configuración
- **Alt+A**: Aplicar cambios
- **Alt+C**: Cerrar aplicación
- **Alt+B**: Examinar archivos
- **Alt+I**: Instalar elemento
- **Alt+R**: Eliminar elemento
- **Alt+N**: Añadir entrada
- **Alt+E**: Editar entrada

### Configuración por Pestañas

#### 🔧 General
- Tiempo de espera del menú
- Entrada predeterminada
- Resolución de pantalla
- Parámetros del kernel
- Opciones de detección de SO

#### 🎨 Apariencia
- **Temas**: Instalar y aplicar temas GRUB
- **Fuentes**: Convertir e instalar fuentes personalizadas
- **Colores**: Personalizar colores de texto y fondo
- **Fondos**: Configurar imágenes de fondo

#### 📝 Entradas
- Añadir entradas de arranque personalizadas
- Editar entradas existentes
- Habilitar/deshabilitar entradas

## 🔧 Características Técnicas

### Sistema de Traducciones
- **Sistema modular**: Carga dinámica de idiomas
- **Fallback inteligente**: Inglés como respaldo
- **Detección automática**: Basada en `$LANG`
- **API consistente**: Función `_()` estándar

### Gestión de Configuración
- **Preservación de estructura**: Mantiene comentarios y formato
- **Copias de seguridad**: Automáticas antes de cambios
- **Validación**: Verificación de sintaxis
- **Limpieza**: Eliminación de duplicados

### Seguridad
- **Privilegios mínimos**: Solo root cuando necesario
- **Validación de entrada**: Sanitización de datos
- **Copias de seguridad**: Restauración automática
- **Logging**: Registro de operaciones

## 📁 Estructura del Proyecto

```
soplos-grub-editor/
├── main.py                 # Punto de entrada principal
├── app_paths.py            # Configuración de rutas
├── requirements.txt        # Dependencias Python
├── setup.py               # Script de instalación
├── README.md              # Este archivo
├── CHANGELOG.md           # Registro de cambios
├── LICENSE               # Licencia GPL v3
│
├── ui/                   # Interfaz de usuario
│   ├── main_window.py    # Ventana principal
│   ├── general_tab.py    # Pestaña general
│   ├── entries_tab.py    # Pestaña de entradas
│   └── appearance_tab.py # Pestaña de apariencia
│
├── utils/                # Utilidades
│   ├── font_utils.py     # Gestión de fuentes
│   ├── theme_utils.py    # Gestión de temas
│   └── system_utils.py   # Utilidades del sistema
│
├── config/               # Configuración
│   └── grub_config.py    # Gestor de config GRUB
│
├── translations/         # Sistema de traducciones
│   ├── strings.py        # Motor de traducciones
│   └── locales/          # Archivos de idioma
│       ├── es.py         # Español
│       ├── en.py         # English
│       ├── fr.py         # Français
│       ├── pt.py         # Português
│       ├── de.py         # Deutsch
│       ├── it.py         # Italiano
│       ├── ru.py         # Русский
│       └── ro.py         # Română
│
├── assets/               # Recursos
│   ├── icons/            # Iconos
│   └── *.desktop         # Archivos desktop
│
└── debian/               # Empaquetado Debian
    ├── control           # Control del paquete
    ├── *.metainfo.xml    # Metadatos AppStream
    └── soplos-grub-editor # Script ejecutable
```

## 🐛 Solución de Problemas

### Error: "No se pudieron obtener privilegios de administrador"
```bash
# Verificar que pkexec esté instalado
sudo apt install pkexec policykit-1

# Verificar que el usuario está en el grupo sudo
sudo usermod -aG sudo $USER
```

### Error: "Configuración de GRUB no encontrada"
```bash
# Verificar que GRUB esté instalado
sudo apt install grub2-common

# Verificar permisos del archivo
sudo chmod 644 /etc/default/grub
```

### Error de dependencias Python
```bash
# Reinstalar dependencias
pip3 install --force-reinstall -r requirements.txt

# En Ubuntu/Debian
sudo apt install python3-gi-dev python3-dev
```

### Problemas de iconos o escritorio
```bash
# Actualizar base de datos desktop
sudo update-desktop-database

# Actualizar caché de iconos
sudo gtk-update-icon-cache /usr/share/icons/hicolor/
```

## 🤝 Contribuir

### Reportar Errores
- Abrir un [issue](https://github.com/SoplosLinux/tyron/issues)
- Incluir información del sistema
- Adjuntar logs relevantes

### Traducciones
Para añadir un nuevo idioma:

1. Crear `translations/locales/XX.py` (XX = código idioma)
2. Copiar estructura de `translations/locales/en.py`
3. Traducir todas las cadenas
4. Añadir el código a `SUPPORTED_LANGUAGES` en `strings.py`
5. Enviar Pull Request

### Desarrollo
```bash
# Fork del repositorio
git clone https://github.com/tu-usuario/soplos-grub-editor.git
cd soplos-grub-editor

# Crear rama para feature
git checkout -b feature/nueva-caracteristica

# Hacer cambios y commit
git commit -am "Añadir nueva característica"

# Push y Pull Request
git push origin feature/nueva-caracteristica
```

## 📄 Licencia

Este proyecto está licenciado bajo **GPL v3.0** - ver [LICENSE](LICENSE) para detalles.

## 👥 Autores

- **Soplos Team** - [soploslinux.com](https://soploslinux.com)
- **Contacto**: info@soploslinux.com

## 🙏 Agradecimientos

- Comunidad de **Soplos Linux**
- Desarrolladores de **GTK** y **PyGObject**
- Comunidad de **GRUB**
- Traductores voluntarios

## 📊 Estado del Proyecto

- ✅ **Versión Estable**: 1.0.2
- ✅ **Internacionalización**: 100% completa
- ✅ **Características**: Implementadas
- ✅ **Documentación**: Actualizada
- ✅ **Pruebas**: En todas las distribuciones objetivo

---

<div align="center">

**[Soplos Linux](https://soploslinux.com)** | **[Documentación](https://soploslinux.com/docs)** | **[Comunidad](https://soploslinux.com/community)**

</div>