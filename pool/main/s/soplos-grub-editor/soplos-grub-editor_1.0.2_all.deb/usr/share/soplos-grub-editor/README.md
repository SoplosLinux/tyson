# Soplos GRUB Editor

[![License: GPL-3.0+](https://img.shields.io/badge/License-GPL--3.0%2B-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![Version](https://img.shields.io/badge/version-1.0.0-green.svg)]()

Una herramienta gráfica para configurar y personalizar fácilmente la configuración del gestor de arranque GRUB en Soplos Linux.

*A graphical tool to easily configure and customize GRUB bootloader settings in Soplos Linux.*

## 📝 Descripción

Soplos GRUB Editor es una herramienta que permite a los usuarios modificar fácilmente la configuración del gestor de arranque GRUB a través de una interfaz gráfica intuitiva, sin necesidad de editar archivos de configuración manualmente.

## ✨ Características

- Configuración sencilla del gestor de arranque GRUB
- Personalización completa de temas para GRUB
- Ajustes avanzados para usuarios experimentados
- Interfaz gráfica intuitiva y fácil de usar
- Gestión de entradas de arranque
- Personalización de tiempos de espera y opciones predeterminadas

## 📸 Capturas de pantalla

### Ventana principal del Editor GRUB
![Ventana principal](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-grub-editor/screenshots/screenshot1.png)

### Configuración de temas GRUB
![Configuración de temas](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-grub-editor/screenshots/screenshot2.png)

### Ajustes avanzados
![Ajustes avanzados](https://raw.githubusercontent.com/SoplosLinux/tyron/main/media/soplos-grub-editor/screenshots/screenshot3.png)

## 🔧 Instalación

El paquete está disponible en los repositorios oficiales de Soplos Linux:

```bash
sudo apt install soplos-grub-editor
```

## 🚀 Uso

Ejecuta la aplicación desde el menú de aplicaciones o con el siguiente comando:

```bash
soplos-grub-editor
```

## 🌐 Idiomas soportados

- Español
- Inglés
- Francés
- Portugués
- Alemán
- Italiano
- Ruso
- Rumano

## 📄 Licencia

Este proyecto está licenciado bajo [GPL-3.0+](https://www.gnu.org/licenses/gpl-3.0.html) (GNU General Public License versión 3 o posterior).

Esta licencia garantiza las siguientes libertades:
- La libertad de usar el programa para cualquier propósito
- La libertad de estudiar cómo funciona el programa y modificarlo
- La libertad de distribuir copias del programa
- La libertad de mejorar el programa y publicar esas mejoras

Cualquier trabajo derivado debe distribuirse bajo la misma licencia (GPL-3.0+).

Para más detalles, consulte el archivo LICENSE o visite [gnu.org/licenses/gpl-3.0](https://www.gnu.org/licenses/gpl-3.0.html).

## 👥 Desarrolladores

Desarrollado por [Equipo de Soplos](https://soploslinux.com)

## 🔗 Enlaces

- [Página web](https://soploslinux.com)
- [Reportar problemas](https://github.com/SoplosLinux/tyron/issues)
- [Ayuda](https://soploslinux.com)

## 📦 Versiones

### v1.0.0 (08/05/2025)
- Versión inicial