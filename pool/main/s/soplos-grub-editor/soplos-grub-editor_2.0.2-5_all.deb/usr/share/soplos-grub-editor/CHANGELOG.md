# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).
## [2.0.2-5] - 2026-07-07

### 🔧 Changed
- Build dependency `python3-all` replaced with `python3`.

---

## [2.0.2-4] - 2026-05-22

### 📚 Documentation
- Aligned Tyson legacy 1.x release timeline to correct July 2025 timestamps.
- Cleaned up obsolete metadata tags in metainfo.xml.

---

## [2.0.2-3] - 2026-05-18

### 📚 Documentation
- **Historical correction (Tyron legacy):** The August 2025 package mislabelled as `1.0.4` is now correctly documented as `1.0.9`. The original Tyron `1.0.4` from the May 2025 sequence has also been restored to the changelog (its `.deb` was overwritten and lost when the packaging error reused the version number).

---

## [2.0.2-2] - 2026-04-30

### 💄 Changed
- Simplified the footer UI text to match the modern Soplos standard layout (`XFCE · X11`).

---

## [2.0.2-1] - 2026-03-21

### ✨ Added
- **F1 — About dialog**: Press F1 to open the About dialog with version, author, license and website.
- **GNOME menu About**: Application menu About action now opens the actual dialog.
- **Ctrl+Shift+Tab**: Keyboard shortcut to navigate to the previous tab.

### 🐛 Fixed
- Notebook tab labels no longer appear orange in inactive tabs — removed `color: inherit` rule that incorrectly propagated the active tab color to all labels.
- Icon files renamed from `com.soplos` to `org.soplos` for naming consistency.
- Duplicate `GTK_THEME` environment variable entry in the pkexec launcher eliminated.
- Wrong i18n domain default (`soplos-repo-selector`) corrected to `soplos-grub-editor`.
- Inline `import subprocess` statements moved to module level in `appearance_view.py`.
- Debug `[DEBUG]` print statement removed from production code.
- Version string in `main.py` docstring and `.desktop` file updated to 2.0.2.

### 🎨 Improved
- CSS architecture refactored to `base.css` (structural styles) + `dark.css`/`light.css` (color variables only), matching the Soplos standard used by Sys Cleaner.
- About dialog appearance standardized across XFCE, GNOME and KDE to match all other Soplos apps.

---

## [2.0.2] - 2026-03-11

### ✨ New Features
- **Hierarchical Submenu Support** - Full parsing and display of GRUB submenus (e.g., "Advanced > Kernel").
- **Submenu Toggle** - New option in Advanced Settings to enable/disable submenus (`GRUB_DISABLE_SUBMENU`).
- **Auto-Sync on Startup** - Implementation of a silent `update-grub` on application launch for better synchronization.
- **Enhanced Path Display** - Hierarchical naming in Boot Entries list and Default Entry selection.
- **Updated Translations** - Full support for all 8 languages updated with new features.

### 🐛 Fixes
- **Selection Bug** - Fixed issue where choosing alternative kernels incorrectly defaulted to the primary one.
- **UI Visual Optimization** - Compacted Boot Entries table by removing excessive padding for a cleaner look.

## [2.0.1] - 2026-03-07

### 🐛 Fixes
- **Robust Theme Management** - Now correctly disables both `05_debian_theme` and `05_soplos_theme` to prevent system conflicts.
- **Cache Cleanup** - Automatically removes problematic `.background_cache.*` images (like progressive JPEGs) that caused the "invalid argument" GRUB crash.
- **Smart UI Automation** - "Show boot menu" checkbox is now automatically disabled and unchecked when Timeout is set to 0.

## [2.0.0] - 2026-01-10

### 🎉 Major Release - Complete Rewrite

#### ✨ New Features
- **Complete Internationalization** - Native support for 8 languages (ES, EN, DE, FR, IT, PT, RO, RU)
- **Smart Light/Dark Theme Detection** - Automatically detects user theme (GNOME, KDE, XFCE) before privilege elevation
- **Improved Desktop Detection** - Accurate identification of Desktop Environment and Display Protocol
- **Refined UI Layout** - New compact split-view for Advanced Options and Kernel Parameters
- **GRUB Theme Installer** - Install themes from .tar.gz, .tar.xz, .tar.bz2, .zip archives
- **GRUB Theme Remover** - Remove installed themes with confirmation
- **UUID Option** - Checkbox to enable/disable GRUB_DISABLE_LINUX_UUID
- **Expanded Resolutions** - Support for 16:9, 16:10, 4:3, and legacy resolutions (up to 4K)
- **Enhanced Theme Preview** - Checks for preview.png, preview.jpg, background.png/jpg

#### 🔧 Improvements
- **Rewritten save_config** - Updates existing lines in place, handling commented lines correctly
- **Colors loaded from GRUB** - Color buttons now reflect actual GRUB_COLOR_* values
- **State Synchronization** - read_config() called after save to keep internal state in sync
- **Optimized get_config** - Only sends keys that have changed or already exist

#### 🐛 Fixes
- **Duplicate Lines Removed** - No longer adds duplicate lines to GRUB config
- **Empty Lines Handling** - Prevents accumulation of blank lines
- **Dynamic Preview** - Background preview updates correctly when typing path
- **Default Colors on Disable** - Sets white/black defaults when a theme is disabled

#### 📦 Documentation
- **Man Page Added** - docs/soplos-grub-editor.1
- **Debian Copyright** - debian/copyright
- **Updated Metainfo** - 8 languages with v2.0.0 release notes

---

## Legacy 1.x — Prior to Unification

Before version 2.0.0, the project existed as two separate branches:

- **Tyron** (XFCE + X11): versions 1.0.0 – 1.0.9, released April–August 2025
- **Tyson** (Plasma 6 + Wayland): versions 1.0.0 – 1.0.5, released May–July 2025

Both branches were merged and unified into version 2.0.0 (January 2026).

---

### Tyron branch

#### [1.0.9] - 2025-08-03

> ⚠️ **Packaging note:** This release was published under the label `1.0.4` by mistake — the project was already at `1.0.8` in May 2025. The correct version number is `1.0.9`.

##### ✨ Added
- **Complete internationalisation:** 8 languages natively supported via `translations/strings.py` and `app_locale/`.
- **Full Tyron desktop integration:** Native integration with the Tyron window manager and taskbars.
- **Asset optimisation:** Massive optimisation of screenshots and icon assets; multi-size icon packaging (48×48, 64×64, 128×128).
- **Updated authorship:** `setup.py` updated to Sergi Perich &lt;info@soploslinux.com&gt;.

#### [1.0.8] - 2025-05-08

##### 🐛 Fixed
- Stability and compatibility: Internal fixes and improvements for the Tyron environment.

#### [1.0.7] - 2025-05-08

##### 🐛 Fixed
- **Application ID restored** to `com.soplos.grubeditor`.
- **Strings module relocated** back to `translations/strings.py`.

#### [1.0.6] - 2025-05-07

##### 🐛 Fixed
- Minor UI and compatibility fixes for the Tyron build.

#### [1.0.5] - 2025-05-07

##### 🐛 Fixed
- Internal cleanup and minor corrections for the Tyron build.

#### [1.0.4] - 2025-05-07

> ⚠️ **Package lost:** The `.deb` file for this release was overwritten and is no longer available. It was destroyed when a packaging error in August 2025 reused this version number for what should have been `1.0.9`.

#### [1.0.3] - 2025-05-06

##### 🔧 Changed
- **Metainfo updated** for AppStream/DEP-11 compliance.
- **Screenshots renamed** to `screenshot1.png`, `screenshot2.png`, etc.
- Minor documentation and metadata improvements.

#### [1.0.2] - 2025-05-05

##### 🔧 Changed
- **Strings module:** UI strings extracted to `strings.py` in the project root.
- **Application ID:** Changed to `com.soplosgrubeditor`.

#### [1.0.1] - 2025-04-25

##### 🌟 Improved
- **Font conversion system:** More robust TTF/OTF → PF2 conversion pipeline.
- **Error handling:** Improved during font installation.
- **User interface:** More responsive under heavy operations.
- **Theme installation:** Optimised process.

##### 🐛 Fixed
- TTF/OTF conversion errors during font processing.
- Permission issues in `/boot/grub/fonts/`.
- UI crashes when loading large themes.
- Memory errors when processing fonts.

#### [1.0.0] - 2025-04-13

##### 🎉 Initial Tyron Release
- **Complete graphical GRUB2 editor** with intuitive GTK3 interface and organised tabs.
- **GRUB Theme management:** Install and apply themes.
- **Font conversion:** TTF/OTF → PF2 for GRUB fonts.
- **Background wallpaper** configuration.
- **Custom boot entries** management.
- **Advanced kernel configuration** (parameters, timeout, default entry, resolution).
- **Automatic OS detection.**
- **Automatic backup system** before applying changes.
- **Secure integration** with `update-grub` using minimum privileges.
- **Keyboard shortcuts** and configuration validation before applying.

---

### Tyson branch

#### [1.0.5] - 2025-07-27

##### 🌟 Improved
- **Metainfo finalized** for AppStream/DEP-11 compliance.
- **Program icons:** Added in 48×48, 64×64 and 128×128 for software center compatibility.
- **Program icon updated.**

#### [1.0.4] - 2025-07-15

##### 🌟 Improved
- **Metainfo finalized** for AppStream/DEP-11 compliance.
- **Program icons:** Added in 48×48, 64×64 and 128×128 for software center compatibility.
- Minor structure and tag improvements.

#### [1.0.3] - 2025-07-14

##### 🐛 Fixed
- **Metainfo corrections:** Final fixes to ensure full visibility in software centers.
- Validated across Plasma Discover, GNOME Software and other AppStream-compatible centers.
- Minor AppStream structure improvements.

#### [1.0.2] - 2025-06-24

##### ✨ Added
- **Dynamic translation system** with on-demand loading.
- **8 languages fully supported:** ES, EN, FR, PT, DE, IT, RU, RO.
- **Automatic language detection** based on `$LANG` with English fallback.
- **`set_language()` and `get_available_languages()`** functions for runtime language management.

##### 🐛 Fixed
- **Hardcoded strings** completely removed from all UI elements.

##### 🔧 Changed
- **New `translations/` module structure** with centralised `strings.py` and separate per-language modules in `locales/`.
- **Plasma Discover compatibility:** Package now visible via updated AppStream metainfo.

#### [1.0.1] - 2025-06-15

##### 🌟 Improved
- **Font conversion system:** More robust TTF/OTF → PF2 conversion pipeline.
- **Error handling:** Improved during font installation.
- **User interface:** More responsive under heavy operations.
- **Theme installation:** Optimised process.

##### 🐛 Fixed
- TTF/OTF conversion errors during font processing.
- Permission issues in `/boot/grub/fonts/`.
- UI crashes when loading large themes.
- Memory errors when processing fonts.

#### [1.0.0] - 2025-05-09

##### 🎉 Initial Tyson Release
- **Complete graphical GRUB2 editor** with intuitive GTK3 interface and organised tabs.
- **GRUB Theme management:** Install and apply themes.
- **Font conversion:** TTF/OTF → PF2 for GRUB fonts.
- **Background wallpaper** configuration.
- **Custom boot entries** management.
- **Advanced kernel configuration** (parameters, timeout, default entry, resolution).
- **Automatic OS detection.**
- **Automatic backup system** before applying changes.
- **Secure integration** with `update-grub` using minimum privileges.
- **Keyboard shortcuts** and configuration validation before applying.

---

## Types of Changes

- **Added** for new features
- **Changed** for changes in existing functionality
- **Deprecated** for features soon to be removed
- **Removed** for now removed features
- **Fixed** for any bug fixes
- **Security** in case of vulnerabilities

## Contribute

To report bugs or request features:
- **Issues**: https://github.com/SoplosLinux/soplos-grub-editor/issues
- **Discussions**: https://github.com/SoplosLinux/soplos-grub-editor/discussions
- **Email**: info@soploslinux.com

To contribute translations:
1. Create file `translations/locales/XX.py` (XX = language code)
2. Copy structure from `translations/locales/en.py`
3. Translate all `STRINGS`
4. Add language to `SUPPORTED_LANGUAGES` in `strings.py`
5. Submit Pull Request

## Support

- **Documentation**: https://soplos.org/docs/soplos-grub-editor
- **Community**: https://soplos.org/community
- **Support**: support@soploslinux.com
