#!/usr/bin/env python3
import os
import sys
import subprocess
import logging
import shutil
import atexit
import gi

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GdkPixbuf, GLib, Gio, Gdk

# Importar nuestros módulos
from translations.strings import TRANSLATIONS
from app_paths import ICON_PATH, LOGO_PATH
from ui.main_window import GrubEditorWindow

# Obtener el idioma del sistema y configurar traducción ANTES de usar _()
def get_system_language():
    lang = os.environ.get('LANG', 'en_US.UTF-8')
    return lang.split('_')[0]

# Configurar el sistema de traducción ANTES de cualquier uso
LANG = get_system_language()
_ = lambda key: TRANSLATIONS.get(LANG, TRANSLATIONS['en']).get(key, TRANSLATIONS['en'][key])

# Definir las constantes de identificación de manera consistente
APP_ID = "com.soplos.grubeditor"
# Obtener WMCLASS del entorno si está definido (prioridad sobre definición interna)
WMCLASS = os.environ.get('WMCLASS', APP_ID)

# Configurar el registro de errores DESPUÉS de tener traducciones disponibles
logging.basicConfig(
    level=logging.ERROR,
    format='%(levelname)s: %(message)s'
)

def detect_kde_theme():
    """Detectar el tema actual de KDE del USUARIO ORIGINAL, incluyendo el nombre específico"""
    try:
        # Determinar el directorio home del usuario original
        user_home = None
        
        # Método 1: Variable de entorno preservada desde el script de lanzamiento
        user_home = os.environ.get('USER_HOME')
        
        # Método 2: SUDO_USER (si se ejecutó con sudo)
        if not user_home:
            original_user = os.environ.get('SUDO_USER')
            if original_user:
                user_home = f"/home/{original_user}"
        
        # Método 3: PKEXEC_UID (si se ejecutó con pkexec)
        if not user_home:
            pkexec_uid = os.environ.get('PKEXEC_UID')
            if pkexec_uid and pkexec_uid.isdigit():
                import pwd
                try:
                    user_info = pwd.getpwuid(int(pkexec_uid))
                    user_home = user_info.pw_dir
                except:
                    pass
        
        # Método 4: Variable ORIGINAL_USER preservada
        if not user_home:
            original_user = os.environ.get('ORIGINAL_USER')
            if original_user:
                user_home = f"/home/{original_user}"
        
        # Si aún no tenemos user_home, no podemos detectar el tema
        if not user_home:
            print("DEBUG: No se pudo determinar el directorio home del usuario original")
            return None
            
        kde_config_path = os.path.join(user_home, ".config", "kdeglobals")
        print(f"DEBUG: Buscando configuración KDE del usuario en: {kde_config_path}")
        
        if not os.path.exists(kde_config_path):
            print(f"DEBUG: No existe configuración KDE en {kde_config_path}")
            return None
            
        with open(kde_config_path, 'r') as f:
            content = f.read()
        
        # Buscar el ColorScheme específico primero
        color_scheme = None
        widget_style = None
        
        # Analizar secciones del archivo
        current_section = None
        for line in content.split('\n'):
            line = line.strip()
            
            # Detectar secciones
            if line.startswith('[') and line.endswith(']'):
                current_section = line[1:-1]
                continue
            
            # Buscar ColorScheme en cualquier sección
            if line.startswith('ColorScheme='):
                color_scheme = line.split('=')[1].strip()
                print(f"DEBUG: ColorScheme encontrado en [{current_section}]: {color_scheme}")
            
            # Buscar también el estilo de widgets
            elif line.startswith('widgetStyle=') or line.startswith('LookAndFeelPackage='):
                widget_style = line.split('=')[1].strip()
                print(f"DEBUG: Widget style encontrado: {widget_style}")
        
        # Si tenemos un ColorScheme específico, intentar mapearlo
        if color_scheme:
            # Mapeo de temas KDE conocidos a sus equivalentes GTK
            theme_mapping = {
                # Temas oscuros
                'BreezeClassicDark': 'Breeze-Dark',
                'BreezeDark': 'Breeze-Dark', 
                'breeze-dark': 'Breeze-Dark',
                'ArcDark': 'Arc-Dark',
                'MateriaDark': 'Materia-dark',
                'PapirusDark': 'Papirus-Dark',
                'OxygenDark': 'oxygen-gtk',
                
                # Temas claros
                'BreezeClassic': 'Breeze',
                'Breeze': 'Breeze',
                'Arc': 'Arc',
                'Materia': 'Materia',
                'Papirus': 'Papirus',
                'Oxygen': 'oxygen-gtk',
                
                # Temas personalizados comunes que pueden tener tonos naranjas
                'SoplasClassic': 'Soplos',  # Si existe un tema Soplos
                'UbuntuOrange': 'Yaru-orange',
                'Orange': 'Yaru-orange',
                'Ambiance': 'Ambiance',
                'Radiance': 'Radiance',
            }
            
            # Buscar mapeo directo
            if color_scheme in theme_mapping:
                mapped_theme = theme_mapping[color_scheme]
                print(f"DEBUG: Tema mapeado: {color_scheme} -> {mapped_theme}")
                return mapped_theme
            
            # Si no hay mapeo directo, usar el nombre del tema KDE como está
            # y verificar si existe un tema GTK con ese nombre
            potential_gtk_theme = color_scheme
            
            # Verificar si existe el tema GTK con el nombre exacto
            theme_paths = [
                f'/usr/share/themes/{potential_gtk_theme}',
                f'/usr/local/share/themes/{potential_gtk_theme}',
                f'{user_home}/.themes/{potential_gtk_theme}',
                f'{user_home}/.local/share/themes/{potential_gtk_theme}'
            ]
            
            for path in theme_paths:
                if os.path.exists(path):
                    print(f"DEBUG: Tema GTK encontrado con nombre exacto: {potential_gtk_theme} en {path}")
                    return potential_gtk_theme
            
            # Si no existe con el nombre exacto, determinar si es oscuro o claro
            # y usar fallback apropiado
            dark_indicators = ['dark', 'noir', 'black', 'shadow', 'midnight']
            is_dark_theme = any(indicator in color_scheme.lower() for indicator in dark_indicators)
            
            if is_dark_theme:
                print(f"DEBUG: Tema oscuro no mapeado: {color_scheme}, usando Breeze-Dark")
                return 'Breeze-Dark'
            else:
                print(f"DEBUG: Tema claro no mapeado: {color_scheme}, usando Breeze")
                return 'Breeze'
        
        # Si no encontramos ColorScheme, detectar por colores de fondo como antes
        bg_color = None
        for line in content.split('\n'):
            if 'BackgroundNormal=' in line:
                bg_color = line.split('=')[1].strip()
                break
                
        if bg_color:
            # Parsear color RGB y determinar si es claro u oscuro
            try:
                if ',' in bg_color:
                    r, g, b = map(int, bg_color.split(',')[:3])
                    # Calcular luminancia usando la fórmula estándar
                    luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255
                    is_dark = luminance < 0.5
                    print(f"DEBUG: Color de fondo RGB({r},{g},{b}), luminancia: {luminance:.2f}, es oscuro: {is_dark}")
                    
                    # Verificar si hay tonos naranjas en el color
                    if r > g and r > b and r > 100:  # Predominio de rojo, posible naranja
                        if is_dark:
                            # Buscar tema naranja oscuro
                            orange_dark_themes = ['Yaru-orange-dark', 'Ubuntu-orange-dark', 'Ambiance']
                            for theme in orange_dark_themes:
                                for path in [f'/usr/share/themes/{theme}', f'/usr/local/share/themes/{theme}']:
                                    if os.path.exists(path):
                                        print(f"DEBUG: Detectado tema naranja oscuro: {theme}")
                                        return theme
                            return 'Breeze-Dark'  # Fallback
                        else:
                            # Buscar tema naranja claro
                            orange_light_themes = ['Yaru-orange', 'Ubuntu-orange', 'Radiance']
                            for theme in orange_light_themes:
                                for path in [f'/usr/share/themes/{theme}', f'/usr/local/share/themes/{theme}']:
                                    if os.path.exists(path):
                                        print(f"DEBUG: Detectado tema naranja claro: {theme}")
                                        return theme
                            return 'Breeze'  # Fallback
                    
                    return 'Breeze-Dark' if is_dark else 'Breeze'
            except Exception as e:
                print(f"DEBUG: Error parseando color de fondo: {e}")
                pass
                
        print("DEBUG: Usando tema Breeze por defecto para el usuario")
        return 'Breeze'  # Fallback por defecto
    except Exception as e:
        print(f"DEBUG: Error detectando tema KDE del usuario: {e}")
        logging.debug(f"Error detectando tema KDE del usuario: {e}")
        return None

def detect_gnome_theme():
    """Detectar el tema de GNOME usando gsettings"""
    try:
        result = subprocess.run(['gsettings', 'get', 'org.gnome.desktop.interface', 'gtk-theme'], 
                              capture_output=True, text=True)
        if result.returncode == 0:
            theme = result.stdout.strip().strip("'\"")
            return theme
    except:
        pass
    
    # Fallback: verificar si existe configuración de tema oscuro
    try:
        result = subprocess.run(['gsettings', 'get', 'org.gnome.desktop.interface', 'color-scheme'], 
                              capture_output=True, text=True)
        if result.returncode == 0 and 'dark' in result.stdout.lower():
            return 'Adwaita-dark'
    except:
        pass
    
    return None

def configure_environment():
    """Detecta y configura el entorno para coherencia de tema del USUARIO ORIGINAL"""
    wayland_session = os.environ.get('XDG_SESSION_TYPE') == 'wayland'
    kde_desktop = 'kde' in os.environ.get('XDG_CURRENT_DESKTOP', '').lower()
    gnome_desktop = 'gnome' in os.environ.get('XDG_CURRENT_DESKTOP', '').lower()
    
    # Verificar si ya tenemos tema configurado desde las variables de entorno del usuario
    existing_theme = os.environ.get('GTK_THEME')
    if existing_theme:
        print(f"DEBUG: Tema ya configurado desde variables del usuario: {existing_theme}")
        # Verificar que sea el tema correcto
        if existing_theme != 'Adwaita-dark' or not kde_desktop:
            return
        else:
            print("DEBUG: Tema Adwaita-dark detectado en KDE, corrigiendo a Breeze-Dark")
    
    theme_name = None
    
    # Agregar debug para ver qué se está detectando
    print(f"DEBUG: Detectando tema para usuario original")
    print(f"DEBUG: Wayland={wayland_session}, KDE={kde_desktop}, GNOME={gnome_desktop}")
    print(f"DEBUG: USER_HOME={os.environ.get('USER_HOME')}")
    print(f"DEBUG: ORIGINAL_USER={os.environ.get('ORIGINAL_USER')}")
    
    if kde_desktop:
        # Detectar tema KDE del usuario original
        theme_name = detect_kde_theme()
        if theme_name:
            # FORZAR el uso de Breeze en KDE, no Adwaita
            if theme_name == 'Breeze-Dark':
                os.environ['GTK_THEME'] = 'Breeze-Dark'
                # También configurar variables adicionales para asegurar el tema correcto
                os.environ['GTK2_RC_FILES'] = '/usr/share/themes/Breeze-Dark/gtk-2.0/gtkrc'
                print(f"DEBUG: FORZADO tema Breeze-Dark para KDE")
            elif theme_name == 'Breeze':
                os.environ['GTK_THEME'] = 'Breeze'
                os.environ['GTK2_RC_FILES'] = '/usr/share/themes/Breeze/gtk-2.0/gtkrc'
                print(f"DEBUG: FORZADO tema Breeze para KDE")
            
            print(f"DEBUG: Aplicado tema GTK del usuario desde KDE: {theme_name}")
            logging.info(f"Aplicado tema GTK del usuario desde KDE: {theme_name}")
        
        # Para KDE en Wayland, también intentar forzar tema oscuro si se detecta
        if wayland_session and theme_name == 'Breeze-Dark':
            os.environ['GTK_APPLICATION_PREFER_DARK_THEME'] = '1'
            print("DEBUG: Forzado GTK_APPLICATION_PREFER_DARK_THEME=1 para el usuario")
    
    elif gnome_desktop:
        # Para GNOME, usar Adwaita es correcto
        theme_name = detect_gnome_theme()
        if theme_name:
            os.environ['GTK_THEME'] = theme_name
            logging.info(f"Aplicado tema GTK desde GNOME: {theme_name}")
    
    # Configuraciones adicionales para Wayland
    if wayland_session:
        os.environ['GTK_USE_PORTAL'] = '1'
        print("DEBUG: Configurado GTK_USE_PORTAL=1 para Wayland")
    
    print(f"DEBUG: Variables de entorno GTK finales:")
    print(f"  GTK_THEME={os.environ.get('GTK_THEME', 'No definido')}")
    print(f"  GTK_APPLICATION_PREFER_DARK_THEME={os.environ.get('GTK_APPLICATION_PREFER_DARK_THEME', 'No definido')}")
    print(f"  GTK2_RC_FILES={os.environ.get('GTK2_RC_FILES', 'No definido')}")

# IMPORTANTE: Configurar el entorno ANTES de importar GTK
configure_environment()

# Configuración para evitar conflictos con módulos estándar de Python
# Eliminar las rutas locales del path para priorizar módulos estándar
std_modules = ['locale', 'gettext']
for module in std_modules:
    if module in sys.modules:
        del sys.modules[module]

# Ahora importar GTK DESPUÉS de configurar el entorno
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GdkPixbuf, GLib, Gio, Gdk

# Variable global para evitar llamadas múltiples - MEJORADA
_app_identity_configured = False

def setup_application_identity():
    """Configurar la identidad de la aplicación una sola vez"""
    global _app_identity_configured
    
    # Verificar si ya se configuró para evitar llamadas múltiples
    if _app_identity_configured:
        return
    
    try:
        # Solo configurar si no se ha hecho antes
        if not GLib.get_prgname():
            GLib.set_prgname(APP_ID)
        
        if not GLib.get_application_name():
            GLib.set_application_name(APP_ID)
        
        # Establecer el icono predeterminado para todas las ventanas
        try:
            Gtk.Window.set_default_icon_name("com.soplos.grubeditor")
        except Exception as e:
            logging.warning(_('icon_set_error').format(e))

        # Configuración para asegurar que GDK use el WMCLASS correcto
        try:
            if hasattr(Gdk, 'set_program_class'):
                Gdk.set_program_class(WMCLASS)
        except Exception as e:
            logging.warning(_('program_class_error').format(e))
        
        _app_identity_configured = True
        
    except Exception as e:
        logging.error(f"Error configurando identidad de aplicación: {e}")

def relanzar_como_root():
    """Relanza la aplicación con permisos de root usando pkexec con variables de entorno necesarias."""
    try:
        env = os.environ.copy()
        xdg_runtime_dir = f"/run/user/{os.getuid()}"
        display = env.get('DISPLAY', ':0')
        xauthority = env.get('XAUTHORITY', os.path.expanduser('~/.Xauthority'))
        
        # Obtener información del usuario actual antes del escalado
        import pwd
        user_info = pwd.getpwuid(os.getuid())
        user_home = user_info.pw_dir
        user_name = user_info.pw_name
        
        # Preparar variables de entorno para pkexec
        env_vars = [
            f"DISPLAY={display}", 
            f"XAUTHORITY={xauthority}",
            f"XDG_RUNTIME_DIR={xdg_runtime_dir}",
            f"WMCLASS={APP_ID}",
            "HOME=/root",
            f"USER_HOME={user_home}",  # Preservar el directorio home original
            f"ORIGINAL_USER={user_name}",  # Preservar el nombre de usuario original
        ]
        
        # Añadir variables de tema si están configuradas
        if 'GTK_THEME' in env:
            env_vars.append(f"GTK_THEME={env['GTK_THEME']}")
        if 'GTK_USE_PORTAL' in env:
            env_vars.append(f"GTK_USE_PORTAL={env['GTK_USE_PORTAL']}")
        if 'GTK_APPLICATION_PREFER_DARK_THEME' in env:
            env_vars.append(f"GTK_APPLICATION_PREFER_DARK_THEME={env['GTK_APPLICATION_PREFER_DARK_THEME']}")
        
        # Detectar tipo de sesión para transmitir
        session_type = env.get('XDG_SESSION_TYPE', '')
        current_desktop = env.get('XDG_CURRENT_DESKTOP', '')
        
        if session_type:
            env_vars.append(f"XDG_SESSION_TYPE={session_type}")
        if current_desktop:
            env_vars.append(f"XDG_CURRENT_DESKTOP={current_desktop}")
        
        print(f"DEBUG: Variables de entorno para pkexec: {env_vars}")
        
        cmd = ['pkexec', '--disable-internal-agent', 'env'] + env_vars + [
            sys.executable,
            sys.argv[0]
        ]
        
        subprocess.run(cmd, check=True)
        sys.exit(0)
    except subprocess.CalledProcessError:
        logging.error(_('pkexec_error'))
        sys.exit(1)
    except Exception as e:
        logging.error(_('relaunch_error').format(str(e)))
        sys.exit(1)

def limpiar_pycache():
    """Limpia todos los directorios __pycache__ en el proyecto."""
    try:
        # Obtener el directorio base actual del script
        if hasattr(sys, '_MEIPASS'):
            # Si está ejecutándose desde un ejecutable empaquetado
            directorio_base = sys._MEIPASS
        else:
            # Usar el directorio donde está ubicado este script
            directorio_base = os.path.dirname(os.path.abspath(__file__))
        
        # También limpiar en las ubicaciones de instalación comunes
        rutas_a_limpiar = [
            directorio_base,
            '/usr/local/bin/Tyson/soplos-grub-editor',
            '/usr/share/soplos-grub-editor',
            '/opt/soplos-grub-editor'
        ]
        
        for base_path in rutas_a_limpiar:
            if os.path.exists(base_path):
                for raiz, dirs, archivos in os.walk(base_path):
                    if '__pycache__' in dirs:
                        ruta_cache = os.path.join(raiz, '__pycache__')
                        try:
                            shutil.rmtree(ruta_cache)
                            logging.info(_('directory_cleaned').format(ruta_cache))
                        except Exception as e:
                            logging.error(_('directory_clean_error').format(ruta_cache, str(e)))
                            
    except Exception as e:
        logging.error(_('directory_clean_error').format('__pycache__', str(e)))

def copy_kde_config_to_root():
    """
    Copia la configuración KDE del usuario al directorio .config de root
    para preservar el tema visual cuando se ejecuta como root.
    """
    try:
        # Detectar información del usuario original
        original_user = os.environ.get('ORIGINAL_USER') or os.environ.get('SUDO_USER')
        user_home = os.environ.get('USER_HOME')
        
        # Método alternativo: usar PKEXEC_UID
        if not user_home and not original_user:
            pkexec_uid = os.environ.get('PKEXEC_UID')
            if pkexec_uid and pkexec_uid.isdigit():
                import pwd
                try:
                    user_info = pwd.getpwuid(int(pkexec_uid))
                    user_home = user_info.pw_dir
                    original_user = user_info.pw_name
                except:
                    pass
        
        # Si no tenemos user_home, construirlo
        if not user_home and original_user:
            user_home = f"/home/{original_user}"
        
        if not user_home or not original_user:
            print("DEBUG: No se pudo determinar el directorio home del usuario original")
            return False
        
        print(f"DEBUG: Copiando configuración KDE desde {user_home} para usuario {original_user}")
        
        # Archivos de configuración KDE a copiar
        kde_config_files = [
            'kdeglobals',
            'kwinrc', 
            'plasma-org.kde.plasma.desktop-appletsrc',
            'plasmarc',
            'plasmashellrc'
        ]
        
        # Directorio de configuración del usuario y root
        user_config_dir = os.path.join(user_home, '.config')
        root_config_dir = '/root/.config'
        
        # Verificar que el directorio de configuración del usuario existe
        if not os.path.exists(user_config_dir):
            print(f"DEBUG: No existe el directorio de configuración del usuario: {user_config_dir}")
            return False
        
        # Crear directorio .config de root si no existe
        if not os.path.exists(root_config_dir):
            os.makedirs(root_config_dir, mode=0o755)
            print(f"DEBUG: Creado directorio {root_config_dir}")
        
        # Copiar cada archivo de configuración
        files_copied = 0
        for config_file in kde_config_files:
            user_file_path = os.path.join(user_config_dir, config_file)
            root_file_path = os.path.join(root_config_dir, config_file)
            
            if os.path.exists(user_file_path):
                try:
                    # Crear copia de seguridad del archivo de root si existe
                    if os.path.exists(root_file_path):
                        backup_path = f"{root_file_path}.backup"
                        shutil.copy2(root_file_path, backup_path)
                        print(f"DEBUG: Backup creado: {backup_path}")
                    
                    # Copiar archivo del usuario a root
                    shutil.copy2(user_file_path, root_file_path)
                    
                    # Establecer permisos correctos
                    os.chown(root_file_path, 0, 0)  # root:root
                    os.chmod(root_file_path, 0o644)
                    
                    print(f"DEBUG: Copiado {config_file} exitosamente")
                    files_copied += 1
                    
                except Exception as e:
                    print(f"DEBUG: Error al copiar {config_file}: {e}")
            else:
                print(f"DEBUG: Archivo no encontrado: {user_file_path}")
        
        print(f"DEBUG: Se copiaron {files_copied} archivos de configuración KDE")
        return files_copied > 0
        
    except Exception as e:
        print(f"DEBUG: Error general al copiar configuración KDE: {e}")
        return False

def restore_root_kde_config():
    """
    Restaura la configuración KDE original de root desde las copias de seguridad.
    """
    try:
        root_config_dir = '/root/.config'
        kde_config_files = [
            'kdeglobals',
            'kwinrc',
            'plasma-org.kde.plasma.desktop-appletsrc', 
            'plasmarc',
            'plasmashellrc'
        ]
        
        files_restored = 0
        for config_file in kde_config_files:
            root_file_path = os.path.join(root_config_dir, config_file)
            backup_path = f"{root_file_path}.backup"
            
            if os.path.exists(backup_path):
                try:
                    shutil.move(backup_path, root_file_path)
                    print(f"DEBUG: Restaurado {config_file} desde backup")
                    files_restored += 1
                except Exception as e:
                    print(f"DEBUG: Error al restaurar {config_file}: {e}")
            elif os.path.exists(root_file_path):
                # Si no hay backup pero existe el archivo, eliminarlo
                # (fue creado por nosotros)
                try:
                    os.remove(root_file_path)
                    print(f"DEBUG: Eliminado {config_file} (creado temporalmente)")
                    files_restored += 1
                except Exception as e:
                    print(f"DEBUG: Error al eliminar {config_file}: {e}")
        
        print(f"DEBUG: Se restauraron/limpiaron {files_restored} archivos de configuración")
        return files_restored > 0
        
    except Exception as e:
        print(f"DEBUG: Error al restaurar configuración KDE: {e}")
        return False

def main():
    """Función principal de la aplicación."""
    # Registrar la función de limpieza para que se ejecute al salir
    atexit.register(limpiar_pycache)
    
    # Verificar si se está ejecutando como root
    if os.geteuid() != 0:
        # Ya se configuró el entorno al inicio del archivo
        relanzar_como_root()
        return
    
    # Si ya somos root, configurar identidad de la aplicación ANTES de crear la aplicación GTK
    setup_application_identity()
        
    # Ignorar mensajes de advertencia del bus de accesibilidad
    os.environ['NO_AT_BRIDGE'] = '1'
    
    # Crear aplicación GTK con el ID específico
    app = Gtk.Application(
        application_id=APP_ID,
        flags=Gio.ApplicationFlags.FLAGS_NONE
    )

    def on_activate(app):
        # Aplicar configuraciones adicionales de tema después de que GTK esté inicializado
        settings = Gtk.Settings.get_default()
        
        # Intentar múltiples formas de aplicar el tema oscuro
        if 'GTK_THEME' in os.environ:
            theme_name = os.environ['GTK_THEME']
            
            # VERIFICAR que tenemos el tema correcto instalado
            theme_paths = [
                f'/usr/share/themes/{theme_name}',
                f'/usr/local/share/themes/{theme_name}',
                f'~/.themes/{theme_name}',
                f'~/.local/share/themes/{theme_name}'
            ]
            
            theme_available = False
            for path in theme_paths:
                expanded_path = os.path.expanduser(path)
                if os.path.exists(expanded_path):
                    theme_available = True
                    print(f"DEBUG: Tema {theme_name} encontrado en: {expanded_path}")
                    break
            
            if not theme_available:
                print(f"DEBUG: ADVERTENCIA - Tema {theme_name} no encontrado, usando fallback")
                # Si Breeze-Dark no está disponible, intentar con otros temas KDE oscuros
                if theme_name == 'Breeze-Dark':
                    fallback_themes = ['Breeze', 'oxygen-gtk', 'QtCurve']
                    for fallback in fallback_themes:
                        for path in theme_paths:
                            expanded_path = os.path.expanduser(path.replace(theme_name, fallback))
                            if os.path.exists(expanded_path):
                                theme_name = fallback
                                os.environ['GTK_THEME'] = fallback
                                print(f"DEBUG: Usando tema fallback: {fallback}")
                                theme_available = True
                                break
                        if theme_available:
                            break
            
            if theme_available:
                settings.set_property('gtk-theme-name', theme_name)
                print(f"DEBUG: Tema GTK configurado en settings: {theme_name}")
                logging.info(f"Tema GTK configurado: {theme_name}")
                
                # Si es tema oscuro, también configurar prefer-dark-theme
                if 'dark' in theme_name.lower() or theme_name == 'Breeze-Dark':
                    settings.set_property('gtk-application-prefer-dark-theme', True)
                    print("DEBUG: Configurado gtk-application-prefer-dark-theme=True")
        
        # Forzar tema oscuro si está configurado en variables de entorno
        if os.environ.get('GTK_APPLICATION_PREFER_DARK_THEME') == '1':
            settings.set_property('gtk-application-prefer-dark-theme', True)
            print("DEBUG: Forzado prefer-dark-theme desde variable de entorno")
        
        win = GrubEditorWindow()
        app.add_window(win)
        
        # Conectar la función de limpieza al cierre de ventana
        win.connect('destroy', lambda w: limpiar_pycache())
        
        # Reemplazar el uso de set_wmclass (obsoleto) con una propiedad moderna
        # La propiedad role es más moderna que set_wmclass
        win.set_role(WMCLASS)
        
        # Establecer el icono del programa para el sistema - orden de prioridad:
        # 1. Por nombre (com.soplos.grubeditor)
        # 2. Por ruta absoluta en sistema (/usr/share/icons/...)
        # 3. Por ruta relativa (assets/icons/...)
        try:
            icon_theme = Gtk.IconTheme.get_default()
            try:
                icon = icon_theme.load_icon("com.soplos.grubeditor", 128, 0)
                win.set_icon(icon)
            except:
                # Fallback a la ruta absoluta si falla la carga por nombre
                icon_path = "/usr/share/icons/hicolor/128x128/apps/com.soplos.grubeditor.png"
                if os.path.exists(icon_path):
                    win.set_icon_from_file(icon_path)
                elif os.path.exists(ICON_PATH):
                    win.set_icon_from_file(ICON_PATH)
        except Exception as e:
            logging.error(f"Error al establecer icono: {e}")
        
        # Forzar actualización de propiedades de ventana antes de mostrar
        win.realize()
        
        # Ahora mostrar la ventana
        win.show_all()

    def on_shutdown(app):
        """Función que se ejecuta al cerrar la aplicación"""
        limpiar_pycache()

    app.connect('activate', on_activate)
    app.connect('shutdown', on_shutdown)
    
    try:
        return app.run(None)
    finally:
        # Asegurar que se limpie incluso si hay error
        limpiar_pycache()

if __name__ == "__main__":
    sys.exit(main())