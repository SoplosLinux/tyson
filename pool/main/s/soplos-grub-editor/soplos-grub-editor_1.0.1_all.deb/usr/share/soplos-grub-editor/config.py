# Este archivo está obsoleto y ha sido reemplazado por app_paths.py
# Se mantiene por compatibilidad, pero se recomienda actualizar todas las importaciones

import warnings
warnings.warn(
    "El módulo 'config' está obsoleto. Use 'app_paths' en su lugar.", 
    DeprecationWarning, 
    stacklevel=2
)

from app_paths import *
