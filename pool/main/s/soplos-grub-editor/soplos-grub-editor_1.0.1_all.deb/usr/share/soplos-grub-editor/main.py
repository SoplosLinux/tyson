#!/usr/bin/env python3
import os
import sys
import gi
import logging
import shutil
import subprocess
from pathlib import Path

# Configurar el logging ANTES de importar GTK
logging.basicConfig(
    level=logging.ERROR,
    format='%(levelname)s: %(message)s'
)

# Función para detectar y aplicar el tema del usuario INMEDIATAMENTE
def apply_user_theme():
    """Aplicar el tema del usuario que fue preservado por el script"""
    try:
        # 1. USAR el GTK_THEME que ya viene preservado
        gtk_theme = os.environ.get('GTK_THEME')
        if gtk_theme:
            print(f"DEBUG: Aplicando tema preservado: {gtk_theme}")
            # Aplicar el tema ANTES de inicializar GTK
            os.environ['GTK_THEME'] = gtk_theme
            return True
        
        # 2. Si no hay GTK_THEME, detectar desde USER_HOME
        user_home = os.environ.get('USER_HOME')
        if user_home and os.path.exists(f"{user_home}/.config/kdeglobals"):
            print(f"DEBUG: Detectando tema desde {user_home}")
            
            with open(f"{user_home}/.config/kdeglobals", 'r') as f:
                content = f.read()
                
            # Buscar ColorScheme
            for line in content.split('\n'):
                if line.startswith('ColorScheme='):
                    color_scheme = line.split('=')[1].strip()
                    
                    # Mapeo directo
                    if 'dark' in color_scheme.lower() or 'Dark' in color_scheme:
                        theme = "Breeze-Dark"
                    else:
                        theme = "Breeze"
                    
                    print(f"DEBUG: Detectado {color_scheme} -> {theme}")
                    os.environ['GTK_THEME'] = theme
                    return True
        
        print("DEBUG: No se pudo detectar tema, usando predeterminado")
        return False
        
    except Exception as e:
        print(f"DEBUG: Error detectando tema: {e}")
        return False

# APLICAR EL TEMA INMEDIATAMENTE
apply_user_theme()

# Ahora sí, configurar GTK
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib, Gio

def main():
    """Función principal"""
    try:
        # Verificar permisos
        if os.geteuid() != 0:
            print("Error: Se requieren privilegios de root")
            return 1
        
        # Crear aplicación GTK
        app = Gtk.Application(application_id='com.soplos.grubeditor')
        
        def on_activate(app):
            # Importar la ventana principal
            from ui.main_window import GrubEditorWindow
            
            # Crear y mostrar la ventana
            window = GrubEditorWindow()
            window.set_application(app)
            window.show_all()
        
        app.connect('activate', on_activate)
        return app.run(sys.argv)
        
    except Exception as e:
        print(f"Error fatal: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())