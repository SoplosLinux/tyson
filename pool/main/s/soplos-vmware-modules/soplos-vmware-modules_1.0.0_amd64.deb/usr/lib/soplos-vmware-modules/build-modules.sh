#!/usr/bin/env bash
# build-modules.sh
# Builds and installs vmmon.ko and vmnet.ko for a specific kernel version.
# Usage: build-modules.sh KERNEL_VERSION
#
# Installed at /usr/lib/soplos-vmware-modules/build-modules.sh
# Called from:
#   - debian/postinst  (for all kernels when the package is installed)
#   - /etc/kernel/postinst.d/soplos-vmware-modules  (new kernel installed)

set -uo pipefail

KVER="${1:?Usage: build-modules.sh KERNEL_VERSION}"
SRC_DIR="/usr/lib/vmware/modules/source"
MODULES_DIR="/lib/modules"
LOG="/var/log/soplos-vmware-modules-${KVER}.log"
WORK=""

err()     { echo "ERROR: $*" >&2; }
die()     { err "$*"; exit 1; }

cleanup() {
    [ -n "$WORK" ] && rm -rf "$WORK"
    WORK=""
}
trap cleanup EXIT

has_headers() {
    [ -f "${MODULES_DIR}/${KVER}/build/include/generated/utsrelease.h" ]
}

has_vmci_module() {
    local base="${MODULES_DIR}/${KVER}/kernel/drivers/misc/vmw_vmci"
    [ -n "$(find "$base" -maxdepth 1 -name 'vmw_vmci.ko*' 2>/dev/null)" ]
}

build_module() {
    local name="$1"
    echo ">> Building ${name} for ${KVER}..."

    tar -xf "${SRC_DIR}/${name}.tar" -C "$WORK" || {
        err "Could not extract ${name}.tar"
        return 1
    }

    if ! make -C "${WORK}/${name}-only" \
            VM_UNAME="$KVER" \
            VM_KBUILD=yes \
            >>"$LOG" 2>&1; then
        echo "   Build of ${name} failed. Last errors:" >&2
        grep -n "error:" "$LOG" | tail -n 15 >&2
        err "Full log at ${LOG}"
        return 1
    fi

    [ -f "${WORK}/${name}-only/${name}.ko" ] || {
        err "${name}.ko was not generated (see ${LOG})"
        return 1
    }

    echo "   ${name}.ko built."
}

load_modules() {
    echo ">> Loading modules for ${KVER}..."

    if ! lsmod | grep -qE '^vmw_vmci\b'; then
        modprobe vmw_vmci || { err "Could not load vmw_vmci."; return 1; }
    fi

    if lsmod | grep -qE '^(vmmon|vmnet)\b'; then
        modprobe -r vmnet vmmon 2>/dev/null || {
            err "VMware modules are in use."
            err "Close VMware and all VMs, then run again."
            return 1
        }
    fi

    modprobe vmmon || { dmesg | tail -n 15 >&2; err "Could not load vmmon."; return 1; }
    modprobe vmnet || { dmesg | tail -n 15 >&2; err "Could not load vmnet."; return 1; }

    echo "   Modules loaded."
}

main() {
    : >"$LOG"
    echo "=== soplos-vmware-modules: kernel ${KVER} ===" | tee -a "$LOG"

    has_headers || die "No headers for ${KVER}. Install linux-headers-${KVER}."

    has_vmci_module || {
        err "Kernel ${KVER} does not provide vmw_vmci."
        err "Expected at: ${MODULES_DIR}/${KVER}/kernel/drivers/misc/vmw_vmci/"
        exit 1
    }

    [ -d "$SRC_DIR" ] || die "Cannot find $SRC_DIR. Is VMware Workstation installed?"

    for mod in vmmon vmnet; do
        [ -f "${SRC_DIR}/${mod}.tar" ] || die "Missing ${SRC_DIR}/${mod}.tar"
    done

    WORK="$(mktemp -d)" || die "Could not create temporary directory."

    build_module vmmon || exit 1
    build_module vmnet || exit 1

    local dest="${MODULES_DIR}/${KVER}/misc"
    echo ">> Installing into ${dest}..."

    install -d "$dest" \
        && install -m 644 \
            "${WORK}/vmmon-only/vmmon.ko" \
            "${WORK}/vmnet-only/vmnet.ko" \
            "$dest/" \
        && depmod -a "$KVER" \
        || die "Installation failed."

    echo "   vmmon.ko and vmnet.ko installed for ${KVER}."

    if [ "$(uname -r)" = "$KVER" ]; then
        load_modules
    fi

    echo "Done: ${KVER}."
}

main
