#!/bin/bash

# Directorio base del paquete
PKG_DIR="/usr/local/bin/os-update-tyson"

# Configurar permisos
sudo chmod 755 $PKG_DIR/DEBIAN
sudo chmod 644 $PKG_DIR/DEBIAN/control

# Configurar permisos para directorios
find $PKG_DIR -type d -exec sudo chmod 755 {} \;

# Configurar permisos para archivos
find $PKG_DIR -type f -not -path "*/DEBIAN/*" -not -path "*/build-soplos-package.sh" -exec sudo chmod 644 {} \;

# Cambiar propietario a root
sudo chown -R root:root $PKG_DIR

# Construir el paquete
cd /usr/local/bin
sudo dpkg-deb --build os-update-tyson soplos-release_0.0.3_all.deb

# Verificar el paquete
dpkg -I soplos-release_0.0.3_all.deb

echo "Paquete soplos-release_0.0.3_all.deb creado con éxito"
