"""
Drivers tab for Soplos Welcome.
Handles hardware driver detection and installation.
"""

import gi
import os
import subprocess
import threading
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib

from core.i18n_manager import _
from config.paths import ASSETS_DIR
from utils.command_runner import CommandRunner


# Compatibility patch for NVIDIA DKMS sources on Soplos kernel 7.x.
# The VMA locking API changed: VM_REFCNT_EXCLUDE_READERS_FLAG replaces
# VMA_LOCK_OFFSET, and __is_vma_write_locked() takes one argument instead of two.
# Without it the DKMS build fails, no NVIDIA module is produced, and since the
# driver package blacklists nouveau the machine boots with no graphics driver.
# Same patch as soplos-kernel-installer/core/nvidia_dkms_patch.py and the
# nvidia-patches repository.
NV_MMAP_VMA_LOCK_PATCH = r"""--- a/nvidia/nv-mmap.c
+++ b/nvidia/nv-mmap.c
@@ -868,17 +868,24 @@

     nvl->safe_to_mmap = safe_to_mmap;
 }
+#ifndef VM_REFCNT_EXCLUDE_READERS_FLAG
+#define VM_REFCNT_EXCLUDE_READERS_FLAG VMA_LOCK_OFFSET
+#else
+#define NV_VMA_WRITE_LOCKED_ONE_ARG 1
+#endif
+
+

 #if !NV_CAN_CALL_VMA_START_WRITE
 static NvBool nv_vma_enter_locked(struct vm_area_struct *vma, NvBool detaching)
 {
-    NvU32 tgt_refcnt = VMA_LOCK_OFFSET;
+    NvU32 tgt_refcnt = VM_REFCNT_EXCLUDE_READERS_FLAG;
     NvBool interrupted = NV_FALSE;
     if (!detaching)
     {
         tgt_refcnt++;
     }
-    if (!refcount_add_not_zero(VMA_LOCK_OFFSET, &vma->vm_refcnt))
+    if (!refcount_add_not_zero(VM_REFCNT_EXCLUDE_READERS_FLAG, &vma->vm_refcnt))
     {
         return NV_FALSE;
     }
@@ -908,7 +915,7 @@
     if (interrupted)
     {
         // Clean up on error: release refcount and dep_map
-        refcount_sub_and_test(VMA_LOCK_OFFSET, &vma->vm_refcnt);
+        refcount_sub_and_test(VM_REFCNT_EXCLUDE_READERS_FLAG, &vma->vm_refcnt);
         rwsem_release(&vma->vmlock_dep_map, _RET_IP_);
         return NV_FALSE;
     }
@@ -924,7 +931,11 @@
 {
     NvU32 mm_lock_seq;
     NvBool locked;
+#ifdef NV_VMA_WRITE_LOCKED_ONE_ARG
+    if (__is_vma_write_locked(vma))
+#else
     if (__is_vma_write_locked(vma, &mm_lock_seq))
+#endif
         return;

     locked = nv_vma_enter_locked(vma, NV_FALSE);
@@ -933,7 +944,7 @@
     if (locked)
     {
         NvBool detached;
-        detached = refcount_sub_and_test(VMA_LOCK_OFFSET, &vma->vm_refcnt);
+        detached = refcount_sub_and_test(VM_REFCNT_EXCLUDE_READERS_FLAG, &vma->vm_refcnt);
         rwsem_release(&vma->vmlock_dep_map, _RET_IP_);
         WARN_ON_ONCE(detached);
     }
"""

# Fixes missing strncpy() declaration in os-interface.c on Linux 7.2+:
# some kernel header that used to transitively pull in <linux/string.h>
# stopped doing so, and NVIDIA's os_get_current_process_name() never
# included it directly. GCC now errors instead of warning on implicit
# function declarations, so the build fails outright. Same patch as
# soplos-kernel-installer/core/nvidia_dkms_patch.py (NV_STRING_H_PATCH)
# and nvidia-patches/patches/nvidia-string-h-kernel7.2.patch.
NV_STRING_H_PATCH = r"""--- a/nvidia/os-interface.c
+++ b/nvidia/os-interface.c
@@ -35,6 +35,7 @@
 #include <linux/mmzone.h>
 #include <linux/numa.h>
 #include <linux/cpuset.h>
 #include <linux/sys_soc.h>
+#include <linux/string.h>

 extern char *NVreg_TemporaryFilePath;
"""


# Fixes dmem_cgroup_register_region() API change on Linux 7.3+:
# kernel commit e11640b9cea4 ("cgroup/dmem: Introduce struct dmem_cgroup_init
# for region initialization") changed the first argument from a bare u64 size
# to a const struct dmem_cgroup_init *.  NVIDIA 610 (open) passes size
# directly, which GCC rejects with -Wint-conversion on kernel 7.3+.
# Same patch as soplos-kernel-installer/core/nvidia_dkms_patch.py
# (NV_DMEM_CGROUP_INIT_PATCH) and nvidia-patches/patches/nvidia-dmem-kernel7.3.patch.
NV_DMEM_CGROUP_INIT_PATCH = r"""--- a/nvidia/os-interface.c
+++ b/nvidia/os-interface.c
@@ -2818,6 +2818,15 @@
 void* NV_API_CALL os_dmem_cgroup_register_region(NvU64 size, const char *name)
 {
+#if LINUX_VERSION_CODE >= KERNEL_VERSION(7, 3, 0)
+    struct dmem_cgroup_init init = {
+        .size = size,
+        .ops  = NULL,
+        .reclaim_priv = NULL,
+    };
+    void *region = dmem_cgroup_register_region(&init, name);
+#else
     void *region = dmem_cgroup_register_region(size, name);
+#endif
     if (IS_ERR(region))
     {
         return NULL;
"""


# NVIDIA 550 (Debian nvidia-kernel-dkms, 550.163.01) on kernels 7.2+: linux/of_gpio.h
# was removed in 7.1, strncpy() in 7.2, and struct drm_atomic_state became
# struct drm_atomic_commit in 7.2. The patch adds the of_gpio.h compat block that
# NVIDIA 610 already carries, replaces the five strncpy() calls, maps the renamed
# DRM names and forces five nvidia-drm configure-time probes. Same patch as
# nvidia-patches/patches/nvidia-550-kernel7.2-compat.patch.
NV_550_KERNEL72_COMPAT_PATCH = r"""--- a/common/inc/nv-linux.h
+++ b/common/inc/nv-linux.h
@@ -2038,7 +2038,71 @@
 #endif
 
 #if defined(NV_LINUX_OF_GPIO_H_PRESENT)
+#if __has_include(<linux/of_gpio.h>)
 #include <linux/of_gpio.h>
+#else
+#include <linux/gpio/driver.h>
+
+static inline int __to_hwgpio(const struct gpio_device *gdev,
+                              const struct of_phandle_args *gpiospec)
+{
+#if defined(CONFIG_OF_GPIO)
+    /*
+     * Use the chip's of_xlate callback to translate the DT GPIO
+     * specifier into a linear offset.  Tegra GPIO controllers encode
+     * port and pin in args[0] and of_xlate sums per-port pin counts
+     * to produce the real offset.
+     */
+    struct gpio_chip *chip = gpio_device_get_chip(gdev);
+
+    if (chip->of_xlate)
+        return chip->of_xlate(chip, gpiospec, NULL);
+#endif
+
+    return gpiospec->args[0];
+}
+
+/*
+ * of_get_named_gpio() was removed along with linux/of_gpio.h by commit
+ * 51aaf65bbd21 ("gpio: of: Remove <linux/of_gpio.h>"). Provide a compat
+ * implementation using the remaining public GPIO APIs.
+ */
+static inline int of_get_named_gpio(const struct device_node *np,
+                                    const char *propname, int index)
+{
+    struct of_phandle_args gpiospec;
+    struct gpio_device *gdev;
+    struct gpio_desc *desc;
+    int ret, hwgpio;
+
+    if (!np)
+        return -ENOENT;
+
+    ret =
+        of_parse_phandle_with_args_map(np, propname, "gpio", index, &gpiospec);
+    if (ret)
+        return ret;
+
+    gdev = gpio_device_find_by_fwnode(of_fwnode_handle(gpiospec.np));
+    of_node_put(gpiospec.np);
+    if (!gdev)
+        return -EPROBE_DEFER;
+
+    hwgpio = __to_hwgpio(gdev, &gpiospec);
+    if (hwgpio < 0) {
+        gpio_device_put(gdev);
+        return hwgpio;
+    }
+
+    desc = gpio_device_get_desc(gdev, hwgpio);
+    gpio_device_put(gdev);
+
+    if (IS_ERR(desc))
+        return PTR_ERR(desc);
+
+    return desc_to_gpio(desc);
+}
+#endif
 #endif
 
 #if defined(NV_LINUX_OF_DEVICE_H_PRESENT)
--- a/nvidia/os-interface.c
+++ b/nvidia/os-interface.c
@@ -750,8 +750,9 @@
 void NV_API_CALL os_get_current_process_name(char *buf, NvU32 len)
 {
     task_lock(current);
-    strncpy(buf, current->comm, len - 1);
-    buf[len - 1] = '\0';
+    if (strscpy(buf, current->comm, len) < 0) {
+        // strscpy() returns -E2BIG on truncation, which is acceptable here.
+    }
     task_unlock(current);
 }
 
--- a/nvidia/linux_nvswitch.c
+++ b/nvidia/linux_nvswitch.c
@@ -2026,7 +2026,7 @@
         return -NVL_ERR_GENERIC;
     }
 
-    strncpy(regkey_val, regkey_val_start, regkey_val_len);
+    memcpy(regkey_val, regkey_val_start, regkey_val_len);
     regkey_val[regkey_val_len] = '\0';
 
     if (nvswitch_os_strtouint(regkey_val, data) != 0)
@@ -2381,7 +2381,13 @@
     NvLength length
 )
 {
-    return strncpy(dest, src, length);
+    NvLength i;
+
+    for (i = 0; i < length && src[i] != '\0'; i++)
+        dest[i] = src[i];
+    for (; i < length; i++)
+        dest[i] = '\0';
+    return dest;
 }
 
 int
--- a/nvidia-modeset/nvidia-modeset-linux.c
+++ b/nvidia-modeset/nvidia-modeset-linux.c
@@ -351,7 +351,13 @@
 
 char* nvkms_strncpy(char *dest, const char *src, size_t n)
 {
-    return strncpy(dest, src, n);
+    size_t i;
+
+    for (i = 0; i < n && src[i] != '\0'; i++)
+        dest[i] = src[i];
+    for (; i < n; i++)
+        dest[i] = '\0';
+    return dest;
 }
 
 void nvkms_usleep(NvU64 usec)
--- a/nvidia-uvm/uvm_pmm_gpu.c
+++ b/nvidia-uvm/uvm_pmm_gpu.c
@@ -3038,7 +3038,7 @@
             size_t size;
             size_t align;
             if (level == 0) {
-                strncpy(chunk_split_cache[level].name, "uvm_gpu_chunk_t", sizeof(chunk_split_cache[level].name) - 1);
+                strscpy(chunk_split_cache[level].name, "uvm_gpu_chunk_t", sizeof(chunk_split_cache[level].name));
                 size = sizeof(uvm_gpu_chunk_t);
                 align = __alignof__(uvm_gpu_chunk_t);
             } else {
--- a/nvidia-drm/nvidia-drm-conftest.h
+++ b/nvidia-drm/nvidia-drm-conftest.h
@@ -215,4 +215,41 @@
 
 #endif /* defined(NV_BSD) */
 
+/*
+ * Linux 7.2 renamed struct drm_atomic_state to struct drm_atomic_commit and
+ * the helpers that operate on it. Map the old names onto the new ones.
+ */
+#include <linux/version.h>
+#if LINUX_VERSION_CODE >= KERNEL_VERSION(7, 2, 0)
+#define drm_atomic_state                        drm_atomic_commit
+#define drm_atomic_state_alloc                  drm_atomic_commit_alloc
+#define drm_atomic_state_get                    drm_atomic_commit_get
+#define drm_atomic_state_put                    drm_atomic_commit_put
+#define drm_atomic_state_free                   drm_atomic_commit_put
+#define drm_atomic_state_clear                  drm_atomic_commit_clear
+#define drm_atomic_state_default_clear          drm_atomic_commit_default_clear
+#define drm_atomic_state_default_release        drm_atomic_commit_default_release
+#define drm_atomic_state_init                   drm_atomic_commit_init
+
+/*
+ * The configure-time probes below look for struct drm_atomic_state, which no
+ * longer exists, so they report the pre-7.2 behavior. Force the 7.2 behavior.
+ */
+#if !defined(NV_DRM_PLANE_ATOMIC_CHECK_HAS_ATOMIC_STATE_ARG)
+#define NV_DRM_PLANE_ATOMIC_CHECK_HAS_ATOMIC_STATE_ARG
+#endif
+#if !defined(NV_DRM_CRTC_ATOMIC_CHECK_HAS_ATOMIC_STATE_ARG)
+#define NV_DRM_CRTC_ATOMIC_CHECK_HAS_ATOMIC_STATE_ARG
+#endif
+#if !defined(NV_DRM_ATOMIC_STATE_REF_COUNTING_PRESENT)
+#define NV_DRM_ATOMIC_STATE_REF_COUNTING_PRESENT
+#endif
+#if !defined(NV_DRM_ATOMIC_HELPER_SWAP_STATE_HAS_STALL_ARG)
+#define NV_DRM_ATOMIC_HELPER_SWAP_STATE_HAS_STALL_ARG
+#endif
+#if !defined(NV_DRM_ATOMIC_HELPER_SWAP_STATE_RETURN_INT)
+#define NV_DRM_ATOMIC_HELPER_SWAP_STATE_RETURN_INT
+#endif
+#endif
+
 #endif /* defined(__NVIDIA_DRM_CONFTEST_H__) */
"""


# NVIDIA 590 open modules (590.48.01, nvidia-open-590) on kernels 7.2+: the same
# of_gpio.h / strncpy() / DRM atomic commit fixes as the 550 patch above, plus the
# nvidia-uvm changes NVIDIA 610 already carries (dev_pagemap_ops page_free became
# folio_free, and zone_device_page_init() takes the pgmap and an order), backported
# through two conftest.sh probes. Applied from kernel-open/ after the VMA patch.
# Same patch as nvidia-patches/patches/nvidia-590-kernel7.2-compat.patch.
NV_590_KERNEL72_COMPAT_PATCH = r"""--- a/common/inc/nv-linux.h
+++ b/common/inc/nv-linux.h
@@ -1714,7 +1714,71 @@
 #include <linux/reset.h>
 #include <linux/dma-buf.h>
 #include <linux/gpio.h>
+#if __has_include(<linux/of_gpio.h>)
 #include <linux/of_gpio.h>
+#else
+#include <linux/gpio/driver.h>
+
+static inline int __to_hwgpio(const struct gpio_device *gdev,
+                              const struct of_phandle_args *gpiospec)
+{
+#if defined(CONFIG_OF_GPIO)
+    /*
+     * Use the chip's of_xlate callback to translate the DT GPIO
+     * specifier into a linear offset.  Tegra GPIO controllers encode
+     * port and pin in args[0] and of_xlate sums per-port pin counts
+     * to produce the real offset.
+     */
+    struct gpio_chip *chip = gpio_device_get_chip(gdev);
+
+    if (chip->of_xlate)
+        return chip->of_xlate(chip, gpiospec, NULL);
+#endif
+
+    return gpiospec->args[0];
+}
+
+/*
+ * of_get_named_gpio() was removed along with linux/of_gpio.h by commit
+ * 51aaf65bbd21 ("gpio: of: Remove <linux/of_gpio.h>"). Provide a compat
+ * implementation using the remaining public GPIO APIs.
+ */
+static inline int of_get_named_gpio(const struct device_node *np,
+                                    const char *propname, int index)
+{
+    struct of_phandle_args gpiospec;
+    struct gpio_device *gdev;
+    struct gpio_desc *desc;
+    int ret, hwgpio;
+
+    if (!np)
+        return -ENOENT;
+
+    ret =
+        of_parse_phandle_with_args_map(np, propname, "gpio", index, &gpiospec);
+    if (ret)
+        return ret;
+
+    gdev = gpio_device_find_by_fwnode(of_fwnode_handle(gpiospec.np));
+    of_node_put(gpiospec.np);
+    if (!gdev)
+        return -EPROBE_DEFER;
+
+    hwgpio = __to_hwgpio(gdev, &gpiospec);
+    if (hwgpio < 0) {
+        gpio_device_put(gdev);
+        return hwgpio;
+    }
+
+    desc = gpio_device_get_desc(gdev, hwgpio);
+    gpio_device_put(gdev);
+
+    if (IS_ERR(desc))
+        return PTR_ERR(desc);
+
+    return desc_to_gpio(desc);
+}
+#endif
 #include <linux/of_device.h>
 #include <linux/of_platform.h>
 
--- a/nvidia/os-interface.c
+++ b/nvidia/os-interface.c
@@ -759,8 +759,9 @@
 void NV_API_CALL os_get_current_process_name(char *buf, NvU32 len)
 {
     task_lock(current);
-    strncpy(buf, current->comm, len - 1);
-    buf[len - 1] = '\0';
+    if (strscpy(buf, current->comm, len) < 0) {
+        // strscpy() returns -E2BIG on truncation, which is acceptable here.
+    }
     task_unlock(current);
 }
 
--- a/nvidia/linux_nvswitch.c
+++ b/nvidia/linux_nvswitch.c
@@ -2059,7 +2059,7 @@
         return -NVL_ERR_GENERIC;
     }
 
-    strncpy(regkey_val, regkey_val_start, regkey_val_len);
+    memcpy(regkey_val, regkey_val_start, regkey_val_len);
     regkey_val[regkey_val_len] = '\0';
 
     if (nvswitch_os_strtouint(regkey_val, data) != 0)
@@ -2414,7 +2414,13 @@
     NvLength length
 )
 {
-    return strncpy(dest, src, length);
+    NvLength i;
+
+    for (i = 0; i < length && src[i] != '\0'; i++)
+        dest[i] = src[i];
+    for (; i < length; i++)
+        dest[i] = '\0';
+    return dest;
 }
 
 int
--- a/nvidia-modeset/nvidia-modeset-linux.c
+++ b/nvidia-modeset/nvidia-modeset-linux.c
@@ -647,7 +647,13 @@
 
 char* nvkms_strncpy(char *dest, const char *src, size_t n)
 {
-    return strncpy(dest, src, n);
+    size_t i;
+
+    for (i = 0; i < n && src[i] != '\0'; i++)
+        dest[i] = src[i];
+    for (; i < n; i++)
+        dest[i] = '\0';
+    return dest;
 }
 
 void nvkms_usleep(NvU64 usec)
--- a/nvidia-uvm/uvm_pmm_gpu.c
+++ b/nvidia-uvm/uvm_pmm_gpu.c
@@ -2786,7 +2786,7 @@
             size_t size;
             size_t align;
             if (level == 0) {
-                strncpy(chunk_split_cache[level].name, "uvm_gpu_chunk_t", sizeof(chunk_split_cache[level].name) - 1);
+                strscpy(chunk_split_cache[level].name, "uvm_gpu_chunk_t", sizeof(chunk_split_cache[level].name));
                 size = sizeof(uvm_gpu_chunk_t);
                 align = __alignof__(uvm_gpu_chunk_t);
             } else {
@@ -3058,9 +3058,20 @@
     UVM_ENTRY_RET(devmem_fault(vmf));
 }
 
+#if defined(NV_PAGEMAP_OPS_HAS_FOLIO_FREE)
+static void devmem_folio_free(struct folio *folio)
+{
+    devmem_page_free(&folio->page);
+}
+#endif
+
 static const struct dev_pagemap_ops uvm_pmm_devmem_ops =
 {
+#if defined(NV_PAGEMAP_OPS_HAS_FOLIO_FREE)
+    .folio_free = devmem_folio_free,
+#else
     .page_free = devmem_page_free,
+#endif
     .migrate_to_ram = devmem_fault_entry,
 };
 
@@ -3163,9 +3174,20 @@
     device_p2p_page_free(page);
 }
 
+#if defined(NV_PAGEMAP_OPS_HAS_FOLIO_FREE)
+static void device_coherent_folio_free(struct folio *folio)
+{
+    device_coherent_page_free(&folio->page);
+}
+#endif
+
 static const struct dev_pagemap_ops uvm_device_coherent_pgmap_ops =
 {
+#if defined(NV_PAGEMAP_OPS_HAS_FOLIO_FREE)
+    .folio_free = device_coherent_folio_free,
+#else
     .page_free = device_coherent_page_free,
+#endif
 };
 
 static NV_STATUS uvm_pmm_cdmm_init(uvm_parent_gpu_t *parent_gpu)
@@ -3300,9 +3322,20 @@
 // ARM
 #if defined(CONFIG_PCI_P2PDMA) && defined(NV_STRUCT_PAGE_HAS_ZONE_DEVICE_DATA) && !defined(NVCPU_AARCH64)
 
+#if defined(NV_PAGEMAP_OPS_HAS_FOLIO_FREE)
+static void device_p2p_folio_free(struct folio *folio)
+{
+    device_p2p_page_free(&folio->page);
+}
+#endif
+
 static const struct dev_pagemap_ops uvm_device_p2p_pgmap_ops =
 {
+#if defined(NV_PAGEMAP_OPS_HAS_FOLIO_FREE)
+    .folio_free = device_p2p_folio_free,
+#else
     .page_free = device_p2p_page_free,
+#endif
 };
 
 void uvm_pmm_gpu_device_p2p_init(uvm_parent_gpu_t *parent_gpu)
--- a/nvidia-uvm/uvm_hmm.c
+++ b/nvidia-uvm/uvm_hmm.c
@@ -74,6 +74,19 @@
 #include "uvm_va_policy.h"
 #include "uvm_tools.h"
 
+//
+// Pass 0 as the order, when actual large order support is added this
+// function will need to be revisited
+//
+static __always_inline void nv_zone_device_page_init(struct page *page)
+{
+#if defined(NV_ZONE_DEVICE_PAGE_INIT_HAS_PGMAP_AND_ORDER_ARGS)
+    zone_device_page_init(page, page_pgmap(page), 0);
+#else
+    zone_device_page_init(page);
+#endif
+}
+
 // The function nv_PageSwapCache() wraps the check for page swap cache flag in
 // order to support a wide variety of kernel versions.
 // The function PageSwapCache() is removed after 32f51ead3d77 ("mm: remove
@@ -2140,7 +2153,7 @@
 
         UVM_ASSERT(!page_count(dpage));
         UVM_ASSERT(!dpage->zone_device_data);
-        zone_device_page_init(dpage);
+        nv_zone_device_page_init(dpage);
         dpage->zone_device_data = gpu_chunk;
         atomic64_inc(&va_block->hmm.va_space->hmm.allocated_page_count);
     }
--- a/nvidia-uvm/nvidia-uvm.Kbuild
+++ b/nvidia-uvm/nvidia-uvm.Kbuild
@@ -68,6 +68,8 @@
 NV_CONFTEST_TYPE_COMPILE_TESTS += mmu_interval_notifier
 NV_CONFTEST_TYPE_COMPILE_TESTS += sg_dma_page_iter
 NV_CONFTEST_TYPE_COMPILE_TESTS += struct_page_has_zone_device_data
+NV_CONFTEST_TYPE_COMPILE_TESTS += dev_pagemap_ops_has_folio_free
+NV_CONFTEST_TYPE_COMPILE_TESTS += zone_device_page_init_has_pgmap_and_order_args
 NV_CONFTEST_TYPE_COMPILE_TESTS += memory_device_coherent_present
 
 NV_CONFTEST_SYMBOL_COMPILE_TESTS += is_export_symbol_present_int_active_memcg
--- a/nvidia-drm/nvidia-drm-conftest.h
+++ b/nvidia-drm/nvidia-drm-conftest.h
@@ -207,4 +207,41 @@
 
 #endif /* defined(NV_BSD) */
 
+/*
+ * Linux 7.2 renamed struct drm_atomic_state to struct drm_atomic_commit and
+ * the helpers that operate on it. Map the old names onto the new ones.
+ */
+#include <linux/version.h>
+#if LINUX_VERSION_CODE >= KERNEL_VERSION(7, 2, 0)
+#define drm_atomic_state                        drm_atomic_commit
+#define drm_atomic_state_alloc                  drm_atomic_commit_alloc
+#define drm_atomic_state_get                    drm_atomic_commit_get
+#define drm_atomic_state_put                    drm_atomic_commit_put
+#define drm_atomic_state_free                   drm_atomic_commit_put
+#define drm_atomic_state_clear                  drm_atomic_commit_clear
+#define drm_atomic_state_default_clear          drm_atomic_commit_default_clear
+#define drm_atomic_state_default_release        drm_atomic_commit_default_release
+#define drm_atomic_state_init                   drm_atomic_commit_init
+
+/*
+ * The configure-time probes below look for struct drm_atomic_state, which no
+ * longer exists, so they report the pre-7.2 behavior. Force the 7.2 behavior.
+ */
+#if !defined(NV_DRM_PLANE_ATOMIC_CHECK_HAS_ATOMIC_STATE_ARG)
+#define NV_DRM_PLANE_ATOMIC_CHECK_HAS_ATOMIC_STATE_ARG
+#endif
+#if !defined(NV_DRM_CRTC_ATOMIC_CHECK_HAS_ATOMIC_STATE_ARG)
+#define NV_DRM_CRTC_ATOMIC_CHECK_HAS_ATOMIC_STATE_ARG
+#endif
+#if !defined(NV_DRM_ATOMIC_STATE_REF_COUNTING_PRESENT)
+#define NV_DRM_ATOMIC_STATE_REF_COUNTING_PRESENT
+#endif
+#if !defined(NV_DRM_ATOMIC_HELPER_SWAP_STATE_HAS_STALL_ARG)
+#define NV_DRM_ATOMIC_HELPER_SWAP_STATE_HAS_STALL_ARG
+#endif
+#if !defined(NV_DRM_ATOMIC_HELPER_SWAP_STATE_RETURN_INT)
+#define NV_DRM_ATOMIC_HELPER_SWAP_STATE_RETURN_INT
+#endif
+#endif
+
 #endif /* defined(__NVIDIA_DRM_CONFTEST_H__) */
--- a/conftest.sh
+++ b/conftest.sh
@@ -4747,6 +4747,56 @@
             compile_check_conftest "$CODE" "NV_DRM_APERTURE_REMOVE_CONFLICTING_FRAMEBUFFERS_HAS_NO_PRIMARY_ARG" "" "types"
         ;;
 
+        zone_device_page_init_has_pgmap_and_order_args)
+            #
+            # Determine if the zone_device_page_init() has two additional
+            # arguments
+            #
+            # This change was introduced by d245f9b4ab80
+            # ("mm/zone_device: support large zone device private folios")
+            #
+            # It was further amended in 9387a71ec62c
+            # (mm/zone_device: reinitialize large zone device private folios)
+            #
+            # both commits are in linux-next, expected in v6.19.
+            #
+            CODE="
+            #include <linux/memremap.h>
+
+            void init_page(void) {
+                struct page *page;
+                struct dev_pagemap *pgmap;
+
+                zone_device_page_init(page, pgmap, 0);
+            }"
+
+            compile_check_conftest "$CODE" "NV_ZONE_DEVICE_PAGE_INIT_HAS_PGMAP_AND_ORDER_ARGS" "" "types"
+        ;;
+
+        dev_pagemap_ops_has_folio_free)
+            #
+            # Determine if the zone device now uses a folio_free() as the callback
+            # function instead of page_free()
+            #
+            # This change was introduced by 3a5a06554566
+            # (mm/zone_device: rename page_free callback to folio_free)
+            #
+            # in linux-next, expected in v6.19.
+            #
+            CODE="
+            #include <linux/memremap.h>
+
+            void test_folio_free(struct folio *folio) {
+            }
+
+            void set_folio_free_ops(void) {
+                struct dev_pagemap_ops ops;
+                ops.folio_free = test_folio_free;
+            }"
+
+            compile_check_conftest "$CODE" "NV_PAGEMAP_OPS_HAS_FOLIO_FREE" "" "types"
+        ;;
+
         struct_page_has_zone_device_data)
             #
             # Determine if struct page has a 'zone_device_data' field.
"""


def get_nvidia_dkms_patch_commands() -> str:
    """
    Return a shell fragment that patches every NVIDIA source tree under
    /usr/src/nvidia-*/ and rebuilds the modules.

    Idempotent: source trees already patched are skipped. Safe on any kernel,
    all patches are guarded (#ifndef / LINUX_VERSION_CODE, or a plain "already
    applied" grep).
    """
    mmap_patch = NV_MMAP_VMA_LOCK_PATCH.replace("'", "'\\''")
    string_h_patch = NV_STRING_H_PATCH.replace("'", "'\\''")
    dmem_patch = NV_DMEM_CGROUP_INIT_PATCH.replace("'", "'\\''")
    compat550_patch = NV_550_KERNEL72_COMPAT_PATCH.replace("'", "'\\''")
    compat590_patch = NV_590_KERNEL72_COMPAT_PATCH.replace("'", "'\\''")

    # The proprietary module keeps its sources at <src>/nvidia/, the open one
    # at <src>/kernel-open/nvidia/. Both layouts must be handled: checking only
    # the first silently skipped every nvidia-open install.
    #
    # Each patch is applied independently — one file missing/already-patched
    # must not skip the check for the other file.
    return (
        "for NVIDIA_SRC in /usr/src/nvidia-*/; do "
        "  for NV_SUB in '' 'kernel-open/'; do "
        "    NV_ROOT=\"${NVIDIA_SRC}${NV_SUB}\"; "
        "    NV_MMAP=\"${NV_ROOT}nvidia/nv-mmap.c\"; "
        "    if [ -f \"$NV_MMAP\" ]; then "
        "      if grep -q 'VM_REFCNT_EXCLUDE_READERS_FLAG' \"$NV_MMAP\" 2>/dev/null; then "
        "        echo \"NVIDIA VMA patch already applied in ${NV_ROOT} - skipping.\"; "
        "      elif ! grep -q 'VMA_LOCK_OFFSET' \"$NV_MMAP\" 2>/dev/null; then "
        "        echo \"${NV_ROOT} does not use VMA_LOCK_OFFSET - patch not needed.\"; "
        "      else "
        "        echo \"Applying NVIDIA VMA lock patch to ${NV_ROOT}...\"; "
        f"        printf '%s' '{mmap_patch}' | patch --fuzz=5 -p1 -d \"$NV_ROOT\" && "
        "        echo \"NVIDIA VMA patch applied.\" || "
        "        echo \"Warning: NVIDIA VMA patch failed for ${NV_ROOT} - DKMS may fail.\"; "
        "      fi; "
        "    fi; "
        "    NV_OSIF=\"${NV_ROOT}nvidia/os-interface.c\"; "
        "    if [ -f \"$NV_OSIF\" ]; then "
        "      if grep -q '#include <linux/string.h>' \"$NV_OSIF\" 2>/dev/null; then "
        "        echo \"NVIDIA string.h patch already applied in ${NV_ROOT} - skipping.\"; "
        "      else "
        "        echo \"Applying NVIDIA string.h patch to ${NV_ROOT}...\"; "
        f"        printf '%s' '{string_h_patch}' | patch --fuzz=5 -p1 -d \"$NV_ROOT\" && "
        "        echo \"NVIDIA string.h patch applied.\" || "
        "        echo \"Warning: NVIDIA string.h patch failed for ${NV_ROOT} - DKMS may fail.\"; "
        "      fi; "
        "      if grep -q 'NV_USE_DMEM_CGROUP_API' \"$NV_OSIF\" 2>/dev/null; then "
        "        if grep -q 'dmem_cgroup_register_region(&init' \"$NV_OSIF\" 2>/dev/null; then "
        "          echo \"NVIDIA dmem cgroup init patch already applied in ${NV_ROOT} - skipping.\"; "
        "        elif grep -q 'dmem_cgroup_register_region(size' \"$NV_OSIF\" 2>/dev/null; then "
        "          echo \"Applying NVIDIA dmem cgroup init patch to ${NV_ROOT}...\"; "
        f"          printf '%s' '{dmem_patch}' | patch --fuzz=5 -p1 -d \"$NV_ROOT\" && "
        "          echo \"NVIDIA dmem cgroup init patch applied.\" || "
        "          echo \"Warning: NVIDIA dmem cgroup init patch failed for ${NV_ROOT} - DKMS may fail.\"; "
        "        fi; "
        "      fi; "
        "    fi; "
        "    NV_LINUXH=\"${NV_ROOT}common/inc/nv-linux.h\"; "
        "    if [ -f \"$NV_LINUXH\" ] && [ -f \"$NV_OSIF\" ] && "
        "       grep -q 'NV_LINUX_OF_GPIO_H_PRESENT' \"$NV_LINUXH\" 2>/dev/null && "
        "       grep -q '^#include <linux/of_gpio.h>' \"$NV_LINUXH\" 2>/dev/null && "
        "       ! grep -q '__has_include(<linux/of_gpio.h>)' \"$NV_LINUXH\" 2>/dev/null && "
        "       grep -q 'strncpy(buf, current->comm, len - 1)' \"$NV_OSIF\" 2>/dev/null; then "
        f"      NV_P550='{compat550_patch}'; "
        "      if printf '%s' \"$NV_P550\" | patch --fuzz=5 -p1 -d \"$NV_ROOT\" --dry-run > /dev/null 2>&1; then "
        "        echo \"Applying NVIDIA 550 kernel 7.2+ compatibility patch to ${NV_ROOT}...\"; "
        "        printf '%s' \"$NV_P550\" | patch --fuzz=5 -p1 -d \"$NV_ROOT\" && "
        "        echo \"NVIDIA 550 compatibility patch applied.\" || "
        "        echo \"Warning: NVIDIA 550 compatibility patch failed for ${NV_ROOT} - DKMS may fail.\"; "
        "      else "
        "        echo \"Warning: NVIDIA 550 compatibility patch does not apply cleanly to ${NV_ROOT} - DKMS may fail.\"; "
        "      fi; "
        "    fi; "
        "    NV_UVMHMM=\"${NV_ROOT}nvidia-uvm/uvm_hmm.c\"; "
        "    if [ -f \"$NV_LINUXH\" ] && [ -f \"$NV_OSIF\" ] && [ -f \"$NV_UVMHMM\" ] && "
        "       ! grep -q 'NV_LINUX_OF_GPIO_H_PRESENT' \"$NV_LINUXH\" 2>/dev/null && "
        "       grep -q '^#include <linux/of_gpio.h>' \"$NV_LINUXH\" 2>/dev/null && "
        "       ! grep -q '__has_include(<linux/of_gpio.h>)' \"$NV_LINUXH\" 2>/dev/null && "
        "       grep -q 'strncpy(buf, current->comm, len - 1)' \"$NV_OSIF\" 2>/dev/null; then "
        f"      NV_P590='{compat590_patch}'; "
        "      if printf '%s' \"$NV_P590\" | patch --fuzz=5 -p1 -d \"$NV_ROOT\" --dry-run > /dev/null 2>&1; then "
        "        echo \"Applying NVIDIA 590 kernel 7.2+ compatibility patch to ${NV_ROOT}...\"; "
        "        printf '%s' \"$NV_P590\" | patch --fuzz=5 -p1 -d \"$NV_ROOT\" && "
        "        echo \"NVIDIA 590 compatibility patch applied.\" || "
        "        echo \"Warning: NVIDIA 590 compatibility patch failed for ${NV_ROOT} - DKMS may fail.\"; "
        "      else "
        "        echo \"Warning: NVIDIA 590 compatibility patch does not apply cleanly to ${NV_ROOT} - DKMS may fail.\"; "
        "      fi; "
        "    fi; "
        "  done; "
        "done"
    )


# XanMod kernels are built with LLVM/Clang (CONFIG_CC_IS_CLANG, CONFIG_LD_IS_LLD).
# DKMS has to build its modules with the same toolchain, so on those kernels a
# gcc-only system cannot build the NVIDIA or VirtualBox modules at all: the build
# fails and the machine ends up with no driver. The check reads the running
# kernel's own config, so nothing is installed on a normal gcc-built kernel.
LLVM_DKMS_TOOLCHAIN = """
if grep -q "CONFIG_CC_IS_CLANG=y" "/boot/config-$(uname -r)" 2>/dev/null; then
    echo "This kernel was built with LLVM/Clang: installing the toolchain DKMS needs..."
    apt install -y clang lld llvm
fi
"""


class DriversTab(Gtk.ScrolledWindow):
    """
    Hardware drivers management tab.
    """
    
    def __init__(self, i18n_manager, theme_manager, environment_detector, parent_window, progress_bar, progress_label):
        super().__init__()
        self.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        
        self.i18n_manager = i18n_manager
        self.theme_manager = theme_manager
        self.environment_detector = environment_detector
        self.parent_window = parent_window
        self.progress_bar = progress_bar
        self.progress_label = progress_label
        
        # Create CommandRunner
        self.command_runner = CommandRunner(self.progress_bar, self.progress_label, self.parent_window)

        # key → {'button', 'handler_id', 'base_label', 'install_fn', 'uninstall_fn', 'check_fn'}
        self._driver_buttons = {}

        # Main container
        self.drivers_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=15)
        self.drivers_box.set_margin_left(20)
        self.drivers_box.set_margin_right(20)
        self.drivers_box.set_margin_top(20)
        self.drivers_box.set_margin_bottom(20)
        
        self.add(self.drivers_box)
        self._create_ui()
        self._refresh_driver_status()
    
    def _create_ui(self):
        """Create the drivers tab interface."""
        # Header
        header = Gtk.Label()
        header.set_markup(f'<span size="20000" weight="bold">{_("Hardware Drivers")}</span>')
        header.set_halign(Gtk.Align.START)
        self.drivers_box.pack_start(header, False, False, 0)
        
        subtitle = Gtk.Label()
        subtitle.set_markup(f'<span size="12000">{_("Install and manage all hardware drivers: graphics, Wi-Fi, audio, Bluetooth, printers and more")}</span>')
        subtitle.set_halign(Gtk.Align.START)
        subtitle.get_style_context().add_class('dim-label')
        self.drivers_box.pack_start(subtitle, False, False, 0)
        
        # Separator
        self.drivers_box.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 10)

        # --- Broken repository notice (only visible when leftovers are found) ---
        self._create_repo_repair_section()

        # --- Hardware Scan Button (at the top for easy access) ---
        scan_label = Gtk.Label()
        scan_label.set_markup(f'<span weight="bold" size="14000">{_("Hardware Detection")}</span>')
        scan_label.set_halign(Gtk.Align.START)
        self.drivers_box.pack_start(scan_label, False, False, 5)
        
        scan_btn = self._create_button(
            _("Scan Hardware"),
            _("Automatically detect hardware and recommend drivers")
        )
        scan_btn.connect("clicked", self._on_scan_hardware)
        self.drivers_box.pack_start(scan_btn, False, False, 5)
        
        # Separator
        self.drivers_box.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 10)
        
        # --- NVIDIA Section ---
        self._create_nvidia_section()
        
        # Separator
        self.drivers_box.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 10)
        
        # --- NVIDIA Hybrid Section ---
        self._create_nvidia_hybrid_section()
        
        # Separator
        self.drivers_box.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 10)
        
        # --- NVIDIA Extras Section ---
        self._create_nvidia_extras_section()
        
        # Separator
        self.drivers_box.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 10)
        
        # --- AMD Section ---
        self._create_amd_section()

        # Separator
        self.drivers_box.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 10)

        # --- AMD Extras Section ---
        self._create_amd_extras_section()

        # Separator
        self.drivers_box.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 10)

        # --- Intel Extras Section ---
        self._create_intel_extras_section()

        # Separator
        self.drivers_box.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 10)

        # --- Wi-Fi Section ---
        self._create_wifi_section()
        
        # Separator
        self.drivers_box.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 10)
        
        # --- Other Drivers Section ---
        self._create_other_section()
        
        # Separator
        self.drivers_box.pack_start(Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL), False, False, 10)
        
        # --- VM Tools Section ---
        self._create_vm_section()

        self.show_all()
    
    def _has_broken_rocm_repo(self):
        """Check for a ROCm repository pointing at a suite AMD does not publish."""
        try:
            with open('/etc/apt/sources.list.d/rocm.list', 'r') as f:
                content = f.read()
        except Exception:
            return False

        if 'repo.radeon.com' not in content:
            return False

        # AMD only publishes Ubuntu suites; anything else breaks every apt update
        broken_suites = ('trixie', 'forky', 'bookworm', 'sid', 'testing', 'unstable', 'debian')
        for line in content.splitlines():
            if 'repo.radeon.com' not in line:
                continue
            if any(suite in line.split() for suite in broken_suites):
                return True
        return False

    def _create_repo_repair_section(self):
        """Create the container for the broken repository notice."""
        self._repo_repair_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.drivers_box.pack_start(self._repo_repair_box, False, False, 5)
        self._refresh_repo_repair_section()

    def _refresh_repo_repair_section(self):
        """Show the repair notice only while a broken repository is present."""
        for child in self._repo_repair_box.get_children():
            self._repo_repair_box.remove(child)

        if not self._has_broken_rocm_repo():
            # set_no_show_all survives the show_all() call of the parent container
            self._repo_repair_box.set_no_show_all(True)
            self._repo_repair_box.hide()
            return

        self._repo_repair_box.set_no_show_all(False)

        warning = Gtk.Label()
        warning.set_markup(
            f"<span color='#ffb86c' weight='bold'>{_('Broken ROCm repository detected')}</span>\n"
            f"<small>{_('A previous version added an AMD repository that does not exist, and it makes every system update fail. Repairing removes it, and you can install ROCm again afterwards.')}</small>"
        )
        warning.set_line_wrap(True)
        warning.set_xalign(0)
        self._repo_repair_box.pack_start(warning, False, False, 0)

        repair_btn = Gtk.Button(label=_("Repair repository"))
        repair_btn.get_style_context().add_class("suggested-action")
        repair_btn.set_halign(Gtk.Align.START)
        repair_btn.connect("clicked", self._on_repair_rocm_repo_clicked)
        self._repo_repair_box.pack_start(repair_btn, False, False, 0)

        self._repo_repair_box.show_all()

    def _on_repair_rocm_repo_clicked(self, button):
        """Remove the broken ROCm repository left behind by earlier versions."""
        script = """#!/bin/bash
echo "=== Repairing ROCm repository ==="
rm -f /etc/apt/sources.list.d/rocm.list
rm -f /etc/apt/keyrings/rocm.gpg
rm -f /etc/apt/preferences.d/rocm-pin-600
apt update -q || true
echo "[+] Broken repository removed."
"""
        self._run_script_as_root(script, "repair-rocm-repo.sh", self._on_repo_repair_complete)

    def _on_repo_repair_complete(self, success=True):
        """Refresh the notice once the repair finished."""
        GLib.timeout_add(1000, self._refresh_repo_repair_section)
        self._refresh_driver_status()

    def _create_nvidia_section(self):
        """Create NVIDIA drivers section."""
        label = Gtk.Label()
        label.set_markup(f'<span weight="bold" size="14000">{_("NVIDIA Graphics Drivers")}</span>')
        label.set_halign(Gtk.Align.START)
        self.drivers_box.pack_start(label, False, False, 5)

        grid = Gtk.Grid()
        grid.set_column_spacing(10)
        grid.set_row_spacing(10)
        grid.set_column_homogeneous(True)
        self.drivers_box.pack_start(grid, False, False, 5)

        # Row 0
        nvidia_610 = self._create_button(
            _("NVIDIA 610 (Latest)"),
            _("Blackwell and newer: RTX 50/60 series and latest hardware")
        )
        grid.attach(nvidia_610, 0, 0, 1, 1)
        self._driver_buttons['nvidia_610'] = {
            'button': nvidia_610, 'handler_id': None,
            'base_label': _("NVIDIA 610 (Latest)"),
            'install_fn': lambda b: self._on_nvidia_cuda_repo_clicked(b, '610'),
            'uninstall_fn': lambda b: self._on_uninstall_nvidia_clicked(b),
            'check_fn': lambda: self._get_nvidia_active_version() == '610',
        }

        nvidia_590 = self._create_button(
            _("NVIDIA 590 (Stable)"),
            _("Turing and newer: GTX 1650/1660, RTX 20/30/40/50 series")
        )
        grid.attach(nvidia_590, 1, 0, 1, 1)
        self._driver_buttons['nvidia_590'] = {
            'button': nvidia_590, 'handler_id': None,
            'base_label': _("NVIDIA 590 (Stable)"),
            'install_fn': lambda b: self._on_nvidia_cuda_repo_clicked(b, '590'),
            'uninstall_fn': lambda b: self._on_uninstall_nvidia_clicked(b),
            'check_fn': lambda: self._get_nvidia_active_version() == '590',
        }

        # Row 1
        nvidia_580 = self._create_button(
            _("NVIDIA 580 (Production)"),
            _("Universal driver: Maxwell to Blackwell (GTX 900 → RTX 5000)")
        )
        grid.attach(nvidia_580, 0, 1, 1, 1)
        self._driver_buttons['nvidia_580'] = {
            'button': nvidia_580, 'handler_id': None,
            'base_label': _("NVIDIA 580 (Production)"),
            'install_fn': lambda b: self._on_nvidia_cuda_repo_clicked(b, '580'),
            'uninstall_fn': lambda b: self._on_uninstall_nvidia_clicked(b),
            'check_fn': lambda: self._get_nvidia_active_version() == '580',
        }

        nvidia_550 = self._create_button(
            _("NVIDIA 550 (Repo)"),
            _("Maxwell to Ada Lovelace (GTX 900, GTX 10xx/16xx, RTX 20/30/40)")
        )
        grid.attach(nvidia_550, 1, 1, 1, 1)
        self._driver_buttons['nvidia_550'] = {
            'button': nvidia_550, 'handler_id': None,
            'base_label': _("NVIDIA 550 (Repo)"),
            'install_fn': lambda b: self._on_nvidia_repo_clicked(b, 'nvidia-driver'),
            'uninstall_fn': lambda b: self._on_uninstall_nvidia_clicked(b),
            'check_fn': lambda: self._get_nvidia_active_version() == '550',
        }

        # Row 2
        nvidia_470 = self._create_button(
            _("NVIDIA 470 (Legacy)"),
            _("Kepler to Ampere (GTX 600/700/900/10xx, RTX 20/30 series)")
        )
        grid.attach(nvidia_470, 0, 2, 1, 1)
        self._driver_buttons['nvidia_470'] = {
            'button': nvidia_470, 'handler_id': None,
            'base_label': _("NVIDIA 470 (Legacy)"),
            'install_fn': lambda b: self._on_legacy_nvidia_clicked(b, 'nvidia-tesla-470-driver'),
            'uninstall_fn': lambda b: self._on_uninstall_nvidia_clicked(b),
            'check_fn': lambda: self._is_package_installed('nvidia-tesla-470-driver'),
        }

        nvidia_390 = self._create_button(
            _("NVIDIA 390 (Legacy)"),
            _("Fermi and Kepler (GTX 400/500/600/700 series)")
        )
        grid.attach(nvidia_390, 1, 2, 1, 1)
        self._driver_buttons['nvidia_390'] = {
            'button': nvidia_390, 'handler_id': None,
            'base_label': _("NVIDIA 390 (Legacy)"),
            'install_fn': lambda b: self._on_legacy_nvidia_clicked(b, 'nvidia-legacy-390xx-driver'),
            'uninstall_fn': lambda b: self._on_uninstall_nvidia_clicked(b),
            'check_fn': lambda: self._is_package_installed('nvidia-legacy-390xx-driver'),
        }

        # Row 3
        nvidia_340 = self._create_button(
            _("NVIDIA 340 (Legacy)"),
            _("Tesla architecture (GeForce 8/9/100/200/300 series)")
        )
        grid.attach(nvidia_340, 0, 3, 1, 1)
        self._driver_buttons['nvidia_340'] = {
            'button': nvidia_340, 'handler_id': None,
            'base_label': _("NVIDIA 340 (Legacy)"),
            'install_fn': lambda b: self._on_legacy_nvidia_clicked(b, 'nvidia-legacy-340xx-driver'),
            'uninstall_fn': lambda b: self._on_uninstall_nvidia_clicked(b),
            'check_fn': lambda: self._is_package_installed('nvidia-legacy-340xx-driver'),
        }

        nouveau = self._create_button(
            _("Nouveau (Open Source)"),
            _("Free and open source NVIDIA driver")
        )
        grid.attach(nouveau, 1, 3, 1, 1)
        self._driver_buttons['nouveau'] = {
            'button': nouveau, 'handler_id': None,
            'base_label': _("Nouveau (Open Source)"),
            'install_fn': lambda b: self._on_nouveau_clicked(b),
            # Both states lead to the same handler: there is nothing to install
            # (nouveau ships with the kernel) and nothing that should ever be
            # uninstalled. Purging xserver-xorg-video-nouveau here used to be
            # offered, which on Tyron stripped the Xorg driver and on Boro and
            # Tyson did nothing at all, since they are Wayland.
            'uninstall_fn': lambda b: self._on_nouveau_clicked(b),
            'check_fn': lambda: self._is_nouveau_active(),
        }

        # Row 4
        uninstall_nvidia = self._create_button(
            _("Uninstall NVIDIA Drivers"),
            _("Remove all NVIDIA packages completely before switching drivers")
        )
        uninstall_nvidia.connect("clicked", self._on_uninstall_nvidia_clicked)
        grid.attach(uninstall_nvidia, 0, 4, 2, 1)

        self._apply_nvidia_compatibility_guards()

    # Branches 590 and 610 only cover Turing and newer, per NVIDIA's supported
    # products list. Installing them on an older card leaves the machine without
    # a working module, and since the NVIDIA package blacklists nouveau, without
    # any graphics driver at all.
    #
    # The marker list itself lives in utils/hardware_detector.py so this guard
    # and the driver recommendation of the hardware scan cannot disagree: they
    # used to keep separate lists, and this one was missing the professional
    # Turing parts (Quadro T400/T600/T1000, Tesla T4), so it disabled the 610
    # button on cards that do support it.
    def _is_turing_plus(self, model):
        """True when the GPU model is Turing or newer."""
        from utils.hardware_detector import is_nvidia_turing_or_newer
        return is_nvidia_turing_or_newer(model)

    def _apply_nvidia_compatibility_guards(self):
        """Disable driver branches the detected NVIDIA GPU cannot use."""
        try:
            from utils.hardware_detector import detect_all_gpus
            nvidia_gpus = [g for g in detect_all_gpus() if g.get('vendor') == 'NVIDIA']
        except Exception:
            return

        if not nvidia_gpus:
            return
        if any(self._is_turing_plus(g.get('model', '')) for g in nvidia_gpus):
            return

        model = nvidia_gpus[0].get('model') or 'NVIDIA'
        for key in ('nvidia_610', 'nvidia_590'):
            entry = self._driver_buttons.get(key)
            if not entry:
                continue
            entry['button'].set_sensitive(False)
            entry['button'].set_tooltip_text(
                _("Not available for {gpu}: this branch only supports Turing and newer "
                  "(GTX 16xx, RTX 20 and later).").format(gpu=model)
            )

    def _create_nvidia_hybrid_section(self):
        """Create NVIDIA hybrid graphics section for laptops."""
        label = Gtk.Label()
        label.set_markup(f'<span weight="bold" size="14000">{_("Hybrid Graphics (Laptops)")}</span>')
        label.set_halign(Gtk.Align.START)
        self.drivers_box.pack_start(label, False, False, 5)
        
        desc_label = Gtk.Label()
        desc_label.set_markup(f'<span size="10000">{_("For laptops with Intel/AMD + NVIDIA graphics")}</span>')
        desc_label.set_halign(Gtk.Align.START)
        desc_label.get_style_context().add_class('dim-label')
        self.drivers_box.pack_start(desc_label, False, False, 0)
        
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        box.set_homogeneous(True)
        self.drivers_box.pack_start(box, False, False, 5)
        
        # PRIME Render Offload (battery saving)
        prime_offload_btn = self._create_button(
            _("PRIME Render Offload"),
            _("Use NVIDIA on demand (recommended, saves battery)")
        )
        prime_offload_btn.connect("clicked", self._on_hybrid_clicked, "offload")
        box.pack_start(prime_offload_btn, True, True, 0)
        
        # NVIDIA as primary (performance)
        nvidia_primary_btn = self._create_button(
            _("NVIDIA Primary"),
            _("Always use NVIDIA GPU (maximum performance)")
        )
        nvidia_primary_btn.connect("clicked", self._on_hybrid_clicked, "nvidia")
        box.pack_start(nvidia_primary_btn, True, True, 0)
        
        # Detect hybrid
        detect_hybrid_btn = self._create_button(
            _("Detect Hybrid Setup"),
            _("Check if you have a hybrid graphics laptop")
        )
        detect_hybrid_btn.connect("clicked", self._on_detect_hybrid_clicked)
        box.pack_start(detect_hybrid_btn, True, True, 0)
    
    def _create_nvidia_extras_section(self):
        """Create NVIDIA extras section (CUDA, OpenCL tools)."""
        label = Gtk.Label()
        label.set_markup(f'<span weight="bold" size="14000">{_("NVIDIA Extras")}</span>')
        label.set_halign(Gtk.Align.START)
        self.drivers_box.pack_start(label, False, False, 5)
        
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        box.set_homogeneous(True)
        self.drivers_box.pack_start(box, False, False, 5)
        
        davinci_pkgs = "nvidia-opencl-icd libcuda1 libglu1-mesa libnvidia-encode1"
        davinci_btn = self._create_button(
            _("DaVinci Resolve Extras"),
            _("OpenCL and CUDA libraries for DaVinci Resolve")
        )
        box.pack_start(davinci_btn, True, True, 0)
        self._driver_buttons['nvidia_davinci'] = {
            'button': davinci_btn, 'handler_id': None,
            'base_label': _("DaVinci Resolve Extras"),
            'install_fn': lambda b: self._on_nvidia_extras_clicked(b, 'davinci'),
            'uninstall_fn': lambda b: self._on_remove_driver_clicked(b, davinci_pkgs),
            'check_fn': lambda: self._is_package_installed('nvidia-opencl-icd'),
        }

        blender_btn = self._create_button(
            _("Blender CUDA Toolkit"),
            _("CUDA toolkit for Blender GPU rendering")
        )
        box.pack_start(blender_btn, True, True, 0)
        self._driver_buttons['nvidia_blender'] = {
            'button': blender_btn, 'handler_id': None,
            'base_label': _("Blender CUDA Toolkit"),
            'install_fn': lambda b: self._on_nvidia_extras_clicked(b, 'blender'),
            'uninstall_fn': lambda b: self._on_remove_driver_clicked(b, 'nvidia-cuda-toolkit'),
            'check_fn': lambda: self._is_package_installed('nvidia-cuda-toolkit'),
        }

        cuda12_btn = self._create_button(
            _("CUDA 12 Toolkit"),
            _("Full CUDA 12 toolkit for PyTorch, TensorFlow and GPU computing")
        )
        box.pack_start(cuda12_btn, True, True, 0)
        self._driver_buttons['cuda12'] = {
            'button': cuda12_btn, 'handler_id': None,
            'base_label': _("CUDA 12 Toolkit"),
            'install_fn': lambda b: self._on_cuda12_clicked(b, 'install'),
            'uninstall_fn': lambda b: self._on_cuda12_clicked(b, 'uninstall'),
            'check_fn': lambda: self._is_cuda12_installed(),
        }

    def _create_amd_section(self):
        """Create AMD drivers section."""
        label = Gtk.Label()
        label.set_markup(f'<span weight="bold" size="14000">{_("AMD Graphics Drivers")}</span>')
        label.set_halign(Gtk.Align.START)
        self.drivers_box.pack_start(label, False, False, 5)

        amd_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        amd_box.set_homogeneous(True)
        self.drivers_box.pack_start(amd_box, False, False, 5)

        amd_pkgs = "firmware-amd-graphics libgl1-mesa-dri libglx-mesa0 mesa-vulkan-drivers xserver-xorg-video-all"
        amd_btn = self._create_button(
            _("AMD Radeon (Open Source)"),
            _("Free drivers for all AMD GPUs")
        )
        amd_box.pack_start(amd_btn, True, True, 0)
        self._driver_buttons['amd'] = {
            'button': amd_btn, 'handler_id': None,
            'base_label': _("AMD Radeon (Open Source)"),
            'install_fn': lambda b: self._on_driver_clicked(b, amd_pkgs),
            'uninstall_fn': lambda b: self._on_remove_driver_clicked(b, amd_pkgs),
            'check_fn': lambda: self._is_amd_driver_installed(),
        }

    
    def _create_amd_extras_section(self):
        """Create AMD Extras section (ROCm OpenCL and full ROCm suite)."""
        label = Gtk.Label()
        label.set_markup(f'<span weight="bold" size="14000">{_("AMD Extras")}</span>')
        label.set_halign(Gtk.Align.START)
        self.drivers_box.pack_start(label, False, False, 5)

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        box.set_homogeneous(True)
        self.drivers_box.pack_start(box, False, False, 5)

        rocm_opencl_btn = self._create_button(
            _("ROCm OpenCL"),
            _("OpenCL runtime for AMD GPUs (RDNA2+) — DaVinci Resolve, Blender HIP, GPU compute")
        )
        box.pack_start(rocm_opencl_btn, True, True, 0)
        self._driver_buttons['rocm_opencl'] = {
            'button': rocm_opencl_btn, 'handler_id': None,
            'base_label': _("ROCm OpenCL"),
            'install_fn': lambda b: self._on_rocm_clicked(b, 'opencl'),
            'uninstall_fn': lambda b: self._on_rocm_clicked(b, 'uninstall'),
            'check_fn': lambda: self._is_package_installed('rocm-opencl-runtime'),
        }

        rocm_full_btn = self._create_button(
            _("ROCm Full Suite"),
            _("Complete ROCm platform for AI/ML development with PyTorch and TensorFlow on AMD GPU")
        )
        box.pack_start(rocm_full_btn, True, True, 0)
        self._driver_buttons['rocm_full'] = {
            'button': rocm_full_btn, 'handler_id': None,
            'base_label': _("ROCm Full Suite"),
            'install_fn': lambda b: self._on_rocm_clicked(b, 'full'),
            'uninstall_fn': lambda b: self._on_rocm_clicked(b, 'uninstall'),
            'check_fn': lambda: self._is_package_installed('rocm'),
        }

    def _create_intel_extras_section(self):
        """Create Intel Extras section (oneAPI Base Toolkit)."""
        label = Gtk.Label()
        label.set_markup(f'<span weight="bold" size="14000">{_("Intel Extras")}</span>')
        label.set_halign(Gtk.Align.START)
        self.drivers_box.pack_start(label, False, False, 5)

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        box.set_homogeneous(True)
        self.drivers_box.pack_start(box, False, False, 5)

        oneapi_btn = self._create_button(
            _("Intel oneAPI Base Toolkit"),
            _("DPC++ compiler, MKL, TBB, VTune — for Intel Arc GPU and CPU computing")
        )
        box.pack_start(oneapi_btn, True, True, 0)
        self._driver_buttons['oneapi'] = {
            'button': oneapi_btn, 'handler_id': None,
            'base_label': _("Intel oneAPI Base Toolkit"),
            'install_fn': lambda b: self._on_oneapi_clicked(b, 'install'),
            'uninstall_fn': lambda b: self._on_oneapi_clicked(b, 'uninstall'),
            'check_fn': lambda: os.path.exists('/opt/intel/oneapi/setvars.sh'),
        }

    def _create_wifi_section(self):
        """Create Wi-Fi drivers section."""
        label = Gtk.Label()
        label.set_markup(f'<span weight="bold" size="14000">{_("Wi-Fi Drivers")}</span>')
        label.set_halign(Gtk.Align.START)
        self.drivers_box.pack_start(label, False, False, 5)

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        box.set_homogeneous(True)
        self.drivers_box.pack_start(box, False, False, 5)

        intel_wifi = self._create_button(_("Intel Wi-Fi"), _("Intel wireless cards"))
        box.pack_start(intel_wifi, True, True, 0)
        self._driver_buttons['wifi_intel'] = {
            'button': intel_wifi, 'handler_id': None,
            'base_label': _("Intel Wi-Fi"),
            'install_fn': lambda b: self._on_driver_clicked(b, 'firmware-iwlwifi'),
            'uninstall_fn': lambda b: self._on_remove_driver_clicked(b, 'firmware-iwlwifi'),
            'check_fn': lambda: self._is_package_installed('firmware-iwlwifi') and self._is_module_loaded('iwlwifi'),
        }

        realtek_wifi = self._create_button(_("Realtek Wi-Fi"), _("Realtek wireless cards"))
        box.pack_start(realtek_wifi, True, True, 0)
        self._driver_buttons['wifi_realtek'] = {
            'button': realtek_wifi, 'handler_id': None,
            'base_label': _("Realtek Wi-Fi"),
            'install_fn': lambda b: self._on_driver_clicked(b, 'firmware-realtek'),
            'uninstall_fn': lambda b: self._on_remove_driver_clicked(b, 'firmware-realtek'),
            'check_fn': lambda: self._is_package_installed('firmware-realtek') and self._is_module_loaded('r8169', 'rtl8xxxu', 'r8188eu', 'rtw88_8822be', 'rtw89_pci'),
        }

        broadcom_wifi = self._create_button(_("Broadcom Wi-Fi"), _("Broadcom wireless cards"))
        box.pack_start(broadcom_wifi, True, True, 0)
        self._driver_buttons['wifi_broadcom'] = {
            'button': broadcom_wifi, 'handler_id': None,
            'base_label': _("Broadcom Wi-Fi"),
            'install_fn': lambda b: self._on_driver_clicked(b, 'firmware-b43-installer'),
            'uninstall_fn': lambda b: self._on_remove_driver_clicked(b, 'firmware-b43-installer'),
            'check_fn': lambda: self._is_package_installed('firmware-b43-installer'),
        }

        # firmware-b43-installer only covers the fully reverse-engineered BCM43xx
        # chips (open b43 driver). Many other Broadcom chips (BCM4311, BCM4312,
        # BCM4313, BCM4321, BCM4322, BCM43142, BCM43224/25/27/28...) have no open
        # driver at all and need the proprietary "wl" driver instead — there was
        # previously no way to install it from Welcome, so those chips had no
        # working option here.
        broadcom_wifi_proprietary = self._create_button(_("Broadcom Wi-Fi (proprietary)"), _("Broadcom wireless cards not supported by the open b43 driver"))
        box.pack_start(broadcom_wifi_proprietary, True, True, 0)
        self._driver_buttons['wifi_broadcom_proprietary'] = {
            'button': broadcom_wifi_proprietary, 'handler_id': None,
            'base_label': _("Broadcom Wi-Fi (proprietary)"),
            'install_fn': lambda b: self._on_driver_clicked(b, 'broadcom-sta-dkms'),
            'uninstall_fn': lambda b: self._on_remove_driver_clicked(b, 'broadcom-sta-dkms'),
            'check_fn': lambda: self._is_package_installed('broadcom-sta-dkms'),
        }

        repair_btn = self._create_button(
            _("Repair Wi-Fi"),
            _("Reload Wi-Fi driver and restart NetworkManager — fixes connection lost after reboot")
        )
        repair_btn.connect("clicked", self._on_repair_wifi_clicked)
        self.drivers_box.pack_start(repair_btn, False, False, 0)
    
    def _create_other_section(self):
        """Create other drivers section."""
        label = Gtk.Label()
        label.set_markup(f'<span weight="bold" size="14000">{_("Other Drivers")}</span>')
        label.set_halign(Gtk.Align.START)
        self.drivers_box.pack_start(label, False, False, 5)

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        box.set_homogeneous(True)
        self.drivers_box.pack_start(box, False, False, 5)

        printer_btn = self._create_button(_("Printers"), _("Printer drivers"))
        box.pack_start(printer_btn, True, True, 0)
        self._driver_buttons['printers'] = {
            'button': printer_btn, 'handler_id': None,
            'base_label': _("Printers"),
            'install_fn': lambda b: self._on_driver_clicked(b, 'printer-driver-all'),
            'uninstall_fn': lambda b: self._on_remove_driver_clicked(b, 'printer-driver-all'),
            'check_fn': lambda: self._is_package_installed('printer-driver-all'),
        }

        bt_pkgs = "bluetooth bluez bluez-tools blueman"
        bluetooth_btn = self._create_button(_("Bluetooth"), _("Bluetooth support"))
        box.pack_start(bluetooth_btn, True, True, 0)
        self._driver_buttons['bluetooth'] = {
            'button': bluetooth_btn, 'handler_id': None,
            'base_label': _("Bluetooth"),
            'install_fn': lambda b: self._on_driver_clicked(b, bt_pkgs),
            'uninstall_fn': lambda b: self._on_remove_driver_clicked(b, bt_pkgs),
            'check_fn': lambda: self._is_package_installed('bluetooth'),
        }
    
    def _create_vm_section(self):
        """Create VM tools section."""
        label = Gtk.Label()
        label.set_markup(f'<span weight="bold" size="14000">{_("Virtual Machine Tools")}</span>')
        label.set_halign(Gtk.Align.START)
        self.drivers_box.pack_start(label, False, False, 5)

        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        box.set_homogeneous(True)
        self.drivers_box.pack_start(box, False, False, 5)

        vmware_btn = self._create_button(_("VMware Tools"), _("For VMware virtual machines"))
        box.pack_start(vmware_btn, True, True, 0)
        self._driver_buttons['vmware'] = {
            'button': vmware_btn, 'handler_id': None,
            'base_label': _("VMware Tools"),
            'install_fn': lambda b: self._on_driver_clicked(b, 'open-vm-tools-desktop'),
            'uninstall_fn': lambda b: self._on_remove_driver_clicked(b, 'open-vm-tools-desktop'),
            'check_fn': lambda: self._is_package_installed('open-vm-tools-desktop'),
        }

        qemu_pkgs = "qemu-guest-agent spice-vdagent spice-webdavd xserver-xspice"
        qemu_btn = self._create_button(_("QEMU/KVM Tools"), _("For QEMU/KVM virtual machines"))
        box.pack_start(qemu_btn, True, True, 0)
        self._driver_buttons['qemu'] = {
            'button': qemu_btn, 'handler_id': None,
            'base_label': _("QEMU/KVM Tools"),
            'install_fn': lambda b: self._on_driver_clicked(b, qemu_pkgs),
            'uninstall_fn': lambda b: self._on_remove_driver_clicked(b, qemu_pkgs),
            'check_fn': lambda: self._is_package_installed('qemu-guest-agent'),
        }

        def _check_vbox():
            try:
                r = subprocess.run(['systemctl', 'is-enabled', 'vboxadd'],
                                   capture_output=True, text=True)
                return r.returncode == 0
            except Exception:
                return False

        vbox_btn = self._create_button(_("VirtualBox Guest"), _("For VirtualBox virtual machines"))
        box.pack_start(vbox_btn, True, True, 0)
        self._driver_buttons['vbox'] = {
            'button': vbox_btn, 'handler_id': None,
            'base_label': _("VirtualBox Guest"),
            'install_fn': lambda b: self._on_vbox_clicked(b),
            'uninstall_fn': lambda b: self._on_vbox_uninstall_clicked(b),
            'check_fn': _check_vbox,
        }
    
    # === DRIVER DETECTION ===

    def _detect_wifi_driver(self):
        """Return (iface, driver) detecting the Wi-Fi module by any available method.

        Strategy 1 — sysfs: works when the interface is up and driver loaded normally.
        Strategy 2 — iw dev: works when the interface is down but module is loaded.
        Strategy 3 — lspci -k: works even when the module is NOT loaded (broken state
                     after reboot), which is exactly the case this button is meant to fix.
        Returns (iface_or_None, driver) — driver is always set if hardware is found.
        """
        import glob

        # Strategy 1: sysfs wireless subdir + device/driver symlink
        for path in glob.glob('/sys/class/net/*/wireless'):
            iface = os.path.basename(os.path.dirname(path))
            driver_link = f'/sys/class/net/{iface}/device/driver'
            try:
                if os.path.islink(driver_link):
                    driver = os.path.basename(os.readlink(driver_link))
                    return iface, driver
            except Exception:
                pass

        # Strategy 2: iw dev (interface exists but may be down)
        try:
            result = subprocess.run(['iw', 'dev'], capture_output=True, text=True)
            for line in result.stdout.splitlines():
                line = line.strip()
                if line.startswith('Interface '):
                    iface = line.split()[1]
                    driver_link = f'/sys/class/net/{iface}/device/driver'
                    try:
                        if os.path.islink(driver_link):
                            driver = os.path.basename(os.readlink(driver_link))
                            return iface, driver
                    except Exception:
                        pass
        except Exception:
            pass

        # Strategy 3: lspci -k — detects the module even when not loaded
        # This is the critical fallback for the "no WiFi after reboot" case
        try:
            result = subprocess.run(['lspci', '-k'], capture_output=True, text=True)
            lines = result.stdout.splitlines()
            in_wifi = False
            for line in lines:
                lower = line.lower()
                if any(k in lower for k in ('network controller', 'wireless', 'wifi', 'wi-fi')):
                    in_wifi = True
                elif line and not line.startswith('\t') and not line.startswith(' '):
                    in_wifi = False
                if in_wifi:
                    if 'kernel modules:' in lower:
                        modules = line.split(':', 1)[1].strip().split(',')
                        driver = modules[0].strip()
                        if driver:
                            return None, driver
                    elif 'kernel driver in use:' in lower:
                        driver = line.split(':', 1)[1].strip()
                        if driver:
                            return None, driver
        except Exception:
            pass

        return None, None

    def _on_repair_wifi_clicked(self, button):
        """Reload the Wi-Fi driver and restart NetworkManager."""
        button.set_sensitive(False)
        self.progress_label.set_text(_("Detecting Wi-Fi hardware..."))

        def _detect():
            iface, driver = self._detect_wifi_driver()
            GLib.idle_add(_on_detected, iface, driver)

        def _on_detected(iface, driver):
            button.set_sensitive(True)
            self.progress_label.set_text("")

            if not driver:
                dialog = Gtk.MessageDialog(
                    transient_for=self.parent_window,
                    flags=0,
                    message_type=Gtk.MessageType.WARNING,
                    buttons=Gtk.ButtonsType.OK,
                    text=_("No Wi-Fi Interface Found")
                )
                dialog.format_secondary_text(
                    _("No active Wi-Fi interface was detected.\nMake sure your Wi-Fi card is connected and recognized by the system.")
                )
                dialog.run()
                dialog.destroy()
                return

            dialog = Gtk.MessageDialog(
                transient_for=self.parent_window,
                flags=0,
                message_type=Gtk.MessageType.QUESTION,
                buttons=Gtk.ButtonsType.YES_NO,
                text=_("Repair Wi-Fi Connection")
            )
            dialog.format_secondary_text(
                _("Detected driver: {driver}  |  Interface: {iface}\n\n"
                  "This will:\n"
                  "  • Unload and reload the Wi-Fi kernel module\n"
                  "  • Restart NetworkManager\n\n"
                  "Your network connection will be briefly interrupted.\n"
                  "Proceed?").format(driver=driver, iface=iface if iface else _("not loaded"))
            )
            response = dialog.run()
            dialog.destroy()

            if response == Gtk.ResponseType.YES:
                script = f"""#!/bin/bash
IFACE="{iface or ''}"
# Bring the interface down first so the kernel releases its reference to
# the module — otherwise "modprobe -r" can fail silently with "device
# busy" while the interface is still up, and the script would report
# success without ever having reloaded anything.
if [ -n "$IFACE" ]; then
    ip link set "$IFACE" down 2>/dev/null || true
fi
modprobe -r {driver} 2>/dev/null || true
sleep 1
modprobe {driver}
systemctl restart NetworkManager
echo "Wi-Fi repair completed. Driver: {driver}"
"""
                self._run_script_as_root(script, "repair-wifi.sh")

        threading.Thread(target=_detect, daemon=True).start()

    def _is_nouveau_blacklisted(self):
        """Return True if any modprobe config blacklists nouveau.

        The blacklist file belongs to the NVIDIA driver package, not to this
        application, so installing the nouveau package does not remove it. The
        proprietary driver has to be uninstalled first.
        """
        import glob
        try:
            for conf in glob.glob('/etc/modprobe.d/*.conf'):
                try:
                    with open(conf) as f:
                        if 'blacklist nouveau' in f.read():
                            return True
                except Exception:
                    pass
        except Exception:
            pass
        return False

    def _is_nouveau_active(self):
        """Return True when nouveau is free to drive the GPU.

        Deliberately does not look at xserver-xorg-video-nouveau: that is an
        Xorg DDX driver, and only Tyron runs X11 — Boro and Tyson are Wayland,
        where the package is irrelevant and usually absent. Checking it made
        this return False on those two even when nouveau was the driver in use.
        Nouveau itself ships with the kernel, so the blacklist is what decides.
        """
        return not self._is_nouveau_blacklisted()

    def _is_amd_driver_installed(self):
        """Return True when the AMD driver stack is present.

        Only the parts that matter under both display protocols are checked.
        xserver-xorg-video-all is still installed by the button — Boro and
        Tyson can run an X11 session even though they boot Wayland — but it
        must not be required here: on a machine that only ever runs Wayland it
        is absent, and demanding it made this return False forever, so the
        button never showed the stack as installed.
        """
        return (
            self._is_package_installed('firmware-amd-graphics') and
            self._is_package_installed('libgl1-mesa-dri') and
            self._is_package_installed('mesa-vulkan-drivers')
        )

    def _is_module_loaded(self, *module_names):
        """Return True if any of the given kernel modules are currently loaded."""
        try:
            result = subprocess.run(['lsmod'], capture_output=True, text=True)
            for name in module_names:
                if name in result.stdout:
                    return True
        except Exception:
            pass
        return False

    def _is_package_installed(self, package):
        """Check if a dpkg package is installed."""
        try:
            result = subprocess.run(
                ['dpkg', '-s', package],
                capture_output=True, text=True
            )
            return 'Status: install ok installed' in result.stdout
        except Exception:
            return False

    def _get_nvidia_active_version(self):
        """Return major version string of active NVIDIA driver (e.g. '590'), or None."""
        # nvidia-smi: works regardless of how the driver was installed
        try:
            result = subprocess.run(
                ['nvidia-smi', '--query-gpu=driver_version', '--format=csv,noheader'],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                ver = result.stdout.strip().split('.')[0]
                if ver.isdigit():
                    return ver
        except Exception:
            pass
        # Fallback: scan dpkg only if NVIDIA hardware is present (e.g. first boot with nouveau)
        try:
            lspci = subprocess.run(['lspci'], capture_output=True, text=True)
            if not any(k in lspci.stdout for k in ('NVIDIA', 'GeForce', 'Quadro', 'Tesla')):
                return None
        except Exception:
            return None
        try:
            import re
            result = subprocess.run(['dpkg', '-l'], capture_output=True, text=True)
            for line in result.stdout.split('\n'):
                if not line.startswith('ii'):
                    continue
                parts = line.split()
                if len(parts) >= 2 and re.fullmatch(r'nvidia-driver-(\d+)', parts[1]):
                    return re.search(r'\d+', parts[1]).group()
        except Exception:
            pass
        return None

    def _apply_driver_state(self, key, installed):
        """Update button label, style and signal handler. Runs on GTK thread."""
        info = self._driver_buttons.get(key)
        if not info:
            return
        button = info['button']

        # Disconnect previous handler
        if info.get('handler_id') is not None:
            try:
                button.disconnect(info['handler_id'])
            except Exception:
                pass

        if installed:
            button.set_label(f"✓  {info['base_label']}")
            info['handler_id'] = button.connect('clicked', info['uninstall_fn'])
        else:
            button.set_label(info['base_label'])
            info['handler_id'] = button.connect('clicked', info['install_fn'])

    def _refresh_driver_status(self):
        """Check all registered driver buttons in background and update their state."""
        def _check():
            for key, info in list(self._driver_buttons.items()):
                try:
                    installed = info['check_fn']()
                    GLib.idle_add(self._apply_driver_state, key, installed)
                except Exception as e:
                    print(f"Error checking driver {key}: {e}")

        threading.Thread(target=_check, daemon=True).start()

    def _create_button(self, label, tooltip):
        """Create a driver button with tooltip."""
        button = Gtk.Button(label=label)
        button.set_tooltip_text(tooltip)
        button.set_size_request(200, 40)
        return button
    
    def _on_driver_clicked(self, button, packages):
        """Install driver from repository."""
        script = f"""#!/bin/bash
set -e
apt update
apt install -y {packages}
echo "Installation completed successfully."
"""
        self._run_script_as_root(script, f"install-{packages.split()[0]}.sh",
                                 self._refresh_driver_status)

    def _on_remove_driver_clicked(self, button, packages):
        """Remove driver packages, including their conffiles (apt purge)."""
        script = f"""#!/bin/bash
set -e
apt purge -y {packages}
apt autoremove -y
echo "Removal completed successfully."
"""
        self._run_script_as_root(script, f"uninstall-{packages.split()[0]}.sh",
                                 self._refresh_driver_status)
    
    def _on_nouveau_clicked(self, button):
        """Switch back to nouveau by removing the proprietary driver.

        Nothing is installed here. The nouveau kernel module ships with the
        kernel and the Xorg driver package is already present, so the only
        thing standing between the user and nouveau is the modprobe blacklist
        that the NVIDIA driver package installs. Purging NVIDIA removes it.
        """
        if not self._is_nouveau_blacklisted():
            dialog = Gtk.MessageDialog(
                transient_for=self.parent_window,
                flags=0,
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.OK,
                text=_("Nouveau Is Already Active")
            )
            dialog.format_secondary_text(
                _("No proprietary NVIDIA driver is blacklisting nouveau, so it "
                  "is already the driver in use. There is nothing to change.")
            )
            dialog.run()
            dialog.destroy()
            return

        dialog = Gtk.MessageDialog(
            transient_for=self.parent_window,
            flags=0,
            message_type=Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.YES_NO,
            text=_("NVIDIA Driver Detected")
        )
        dialog.format_secondary_text(
            _("The installed NVIDIA driver keeps nouveau blacklisted, so "
              "nouveau cannot load while it is present.\n\n"
              "To switch to nouveau, the NVIDIA drivers have to be removed. "
              "This will:\n\n"
              "1. Remove all NVIDIA and CUDA packages, their DKMS modules and "
              "the NVIDIA repository.\n"
              "2. Regenerate the initramfs and update GRUB.\n\n"
              "Nouveau needs no installation: it ships with the kernel and "
              "takes over once the blacklist is gone.\n\n"
              "A system restart will be required.\n\n"
              "Do you want to remove the NVIDIA drivers?")
        )
        response = dialog.run()
        dialog.destroy()
        if response != Gtk.ResponseType.YES:
            return

        self._run_script_as_root(self._build_nvidia_uninstall_script(),
                                 "switch-to-nouveau.sh",
                                 self._refresh_driver_status)

    def _on_legacy_nvidia_clicked(self, button, package_name):
        """Show warning about Debian Sid requirement before installing legacy drivers."""
        dialog = Gtk.MessageDialog(
            transient_for=self.parent_window,
            flags=0,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.YES_NO,
            text=_("Legacy Driver Support Required")
        )
        
        dialog.format_secondary_text(
            _("This legacy driver is only available in the unstable repositories.\n\n"
              "We will now open <b>Soplos Repo Selector</b> so you can temporarily enable "
              "the <b>Debian Sid (Unstable)</b> repository.\n\n"
              "After completing the driver installation, it is CRITICAL that you return "
              "to Soplos Repo Selector and disable Sid, or you may break your system "
              "during future updates.\n\n"
              "Do you want to enable Sid and continue with the installation?")
        )
        
        # Enable markup for the secondary text to support <b> tags
        dialog.get_message_area().get_children()[1].set_use_markup(True)

        response = dialog.run()
        dialog.destroy()

        if response == Gtk.ResponseType.YES:
            # Launch Soplos Repo Selector asynchronously
            try:
                import subprocess
                subprocess.Popen(['soplos-repo-selector'])
            except Exception as e:
                print(f"Failed to launch soplos-repo-selector: {e}")
                
            # Show a second dialog waiting for the user to finish with Repo Selector
            wait_dialog = Gtk.MessageDialog(
                transient_for=self.parent_window,
                flags=0,
                message_type=Gtk.MessageType.QUESTION,
                buttons=Gtk.ButtonsType.OK_CANCEL,
                text=_("Waiting for Soplos Repo Selector")
            )
            
            wait_dialog.format_secondary_text(
                _("Soplos Repo Selector has been opened.\n\n"
                  "1. Enable the <b>Debian Sid (Unstable)</b> repository.\n"
                  "2. Wait for the operation to finish and close Soplos Repo Selector.\n"
                  "3. Click <b>OK</b> below to begin the driver installation.\n\n"
                  "If you changed your mind, click Cancel.")
            )
            wait_dialog.get_message_area().get_children()[1].set_use_markup(True)
            
            wait_response = wait_dialog.run()
            wait_dialog.destroy()
            
            if wait_response == Gtk.ResponseType.OK:
                self._on_nvidia_repo_clicked(button, package_name)

    def _on_nvidia_repo_clicked(self, button, package):
        """Install NVIDIA driver from repository with proper configuration."""
        # Show confirmation dialog before proceeding
        confirm_dialog = Gtk.MessageDialog(
            transient_for=self.parent_window,
            flags=0,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.YES_NO,
            text=_("Confirm NVIDIA Driver Installation")
        )
        confirm_dialog.format_secondary_text(
            _("This will:\n\n"
              "1. Remove any existing NVIDIA drivers to prevent conflicts.\n"
              "2. Install the driver: {package}\n"
              "3. Install auxiliary tools (nvidia-smi, nvidia-settings).\n"
              "4. Regenerate initramfs.\n\n"
              "A system restart will be required after installation.\n\n"
              "Do you want to continue?").format(package=package)
        )
        response = confirm_dialog.run()
        confirm_dialog.destroy()
        if response != Gtk.ResponseType.YES:
            return

        nvidia_patch = get_nvidia_dkms_patch_commands()

        script = f"""#!/bin/bash

set -e

echo "Installing NVIDIA driver from repository..."

# === CLEANUP DKMS MODULES ===
echo "Removing NVIDIA DKMS modules from all kernels..."
for entry in $(dkms status | grep -i nvidia | awk -F'[:,]' '{{print $1"/"$2}}' | tr -d ' '); do
    dkms remove --force "$entry" --all 2>/dev/null || true
done
for kver in $(ls /lib/modules/); do
    rm -f /lib/modules/$kver/updates/dkms/nvidia*.ko*
    depmod -a "$kver" 2>/dev/null || true
done
rm -rf /var/lib/dkms/nvidia*

# === CLEANUP EXISTING NVIDIA PACKAGES ===
echo "Removing existing NVIDIA packages to prevent conflicts..."
apt purge -y 'nvidia-driver*' 'nvidia-kernel*' 'libnvidia*' 'nvidia-modprobe' \
    'nvidia-settings' 'nvidia-smi' 'nvidia-opencl*' 'nvidia-cuda*' \
    'cuda-drivers*' 'xserver-xorg-video-nvidia*' 2>/dev/null || true
apt autoremove -y 2>/dev/null || true

# Install kernel headers and DKMS build dependencies
apt update
apt install -y dkms build-essential linux-headers-$(uname -r)
{LLVM_DKMS_TOOLCHAIN}
# The headers package being installed is not enough: DKMS needs a usable build
# tree, otherwise it skips the build and the system boots with no driver.
if [ ! -e "/lib/modules/$(uname -r)/build/Makefile" ]; then
    echo "Kernel build tree missing or broken, reinstalling headers..."
    apt install -y --reinstall linux-headers-$(uname -r) || true
fi
if [ ! -e "/lib/modules/$(uname -r)/build/Makefile" ]; then
    echo "ERROR: no usable kernel build tree for $(uname -r)."
    echo "DKMS cannot build the NVIDIA module, so the driver is NOT installed."
    exit 1
fi

# Install NVIDIA driver + auxiliary packages
# The driver package builds its DKMS module while dpkg configures it, and that
# first build runs on unpatched sources. When it fails apt exits, so set -e would
# stop the script before the patch is applied. The failure is tolerated here, the
# sources are patched, and the configuration is retried below.
apt install -y {package} nvidia-smi nvidia-settings nvidia-modprobe libglu1-mesa || \
    echo "First attempt failed (the DKMS build runs before the patch); patching the sources and retrying..."

# === PATCH AND REBUILD DKMS MODULES ===
echo "Applying NVIDIA DKMS compatibility patch for Soplos 7.x kernels..."
{nvidia_patch}
dpkg --configure -a
apt install -y {package} nvidia-smi nvidia-settings nvidia-modprobe libglu1-mesa
echo "Rebuilding NVIDIA DKMS modules..."
dkms autoinstall || true
if ! dkms status | grep -qi "nvidia.*installed"; then
    echo "ERROR: the NVIDIA DKMS module did not build. The system would boot"
    echo "without any graphics driver, since nouveau is blacklisted."
    echo "Run 'sudo dkms autoinstall' and check the output before rebooting."
fi

# === CONFIGURE GRUB ===
echo "Configuring GRUB with nvidia-drm.modeset=1..."
if ! grep -q "nvidia-drm.modeset=1" /etc/default/grub; then
    sed -i 's/GRUB_CMDLINE_LINUX_DEFAULT="\\([^"]*\\)"/GRUB_CMDLINE_LINUX_DEFAULT="\\1 nvidia-drm.modeset=1"/' /etc/default/grub
    update-grub
fi

# === CONFIGURE DRACUT/INITRAMFS ===
if command -v dracut >/dev/null 2>&1; then
    echo "Configuring Dracut..."
    mkdir -p /etc/dracut.conf.d
    echo 'omit_drivers+=" nouveau "' > /etc/dracut.conf.d/blacklist-nouveau.conf
    # The NVIDIA modules must NOT be forced into the initramfs: nvidia_drm takes
    # the display there and the handover at switch-root can leave the boot stuck
    # on a black screen. They load normally once the real system is up, so the
    # file is removed instead of written, also cleaning up earlier installs.
    rm -f /etc/dracut.conf.d/nvidia.conf
    echo "Regenerating initramfs..."
    dracut --force
elif command -v update-initramfs >/dev/null 2>&1; then
    echo "Regenerating initramfs..."
    update-initramfs -u
fi

echo ""
echo "=== Installation completed ==="
echo "NVIDIA driver installed successfully."
echo "Auxiliary tools installed: nvidia-smi, nvidia-settings, nvidia-modprobe"
echo "IMPORTANT: Restart the system to apply the changes."
"""
        self._run_script_as_root(script, f"install-{package}.sh", self._refresh_driver_status)

    
    def _on_nvidia_cuda_repo_clicked(self, button, version):
        """Install NVIDIA driver from official CUDA repository for Debian."""
        # Show confirmation dialog before proceeding
        confirm_dialog = Gtk.MessageDialog(
            transient_for=self.parent_window,
            flags=0,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.YES_NO,
            text=_("Confirm NVIDIA CUDA Driver Installation")
        )
        confirm_dialog.format_secondary_text(
            _("This will:\n\n"
              "1. Remove any existing NVIDIA drivers to prevent conflicts.\n"
              "2. Add the official NVIDIA CUDA repository.\n"
              "3. Install driver version {version} with auxiliary tools.\n"
              "4. Regenerate initramfs.\n\n"
              "A system restart will be required after installation.\n\n"
              "Do you want to continue?").format(version=version)
        )
        response = confirm_dialog.run()
        confirm_dialog.destroy()
        if response != Gtk.ResponseType.YES:
            return

        distro = "debian12" if version == "580" else "debian13"
        if version == "580":
            # debian12 CUDA repo usa SHA1 en las binding signatures de su clave GPG.
            # sqv (usado por Debian 13) rechaza SHA1 desde 2026-02-01, así que
            # no podemos usar cuda-keyring. Añadimos el repo con trusted=yes.
            repo_setup = """echo "deb [trusted=yes] https://developer.download.nvidia.com/compute/cuda/repos/debian12/x86_64/ /" \\
    > /etc/apt/sources.list.d/cuda-debian12-x86_64.list
trap 'rm -f /etc/apt/sources.list.d/cuda-debian12-x86_64.list' EXIT"""
            install_driver = "apt install -y nvidia-driver-pinning-580\napt install -y --allow-downgrades cuda-drivers-580"
            repo_cleanup = """trap - EXIT
rm -f /etc/apt/sources.list.d/cuda-debian12-x86_64.list
apt update -q"""
        elif version == "590":
            repo_setup = r"""TEMP_DIR=$(mktemp -d)
wget -q -O "$TEMP_DIR/cuda-keyring.deb" \
    https://developer.download.nvidia.com/compute/cuda/repos/debian13/x86_64/cuda-keyring_1.1-1_all.deb
if [ ! -s "$TEMP_DIR/cuda-keyring.deb" ]; then
    echo "ERROR: Failed to download cuda-keyring."
    rm -rf "$TEMP_DIR"
    exit 1
fi
dpkg -i "$TEMP_DIR/cuda-keyring.deb"
rm -rf "$TEMP_DIR"
"""
            install_driver = "apt install -y nvidia-driver-pinning-590\napt install -y nvidia-open-590"
            # Remove the NVIDIA repository once the driver is installed, so a
            # later 'apt upgrade' cannot move the user to another driver branch
            # on its own, and so it stops shadowing Debian packages such as dkms.
            repo_cleanup = """apt purge -y cuda-keyring
rm -f /etc/apt/sources.list.d/cuda-debian13-x86_64.list
apt update -q"""
        else:
            repo_setup = r"""TEMP_DIR=$(mktemp -d)
wget -q -O "$TEMP_DIR/cuda-keyring.deb" \
    https://developer.download.nvidia.com/compute/cuda/repos/debian13/x86_64/cuda-keyring_1.1-1_all.deb
if [ ! -s "$TEMP_DIR/cuda-keyring.deb" ]; then
    echo "ERROR: Failed to download cuda-keyring."
    rm -rf "$TEMP_DIR"
    exit 1
fi
dpkg -i "$TEMP_DIR/cuda-keyring.deb"
rm -rf "$TEMP_DIR"
"""
            install_driver = "apt install -y nvidia-driver-pinning-610\napt install -y nvidia-open-610"
            # Same cleanup as the 590 branch: the repository must not survive
            # the installation.
            repo_cleanup = """apt purge -y cuda-keyring
rm -f /etc/apt/sources.list.d/cuda-debian13-x86_64.list
apt update -q"""

        nvidia_patch = get_nvidia_dkms_patch_commands()

        script = f"""#!/bin/bash

set -e
NVIDIA_VERSION="{version}"
DISTRO="{distro}"
LOG="/tmp/nvidia-install-$NVIDIA_VERSION.log"
exec > >(tee -a "$LOG") 2>&1

echo "=== NVIDIA $NVIDIA_VERSION Official CUDA Repository ($DISTRO) ==="
echo ""

echo "[0/6] Removing NVIDIA DKMS modules from all kernels..."
for entry in $(dkms status | grep -i nvidia | awk -F'[:,]' '{{print $1"/"$2}}' | tr -d ' '); do
    dkms remove --force "$entry" --all 2>/dev/null || true
done
for kver in $(ls /lib/modules/); do
    rm -f /lib/modules/$kver/updates/dkms/nvidia*.ko*
    depmod -a "$kver" 2>/dev/null || true
done
rm -rf /var/lib/dkms/nvidia*

echo "[1/6] Removing existing NVIDIA/CUDA packages..."
rm -f /etc/dracut.conf.d/nvidia.conf
rm -f /etc/dracut.conf.d/blacklist-nouveau.conf
rm -f /etc/apt/apt.conf.d/99nvidia-sha1-exception
apt purge -y 'nvidia*' 'cuda*' 'libnvidia*' 2>/dev/null || true
apt autoremove -y 2>/dev/null || true
apt -f install -y 2>/dev/null || true

echo "[2/6] Installing kernel headers and DKMS build dependencies..."
apt install -y dkms build-essential
apt install -y linux-headers-$(uname -r) || true
{LLVM_DKMS_TOOLCHAIN}

# Having the headers package installed is not enough: the build tree under
# /lib/modules/<kernel>/build must be usable, or DKMS silently skips the build
# and leaves the module as "added". The machine then boots with no graphics
# driver at all, because the NVIDIA package blacklists nouveau.
if [ ! -e "/lib/modules/$(uname -r)/build/Makefile" ]; then
    echo "Kernel build tree missing or broken, reinstalling headers..."
    apt install -y --reinstall linux-headers-$(uname -r) || true
fi
if [ ! -e "/lib/modules/$(uname -r)/build/Makefile" ]; then
    echo "ERROR: no usable kernel build tree for $(uname -r)."
    echo "DKMS cannot build the NVIDIA module, so the driver is NOT installed."
    echo "Install linux-headers-$(uname -r) and run this again."
    exit 1
fi

echo "[3/6] Setting up NVIDIA CUDA repository ($DISTRO)..."
{repo_setup}

echo "[4/6] Installing NVIDIA Driver $NVIDIA_VERSION..."
apt update
# The driver package builds its DKMS module while dpkg configures it, and that
# first build runs on unpatched sources. When it fails apt exits, so set -e would
# stop the script before the patch is applied. The failure is tolerated here, the
# sources are patched, and the install is repeated while the repository is still
# configured, before it is removed.
{install_driver} || \
    echo "First attempt failed (the DKMS build runs before the patch); patching the sources and retrying..."

echo "[+] Applying NVIDIA DKMS compatibility patch for Soplos 7.x kernels..."
{nvidia_patch}
dpkg --configure -a
{install_driver}
{repo_cleanup}

echo "[+] Rebuilding NVIDIA DKMS modules..."
dkms autoinstall || true
if ! dkms status | grep -qi "nvidia.*installed"; then
    echo "ERROR: the NVIDIA DKMS module did not build. The system would boot"
    echo "without any graphics driver, since nouveau is blacklisted."
    echo "Run 'sudo dkms autoinstall' and check the output before rebooting."
fi

echo "[5/6] Configuring dracut and regenerating initramfs..."
if command -v dracut >/dev/null 2>&1; then
    mkdir -p /etc/dracut.conf.d
    echo 'omit_drivers+=" nouveau "' > /etc/dracut.conf.d/blacklist-nouveau.conf
    # The NVIDIA modules must NOT be forced into the initramfs: nvidia_drm takes
    # the display there and the handover at switch-root can leave the boot stuck
    # on a black screen. They load normally once the real system is up, so the
    # file is removed instead of written, also cleaning up earlier installs.
    rm -f /etc/dracut.conf.d/nvidia.conf
    dracut --force
elif command -v update-initramfs >/dev/null 2>&1; then
    update-initramfs -u
fi

echo "[+] Configuring GRUB with nvidia-drm.modeset=1..."
if ! grep -q "nvidia-drm.modeset=1" /etc/default/grub; then
    sed -i 's/GRUB_CMDLINE_LINUX_DEFAULT="\\([^"]*\\)"/GRUB_CMDLINE_LINUX_DEFAULT="\\1 nvidia-drm.modeset=1"/' /etc/default/grub
fi
update-grub

echo ""
echo "[6/6] Done."
echo "=== Installation completed successfully ==="
echo "NVIDIA driver $NVIDIA_VERSION installed. Restart to apply changes."
"""
        self._run_script_as_root(script, f"install-nvidia-cuda-{version}.sh", self._refresh_driver_status)

    
    def _on_nvidia_extras_clicked(self, button, mode):
        """Install additional NVIDIA support for DaVinci Resolve or Blender."""
        if mode == "davinci":
            packages = "nvidia-opencl-icd libcuda1 libglu1-mesa libnvidia-encode1"
            script_name = "install-nvidia-davinci-extras.sh"
        elif mode == "blender":
            packages = "nvidia-cuda-toolkit"
            script_name = "install-nvidia-blender-cuda.sh"
        else:
            return
        
        script = f"""#!/bin/bash
set -e
apt update
apt install -y {packages}
echo "Installation completed successfully."
"""
        self._run_script_as_root(script, script_name, self._refresh_driver_status)

    def _on_rocm_clicked(self, button, mode):
        """Install or remove ROCm from the official AMD repository."""
        if mode == 'uninstall':
            confirm_dialog = Gtk.MessageDialog(
                transient_for=self.parent_window,
                flags=0,
                message_type=Gtk.MessageType.WARNING,
                buttons=Gtk.ButtonsType.YES_NO,
                text=_("Remove ROCm")
            )
            confirm_dialog.format_secondary_text(
                _("This will remove all ROCm packages and the AMD ROCm repository.\n\n"
                  "Do you want to continue?")
            )
            response = confirm_dialog.run()
            confirm_dialog.destroy()
            if response != Gtk.ResponseType.YES:
                return

            script = """#!/bin/bash
set -e
echo "=== Removing ROCm ==="
apt purge -y 'rocm*' 'hip*' 'hsa*' 'comgr*' 'rocblas*' 'rocsolver*' 2>/dev/null || true
apt autoremove -y 2>/dev/null || true
rm -f /etc/apt/sources.list.d/rocm.list
rm -f /etc/apt/keyrings/rocm.gpg
rm -f /etc/apt/preferences.d/rocm-pin-600
apt update -q
echo "[+] ROCm removed successfully."
"""
            self._run_script_as_root(script, "remove-rocm.sh", self._refresh_driver_status)
            return

        pkg = 'rocm-opencl-runtime' if mode == 'opencl' else 'rocm'
        label = _("ROCm OpenCL") if mode == 'opencl' else _("ROCm Full Suite")
        size_note = _("~200 MB download.") if mode == 'opencl' else _("Several GB download — this may take a while.")

        confirm_dialog = Gtk.MessageDialog(
            transient_for=self.parent_window,
            flags=0,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.YES_NO,
            text=_("Confirm ROCm Installation — {label}").format(label=label)
        )
        confirm_dialog.format_secondary_text(
            _("This will:\n\n"
              "1. Add the official AMD ROCm repository.\n"
              "2. Install {label}.\n"
              "3. Add your user to the render and video groups.\n\n"
              "Requires a ROCm-supported AMD GPU: RDNA2 (RX 6800 and newer),\n"
              "RDNA3 (RX 7700-7900), RDNA4 (RX 9060-9070) or Instinct accelerators.\n"
              "The RX 5000 series and integrated GPUs are not supported.\n\n"
              "{size}\n\n"
              "A session restart will be required after installation.\n\n"
              "Do you want to continue?").format(label=label, size=size_note)
        )
        response = confirm_dialog.run()
        confirm_dialog.destroy()
        if response != Gtk.ResponseType.YES:
            return

        script = f"""#!/bin/bash
set -e
LOG="/tmp/rocm-install.log"
exec > >(tee -a "$LOG") 2>&1

echo "=== AMD ROCm Installation ({label}) ==="
echo ""

echo "[1/5] Removing any leftover ROCm repository..."
# Earlier versions wrote a Debian suite that AMD does not publish, which leaves
# apt failing on every update. Reinstalling must repair that state.
rm -f /etc/apt/sources.list.d/rocm.list
rm -f /etc/apt/keyrings/rocm.gpg
rm -f /etc/apt/preferences.d/rocm-pin-600

echo "[2/5] Setting up AMD ROCm repository..."
mkdir -p /etc/apt/keyrings
curl -fsSL https://repo.radeon.com/rocm/rocm.gpg.key | gpg --dearmor -o /etc/apt/keyrings/rocm.gpg

# AMD publishes Ubuntu suites only. The noble packages depend on plain
# libc6/libstdc++6/python3 and install under /opt/rocm, so they run on Debian.
echo "deb [arch=amd64 signed-by=/etc/apt/keyrings/rocm.gpg] https://repo.radeon.com/rocm/apt/latest noble main" \\
    > /etc/apt/sources.list.d/rocm.list

# Confine this repository so it can never replace a Debian package
cat > /etc/apt/preferences.d/rocm-pin-600 <<'PINEOF'
Package: *
Pin: release o=repo.radeon.com
Pin-Priority: 600
PINEOF

echo "[3/5] Updating package lists..."
apt update

echo "[4/5] Installing {label}..."
apt install -y {pkg}

echo "[5/5] Adding user to render and video groups..."
REAL_USER=$(getent passwd $PKEXEC_UID | cut -d: -f1)
usermod -aG render,video "$REAL_USER"

echo ""
echo "=== Installation completed successfully ==="
echo "ROCm installed. Please restart your session to apply group membership."
"""
        self._run_script_as_root(script, f"install-rocm-{mode}.sh", self._refresh_driver_status)

    def _is_cuda12_installed(self):
        """Check if CUDA 12 toolkit is installed."""
        return os.path.exists('/usr/local/cuda/bin/nvcc')

    def _on_cuda12_clicked(self, button, mode):
        """Install or remove CUDA 12 Toolkit from the NVIDIA debian12 repository."""
        if mode == 'uninstall':
            confirm_dialog = Gtk.MessageDialog(
                transient_for=self.parent_window,
                flags=0,
                message_type=Gtk.MessageType.WARNING,
                buttons=Gtk.ButtonsType.YES_NO,
                text=_("Remove CUDA 12 Toolkit")
            )
            confirm_dialog.format_secondary_text(
                _("This will remove all CUDA 12 packages and the NVIDIA CUDA repository.\n\n"
                  "Do you want to continue?")
            )
            response = confirm_dialog.run()
            confirm_dialog.destroy()
            if response != Gtk.ResponseType.YES:
                return

            script = """#!/bin/bash
set -e
echo "=== Removing CUDA 12 Toolkit ==="
apt purge -y 'cuda-toolkit-12*' 'cuda-compiler-12*' 'cuda-libraries-12*' \
    'cuda-tools-12*' 'cuda-documentation-12*' 'cuda-nvml-dev-12*' 2>/dev/null || true
apt autoremove -y 2>/dev/null || true
rm -f /etc/apt/sources.list.d/cuda-debian12-x86_64.list
apt update -q
echo "[+] CUDA 12 Toolkit removed successfully."
"""
            self._run_script_as_root(script, "remove-cuda12.sh", self._refresh_driver_status)
            return

        confirm_dialog = Gtk.MessageDialog(
            transient_for=self.parent_window,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.YES_NO,
            text=_("Confirm CUDA 12 Toolkit Installation")
        )
        confirm_dialog.format_secondary_text(
            _("This will:\n\n"
              "1. Add the NVIDIA CUDA repository.\n"
              "2. Install CUDA 12 Toolkit (nvcc, cuBLAS, cuDNN, CUDA libraries).\n\n"
              "Compatible with PyTorch and TensorFlow cu12 builds.\n"
              "Requires an NVIDIA GPU with a driver already installed.\n\n"
              "Several GB download — this may take a while.\n\n"
              "Do you want to continue?")
        )
        response = confirm_dialog.run()
        confirm_dialog.destroy()
        if response != Gtk.ResponseType.YES:
            return

        script = """#!/bin/bash
set -e
LOG="/tmp/cuda12-install.log"
exec > >(tee -a "$LOG") 2>&1

echo "=== CUDA 12 Toolkit Installation ==="
echo ""

echo "[1/3] Setting up NVIDIA CUDA repository..."
echo "deb [trusted=yes] https://developer.download.nvidia.com/compute/cuda/repos/debian12/x86_64/ /" \\
    > /etc/apt/sources.list.d/cuda-debian12-x86_64.list

echo "[2/3] Updating package lists..."
apt update

echo "[3/3] Installing CUDA 12 Toolkit..."
apt install -y cuda-toolkit-12

# Remove the repository once the toolkit is installed. It is added with
# trusted=yes (the debian12 CUDA repo signs with SHA1, which sqv rejects), so
# leaving it enabled would keep an unverified source active indefinitely and
# let it shadow Debian packages on every later upgrade. Same cleanup the
# driver flows already do.
rm -f /etc/apt/sources.list.d/cuda-debian12-x86_64.list
apt update -q

echo ""
echo "=== Installation completed successfully ==="
echo "CUDA 12 Toolkit installed. Run 'nvcc --version' to verify."
"""
        self._run_script_as_root(script, "install-cuda12.sh", self._refresh_driver_status)

    def _on_oneapi_clicked(self, button, mode):
        """Install or remove Intel oneAPI Base Toolkit."""
        if mode == 'uninstall':
            confirm_dialog = Gtk.MessageDialog(
                transient_for=self.parent_window,
                flags=0,
                message_type=Gtk.MessageType.WARNING,
                buttons=Gtk.ButtonsType.YES_NO,
                text=_("Remove Intel oneAPI")
            )
            confirm_dialog.format_secondary_text(
                _("This will remove the Intel oneAPI Base Toolkit and its repository.\n\n"
                  "Do you want to continue?")
            )
            response = confirm_dialog.run()
            confirm_dialog.destroy()
            if response != Gtk.ResponseType.YES:
                return

            script = """#!/bin/bash
set -e
echo "=== Removing Intel oneAPI Base Toolkit ==="
apt purge -y 'intel-basekit*' 'intel-oneapi-*' 2>/dev/null || true
apt autoremove -y 2>/dev/null || true
rm -f /etc/apt/sources.list.d/intel-oneapi.list
rm -f /etc/apt/keyrings/intel-oneapi.gpg
rm -f /etc/apt/preferences.d/intel-oneapi-pin-600
apt update -q
echo "[+] Intel oneAPI removed successfully."
"""
            self._run_script_as_root(script, "remove-oneapi.sh", self._refresh_driver_status)
            return

        confirm_dialog = Gtk.MessageDialog(
            transient_for=self.parent_window,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.YES_NO,
            text=_("Confirm Intel oneAPI Installation")
        )
        confirm_dialog.format_secondary_text(
            _("This will:\n\n"
              "1. Add the official Intel oneAPI repository.\n"
              "2. Install Intel oneAPI Base Toolkit (DPC++ compiler, MKL, TBB, VTune, Advisor).\n\n"
              "Recommended for Intel Arc GPU users and Intel CPU-accelerated computing.\n\n"
              "Several GB download — this may take a while.\n\n"
              "Do you want to continue?")
        )
        response = confirm_dialog.run()
        confirm_dialog.destroy()
        if response != Gtk.ResponseType.YES:
            return

        script = """#!/bin/bash
set -e
LOG="/tmp/oneapi-install.log"
exec > >(tee -a "$LOG") 2>&1

echo "=== Intel oneAPI Base Toolkit Installation ==="
echo ""

echo "[1/3] Setting up Intel oneAPI repository..."
mkdir -p /etc/apt/keyrings
curl -fsSL https://apt.repos.intel.com/intel-gpg-keys/GPG-PUB-KEY-INTEL-SW-PRODUCTS.PUB \\
    | gpg --dearmor -o /etc/apt/keyrings/intel-oneapi.gpg
echo "deb [arch=amd64 signed-by=/etc/apt/keyrings/intel-oneapi.gpg] https://apt.repos.intel.com/oneapi all main" \\
    > /etc/apt/sources.list.d/intel-oneapi.list

# Confine this repository so it can never replace a Debian package
cat > /etc/apt/preferences.d/intel-oneapi-pin-600 <<'PINEOF'
Package: *
Pin: release o=Intel Corporation
Pin-Priority: 600
PINEOF

echo "[2/3] Updating package lists..."
apt update

# intel-basekit is a legacy alias that stops at the 2025 release;
# intel-oneapi-toolkit is the umbrella Intel keeps current.
echo "[3/3] Installing Intel oneAPI Toolkit..."
apt install -y intel-oneapi-toolkit

echo ""
echo "=== Installation completed successfully ==="
echo "Run 'source /opt/intel/oneapi/setvars.sh' to activate the environment."
"""
        self._run_script_as_root(script, "install-oneapi.sh", self._refresh_driver_status)

    def _on_vbox_uninstall_clicked(self, button):
        """Uninstall VirtualBox Guest Additions.

        These are installed via the official .run installer (see
        _on_vbox_clicked), never as an apt package — so `apt remove` on
        'virtualbox-guest-utils virtualbox-guest-x11' is a no-op that leaves
        the kernel modules, DKMS entries and /opt/VBoxGuestAdditions-*
        payload fully in place. Run the official uninstaller instead, with
        an apt purge as a fallback for the (rare) case any of these were
        also installed via apt.
        """
        self._run_script_as_root(self._build_vbox_uninstall_script(),
                                 "uninstall-vbox-guest.sh", self._refresh_driver_status)

    def _build_vbox_uninstall_script(self):
        """Script body that removes VirtualBox Guest Additions — shared by
        the individual VBox uninstall button and the "Remove All Detected"
        combined action."""
        return """#!/bin/bash
UNINSTALLER=$(ls -d /opt/VBoxGuestAdditions-*/uninstall.sh 2>/dev/null | head -1)
if [ -n "$UNINSTALLER" ] && [ -x "$UNINSTALLER" ]; then
    echo "Running official VirtualBox Guest Additions uninstaller..."
    "$UNINSTALLER" || true
elif command -v rcvboxadd >/dev/null 2>&1; then
    echo "Running rcvboxadd cleanup..."
    rcvboxadd cleanup || true
else
    echo "No official VirtualBox Guest Additions uninstaller found on disk."
fi

# Fallback: purge these too in case any were installed via apt
apt purge -y virtualbox-guest-utils virtualbox-guest-x11 virtualbox-guest-dkms 2>/dev/null || true
apt autoremove -y 2>/dev/null || true

echo "VirtualBox Guest Additions removal completed."
"""

    def _on_vbox_clicked(self, button):
        """Install VirtualBox Guest Additions."""
        vbox_run = os.path.join(ASSETS_DIR, "vbox", "VBoxLinuxAdditions.run")
        script = f"""#!/bin/bash

echo "Installing VirtualBox Guest Additions..."

# Install dependencies
apt update
apt install -y build-essential dkms linux-headers-$(uname -r)
{LLVM_DKMS_TOOLCHAIN}
# Run installer (non-zero exit expected when not running inside VirtualBox)
"{vbox_run}" || true

echo ""
echo "=== Installation completed ==="
echo "VirtualBox Guest Additions installed."
echo "IMPORTANT: Restart the system to apply the changes."
"""
        self._run_script_as_root(script, "install-vbox-guest.sh", self._refresh_driver_status)
    
    def _run_script(self, script_content, script_name):
        """Create and run installation script (no root)."""
        script_path = f"/tmp/{script_name}"
        try:
            with open(script_path, "w") as f:
                f.write(script_content)
            os.chmod(script_path, 0o755)
            self.command_runner.run_command(script_path)
        except Exception as e:
            print(f"Error creating script {script_name}: {e}")
    
    def _run_script_as_root(self, script_content, script_name, on_complete=None):
        """Create and run installation script with root privileges (single pkexec)."""
        script_path = f"/tmp/{script_name}"
        try:
            with open(script_path, "w") as f:
                f.write(script_content)
            os.chmod(script_path, 0o755)
            self.command_runner.run_command(f"pkexec bash {script_path}", on_complete)
        except Exception as e:
            print(f"Error creating script {script_name}: {e}")
    
    def _is_flatpak_installed(self, flatpak_id):
        """Check if a Flatpak app is installed."""
        try:
            result = subprocess.run(['flatpak', 'info', flatpak_id],
                                    capture_output=True, text=True)
            return result.returncode == 0
        except Exception:
            return False


    def _on_scan_hardware(self, button):
        """Scan hardware and show results."""
        from utils.hardware_detector import scan_hardware

        def update_status(text):
            self.progress_label.set_text(text)

        def update_progress(fraction):
            self.progress_bar.set_fraction(fraction)

        def _make_frame(title):
            frame = Gtk.Frame(label=title)
            box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            box.set_margin_left(15)
            box.set_margin_right(15)
            box.set_margin_top(10)
            box.set_margin_bottom(10)
            frame.add(box)
            return frame, box

        def _driver_action_buttons(parent_box, driver_status, missing_packages,
                                    recommended_driver, install_cb, uninstall_cb=None):
            """Add Install/Uninstall button row based on driver_status."""
            if driver_status == 'installed':
                lbl = Gtk.Label()
                lbl.set_markup(f"<span foreground='green'>✓ {_('Driver installed')}</span>")
                lbl.set_xalign(0)
                parent_box.pack_start(lbl, False, False, 0)
                if uninstall_cb:
                    btn = Gtk.Button(label=_("Uninstall"))
                    btn.connect('clicked', uninstall_cb)
                    parent_box.pack_start(btn, False, False, 2)
            elif driver_status == 'different_version':
                lbl = Gtk.Label()
                lbl.set_markup(f"<span foreground='orange'>⚠ {_('Different version installed')}</span>")
                lbl.set_xalign(0)
                parent_box.pack_start(lbl, False, False, 0)
                btn = Gtk.Button(label=f"{_('Switch to')} {recommended_driver}")
                btn.connect('clicked', install_cb)
                parent_box.pack_start(btn, False, False, 2)
            elif driver_status == 'partial':
                lbl = Gtk.Label()
                lbl.set_markup(f"<span foreground='orange'>⚠ {_('Partially installed — missing:')} {', '.join(missing_packages)}</span>")
                lbl.set_xalign(0)
                lbl.set_line_wrap(True)
                parent_box.pack_start(lbl, False, False, 0)
                btn = Gtk.Button(label=_("Complete installation"))
                btn.connect('clicked', install_cb)
                parent_box.pack_start(btn, False, False, 2)
            else:  # missing
                lbl = Gtk.Label()
                lbl.set_markup(f"<span foreground='red'>✗ {_('Not installed')}</span>")
                lbl.set_xalign(0)
                parent_box.pack_start(lbl, False, False, 0)
                btn = Gtk.Button(label=f"{_('Install')} {recommended_driver}")
                btn.connect('clicked', install_cb)
                parent_box.pack_start(btn, False, False, 2)

        def show_results(results):
            self.progress_bar.set_fraction(0.0)

            dialog = Gtk.Dialog(
                title=_("Hardware Detection"),
                parent=self.parent_window,
                flags=0
            )
            dialog.set_default_size(700, 650)

            scrolled = Gtk.ScrolledWindow()
            scrolled.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
            dialog.get_content_area().pack_start(scrolled, True, True, 0)

            main_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
            main_box.set_margin_left(20)
            main_box.set_margin_right(20)
            main_box.set_margin_top(20)
            main_box.set_margin_bottom(10)
            scrolled.add(main_box)

            # ── CPU ──
            if results.get('cpu'):
                frame, box = _make_frame(_('Processor'))
                cpu = results['cpu']
                lbl = Gtk.Label()
                lbl.set_markup(
                    f"<b>{_('Model:')}</b> {cpu.get('model', 'N/A')}\n"
                    f"<b>{_('Cores:')}</b> {cpu.get('cores', 0)}  "
                    f"<b>{_('Threads:')}</b> {cpu.get('threads', 0)}"
                )
                lbl.set_xalign(0)
                lbl.set_line_wrap(True)
                box.pack_start(lbl, False, False, 0)
                main_box.pack_start(frame, False, False, 0)

            # ── RAM ──
            if results.get('memory'):
                frame, box = _make_frame(_('RAM Memory'))
                mem = results['memory']
                lbl = Gtk.Label()
                lbl.set_markup(
                    f"<b>{_('Total:')}</b> {mem.get('total', '?')}  "
                    f"<b>{_('Available:')}</b> {mem.get('available', '?')}"
                )
                lbl.set_xalign(0)
                box.pack_start(lbl, False, False, 0)
                main_box.pack_start(frame, False, False, 0)

            # ── VM ──
            vm = results.get('vm_detection', {})
            if vm.get('is_vm'):
                frame, box = _make_frame(_("Virtual Machine"))
                lbl = Gtk.Label()
                lbl.set_markup(f"<b>{_('Type:')}</b> {vm.get('type', '?')}")
                lbl.set_xalign(0)
                box.pack_start(lbl, False, False, 0)

                required = vm.get('required_packages', [])
                if required:
                    pkgs_str = ' '.join(required)
                    rec_lbl = Gtk.Label()
                    rec_lbl.set_markup(f"<b>{_('Recommended tools:')}</b> {pkgs_str}")
                    rec_lbl.set_xalign(0)
                    box.pack_start(rec_lbl, False, False, 0)

                    def _install_vm(b, p=pkgs_str):
                        dialog.destroy()
                        self._on_driver_clicked(b, p)

                    def _uninstall_vm(b, p=pkgs_str):
                        dialog.destroy()
                        self._on_remove_driver_clicked(b, p)

                    _driver_action_buttons(
                        box,
                        vm.get('driver_status', 'missing'),
                        vm.get('missing_packages', []),
                        pkgs_str,
                        _install_vm,
                        _uninstall_vm
                    )
                main_box.pack_start(frame, False, False, 0)

            # ── GPUs ──
            for gpu in results.get('gpus', []):
                title = f"{_('Graphics Card')} — {gpu.get('vendor', '?')} {gpu.get('model', '')}"
                frame, box = _make_frame(title)

                type_lbl = Gtk.Label()
                type_lbl.set_markup(f"<b>{_('Type:')}</b> {gpu.get('type', '?')}")
                type_lbl.set_xalign(0)
                box.pack_start(type_lbl, False, False, 0)

                rec = gpu.get('recommended_driver')
                if rec:
                    rec_lbl = Gtk.Label()
                    rec_lbl.set_markup(f"<b>{_('Recommended driver:')}</b> {rec}")
                    rec_lbl.set_xalign(0)
                    box.pack_start(rec_lbl, False, False, 0)

                    def _install_gpu(b, driver=rec):
                        dialog.destroy()
                        self._on_install_recommended_driver(b, driver, dialog)

                    def _uninstall_gpu(b):
                        dialog.destroy()
                        self._on_uninstall_nvidia_clicked(b)

                    _driver_action_buttons(
                        box,
                        gpu.get('driver_status', 'missing'),
                        gpu.get('missing_packages', []),
                        rec,
                        _install_gpu,
                        _uninstall_gpu if gpu.get('vendor') == 'NVIDIA' else None
                    )
                main_box.pack_start(frame, False, False, 0)

            # ── Hybrid Graphics ──
            hybrid = results.get('hybrid_gpu', {})
            if hybrid.get('is_hybrid'):
                frame, box = _make_frame(_('Hybrid Graphics'))
                lbl = Gtk.Label()
                lbl.set_markup(
                    f"<b>{_('Integrated:')}</b> {hybrid.get('integrated', '?')}\n"
                    f"<b>{_('Dedicated:')}</b> {hybrid.get('dedicated', '?')}"
                )
                lbl.set_xalign(0)
                box.pack_start(lbl, False, False, 0)

                btn_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
                offload_btn = Gtk.Button(label=_("PRIME Render Offload"))
                offload_btn.set_tooltip_text(_("Use NVIDIA on demand (saves battery)"))
                offload_btn.connect("clicked", self._on_hybrid_clicked, "offload")
                offload_btn.connect("clicked", lambda x: dialog.destroy())
                btn_box.pack_start(offload_btn, True, True, 0)

                primary_btn = Gtk.Button(label=_("NVIDIA Primary"))
                primary_btn.set_tooltip_text(_("Always use NVIDIA (max performance)"))
                primary_btn.connect("clicked", self._on_hybrid_clicked, "nvidia")
                primary_btn.connect("clicked", lambda x: dialog.destroy())
                btn_box.pack_start(primary_btn, True, True, 0)

                box.pack_start(btn_box, False, False, 4)
                main_box.pack_start(frame, False, False, 0)

            # ── Wi-Fi ──
            wifi_list = results.get('wifi', [])
            if wifi_list:
                frame, box = _make_frame(_('Wi-Fi'))
                for adapter in wifi_list:
                    sep_lbl = Gtk.Label()
                    sep_lbl.set_markup(
                        f"<b>{adapter.get('vendor', '?')}</b> — {adapter.get('model', '')}"
                    )
                    sep_lbl.set_xalign(0)
                    sep_lbl.set_line_wrap(True)
                    box.pack_start(sep_lbl, False, False, 0)

                    pkg = adapter.get('firmware_package')
                    if pkg:
                        def _install_wifi(b, p=pkg):
                            dialog.destroy()
                            self._on_driver_clicked(b, p)

                        def _uninstall_wifi(b, p=pkg):
                            dialog.destroy()
                            self._on_remove_driver_clicked(b, p)

                        _driver_action_buttons(
                            box,
                            adapter.get('driver_status', 'missing'),
                            adapter.get('missing_packages', []),
                            pkg,
                            _install_wifi,
                            _uninstall_wifi
                        )
                main_box.pack_start(frame, False, False, 0)

            # ── Audio ──
            audio_list = results.get('audio', [])
            if audio_list:
                frame, box = _make_frame(_('Audio'))
                for device in audio_list:
                    dev_lbl = Gtk.Label()
                    dev_lbl.set_markup(f"• {device.get('model', '?')}")
                    dev_lbl.set_xalign(0)
                    dev_lbl.set_line_wrap(True)
                    box.pack_start(dev_lbl, False, False, 0)

                    pkgs = device.get('required_packages', [])
                    if pkgs:
                        pkgs_str = ' '.join(pkgs)

                        def _install_audio(b, p=pkgs_str):
                            dialog.destroy()
                            self._on_driver_clicked(b, p)

                        def _uninstall_audio(b, p=pkgs_str):
                            dialog.destroy()
                            self._on_remove_driver_clicked(b, p)

                        _driver_action_buttons(
                            box,
                            device.get('driver_status', 'missing'),
                            device.get('missing_packages', []),
                            pkgs_str,
                            _install_audio,
                            _uninstall_audio
                        )
                main_box.pack_start(frame, False, False, 0)

            # ── Bluetooth ──
            bt = results.get('bluetooth')
            if bt:
                frame, box = _make_frame(_('Bluetooth'))
                bt_lbl = Gtk.Label()
                bt_lbl.set_markup(f"• {bt.get('model', '?')}")
                bt_lbl.set_xalign(0)
                box.pack_start(bt_lbl, False, False, 0)

                pkgs = bt.get('required_packages', [])
                if pkgs:
                    pkgs_str = ' '.join(pkgs)

                    def _install_bt(b, p=pkgs_str):
                        dialog.destroy()
                        self._on_driver_clicked(b, p)

                    def _uninstall_bt(b, p=pkgs_str):
                        dialog.destroy()
                        self._on_remove_driver_clicked(b, p)

                    _driver_action_buttons(
                        box,
                        bt.get('driver_status', 'missing'),
                        bt.get('missing_packages', []),
                        pkgs_str,
                        _install_bt,
                        _uninstall_bt
                    )
                main_box.pack_start(frame, False, False, 0)

            # ── Printers ──
            pr = results.get('printers')
            if pr:
                frame, box = _make_frame(_('Printers'))
                pr_lbl = Gtk.Label()
                pr_lbl.set_markup(f"• {pr.get('model', '?')}")
                pr_lbl.set_xalign(0)
                box.pack_start(pr_lbl, False, False, 0)

                pkgs = pr.get('required_packages', [])
                if pkgs:
                    pkgs_str = ' '.join(pkgs)

                    def _install_pr(b, p=pkgs_str):
                        dialog.destroy()
                        self._on_driver_clicked(b, p)

                    def _uninstall_pr(b, p=pkgs_str):
                        dialog.destroy()
                        self._on_remove_driver_clicked(b, p)

                    _driver_action_buttons(
                        box,
                        pr.get('driver_status', 'missing'),
                        pr.get('missing_packages', []),
                        pkgs_str,
                        _install_pr,
                        _uninstall_pr
                    )
                main_box.pack_start(frame, False, False, 0)

            # ── Storage ──
            if results.get('storage'):
                frame, box = _make_frame(_('Storage'))
                for device in results['storage']:
                    lbl = Gtk.Label()
                    lbl.set_markup(f"• <b>{device.get('name', '?')}:</b> {device.get('size', '?')}")
                    lbl.set_xalign(0)
                    box.pack_start(lbl, False, False, 0)
                main_box.pack_start(frame, False, False, 0)

            # ── Network ──
            if results.get('network'):
                frame, box = _make_frame(_('Network'))
                for iface in results['network']:
                    text = f"• <b>{iface.get('name', '?')}:</b> {iface.get('type', '?')}"
                    if iface.get('status'):
                        text += f" — {iface['status']}"
                    lbl = Gtk.Label()
                    lbl.set_markup(text)
                    lbl.set_xalign(0)
                    box.pack_start(lbl, False, False, 0)
                main_box.pack_start(frame, False, False, 0)

            # ── Unnecessary software ──
            unnecessary = results.get('unnecessary_software', [])
            if unnecessary:
                frame, box = _make_frame(_('Unnecessary Software Detected'))

                if len(unnecessary) > 1:
                    def _uninstall_all(b, items=unnecessary):
                        dialog.destroy()
                        self._on_uninstall_all_unnecessary_clicked(b, items)

                    all_btn = Gtk.Button(label=_("Remove All Detected"))
                    all_btn.get_style_context().add_class('destructive-action')
                    all_btn.connect('clicked', _uninstall_all)
                    box.pack_start(all_btn, False, False, 4)

                for item in unnecessary:
                    lbl = Gtk.Label()
                    lbl.set_markup(
                        f"<span foreground='orange'>⚠</span> <b>{item.get('name', '?')}</b> — {item.get('detail', '')}"
                    )
                    lbl.set_xalign(0)
                    lbl.set_line_wrap(True)
                    box.pack_start(lbl, False, False, 0)

                    action = item.get('action')
                    item_packages = item.get('packages', [])

                    def _uninstall_unnecessary(b, action=action, packages=item_packages):
                        dialog.destroy()
                        if action == 'nvidia':
                            self._on_uninstall_nvidia_clicked(b)
                        elif action == 'vbox':
                            self._on_vbox_uninstall_clicked(b)
                        elif action == 'generic' and packages:
                            self._on_remove_driver_clicked(b, ' '.join(packages))

                    unin_btn = Gtk.Button(label=_("Uninstall"))
                    unin_btn.connect('clicked', _uninstall_unnecessary)
                    box.pack_start(unin_btn, False, False, 2)
                main_box.pack_start(frame, False, False, 0)

            # ── Close button ──
            close_btn = Gtk.Button(label=_("Close"))
            close_btn.connect("clicked", lambda x: dialog.destroy())
            btn_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
            btn_row.set_halign(Gtk.Align.END)
            btn_row.set_margin_top(8)
            btn_row.set_margin_bottom(10)
            btn_row.set_margin_end(10)
            btn_row.pack_start(close_btn, False, False, 0)
            dialog.get_content_area().pack_start(btn_row, False, False, 0)

            dialog.show_all()

        scan_hardware(update_status, update_progress, show_results)
    
    def _on_install_recommended_driver(self, button, driver, dialog):
        """Install recommended driver from hardware scan."""
        button.set_sensitive(False)
        dialog.destroy()

        cuda_drivers = {"nvidia-driver-580": "580", "nvidia-driver-590": "590", "nvidia-driver-610": "610"}
        legacy_drivers = {"nvidia-tesla-470-driver", "nvidia-legacy-390xx-driver", "nvidia-legacy-340xx-driver"}

        if driver in cuda_drivers:
            self._on_nvidia_cuda_repo_clicked(button, cuda_drivers[driver])
        elif driver == "nvidia-driver":
            self._on_nvidia_repo_clicked(button, "nvidia-driver")
        elif driver in legacy_drivers:
            self._on_legacy_nvidia_clicked(button, driver)
        elif driver == "nouveau":
            self._on_nouveau_clicked(button)
        else:
            self._on_driver_clicked(button, driver)
    
    def _on_detect_hybrid_clicked(self, button):
        """Detect if the system has hybrid graphics."""
        from utils.hardware_detector import detect_hybrid_gpu
        
        result = detect_hybrid_gpu()
        
        dialog = Gtk.MessageDialog(
            transient_for=self.parent_window,
            flags=0,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text=_("Hybrid Graphics Detection")
        )
        
        if result['is_hybrid']:
            dialog.format_secondary_text(
                _("Hybrid graphics detected!\n\n"
                  "Integrated GPU: {integrated}\n"
                  "Dedicated GPU: {dedicated}\n\n"
                  "You can configure PRIME Render Offload (saves battery) "
                  "or NVIDIA Primary (maximum performance).").format(
                    integrated=result.get('integrated', 'Unknown'),
                    dedicated=result.get('dedicated', 'Unknown')
                )
            )
        else:
            dialog.format_secondary_text(
                _("No hybrid graphics detected.\n\n"
                  "Your system has: {gpu}\n\n"
                  "Hybrid configuration is not needed.").format(
                    gpu=result.get('primary', 'Unknown GPU')
                )
            )
        
        dialog.run()
        dialog.destroy()

    def _on_uninstall_all_unnecessary_clicked(self, button, items):
        """
        Uninstall every item from "Unnecessary Software Detected" in one go,
        instead of clicking each row's "Uninstall" button one by one. Reuses
        the exact same script bodies as the individual nvidia/vbox handlers
        (via _build_nvidia_uninstall_script/_build_vbox_uninstall_script),
        concatenated with 'generic' apt purges into a single script run once.
        """
        names = ', '.join(item.get('name', '?') for item in items)
        confirm_dialog = Gtk.MessageDialog(
            transient_for=self.parent_window,
            flags=0,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.YES_NO,
            text=_("Remove All Detected Software")
        )
        confirm_dialog.format_secondary_text(
            _("This will uninstall everything listed below:\n\n{}\n\n"
              "A system restart may be required.\n\n"
              "Do you want to continue?").format(names)
        )
        response = confirm_dialog.run()
        confirm_dialog.destroy()
        if response != Gtk.ResponseType.YES:
            return

        parts = ["#!/bin/bash"]
        for item in items:
            action = item.get('action')
            packages = item.get('packages', [])
            if action == 'nvidia':
                parts.append(self._build_nvidia_uninstall_script().replace('#!/bin/bash', '', 1))
            elif action == 'vbox':
                parts.append(self._build_vbox_uninstall_script().replace('#!/bin/bash', '', 1))
            elif action == 'generic' and packages:
                pkg_str = ' '.join(packages)
                parts.append(f'echo "Removing: {pkg_str}"\napt purge -y {pkg_str} 2>/dev/null || true\napt autoremove -y 2>/dev/null || true\n')

        script = '\n'.join(parts)
        self._run_script_as_root(script, "uninstall-all-unnecessary.sh", self._refresh_driver_status)

    def _on_uninstall_nvidia_clicked(self, button):
        """Remove all NVIDIA drivers and related packages."""
        confirm_dialog = Gtk.MessageDialog(
            transient_for=self.parent_window,
            flags=0,
            message_type=Gtk.MessageType.WARNING,
            buttons=Gtk.ButtonsType.YES_NO,
            text=_("Uninstall NVIDIA Drivers")
        )
        confirm_dialog.format_secondary_text(
            _("This will completely remove all NVIDIA and CUDA packages from your system.\n\n"
              "This includes drivers, kernel modules, DKMS entries, CUDA libraries "
              "and NVIDIA repository sources.\n\n"
              "After removal you can install a different driver version.\n\n"
              "A system restart will be required.\n\n"
              "Do you want to continue?")
        )
        response = confirm_dialog.run()
        confirm_dialog.destroy()
        if response != Gtk.ResponseType.YES:
            return

        self._run_script_as_root(self._build_nvidia_uninstall_script(),
                                 "uninstall-nvidia.sh", self._refresh_driver_status)

    def _build_nvidia_uninstall_script(self):
        """Script body that fully removes NVIDIA/CUDA — shared by the
        individual NVIDIA uninstall button and the "Remove All Detected"
        combined action."""
        return """#!/bin/bash

echo "=== Removing all NVIDIA drivers ==="
echo ""

echo "[0/7] Removing NVIDIA DKMS modules from all kernels..."
for entry in $(dkms status | grep -i nvidia | awk -F'[:,]' '{print $1"/"$2}' | tr -d ' '); do
    dkms remove --force "$entry" --all 2>/dev/null || true
done
for kver in $(ls /lib/modules/); do
    rm -f /lib/modules/$kver/updates/dkms/nvidia*.ko*
    rm -f /lib/modules/$kver/updates/dkms/nvidia-*.ko*
    depmod -a "$kver" 2>/dev/null || true
done
rm -rf /var/lib/dkms/nvidia*

echo "[1/7] Fixing any interrupted dpkg state..."
dpkg --configure -a 2>/dev/null || true

echo "[2/7] Removing NVIDIA and CUDA packages..."
NVIDIA_PKGS=$(dpkg -l | grep -iE '^[a-z]+[[:space:]]+(nvidia|libnvidia|cuda)' | awk '{print $2}' | tr '\n' ' ')
if [ -n "$NVIDIA_PKGS" ]; then
    echo "Packages to remove: $NVIDIA_PKGS"
    apt purge -y $NVIDIA_PKGS 2>/dev/null || dpkg --purge --force-depends $NVIDIA_PKGS
else
    echo "No NVIDIA/CUDA packages found."
fi
apt autoremove -y 2>/dev/null || true

echo "[3/7] Removing NVIDIA CUDA repository sources..."
rm -f /etc/apt/sources.list.d/cuda-*.list
rm -f /etc/apt/sources.list.d/nvidia*.list
rm -f /usr/share/keyrings/cuda-*.gpg
rm -f /usr/share/keyrings/nvidia*.gpg
apt update -q

echo "[4/7] Removing NVIDIA dracut configuration..."
rm -f /etc/dracut.conf.d/nvidia.conf
rm -f /etc/dracut.conf.d/blacklist-nouveau.conf
rm -f /etc/apt/apt.conf.d/99nvidia-sha1-exception

echo "[5/7] Restoring GRUB defaults..."
sed -i 's/ nvidia-drm.modeset=1//' /etc/default/grub 2>/dev/null || true
update-grub 2>/dev/null || true

echo "[6/7] Regenerating initramfs..."
if command -v dracut >/dev/null 2>&1; then
    dracut --force
elif command -v update-initramfs >/dev/null 2>&1; then
    update-initramfs -u
fi

echo ""
echo "[7/7] Done."
echo "=== NVIDIA drivers removed completely ==="
echo "Restart the system before installing a new driver version."
"""

    def _on_hybrid_clicked(self, button, mode):
        """Configure hybrid graphics."""
        if mode == "offload":
            de = self.environment_detector.desktop_environment.value
            script = f"""#!/bin/bash
set -e

DESKTOP_ENV="{de}"
echo "Configuring PRIME Render Offload..."

# Check if NVIDIA driver is installed
if ! command -v nvidia-smi &>/dev/null; then
    echo "ERROR: NVIDIA driver is not installed."
    echo "Please install the NVIDIA driver first."
    exit 1
fi

# Remove any existing NVIDIA primary configuration
echo "Removing NVIDIA primary configuration..."
rm -f /etc/X11/xorg.conf.d/10-nvidia-prime.conf
rm -f /etc/X11/xorg.conf
rm -f /etc/environment.d/10-nvidia-primary.conf
rm -f /etc/udev/rules.d/61-nvidia-prime.rules
rm -f /etc/udev/rules.d/61-gdm-nvidia.rules

# Create script for running apps with NVIDIA (works on Xorg AND Wayland)
cat > /usr/local/bin/prime-run << 'PRIMERUN'
#!/bin/bash
# PRIME Render Offload - Run application with NVIDIA GPU
# Works on both Xorg and Wayland

export __NV_PRIME_RENDER_OFFLOAD=1
export __NV_PRIME_RENDER_OFFLOAD_PROVIDER=NVIDIA-G0
export __GLX_VENDOR_LIBRARY_NAME=nvidia
export __VK_LAYER_NV_optimus=NVIDIA_only

# For Wayland/EGL
export __EGL_VENDOR_LIBRARY_FILENAMES=/usr/share/glvnd/egl_vendor.d/10_nvidia.json
export GBM_BACKEND=nvidia-drm

exec "$@"
PRIMERUN
chmod +x /usr/local/bin/prime-run

# Create desktop entry for running apps with NVIDIA
mkdir -p /usr/share/applications
cat > /usr/share/applications/prime-run.desktop << 'DESKTOP'
[Desktop Entry]
Name=Run with NVIDIA GPU
Comment=Run application using the NVIDIA GPU
Exec=prime-run %f
Icon=nvidia
Terminal=false
Type=Application
NoDisplay=true
DESKTOP

# Generate kwinoutputconfig.json for KDE Plasma to fix wallpaper/icons loss on reboot
if [ "$DESKTOP_ENV" = "kde" ]; then
    echo "KDE Plasma detected - generating kwinoutputconfig.json..."

    INTEL_CONNECTOR=$(ls /sys/class/drm/ | grep -E "^card[0-9]+-eDP" | head -1 | sed 's/card[0-9]*-//')
    if [ -z "$INTEL_CONNECTOR" ]; then
        INTEL_CONNECTOR=$(ls /sys/class/drm/ | grep -E "^card[0-9]+-LVDS" | head -1 | sed 's/card[0-9]*-//')
    fi

    if [ -n "$INTEL_CONNECTOR" ]; then
        echo "Detected connector: $INTEL_CONNECTOR"
        REAL_USER=$(getent passwd $PKEXEC_UID | cut -d: -f1)
        REAL_HOME=$(getent passwd $PKEXEC_UID | cut -d: -f6)

        KWIN_CONFIG_DIR="$REAL_HOME/.config/kdedefaults"
        mkdir -p "$KWIN_CONFIG_DIR"

        cat > "$KWIN_CONFIG_DIR/kwinoutputconfig.json" << EOF
[
    {{
        "data": [{{"connectorName": "$INTEL_CONNECTOR"}}],
        "name": "outputs"
    }},
    {{
        "data": [
            {{
                "lidClosed": false,
                "outputs": [
                    {{
                        "enabled": true,
                        "outputIndex": 0,
                        "position": {{"x": 0, "y": 0}},
                        "priority": 0
                    }}
                ]
            }}
        ],
        "name": "setups"
    }}
]
EOF
        chown -R "$REAL_USER:$REAL_USER" "$KWIN_CONFIG_DIR" 2>/dev/null
        echo "kwinoutputconfig.json created for user $REAL_USER."
    else
        echo "No eDP/LVDS connector detected, skipping kwinoutputconfig.json."
    fi
fi

echo ""
echo "=== Configuration complete ==="
echo "PRIME Render Offload configured."
echo ""
echo "Works on both Xorg and Wayland."
echo ""
echo "To run an application with NVIDIA GPU, use:"
echo "  prime-run <application>"
echo ""
echo "Examples:"
echo "  prime-run glxgears"
echo "  prime-run steam"
echo "  prime-run blender"
echo ""
echo "No reboot required. You can use prime-run immediately."
"""
            self._run_script_as_root(script, "configure-prime-offload.sh")
        
        elif mode == "nvidia":
            # Get current desktop environment and display protocol
            de = self.environment_detector.desktop_environment.value
            protocol = self.environment_detector.display_protocol.value
            
            # NVIDIA as primary GPU - Adapts to detected environment
            script = f"""#!/bin/bash
set -e

# Detected environment: {de} on {protocol}
DESKTOP_ENV="{de}"

echo "Configuring NVIDIA as primary GPU..."
echo "Detected desktop: $DESKTOP_ENV"

# Check if NVIDIA driver is installed
if ! command -v nvidia-smi &>/dev/null; then
    echo "ERROR: NVIDIA driver is not installed."
    echo "Please install the NVIDIA driver first."
    exit 1
fi

# Check driver version for Wayland GBM support (495+)
DRIVER_VERSION=$(nvidia-smi --query-gpu=driver_version --format=csv,noheader 2>/dev/null | head -1 | cut -d. -f1)
echo "Detected NVIDIA driver version: $DRIVER_VERSION"

# Ensure nvidia-drm.modeset=1 is set (required for Wayland and proper X11)
if ! grep -q "nvidia-drm.modeset=1" /etc/default/grub; then
    echo "Adding nvidia-drm.modeset=1 to GRUB..."
    sed -i 's/GRUB_CMDLINE_LINUX_DEFAULT="\\([^"]*\\)"/GRUB_CMDLINE_LINUX_DEFAULT="\\1 nvidia-drm.modeset=1"/' /etc/default/grub
    update-grub
fi

# Create environment file for NVIDIA as primary (works for all DEs)
echo "Setting up environment variables..."
mkdir -p /etc/environment.d
cat > /etc/environment.d/10-nvidia-primary.conf << 'ENVCONF'
# NVIDIA as primary GPU - Works on X11 and Wayland
__EGL_VENDOR_LIBRARY_FILENAMES=/usr/share/glvnd/egl_vendor.d/10_nvidia.json
__GLX_VENDOR_LIBRARY_NAME=nvidia
ENVCONF

# Configure based on detected desktop environment
case "$DESKTOP_ENV" in
    "gnome")
        echo "Configuring for GNOME (GDM3)..."
        if [ -f /etc/gdm3/custom.conf ]; then
            # Enable Wayland with NVIDIA (driver 495+ required)
            sed -i '/WaylandEnable=false/d' /etc/gdm3/custom.conf
            # Udev rule for Wayland with NVIDIA
            mkdir -p /etc/udev/rules.d
            echo 'ENV{{DRIVER}}=="nvidia", RUN+="/usr/bin/gdm-runtime-config set daemon WaylandEnable true"' > /etc/udev/rules.d/61-gdm-nvidia.rules
        fi
        ;;
    "kde")
        echo "Configuring for KDE Plasma (SDDM)..."
        # SDDM supports both X11 and Wayland sessions natively
        # User can choose at login screen — no additional config needed
        ;;
    "xfce")
        echo "Configuring for Xfce (LightDM)..."
        # Xfce only supports X11, configure Xorg properly
        if [ -f /etc/lightdm/lightdm.conf ]; then
            echo "LightDM detected - X11 only, no additional configuration needed."
        fi
        ;;
    *)
        echo "Unknown desktop environment, applying generic configuration..."
        ;;
esac

# Xorg configuration. Only takes effect in an X11 session, but it is written
# unconditionally: Boro and Tyson boot Wayland yet can still offer a Plasma X11
# or GNOME on Xorg session, and which one the user lands on can change at the
# next login. Under Wayland the work is done by nvidia-drm.modeset=1 above.
echo "Creating Xorg configuration (used when logging into an X11 session)..."
mkdir -p /etc/X11/xorg.conf.d
cat > /etc/X11/xorg.conf.d/10-nvidia-prime.conf << 'XORGCONF'
Section "OutputClass"
    Identifier "nvidia"
    MatchDriver "nvidia-drm"
    Driver "nvidia"
    Option "AllowEmptyInitialConfiguration"
    Option "PrimaryGPU" "yes"
    ModulePath "/usr/lib/x86_64-linux-gnu/nvidia/xorg"
EndSection
XORGCONF

# Ensure NVIDIA modules are included in initramfs
if command -v dracut >/dev/null 2>&1; then
    mkdir -p /etc/dracut.conf.d
    echo 'omit_drivers+=" nouveau "' > /etc/dracut.conf.d/blacklist-nouveau.conf
    # The NVIDIA modules must NOT be forced into the initramfs: nvidia_drm takes
    # the display there and the handover at switch-root can leave the boot stuck
    # on a black screen. They load normally once the real system is up, so the
    # file is removed instead of written, also cleaning up earlier installs.
    rm -f /etc/dracut.conf.d/nvidia.conf
    echo "Regenerating initramfs with NVIDIA modules..."
    dracut --force
elif command -v update-initramfs >/dev/null 2>&1; then
    echo "Regenerating initramfs..."
    update-initramfs -u
fi

echo ""
echo "=== Configuration complete ==="
echo "NVIDIA configured as primary GPU for $DESKTOP_ENV."
echo ""
if [ "$DESKTOP_ENV" = "xfce" ]; then
    echo "Xfce uses X11 only."
else
    echo "Both X11 and Wayland sessions are available."
    if [[ "$DRIVER_VERSION" =~ ^[0-9]+$ ]] && [ "$DRIVER_VERSION" -ge 555 ]; then
        echo "Wayland: fully supported (driver $DRIVER_VERSION)."
    elif [[ "$DRIVER_VERSION" =~ ^[0-9]+$ ]] && [ "$DRIVER_VERSION" -ge 550 ]; then
        echo "WARNING: Driver 550 has known freezes with KDE Wayland."
        echo "Upgrade to 610 for a stable Wayland experience."
    else
        echo "WARNING: Could not detect driver version or version below 550."
        echo "Wayland stability not guaranteed. Use X11 session if issues arise."
    fi
fi
echo ""
echo "IMPORTANT: Restart the system to apply changes."
"""
            self._run_script_as_root(script, "configure-nvidia-primary.sh")
