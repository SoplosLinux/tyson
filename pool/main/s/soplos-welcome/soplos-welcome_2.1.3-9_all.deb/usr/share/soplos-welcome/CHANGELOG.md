# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/lang/en/).
 
## [2.1.3-9] - 2026-10-21
 
### Fixed
- **Drivers tab (NVIDIA DKMS on Linux 7.3+)**: the `NV_DMEM_CGROUP_INIT_PATCH` added in 2.1.3-8 was never applied. Its hunk header declared 7 old and 17 new lines while the body has 6 and 15, so `patch` rejected it as malformed and the install script only printed a warning. The header is corrected (`@@ -2818,6 +2818,15 @@`). Checked against the real NVIDIA 610.57.04 sources: it applies cleanly and the module builds against the Linux 7.3 headers, where the unpatched sources fail with `-Wint-conversion` at `os-interface.c:2820`.

## [2.1.3-8] - 2026-10-20
 
### Fixed
- **Drivers tab (NVIDIA DKMS on Linux 7.3+)**: added `NV_DMEM_CGROUP_INIT_PATCH` compatibility patch fixing `-Wint-conversion` error in `os-interface.c` due to the `dmem_cgroup_register_region()` signature change in Linux 7.3+.

## [2.1.3-7] - 2026-10-10

### Fixed
- **Drivers tab / hardware scanner (Ralink/MediaTek Wi-Fi firmware button did nothing)**: `firmware-ralink` has no install candidate in Debian testing (forky) — confirmed by downloading `firmware-mediatek`'s `.deb` directly and listing its contents, which include the Ralink blobs (`rt2860.bin`, `rt2870.bin`, `rt3071.bin`, plus the `rt3070.bin`/`rt3090.bin` symlinks). `_identify_wifi_vendor()` in `hardware_detector.py` now returns `firmware-mediatek` for Ralink/MediaTek adapters. Reported on the forum.

### Added
- **Drivers tab (Broadcom Wi-Fi)**: added a second button, "Broadcom Wi-Fi (proprietary)", installing `broadcom-sta-dkms`. The existing button only ever offered `firmware-b43-installer`, which covers just the fully reverse-engineered BCM43xx chips — several other Broadcom chips (BCM4311, BCM4312, BCM4313, BCM4321, BCM4322, BCM43142, BCM43224/25/27/28...) have no open driver at all and need the proprietary one, for which Welcome previously offered no install path.

## [2.1.3-6] - 2026-10-08

### Added
- **Recommended tab**: ported everything still missing from the Welcome 3.0 catalog, found via a full field-by-field audit (not just app names) against it — PrintCraft (Office), FilmCraft and EffectCraft (Multimedia), PhotoCraft, VectorCraft and LightCraft (Graphics), all clean-room Adobe-suite alternatives written in Rust, installed from their latest GitHub release `.deb`. Added VirtualBox and VirtualBox Extension Pack to Virtualization, with a new generic `license_confirm` dialog in `recommended_tab.py` (reusable for any future package, not hardcoded to these two). Added VMware Workstation Pro, with a DaVinci-Resolve-style manual flow (`.bundle` file picker, unattended install, then `soplos-vmware-modules` from the Soplos repos for vmmon/vmnet).

### Changed
- **Recommended tab**: Waydroid moved from Development to Virtualization, matching Welcome 3.0's reorganization.
- **Recommended tab (Multimedia)**: Audacity now installs from the official AppImage instead of apt. Audacity 4 ships no Debian package at all (confirmed on audacityteam.org and GitHub releases), so the apt entry was silently installing the stale 3.7.8 from Debian instead of the current 4.x. Icon updated to the current Audacity 4 artwork, matching 3.0.
- **Recommended tab (Development)**: Google Antigravity now downloads the official tarball straight from Google's CDN into `/opt` instead of using Google's own apt repository, which has been discontinued. The install step also cleans up the old repo-based install (package, repo file, keyring) so upgrading from it leaves nothing behind.

## [2.1.3-5] - 2026-09-30

### Added
- **Recommended tab (Multimedia)**: added Glassy Music, Orchard and Sonora (YouTube Music/streaming clients) and Concat (AI-captioning video editor), ported from the Welcome 3.0 catalog. Orchard is pinned to a specific beta release rather than resolved from GitHub's "latest" API, since its stable channel has shipped no Linux assets since v4.5.0. Sonora installs from its own single-app Flatpak repo via a `.flatpakref` URL rather than Flathub.

## [2.1.3-4] - 2026-09-29

### Fixed
- **Recommended tab (DaVinci Resolve install produced no `.deb`)**: the bundled `makeresolvedeb` was pinned to 1.10.0 (May), which doesn't know about the `Immersive` directory DaVinci Resolve 21.1's installer introduced — it has no existence check before touching it, unlike 1.10.1 (already in use in Welcome 3.0). On Resolve 21.1 the conversion step ran to completion but left loose unpacked directories in the work folder instead of finished `.deb` packages, so the install silently produced nothing installable. Replaced `services/makeresolvedeb_1.10.0_multi.sh` with `makeresolvedeb_1.10.1_multi.sh`, matching 3.0.

## [2.1.3-3] - 2026-09-28

### Added
- **Recommended tab (Graphics)**: added Fog Panther (Flatpak, `com.fogpanther.FogPanther`) and Patchy, an open-source image editor focused on PSD compatibility. Patchy isn't on Flathub, so it installs from the `.flatpak` bundle published on its GitHub releases, at user level: the install commands run under `pkexec`, so the Flatpak calls go through `sudo -u $REAL_USER` (resolved from `$PKEXEC_UID`) to land in the logged-in user's installation and match the `check_path`. Both ported from the Welcome 3.0 catalog, with their icons and translations in all 8 languages.

## [2.1.3-2] - 2026-09-26

### Fixed
- Depends on `soplos-fontconfig-woff-fix` to prevent Qt applications from crashing in `FcCharSetHasChar` after Chromium 154-based browsers rewrite the user font cache (fontconfig #565).

## [2.1.3-1] - 2026-09-24

### Added
- **Recommended tab (Communication)**: WhatsApp switched from an unofficial third-party Flatpak to a WhatsApp Web desktop shortcut created through the same mechanism as Soplos WebApp Manager. This required porting the whole webapp install/uninstall/status-check machinery from `gaming_tab.py` into `recommended_tab.py`, which didn't have any webapp support before — reusable now for future webapp entries in Recommended.
- **Software tab**: added Warehouse and Easy Flatpak (both Flatpak) to all three desktop variants (GNOME, Plasma, Xfce). Added Discover (KDE's software center) too, with a confirmation dialog before installing on non-Plasma desktops explaining the extra KDE Frameworks packages it pulls in — matching the same confirmation pattern already used for Bazaar.
- **Translations**: added real (not English-passthrough) translations across all 8 languages for every string introduced since 2.1.3 — Remote Desktops, Virtualization and their packages, GenOffice, the WhatsApp webapp description, the WebApp badge, and the three new software stores with Discover's dialog. Fixed missing header fields (`Project-Id-Version`, `PO-Revision-Date`, `Last-Translator`, `Language-Team`, `Language`, `MIME-Version`) that `msgfmt --check` was warning about in all 8 `.po` files. Compiled `.mo` files for all 8 languages.

### Changed
- **Recommended tab (Communication)**: Telegram now installs from Soplos's own apt repository instead of Flatpak, now that it's packaged there — removed from the `prefer_flatpak` override list.
- **Software tab**: Repo Selector moved to the first position in the grid in all three desktop variants, matching Welcome 3.0's ordering.

## [2.1.3] - 2026-09-18

### Added
- **Recommended tab**: added two new categories, ported from the Welcome 3.0 (Tauri) alpha catalog to keep both versions in sync while 2.x is still the shipping one — **Remote Desktops** (Remmina, RustDesk, AnyDesk, NoMachine, all Flatpak) and **Virtualization** (`virt-manager`, GNOME Boxes, both apt; VirtualBox and its Extension Pack intentionally left out — porting their install logic was decided not to be worth repeating after the trouble it took to get right in 3.0). Icons copied from the 3.0 alpha's asset set.

### Fixed
- **Recommended tab (new categories weren't showing up)**: `_load_recommended_software()` renders categories from a hardcoded list ([recommended_tab.py:147](ui/tabs/recommended_tab.py#L147)) instead of iterating every key in `SOFTWARE_CATEGORIES`, so the two new categories existed in the data but never got drawn until they were added to that list too.
- **Packaging (missing `wmctrl` dependency)**: `core/environment.py` shells out to `wmctrl` to detect the running window manager, but the package was never declared in `debian/control`'s `Depends`. On a machine where nothing else happened to pull it in (a bare Debian install, notably), Welcome would fail. Added `wmctrl` to `Depends`.

## [2.1.2-9] - 2026-09-15

### Added
- **Recommended tab (Office)**: added GenOffice, an open-source AI office suite (Docs, Sheets, Slides, PDF, HTML and Markdown editors). Installs from the `.deb` served at `genoffice.ai/download/linux-deb`, which always redirects to the vendor's latest GitHub release, so the entry never needs to be re-pinned to a version.

### Fixed
- **Recommended tab (silent install failures across the whole tab)**: the script generated by `recommended_tab.py` had no `set -e`, so any failing command (a bad Flatpak ref, a broken download, an `apt` error) was ignored and the script still printed "Operation completed successfully". This masked every other bug below until now — they all failed silently before this fix. `set -e` is now written into every generated script, matching the other five tabs that already had it (Software, Gaming, Drivers, Kernels, Security).
- **Recommended tab (Collabora Office never installed)**: its Flatpak ID was `org.collaboraoffice.CollaboraOffice`, which does not exist on Flathub — verified against Flathub's own API. The real ID is `com.collaboraoffice.Office`.
- **Recommended tab (GeForce NOW installed at system level instead of user level)**: its `install_commands` ran `flatpak remote-add`/`flatpak install` with no `--user`, and since custom `install_commands` always run under `pkexec` (root), the remote and the app landed in root's Flatpak installation instead of the real user's — invisible to Welcome's own install-state check and to every other Flatpak app, which are all installed at user level. Added `--user` to both commands, and `sudo -u $REAL_USER` (resolved from `$PKEXEC_UID`, the same pattern already used by the AppImage entries in this file) so the operations actually target the logged-in user despite the script running as root.
- **Recommended tab (DaVinci Resolve install button stuck forever after cancelling)**: `_on_install_package` marks the package as "installing" before calling `_install_davinci_resolve`, but cancelling either of its first two dialogs (the initial notice, the archive/file picker) returned without ever clearing that mark. The button stayed disabled until Welcome was restarted. Both cancel paths now clear the mark and refresh the UI.
- **Recommended tab (LMMS had no install candidate)**: LMMS is present in Debian stable (trixie) and unstable (sid) but was dropped from testing (forky, Soplos's actual base) — confirmed against Debian's madison archive, not the cached package-search page. Switched from `apt` to its Flathub entry (`io.lmms.LMMS`), which also takes it out of the batch-install `apt` transaction, so a failure there no longer blocks every other package selected in the same batch.
- **Recommended tab (amdgpu_top installed nothing, silently)**: its install script parses the latest GitHub release for a `browser_download_url` ending in `amd64.deb`, but the current release ships two matches (`amdgpu-top_*_amd64.deb` and `amdgpu-top_without_gui_*_amd64.deb`); the un-narrowed `grep` captured both URLs on separate lines, so `wget` received a broken multi-line argument and failed — invisibly, before the `set -e` fix above. Added `grep -v without_gui` to keep only the GUI build.
- **Recommended tab (CPU Power installed but never did anything)**: its `package` key only listed `cpupower-gui` (the GUI), while a second, unused key named `packages` (never read anywhere in the codebase) held `linux-cpupower`, the actual backend the GUI needs to read/set the CPU governor. Moved both into a single `install_commands: apt install -y cpupower-gui linux-cpupower`.
- **Software tab (double password prompt installing Snap Store without Snapd)**: when Snapd wasn't already installed, the generated script ran `pkexec apt install -y snapd ...` and `pkexec snap install ...` as two separate commands, each prompting for authentication. Merged into a single `pkexec bash -c '... && ...'`, one prompt, same fix already applied to Cloudflare WARP. Fixed identically in all three desktop variants (GNOME, Plasma, Xfce).

### Changed
- **Software tab**: removed an emoji from a debug `print()` (not visible in the UI) in all three desktop variants, per project convention.

## [2.1.2-8] - 2026-09-10

### Fixed
- **Recommended tab (Waydroid — adapted to Android Binder going built-in)**: `ANDROID_BINDER_IPC` turned out to be a plain bool in Kconfig with no module form at all, so kernel-installer now enables it as `y` instead of `m`. Removed the now-pointless `modprobe`/`modules-load.d`/`modprobe.d` steps from the install script (nothing to load, the driver initializes at boot), and switched the availability check from `modinfo binder_linux` (which never detects anything built-in) to checking for `/dev/binder`.

## [2.1.2-7] - 2026-09-09

### Added
- **Recommended tab (Development)**: added Waydroid, an Android container for developing and testing Android apps. Its official repo (`repo.waydro.id`) auto-detects the distro codename and fails on Soplos (`VERSION_CODENAME`/`/etc/debian_version` aren't in its supported list), so the suite is pinned to `trixie` (verified: has real packages published there), same reasoning as the XanMod/ROCm/Cloudflare WARP fixes.
- **Recommended tab (Waydroid — modprobe automation)**: Waydroid's own `waydroid-container.service` expects the `binder_linux` kernel module already loaded — it never loads it itself, the most commonly reported Waydroid installation failure on any distro. The install step now also writes `/etc/modules-load.d/waydroid.conf` (autoload on every boot) and `/etc/modprobe.d/waydroid.conf` (the three device nodes Waydroid needs: binder, hwbinder, vndbinder), and loads the module immediately so it works without a reboot.
- **Recommended tab (Waydroid — kernel gate)**: `binder_linux` only exists on Soplos kernels built after the corresponding kernel-installer change, and installed kernels aren't kept side by side — updating removes the previous one. The Install button is now disabled with an explanatory tooltip when `modinfo binder_linux` doesn't find the module, instead of letting the user hit a guaranteed failure.

## [2.1.2-6] - 2026-09-02

### Fixed
- **Security, Recommended and Gaming tabs (Flatpak apps reported as installed without Flatpak)**: these three tabs launched `flatpak install` with no checks, so on a system without Flatpak the command failed with "command not found" while the script still printed its success message and the operation was reported as completed. All three now check that Flatpak is present and that Flathub is configured **for the user**, which is the level Welcome installs at, and otherwise explain that Flatpak and Flathub have to be installed from the Software tab. The check also covers the case Bazaar leaves behind: Bazaar moves Flathub to the system level, and with only a system-wide remote these installs fail too, so that situation gets its own message.
- **Kernels and Drivers tabs (NVIDIA DKMS failed on XanMod)**: XanMod kernels are built with LLVM/Clang (`CONFIG_CC_IS_CLANG`, `CONFIG_LD_IS_LLD`), and DKMS has to build its modules with the same toolchain, so on a gcc-only system the NVIDIA module did not compile and the machine ended up with no driver. `clang`, `lld` and `llvm` are now installed before the build in all four places that trigger one: the XanMod installer, NVIDIA from the repository, NVIDIA from the `.run` file, and VirtualBox Guest Additions. Installing XanMod only pulls the toolchain in when the system already has DKMS modules; the driver installers check the running kernel's own config, so a normal gcc-built kernel installs nothing extra.
- **Welcome tab (Forums button did nothing)**: the button opened `https://soplos.org/forums`, which returns a 404. With the trailing slash the site redirects correctly to `https://forums.soplos.org/`. Reported by users.

## [2.1.2-5] - 2026-08-29

### Fixed
- **Kernels tab (Liquorix blocked on any NVIDIA machine)**: the Install button was greyed out, with an "Incompatible with NVIDIA" label, whenever a GPU from that vendor was detected. It was a hard block, not a warning: the handler was never connected, so there was no way to install Liquorix at all. The condition looked only at the vendor reported by `detect_gpu()`, so it also caught machines running nouveau, which have nothing to do with the proprietary driver. Liquorix works with NVIDIA and upstream documents no such incompatibility, so the block is gone: Liquorix now installs like any other kernel. Liquorix was also the only kernel gated this way, while the XanMod variants are gated only by CPU microarchitecture.

## [2.1.2-4] - 2026-08-28

### Added
- **Security tab (VPN)**: added NordVPN, installed from NordVPN's own apt repository. Upstream only documents a Snap package or piping their `install.sh` into a root shell; that script does nothing on Debian beyond registering this same repository, so those four steps are performed directly instead. Two improvements over the upstream script: the signing key goes to `/etc/apt/keyrings` with `signed-by` rather than to `/etc/apt/trusted.gpg.d`, where it would be trusted for every repository on the system, and `apt` runs non-interactively (their script leaves it interactive, which would hang behind Welcome's non-tty pipe). Their suite is literally `stable`, not a Debian codename, so the forky problem that forced a hardcoded `trixie` on Cloudflare WARP does not apply here. Installing also adds the desktop user to the `nordvpn` group, which NordVPN's postinst creates but leaves empty, and a dialog explains that the session has to be restarted before the client can reach `/run/nordvpn/nordvpnd.sock`. Uninstalling purges both packages, removes the user from the group, deletes the group when no members are left, and removes the repository and the keyring.

### Changed
- **Recommended tab (Multimedia → Audio/DAW)**: KutEditor is now a normal apt package from the Soplos repositories. The previous entry installed a full Qt6 build toolchain on the user's machine, cloned the upstream repository as root and compiled it there. That build could not even succeed on a clean system: upstream ships `libdeepfilter.so.0.5` with no unversioned symlink, so `find_library()` never found it while `HAVE_DEEPFILTERNET` was defined anyway, and the link step failed on undefined symbols. With no `set -e` in the generated script, the failure was reported to the user as "Operation completed successfully". KutEditor has since been packaged properly as a `.deb` (see the `kuteditor-deb` project), so the entry is now six lines with no `install_commands` at all.

### Fixed
- **Security tab (Cloudflare WARP uninstaller left the keyring behind)**: the installer writes the key to `/etc/apt/keyrings/cloudflare-warp-archive-keyring.gpg` while the uninstaller deleted `/usr/share/keyrings/cloudflare-warp-archive-keyring.gpg`. Different path, so `rm -f` silently removed nothing and reported success, leaving Cloudflare's key on the system forever. Both paths are now removed, so machines already uninstalled with the broken script get cleaned up too.
- **Security tab (two password prompts to uninstall Cloudflare WARP)**: the script body carried one `pkexec` per privileged line and was launched without one, so polkit authenticated each separately. The `pkexec` now wraps the whole script, as its own installer and the rest of the application already did.
- **Security tab (Portmaster and Kudu uninstallers left their files on disk)**: only the `apt purge` line carried `pkexec`; the `rm -rf /opt/safing` and `rm -rf /opt/Kudu` calls below it ran unprivileged against root-owned paths and failed with a permission error every time. With no `set -e`, the script carried on and reported "Uninstallation complete". Those directories are precisely what `apt purge` does not remove, so the only part of the uninstall that mattered was the part that never ran. Both scripts now run entirely under a single `pkexec`.

### Translations
- Four new NordVPN strings across all 8 languages (description, Open button, installed dialog title and its group/re-login message).

## [2.1.2-3] - 2026-08-23

### Added
- **Security tab (VPN)**: added Cloudflare WARP, installed from Cloudflare's official apt repository. Their repo only publishes Debian codenames trixie/bookworm (and older bullseye/buster/stretch) — Soplos's real base (forky) isn't published there, so the suite is hardcoded to trixie (verified with curl: `.../dists/trixie/Release` is 200, `.../dists/forky/Release` is 404), same reasoning as the ROCm fix.
- **Recommended tab (Multimedia → Audio/DAW)**: added KutEditor, a native podcast editor (Qt6/QML, multitrack audio, AI transcription, Podcasting 2.0 chapters) by Ernesto Acosta. No prebuilt package exists upstream (no GitHub releases), so the install script builds it from source on the user's machine: installs build dependencies, clones the repo, builds with CMake, packages the result into a real `.deb` with `cpack -G DEB` (same step the upstream `installer.sh` performs for Debian), then installs that freshly-built package with `apt install`. AI transcription (whisper.cpp) is left disabled by default to keep the unattended build lighter and less likely to fail.

## [2.1.2-2] - 2026-08-17

### Added
- **Gaming tab**: GeForce NOW now installs NVIDIA's official native Flatpak app (`com.nvidia.geforcenow`, from NVIDIA's own Flatpak remote) instead of the old WebApp shortcut, now that it's out of beta with official Linux support. Added to both the Gaming tab and Recommended → Gaming.
- **Gaming tab**: added Mocktail (`space.bigrat.mocktail`), an independent community Roblox client.
- **Security tab (VPN)**: added VPN Unlimited (`com.keepsolid.VpnUnlimited`).

### Changed
- **Gaming tab is now a permanent tab**, no longer hidden behind the Ctrl+G easter egg or the "Activate Gaming Mode" link on the welcome page — it has grown into a full feature (launchers, GameMode, sysctl tweaks, disk I/O schedulers) that deserved to be discoverable. The welcome page keeps a plain feature-list entry instead of the removed link.

### Fixed
- **Gaming tab / Recommended tab (wrong badge on GeForce NOW)**: install-method badges were inferred only from the coarse install method ('flatpak' vs 'custom' vs 'webapp'), so GeForce NOW's Flatpak-via-custom-remote-add install showed as "AppImage" (Gaming tab) or no badge at all (Recommended tab). Both now detect a `flatpak install` call inside custom install commands and show the Flatpak badge correctly.

## [2.1.2-1] - 2026-08-17

### Fixed
- **Drivers tab (NVIDIA DKMS build failure on kernel 7.2+)**: `nvidia/os-interface.c` calls `strncpy()` without including `<linux/string.h>`, relying on some other kernel header to pull it in transitively — which stopped happening on 7.2+, turning it into a hard build error (`implicit declaration of function 'strncpy'`). Welcome's own copy of the NVIDIA DKMS compatibility patcher only carried the earlier `VMA_LOCK_OFFSET` fix; added the same `NV_STRING_H_PATCH` already applied by `soplos-kernel-installer` and published in the `nvidia-patches` repo (Fix 4), keeping both copies in sync as intended.

## [2.1.2] - 2026-08-14

### Fixed
- **Kernels tab (XanMod could not be installed at all)**: the repository was written with the `releases` suite, which upstream retired. XanMod now publishes one suite per Debian codename, so every install failed on `apt update` with a 404. The codename is read from the Debian repositories configured on the system — `/etc/os-release` cannot be used, since Soplos declares its own `VERSION_CODENAME` (`tyron`, `tyson` or `boro`). If no Debian codename can be determined, the script aborts with a message instead of guessing one.
- **Kernels tab (the x64v4 button installed a package that does not exist)**: `linux-xanmod-x64v4` is not published in any suite of the repository. The variant was removed, and the RT (PREEMPT_RT) build took its place.
- **Kernels tab (variants could leave an unbootable system)**: the x86-64 psABI level of the CPU is now detected, and the package is resolved accordingly — v3 builds on capable CPUs, v2 builds otherwise. Below x86-64-v2 only LTS remains available (`linux-xanmod-lts-x64v1`) and the other variants are greyed out with the reason shown.
- **Kernels tab (the XanMod keyring failed silently)**: `/etc/apt/keyrings` was not created and the `gpg` error was swallowed by `|| true`. The directory is created, and a failed key download now aborts the install.
- **Kernels tab (Liquorix reported success after a failed download)**: the installer was piped straight from `curl -s` into a root shell, so an HTTP error page was executed as root and the tab still printed "Installation complete". It is downloaded with `curl -fsSL` and only executed if the download succeeded.
- **Kernels tab (uninstalling Liquorix left its repository behind)**: `liquorix.list` and its keyring are now removed as well.
- **Kernels tab (cleaning old kernels removed the Debian fallback)**: Soplos kernels were classified together with Debian's, so only the higher version of the two survived. They are now their own family, and the latest of each of the four — Debian, Soplos, Liquorix and XanMod — is kept.
- **Drivers tab (ROCm could not be installed and broke apt)**: the repository was written with a Debian suite, and AMD only publishes Ubuntu suites. Beyond failing, the invalid entry stayed behind and made every later `apt update` fail. It now points at `repo.radeon.com/rocm/apt/latest noble main`, confined by an APT pin so it can never replace a Debian package.
- **Drivers tab (wrong ROCm hardware requirements)**: the dialog claimed RDNA1 and newer, listing the RX 5000 series and 600M/700M integrated GPUs. ROCm supports none of those. It now states RDNA2 (RX 6800 and newer), RDNA3, RDNA4 and Instinct accelerators.
- **Drivers tab (Intel oneAPI installed a 2025 release)**: `intel-basekit` has been a transitional alias since 2025.0 and resolves to `intel-oneapi-base-toolkit`, which Intel froze at 2025.3.2. The current umbrella, `intel-oneapi-toolkit`, is installed instead, and the repository is confined by an APT pin and restricted to amd64.

### Added
- **Kernels and Drivers tabs**: a repair notice that detects the broken XanMod and ROCm repositories left behind by earlier versions and removes them on request. Reinstalling either also repairs the state on its own.
- **Recommended tab (Multimedia)**: added Drift (`org.cutwire.Drift`) and Prism (`org.cutwire.Prism`), both Flatpak.

## [2.1.1-9] - 2026-08-04

### Added
- **Security tab (System Cleaning)**: added Kudu, an all-in-one maintenance suite (cache cleaner, malware scanner, performance monitor, app uninstaller), installed as `.deb` resolved dynamically from its GitHub releases, following the same pattern already used for Portmaster.
- **Recommended tab (Developer)**: added Zed (`dev.zed.Zed`, Flatpak), a high-performance multiplayer code editor.

### Changed
- **Security tab (System Cleaning)**: removed the "Recommended" badge from BleachBit — Soplos Sys Cleaner is the recommended option in that section.

## [2.1.1-8] - 2026-08-03

### Fixed
- **Drivers tab (professional and laptop NVIDIA GPUs got the wrong driver)**: the GPU model was read with a pattern that only understood names starting with `GeForce`. Everything else — Quadro, Tesla, RTX A-series, all common on laptops — fell through to a pattern that stops at the opening bracket and returned the chip codename instead (`[Quadro T1000 Mobile]` came back as `Corporation TU117GLM`). Those cards matched no rule and ended up on the Debian 550 branch. The bracketed marketing name, which is what lspci actually publishes, is now read first.
- **Drivers tab (610 and 590 buttons disabled on supported cards)**: the guard that disables those branches on pre-Turing GPUs kept its own marker list, separate from the one used to recommend a driver, and the two had drifted apart. Quadro T400/T600/T1000 and Tesla T4 are Turing and support 610, yet the buttons were greyed out. Both now read a single shared classifier, `is_nvidia_turing_or_newer()`, which also covers the T500/T550/T1200 laptop parts, MX570 and the RTX A-series.
- **Drivers tab (GT 750M offered a branch that cannot build)**: the marker sat among the Maxwell laptop parts in the 580 group, but the GT 750M is Kepler and 580 starts at Maxwell. The module could not build and, with nouveau blacklisted by the NVIDIA package, the laptop was left with no graphics driver. Moved to the 470 group, next to its sibling the GT 650M.
- **Drivers tab (unrecognised GPUs offered a branch that cannot build)**: any NVIDIA card matching no rule fell back to `nvidia-driver`, the Debian 550 branch, which only covers Maxwell to Ada. A Fermi such as the GT 540M ended up there with the same result as above. The fallback is now nouveau, which always works.
- **Drivers tab (nouveau never reported as active on Boro and Tyson)**: the check required `xserver-xorg-video-nouveau`, an Xorg driver that is irrelevant and usually absent on Wayland. It returned False even when nouveau was the driver in use. Only the modprobe blacklist is checked now, since nouveau itself ships with the kernel.
- **Drivers tab (AMD stack never reported as installed on Boro and Tyson)**: the same mistake, this time requiring `xserver-xorg-video-all`. The check now looks only at the parts that matter under both display protocols. The package is still installed, because an X11 session can be selected at login on either distribution.
- **Drivers tab (Nouveau button did nothing when switching back from NVIDIA)**: pressing it ran an `apt install` while the NVIDIA package kept nouveau blacklisted, so nothing changed and the button never marked itself as active. It now explains the situation and offers to remove the NVIDIA drivers, which is the only thing actually required. Its uninstall action no longer purges the Xorg driver, which stripped it on Tyron and did nothing on the other two.
- **Drivers tab (CUDA 12 repository left configured)**: the toolkit installer added the repository with `trusted=yes`, needed because the debian12 CUDA repo signs with SHA1, and never removed it, leaving an unverified source enabled indefinitely and shadowing Debian packages. It is now removed after installing, as the driver flows already did.

### Changed
- **Driver recommendation**: MX150 and MX250 moved to the 580 branch. They are Pascal, like the MX330 and MX350 already there.
- **NVIDIA Primary**: the message about the Xorg configuration now states that it applies to X11 sessions, and the driver upgrade advice points to the 610 branch.

### Added
- **Translations**: 4 new strings for the Nouveau switch dialog, in all 8 languages.

## [2.1.1-7] - 2026-07-27

### Fixed
- **Drivers tab (dead cleanup code)**: the PRIME Render Offload script still removed `/etc/sddm.conf.d/10-wayland.conf`, a file no longer written anywhere in the project. Removed the no-op cleanup block.

### Added
- **Recommended tab**: added ART (`us.pixls.art.ART`, Flatpak), a RAW photo editor, to Graphics and Design → Photography/RAW.

## [2.1.1-6] - 2026-07-27

### Fixed
- **Drivers tab (system left with no graphics driver after installing an NVIDIA driver)**: the install proceeded even when DKMS could not build the module. Having the `linux-headers` package installed is not enough — the build tree under `/lib/modules/<kernel>/build` must be usable, and when it is not, DKMS silently skips the build and leaves the module as `added`. Since the NVIDIA package blacklists nouveau, the machine then booted to a black screen with no driver at all. Both install paths now verify the build tree, reinstall the headers when it is missing or broken, and abort with a clear message instead of installing a driver that cannot be built.
- **Drivers tab (DKMS compatibility patch never applied)**: the VMA locking patch for Soplos 7.x kernels was only applied by soplos-kernel-installer, never by Welcome, which is the path the distribution recommends to the user after installing. It is now applied in both install paths, covering the proprietary source layout (`/usr/src/nvidia-*/nvidia/`) and the open module one (`/usr/src/nvidia-*/kernel-open/nvidia/`), and only when the source actually uses `VMA_LOCK_OFFSET`.
- **Drivers tab (initramfs regenerated too early)**: dracut ran before the DKMS modules existed, producing an initramfs that excluded nouveau and requested NVIDIA modules that were not there yet. The patch and module rebuild now run before the initramfs is regenerated.
- **Drivers tab (boot hanging at switch-root after installing the driver)**: Welcome wrote `/etc/dracut.conf.d/nvidia.conf` forcing the NVIDIA modules into the initramfs. `nvidia_drm` then took the display inside the initramfs, and the handover to the real root could leave the boot stuck on a black screen, intermittently and only on some reboots. The file is no longer written, and it is removed on install so existing systems are cleaned up too. The modules load normally once the real system is up.
- **Drivers tab (NVIDIA repository left configured)**: the 590 and 610 branches never removed the CUDA repository after installing, so it kept shadowing Debian packages such as `dkms` and could move the user to another driver branch on a routine `apt upgrade`. Both now clean it up after installing, as the 580 branch already did.

### Changed
- **Driver recommendation**: Turing and newer (GTX 16xx, RTX 20/30/40/50, MX450/550) now recommend the 610 branch, the newest one listing them as supported products. Pascal and Maxwell (GTX 10xx, GTX 9xx, MX330/350) recommend 580, which is their maximum supported branch.
- **Drivers tab**: the 590 and 610 buttons are disabled on pre-Turing GPUs, with a tooltip explaining why, instead of letting the user install a branch their card does not support.

## [2.1.1-5] - 2026-07-27

### Fixed
- **Drivers tab (NVIDIA 590/610 install failing)**: a previous edit forced `apt install` to request `cuda-drivers-590`/`cuda-drivers-610` together with `nvidia-kernel-open-dkms` in the same command — but NVIDIA's `cuda-drivers` (590/610 branch) package explicitly declares `Conflicts: nvidia-kernel-open-dkms, nvidia-open`, so the two were mutually unsatisfiable and `apt` aborted every time with a dependency error. Reverted that change.
- **Drivers tab (silent false "success" on failed installs)**: `CommandRunner.run_command` never checked the subprocess exit code after `process.wait()`, so any failed script (apt errors, `pkexec` cancelled, network failure, etc.) was reported as "Operation completed successfully" instead of showing the real error. Now checks `process.returncode` and shows a failure message when it's non-zero.

### Changed
- **Drivers tab (NVIDIA 590/610 now install open kernel modules)**: switched the install target from `cuda-drivers-590`/`cuda-drivers-610` (closed `nvidia-kernel-dkms`) to `nvidia-open-590`/`nvidia-open-610` (NVIDIA's official open-kernel-module meta-package), matching the hardware these branches target (Turing and newer, which fully supports open modules).
- **Drivers tab**: removed the standalone "Open Kernel Modules" button (`_on_nvidia_open_clicked`/`_is_turing_plus`) from NVIDIA Extras — it always hit the same `cuda-drivers` vs `nvidia-kernel-open-dkms` conflict described above when a 590/610 driver was already installed, and is no longer needed now that 590/610 install open modules directly.

## [2.1.1-4] - 2026-07-26

### Fixed
- **Customization tab (Tyson)**: the "Login Screen" tile in KDE Settings pointed to `kcm_sddm.desktop`, which no longer exists — SDDM was replaced by Plasma Login Manager (a fork of SDDM, `Conflicts`/`Replaces: sddm`). Now points to `kcm_plasmalogin.desktop`, with the description/tooltip updated to reference Plasma Login instead of SDDM.
- **Drivers tab (NVIDIA setup)**: removed dead cleanup code for `/etc/sddm.conf.d/10-wayland.conf` — nothing in the script created that file anymore. Updated the KDE branch's status message from "SDDM" to "Plasma Login".
- Updated the corresponding translatable strings and all 8 `.po` files (es, ro, de, pt, ru, it, en, fr) plus the `.pot` template — the old SDDM-referencing strings were orphaned by the source text change.

## [2.1.1-3] - 2026-07-25

### Changed
- Donate button now points to https://soplos.org/community/donate/ instead of PayPal.

---

## [2.1.1-2] - 2026-07-24

### Fixed — Drivers Tab

- **Duplicate nouveau blacklist on NVIDIA install**: the basic and CUDA install paths both wrote `/etc/modprobe.d/blacklist-nouveau.conf` in addition to the dracut-managed `/etc/dracut.conf.d/blacklist-nouveau.conf`. The NVIDIA package already creates its own modprobe blacklist via `/etc/modprobe.d/nvidia.conf`, making the Welcome-written modprobe file redundant and a potential source of conflicts. Removed the modprobe writes; dracut.conf.d remains the single source of truth for nouveau blacklisting.

---

## [2.1.1-1] - 2026-07-22

### Fixed — Drivers Tab

- **VirtualBox Guest Additions never detected inside a real VM**: the unnecessary-software VBox check was nested inside `if not vm_info.get('is_vm'):`, so it only ever ran when the machine was NOT detected as a virtual machine — meaning it never fired on Proxmox, VMware or even VirtualBox itself, exactly the cases where Guest Additions are actually installed and meaningful to offer for removal. Moved out of that block; now checked unconditionally, with the detail message adjusted depending on whether the machine is a VM or not.

### Added — Drivers Tab

- **"Remove All Detected" button**: the "Unnecessary Software Detected" section rendered one separate "Uninstall" button per finding — up to five rows (NVIDIA, AMD, Broadcom, VM guest tools, VirtualBox), each requiring its own click and, for NVIDIA/VBox, its own confirmation dialog. Added a single "Remove All Detected" button (shown when there is more than one finding) that presents one combined confirmation and runs every item's removal in a single script. The NVIDIA and VirtualBox uninstall scripts were extracted into `_build_nvidia_uninstall_script()`/`_build_vbox_uninstall_script()` so both the individual buttons and the combined action share the exact same script body instead of duplicating it.

### Fixed — Translations

- 4 new strings from the two fixes above added to all 8 language files and `.mo` files recompiled.

---

## [2.1.1] - 2026-07-21

### Fixed — Drivers Tab

- **Wi-Fi repair (`_on_repair_wifi_clicked`)**: the script ran `modprobe -r <driver>` without bringing the interface down first — if the interface was still up, the kernel could refuse to unload the module with "device busy", failing silently (swallowed by `|| true`) and reporting success without ever having reloaded anything. Now runs `ip link set <iface> down` first when an active interface is known.
- **VirtualBox Guest uninstall**: pointed to `apt remove virtualbox-guest-utils virtualbox-guest-x11` — packages that are never installed via apt, since Guest Additions come from the bundled `.run` installer. The button was effectively a no-op. Now runs the official `uninstall.sh` (or `rcvboxadd cleanup`) found under `/opt/VBoxGuestAdditions-*/`, with an `apt purge` fallback for the rare mixed-install case.
- **Generic driver uninstall (`_on_remove_driver_clicked`)**: used `apt remove` instead of `apt purge`, leaving conffiles behind — affects every non-NVIDIA uninstall button (AMD, Wi-Fi, Bluetooth, printers, VMware/QEMU tools).
- **NVIDIA driver recommendation (`_recommend_nvidia_driver`)**: RTX 50 series GPUs were recommended `nvidia-driver-590` even though the "NVIDIA 610 (Latest)" button explicitly targets "RTX 50/60 series and latest hardware" — 610 was only reachable by clicking the button manually, never through hardware auto-detection. RTX 50 now maps to `nvidia-driver-610`.

### Added — Drivers Tab

- **Unnecessary software detection**: the hardware scan (`scan_hardware()`) now also flags installed software that doesn't match the hardware actually present — NVIDIA/CUDA packages without an NVIDIA GPU, AMD/ROCm packages without an AMD GPU, the Broadcom proprietary Wi-Fi driver without a Broadcom adapter, VM guest tools (`open-vm-tools`, `qemu-guest-agent`, `spice-vdagent`/`spice-webdavd`, `hyperv-daemons`) when this machine is not a VM, and VirtualBox Guest Additions when this machine is not a VM. Shown in the scan results dialog with an "Uninstall" button that reuses the existing removal flows (`nvidia`/`vbox`/generic `apt purge`) instead of adding new removal logic. Printers, Bluetooth and generic Intel packages are deliberately not checked — those are commonly kept installed regardless of whether the peripheral is currently attached.

### Fixed — Translations

- 11 new strings introduced by the unnecessary-software-detection feature above (`"Unnecessary Software Detected"`, per-category names and detail messages) were missing from all 8 language files. Added translations in en, es, de, fr, it, pt, ro, ru and recompiled all `.mo` files.

---

## [2.1.0-9] - 2026-07-20

### Fixed — Translations

- **Customization Tab (GNOME) — Layout Switcher**: Three strings were missing from all 8 language files — `"Layout Switcher"`, `"Switch between GNOME Shell layout presets"` and `"Launch Soplos Layout Switcher"`. Added translations in en, es, de, fr, it, pt, ro, ru and recompiled all .mo files.

---

## [2.1.0-8] - 2026-07-19

### Added — Customization Tab (GNOME)

- **Layout Switcher**: Added to the Soplos Tools section alongside GRUB Editor and Plymouth Manager. Launches `/usr/bin/soplos-layout-switcher` to switch between GNOME Shell layout presets. Uses the existing install-if-missing flow (`pkexec apt-get install soplos-layout-switcher`) when the package is not present.

---

## [2.1.0-7] - 2026-07-10

### Added — Drivers Tab

- **NVIDIA Extras — CUDA 12 Toolkit**: Installs `cuda-toolkit-12` from the NVIDIA CUDA debian12 repository. Compatible with PyTorch and TensorFlow cu12 builds. Requires an NVIDIA driver already installed. Button reflects install state and supports uninstall with full repository cleanup.
- **NVIDIA Extras — Open Kernel Modules**: Installs `nvidia-kernel-open-dkms` (official open source NVIDIA kernel module, recommended for RTX 30 series and newer). GPU compatibility is verified via `_is_turing_plus()` before proceeding — Maxwell and Pascal GPUs receive an incompatibility error dialog. Supports switching back to the proprietary `nvidia-kernel-dkms` module.
- **NVIDIA 590/610 drivers**: `nvidia-kernel-open-dkms` is now included automatically in the install command for the 590 and 610 branches, which target Turing+ hardware exclusively.
- **Intel Extras section**: New section added between AMD Extras and Wi-Fi. Contains Intel oneAPI Base Toolkit — adds the official Intel oneAPI apt repository (GPG key from `apt.repos.intel.com`) and installs `intel-basekit` (DPC++ compiler, MKL, TBB, VTune, Advisor). Supports full uninstall including repository and keyring removal.
- **Translations**: CUDA 12 Toolkit, Open Kernel Modules and Intel oneAPI strings added to all 8 languages (en, es, de, fr, it, pt, ro, ru).

---

## [2.1.0-6] - 2026-07-08

### Fixed
- **Environment detection — Qt version**: `_detect_qt_version()` in `core/environment.py` added `FileNotFoundError` to the exception catch — previously only `subprocess.SubprocessError` and `subprocess.TimeoutExpired` were handled, so when `qmake` is not installed `subprocess.run` raised `FileNotFoundError` that propagated up through `detect_all()` and crashed the application on startup.

## [2.1.0-5] - 2026-07-07

### Changed
- Build dependency `python3-all` replaced with `python3`.

---

## [2.1.0-4] - 2026-07-06

### Added — Customization Tab

- **LucidGlyph**: New entry in the Soplos Tools section for all three DEs (XFCE, GNOME, KDE). Downloads the latest release tarball from GitHub, extracts it and runs `./lucidglyph.sh install` via pkexec. Uninstall runs `./lucidglyph.sh remove`. Detection via `/usr/local/share/lucidglyph/version` marker file.
- **LucidGlyph — DE-specific post-install**: On GNOME, `gsettings set org.gnome.desktop.interface font-antialiasing grayscale` is applied automatically after install and reset on removal. On KDE, a manual instruction dialog is shown pointing to System Settings - Text and Fonts - Sub-pixel rendering = None.

### Added — Recommended Tab

- **Hardware — amdgpu_top**: Real-time AMD GPU usage monitor. Installs via GitHub latest release `.deb` (dynamic URL via GitHub API).
- **Hardware — nvtop**: GPU process monitor for NVIDIA, AMD and Intel. Installs from official Debian repository.

### Fixed — Recommended Tab

- **FileZilla duplicate**: FileZilla was listed in both Developer and Files categories. Removed from Developer; remains only in Files.

### Translations

- Updated all 8 languages (en, es, de, fr, it, pt, ro, ru) with new strings for LucidGlyph install/uninstall flow, amdgpu_top and nvtop descriptions.

## [2.1.0-3] - 2026-06-30

### Fixed — Drivers Tab

- **Hybrid graphics — $SUDO_USER empty under pkexec**: `_on_hybrid_clicked` used `$SUDO_USER` to resolve the real user's home directory, but pkexec never sets `$SUDO_USER`. The `kwinoutputconfig.json` fix for KDE Plasma was being written to `/root/.config/kdedefaults/` instead of the actual user's home. Replaced with `$PKEXEC_UID` pattern already used by the ROCm scripts.
- **UI freeze on Wi-Fi repair**: `_on_repair_wifi_clicked` called `_detect_wifi_driver()` synchronously in the GTK main thread. On degraded hardware, `lspci -k` can block for several seconds, making the window unresponsive. Detection moved to a background thread via `threading.Thread`; result returned to GTK via `GLib.idle_add`.
- **Race condition on driver install**: Double-clicking the recommended driver install button launched multiple concurrent `pkexec apt install` processes, causing dpkg lock conflicts. Button is now disabled with `set_sensitive(False)` on first click.

### Fixed — Software Tab

- **Flatpak install missing update notifier**: Installing Flatpak pulled in `gnome-software` as a dependency of `gnome-software-plugin-flatpak`, but `package-update-indicator` was not installed. The update tray applet was missing. Added `package-update-indicator` to the Flatpak package list in all three DEs.
- **Bazaar requires system-level Flathub**: Bazaar (`io.github.kolunmi.Bazaar`) only works with Flathub enabled at the system level, but Welcome uses user-level Flathub for all other Flatpak apps. Installing Bazaar via the standard path left it broken. Now shows a warning dialog explaining the conflict and, if confirmed, adds Flathub `--system` and installs Bazaar `--system` via pkexec. Uninstalling Bazaar also removes the system Flathub remote, leaving no residue.

### Changed — Recommended Tab — Software categories reorganized

- **New category: App Management** — Soplos WebApp Manager, Soplos AppImage Manager, Flatseal, Gear Lever, Warehouse.
- **New category: Downloads** — qBittorrent, Transmission, JDownloader, Syncthing Tray.
- **New category: Hardware** — Resources, LACT, CPU Power, CoolerControl.
- **New category: Files** (replaces Utilities) — PeaZip, FileZilla, GNOME Commander, Double Commander (AppImage from OpenSUSE Build Service, latest GTK version).
- **Multimedia reordered**: grouped into Media Players (VLC, MPV, Kodi, Spotify), Video (OBS Studio, Kdenlive, OpenShot, HandBrake, DaVinci Resolve) and Audio/DAW (Audacity, LMMS, Mixxx, Bitwig Studio, Reaper, Zrythm, Ardour).
- **Graphics and Design reordered**: grouped into Image Editing (GIMP, Krita, Affinity Suite), Vector/Design (Inkscape), 3D (Blender) and Photography/RAW (darktable, RapidRAW, RawTherapee, Hugin).
- **Office reordered**: grouped into Office Suites (LibreOffice, OnlyOffice, WPS Office, Calligra, Collabora Office) and PDF (Adobe Reader, JoPDF).
- **Icon folders restructured**: icons moved from `assets/icons/utilities/` to their respective new category folders.

## [2.1.0-2] - 2026-06-29

### Fixed — Drivers Tab — NVIDIA and ROCm

- **DKMS not cleaned on uninstall**: `apt purge` leaves compiled `.ko` files in `/lib/modules/`. When reinstalling a different driver version, DKMS refused with "version not newer". Uninstall script now runs `dkms remove --force` on all NVIDIA entries and removes orphaned `.ko` files from every kernel directory before purging packages.
- **DKMS not cleaned on install**: Same stale DKMS state caused installation failures when switching driver versions. Both the CUDA-repo path (590/610) and the Debian-repo path (550) now perform the same DKMS cleanup before `apt install`.
- **Escaped quotes in 590 and 610 repo setup**: The `rm -rf "$TEMP_DIR"` line inside Python triple-quoted strings generated an extra trailing quote in the bash output (`"$TEMP_DIR""`), corrupting the cleanup command. Fixed by converting those blocks to raw strings (`r"""..."""`).
- **ROCm codename**: The `CODENAME` case statement included `bookworm` as a branch, but Soplos is based on Debian Testing/Trixie moving toward Forky — never Debian 12. Replaced with `trixie` and `forky` cases only.

## [2.1.0-1] - 2026-06-24

### Added — Drivers Tab — AMD Extras (ROCm)

- **ROCm OpenCL**: new section "AMD Extras" with OpenCL runtime for AMD GPUs (RDNA1+). Installs `rocm-opencl-runtime` from the official AMD ROCm 6.4 repository. Adds the user to `render` and `video` groups automatically. For DaVinci Resolve, Blender HIP and general GPU compute.
- **ROCm Full Suite**: full ROCm platform (`rocm`) for AI/ML development with PyTorch and TensorFlow on AMD GPU. Several GB download.
- Both buttons support install/uninstall with checkmark detection via `_driver_buttons`.

### Added — Recommended Tab — Helium browser

- **Helium**: privacy-focused browser built on Chromium with YouTube integration. Installed from the latest GitHub release `.deb` (`imputnet/helium-linux`) via dynamic URL — package `helium-bin`.

### Fixed — Drivers Tab

- **NVIDIA Extras checkmarks**: DaVinci Resolve Extras and Blender CUDA Toolkit buttons now show a checkmark when their packages (`nvidia-opencl-icd`, `nvidia-cuda-toolkit`) are installed. Previously they had no state detection.
- **LACT removed**: LACT GPU Control Center was duplicated in both Drivers and Recommended tabs. Removed from Drivers — it belongs in Recommended only.

### Changed — Drivers Tab — VirtualBox Guest Additions

- **Updated to 7.2.10**: replaced bundled `VBoxLinuxAdditions.run` with the 7.2.10 release.

### Fixed — Assets permissions

- **Normalized to 644/755**: all files under `assets/` set to 644, all directories to 755, `VBoxLinuxAdditions.run` kept at 755.

## [2.1.0] - 2026-06-20

### Added — Drivers Tab — NVIDIA 610

- **NVIDIA 610 (Latest)**: new driver button for Blackwell and newer hardware (RTX 50/60 series). Installed from the official NVIDIA CUDA repository for Debian 13 (`nvidia-driver-pinning-610` + `cuda-drivers-610`). Verified present in the CUDA debian13 repo (`nvidia-driver-pinning-610_610-2`).
- **NVIDIA 590 renamed to Stable**: the 590 button label has been updated from "Latest" to "Stable" to reflect that 610 is now the most recent branch.
- **Grid layout updated**: 610 occupies row 0 col 0, 590 moves to row 0 col 1. All other drivers shift one row down. Uninstall button now spans both columns in row 4.

### Added — Welcome Tab — Gaming Mode link

- **Gaming Mode link on home screen**: a new row below "Customize your desktop" shows the gaming controller icon and a clickable link ("Activate Gaming Mode") that triggers `_toggle_gaming_tab()` — identical to Ctrl+G. The row only renders if the Gaming tab loaded correctly.

## [2.0.9-3] - 2026-06-09

### Fixed — Recommended Tab

- **Brave Origin icon**: moved from `brave-origin-icons/48x48/apps/brave-origin.png` to `brave-origin.png` at the browsers icons root — same flat structure as all other browser icons, avoids packaging issues with nested subdirectories.
- **Affinity Suite reverted to 3.0.2**: the 3.2.0 AppImage switched to Wine 11 and fails on most systems. Reverted to the 3.0.2 AppImage (Wine 10), available at the same release tag (`3.2.0`) of the upstream repo. Updated `check_path`, wget URL, chmod target, and `.desktop` `Exec` entry accordingly.

## [2.0.9-2] - 2026-06-09

### Added — Recommended Tab — New browsers

- **Brave Origin**: privacy-focused browser by Brave with integrated AI assistant. Installed via Brave's official script (`FLAVOR=origin`). Icon patch replaces the bundled orange icon with a black version in all sizes, patching both `/usr/share/icons/hicolor/` and `/opt/brave.com/brave-origin/` (postinst source) to survive updates.
- **Opera**: feature-rich browser with built-in VPN and ad blocker. Installed as Flatpak (`com.opera.Opera`).
- **Zen Browser**: privacy-focused Firefox-based browser with beautiful design. Installed from the latest GitHub release `.deb` via dynamic URL.

### Fixed — Drivers Tab — NVIDIA false positives

- **NVIDIA 550 detection**: `check_fn` now uses `_get_nvidia_active_version() == '550'` instead of `_is_package_installed('nvidia-driver')`. Previously, having any NVIDIA driver installed (e.g. 580) also marked 550 as installed because both share the `nvidia-driver` meta-package.
- **NVIDIA false positives on AMD systems**: the dpkg fallback in `_get_nvidia_active_version()` now only runs when `lspci` detects NVIDIA hardware. On AMD-only systems, leftover NVIDIA packages in dpkg no longer trigger false-positive driver checkmarks.

## [2.0.9-1] - 2026-05-29

### Fixed — App icon in GNOME Software

- **Removed `slide1.png` from `assets/icons/`**: this file was being picked up by the repo manager and packaged as the application icon, causing GNOME Software to display the wrong image instead of the correct `org.soplos.welcome.png` icon.

## [2.0.9] - 2026-05-28

### Changed — Drivers Tab — VirtualBox Guest Additions

- **Updated to VirtualBox Guest Additions 7.2.8**: first release with official Linux 7.0 kernel support. The previous script downloaded the obsolete 7.0.20 ISO from Oracle's servers. The `VBoxLinuxAdditions.run` installer is now bundled directly in the package under `assets/vbox/` — no internet connection required at install time.
- **Compiles `vboxguest`, `vboxsf` and `vboxvideo`** for kernel 7.0.9-soplos via DKMS. The "unable to load vboxguest kernel module" message is expected when the system runs in VMware/QEMU (not in VirtualBox) — the modules load correctly when booted inside VirtualBox.

### Fixed — Pango Markup

- **"Security & System Protection" header**: the `&` character was unescaped in the `en` and `de` `.po` translations, causing a GTK warning (`Error on line 1: Entity did not end with a semicolon`) when the Security tab was created. Fixed by using `&amp;` in the `msgstr` of both locales.

## [2.0.8-9] - 2026-05-27

### Fixed — Recommended Tab

- **Affinity AppImage URL updated to 3.2.0**: the previous URL pointing to 3.0.2 returned HTTP 404, causing `wget` to exit with code 8 and aborting the entire batch install chain due to `set -e`. URL now points to the 3.2.0 release.
- **Affinity `.desktop` file ownership**: `printf '...' > file` under pkexec wrote the file as root. Replaced with `sudo -u $REAL_USER tee` so the file is owned by the real user. Also ensured the parent directory is created with `sudo -u $REAL_USER mkdir -p` before writing.
- **ES-DE `.desktop` file ownership**: same `tee` fix applied — `.desktop` file was being created as root under pkexec.
- **RapidRAW reverted to Flatpak**: a previous session had incorrectly changed RapidRAW from `flatpak install flathub io.github.CyberTimon.RapidRAW` to a Debian `.deb` install. Reverted to Flatpak.
- **Batch install chain failure with `set -e`**: the consolidated batch script used a global `set -e`, so a single failed package (e.g. Affinity 404) would abort all remaining packages in the selection. Each package is now wrapped in its own subshell with `set -e` isolated inside — a failure prints a warning and the script continues with the next package.

### Changed — Kernels Tab

- **Removed NVIDIA/Liquorix warning**: the notice advising against using Liquorix with NVIDIA has been removed from the tab.
- **Soplos Kernel Installer repositioned**: moved from after XanMod to between Microcodes and the Available Kernels section (below Liquorix was before).
- **Soplos Kernel Installer icon added**: the section now displays the application icon (`org.soplos.kernel-installer.png`) with the same layout as packages in the Recommended tab — icon on the left, bold name and description stacked to the right, action buttons at the end of the row.

## [2.0.8-8] - 2026-05-26

### Fixed — DaVinci GPU Patch

- **Fixed permission error in `davinci-gpu-patch.sh`**: the `mkdir -p ~/.local/share/applications/` call was running as root (via pkexec), causing that directory to be owned by root. Subsequent writes from Soplos WebApp Manager and Soplos AppImage Manager failed with `PermissionError: [Errno 13]`. The command now uses `sudo -u "$REAL_USER"` to create the directory with the correct ownership.

### Fixed — Lutris Vulkan Patch

- **Fixed Lutris Vulkan fix targeting wrong deployment**: `lutris-vulkan-patch.sh` used a plain `find` that could pick up `gpu.py` from an old Flatpak deployment instead of the active one. After a Flatpak update, the new deployment had the unpatched file and Lutris kept sending a GPU/vulkaninfo error notification repeatedly. The script now searches under the `active` symlink (`x86_64/stable/active`) with `-L` to follow symlinks, with a fallback that searches any `*/active/*` path for non-standard architectures or branches.

## [2.0.8-7] - 2026-05-25

### 🎬 Recommended Tab — DaVinci Resolve

- **Updated MakeResolveDeb to 1.10.0** (release 2026-05-15 by Daniel Tufvesson): adds split `-data` package for DaVinci Resolve 21+ (plugins folder separated into `davinci-resolve-data` package). Drops slow `xz -9` compression in favour of default gzip — significantly faster build.
- **Install step now handles two `.deb` files**: for Resolve 21+ MakeResolveDeb generates a main package and a `-data` package; both are now installed in sequence automatically.

### 🎨 Recommended Tab — Icons

- **Calligra**: updated icon.

## [2.0.8-6] - 2026-05-24

### 🔧 Drivers Tab — Wi-Fi Repair Detection Improved

- **Triple detection strategy**: (1) sysfs `/sys/class/net/*/wireless` — works when interface is active; (2) `iw dev` — works when interface is down but module is loaded; (3) `lspci -k` — works when the module is not loaded at all, which is the exact case of broken WiFi after reboot (module loads but fails to find firmware → circular dependency). Now the button can always identify the driver and repair WiFi regardless of the system state.

## [2.0.8-5] - 2026-05-23

### 🔧 Drivers Tab — Wi-Fi Repair

- **Added "Repair Wi-Fi" button**: Automatically detects the active Wi-Fi driver by reading `/sys/class/net/*/wireless` (no external commands needed). Shows a confirmation dialog with the detected driver and interface name. On confirmation runs `modprobe -r <driver>`, waits 1 second, `modprobe <driver>` and `systemctl restart NetworkManager`. Works with any brand — Intel (`iwlwifi`), Realtek, Atheros, MediaTek, Broadcom, etc. If no Wi-Fi interface is found, shows a warning dialog instead.

### 🌍 Translations

- Added Wi-Fi Repair strings (button label, tooltip, dialogs) in all 8 languages.

## [2.0.8-4] - 2026-05-22

### 🖥️ Drivers Tab — Detection Fixes

- **Fixed false "installed" state on Nouveau button**: now checks `/etc/modprobe.d/*.conf` for `blacklist nouveau` — if blacklisted the button correctly shows as not active, even though the package is present on the system.
- **Fixed false "installed" state on AMD button**: now requires all three packages (`firmware-amd-graphics`, `mesa-vulkan-drivers`, `xserver-xorg-video-all`) to be installed simultaneously, instead of just one.
- **Fixed false "installed" state on Wi-Fi Intel/Realtek buttons**: now combines package presence with `lsmod` module check, so the button only shows as installed when the firmware package is present AND the corresponding kernel module is actually loaded.

### 📦 Recommended Tab — Utilities

- **Added Syncthing Tray** (`io.github.martchus.syncthingtray`): tray application for Syncthing — sync files between devices. Available as Flatpak from Flathub.

### 🌍 Translations

- Added Syncthing Tray description string in all 8 languages.

## [2.0.8-3] - 2026-05-18

### 🎮 Gaming Tab — Optimizations

- **Added RyzenAdj** to the Optimizations section: compiles from source, installs the binary and shared library, and creates a systemd service that applies AMD thermal limits (`--tctl-temp=85`, `--stapm-limit=35000`, `--fast-limit=35000`, `--slow-limit=35000`) at boot. Ideal for AMD mini PCs with proprietary EC firmware that blocks NBFC-based tools.
- **Added Lutris Vulkan Fix** button to the Optimizations section: patches `gpu.py` inside the Lutris Flatpak sandbox to use `/app/bin/vulkaninfo` instead of the broken `/usr/bin/vulkaninfo` path. Replaces the unreliable automatic post-install hook — must be run manually after Lutris has been launched at least once.
- **Removed Ryzen Master Commander**: eliminated from the Optimizations section as it requires NBFC for fan control, which is incompatible with the proprietary EC firmware on AMD mini PCs.
- **Removed Lutris Vulkan patch from post_install_script**: the automatic patch after Lutris install was unreliable (Flatpak sandbox not yet initialised at that point); replaced by the manual button above.

### 🔧 Fixes

- **Ctrl+Shift+Tab**: backward tab navigation was silently ignored because GTK sends `KEY_ISO_Left_Tab` for that combination, not `KEY_Tab`. The key handler now checks for `KEY_ISO_Left_Tab` explicitly and navigates to the previous tab correctly.

### 🌍 Translations

- Added strings for RyzenAdj (install/uninstall labels, description, confirmation dialogs) in all 8 languages.
- Added strings for Lutris Vulkan Fix (label, description, warning dialog) in all 8 languages.

## [2.0.8-2] - 2026-04-30

### 🛍️ Software Tab — Snap Store & Bazaar

- **Added Snap Store and Bazaar to all three DEs** (XFCE, GNOME, KDE/Plasma): The software grid is now 4 columns × 2 rows. Snap Store (`snap:snap-store`) and Bazaar (`flatpak:io.github.kolunmi.Bazaar`) occupy the new column.
- **Dependency check dialog**: If the user clicks Snap Store without `snapd` installed, or Bazaar without `flatpak` installed, a warning dialog offers to install the missing runtime first.
- **Fixed: buttons now correctly show "Uninstall" state** for Snap and Flatpak apps: `snap install/remove` now uses `pkexec` (was failing silently as a regular user, leaving the button stuck on "Install"). The post-operation callback no longer leaks a `GLib.idle_add` loop by returning the timer source ID.
- **Fixed: program no longer hangs after installing Bazaar**: `flatpak install` now uses `--user --noninteractive` flags, which avoids prompting for interactive confirmation and eliminates the need for `pkexec`.

### 🔒 Security Tab — VPN

- **Added Surfshark** (`com.surfshark.Surfshark`) and **Mozilla VPN** (`org.mozilla.vpn`) to the VPN section as Flatpak apps. Both include Install/Uninstall/Open buttons with state detection.

### 🎮 Gaming Tab — Optimizations

- **Added CPU Power** tool to the Optimizations section: installs `linux-cpupower` and `cpupower-gui` via `pkexec apt`, allowing control of the CPU frequency governor (powersave, performance, etc.) from a graphical interface.

### 📦 Recommended Tab — Office

- **Added Calligra** (`org.kde.calligra`) and **Collabora Office** (`org.collaboraoffice.CollaboraOffice`) as Flatpak entries in the Office section. Both support multi-selection batch install.

### 🖥️ Footer

- **Removed "Ready/Listo" status text**: The footer now shows only the desktop environment and display protocol, without the translated "Ready" prefix.

### 🎨 Customization Tab

- **Docklike removed from XFCE**: The Docklike launcher has been removed from the XFCE tools since its functionality is now completely integrated into Soplos Theme Manager.

## [2.0.8-1] - 2026-04-04

### 🎮 Hybrid Graphics — Fixes

- **Fixed NVIDIA Primary mode not booting**: The "NVIDIA Primary" script was regenerating the initramfs without first creating the dracut configuration files (`/etc/dracut.conf.d/nvidia.conf`, `blacklist-nouveau.conf`). This caused the system to boot without NVIDIA modules loaded, resulting in a black screen or failed boot on laptops. Now creates the dracut configs before calling `dracut --force`, consistent with the repository install script.
- **PRIME Render Offload — KDE Plasma fix**: On KDE Plasma systems with Optimus hybrid graphics, KWin could lose the wallpaper and desktop icons after each reboot due to not correctly identifying the laptop screen connector. The PRIME Offload script now detects the Intel display connector dynamically from `/sys/class/drm/` (`eDP` or `LVDS`) and generates `~/.config/kdedefaults/kwinoutputconfig.json` with the correct output priority, leaving resolution, refresh rate and scale for KWin to fill in. Only runs on KDE Plasma (detected via `EnvironmentDetector` at launch, not by scanning binaries at runtime).



### 🎬 DaVinci Resolve — Script Update & Optional Patches

- **MakeResolveDeb updated to 1.9.0** (by Daniel Tufvesson, 2026-04-14): Adds full support for DaVinci Resolve 21 with its own `process_21()` function. In version 21, the `Apple Immersive` folder is copied from the installer if present instead of always being created empty. Package compression changed from gzip level 1 to xz level 9 for smaller output.
- **Virtual microphone patch**: New optional post-install patch that creates a PipeWire virtual microphone so DaVinci Resolve can start on systems without a physical audio capture device. The patch auto-detects whether a real capture device is present and skips itself if one is found.
- **Integrated GPU patch (AMD / Intel iGPU)**: New optional post-install patch for mini PCs and systems with integrated graphics. Installs the appropriate OpenCL stack (Mesa Rusticl for AMD, Intel NEO for Intel), downloads i915 firmware for ADL-N/N-series chips if missing, injects a libProResRAW stub to prevent Signal 11 crashes, patches the `.desktop` launcher with the correct environment variables, and adds the user to the `render` and `video` groups.
- **Post-install patches dialog**: After successfully installing DaVinci Resolve, a new dialog offers both patches as optional checkboxes ("Skip" / "Apply Selected"). Selecting none goes straight to cleanup. When both are selected, the mic patch runs first, then the GPU patch, then cleanup.

### 🔧 Drivers Tab — Fixes & Full Rework

- **Fixed crash on startup**: `self._driver_buttons` dict was never initialized and `subprocess` was not imported at module level, causing `AttributeError` and `NameError` on load.
- **Install/Uninstall toggle**: All 15 driver buttons (NVIDIA 590/580/550/470/390/340, Nouveau, AMD, Wi-Fi Intel/Realtek/Broadcom, Printers, Bluetooth, VMware/QEMU/VirtualBox) now show `✓ name` when the driver is installed and act as uninstall on click, or as install when not present — consistent with the Gaming and Recommended tabs.
- **NVIDIA 590 and 580 buttons**: Were created but never stored in `_driver_buttons`, so their state was never reflected. Now fully registered.
- **Auto-refresh after operations**: `_refresh_driver_status` is called on startup and as a callback after every install/uninstall, keeping all buttons in sync.

### 🔍 Hardware Scanner — Fixes & Full Rework

- **Fixed broken GPU section**: Dialog was using `results['gpu']` (old single-GPU key) instead of `results['gpus']` (list). On systems with no GPU entry under that key the section was silently skipped.
- **All hardware sections now shown**: GPU(s), Hybrid Graphics, Wi-Fi adapters, Audio, Bluetooth, Printers, VM Tools — each with their detected model, driver status (✓ installed / ✗ missing / ⚠ partial) and Install/Uninstall button.
- **VM Tools detection**: If running inside VMware, VirtualBox or QEMU/KVM, the scanner now detects it, shows whether the guest tools are installed, and offers to install or uninstall them directly.

### ➕ New Applications
- **ProtonVPN** (`com.protonvpn.www`): Added to Security tab in a new VPN section, with Install/Uninstall toggle.
- **ClamUI** (`io.github.linx_systems.ClamUI`): Added to Security tab in the antivirus section alongside ClamTk.
- **LACT** (`io.github.ilya_zlobintsev.LACT`): Added to Drivers tab in the AMD section for GPU overclocking and monitoring.
- **Resources** (`net.nokyan.Resources`): Added to Recommended tab in the utilities section as a modern system monitor.
- **Soplos Kernel Installer** (`soplos-kernel-installer`): Added to Kernels tab with Install/Uninstall toggle and Open button.
- **Portmaster**: Added to Security tab (Firewall section) as a privacy-focused packet filter. Downloads the official `portmaster-installer.deb` with no hardcoded version.
- **JoPDF**: Added to Recommended tab (Ofimática section) as a PDF editor. Downloads `jopdf-linux-amd64_setup.deb` directly from the official site.
- **qBittorrent** (`org.qbittorrent.qBittorrent`): Added to Recommended tab (Utilities section) via Flatpak.
- **JDownloader** (`org.jdownloader.JDownloader`): Added to Recommended tab (Utilities section) via Flatpak.
- **PPSSPP** (`org.ppsspp.PPSSPP`): Added to Recommended (Gaming section) and Gaming tab launchers via Flatpak. Includes a post-install script that creates a symlink to the Flatpak binary as the Lutris runner, making PSP games playable directly from Lutris.
- **LACT** (`io.github.ilya_zlobintsev.LACT`): Also added to Recommended tab (Utilities section) via Flatpak.
- **CoolerControl**: Added to Recommended tab (Utilities section) as an AppImage that runs as root (fan/cooling daemon) plus a WebApp shortcut pointing to `http://localhost:11987/`.

### 🎮 Gaming Tab — MangoHud Rework
- **MangoHud** now installs via Flatpak instead of system packages. Six packages are installed: `MangoHud`, `GOverlay`, `VulkanInfo`, `vkBasalt`, `gamescope`, and `DXVK`.

### 🔧 Post-Install Script System
- **Lutris Vulkan patch**: After installing Lutris (Flatpak) from Recommended or Gaming tab, `lutris-vulkan-patch.sh` runs automatically and patches `gpu.py` inside the Flatpak to use `/app/bin/vulkaninfo` instead of the broken `/usr/bin/vulkaninfo` path.
- **PPSSPP Lutris runner**: After installing PPSSPP Flatpak, `ppsspp-lutris-runner.sh` runs automatically. It backs up any existing `PPSSPPSDL` binary in Lutris' runner directory and creates a symlink to the PPSSPP Flatpak binary.
- **General post-install hook**: Both `recommended_tab.py` and `gaming_tab.py` now support a `post_install_script` key in any package dict. After a successful install, the named script (from `services/`) is executed as the current user.

### 🛡️ Security Tab — Icons & Layout
- **Icons added to all 14 tools**: Timeshift, Grub BTRFS, Deja Dup, BTRFS Assistant, GUFW, Portmaster, Proton VPN, BleachBit, Stacer, Sweeper, Soplos Sys Cleaner, ClamTk, ClamUI and rkhunter now show a 48 px icon from `assets/icons/security/`.
- **Same row layout as Gaming/Recommended**: Each tool's icon is now centred vertically next to both the name and the description, matching the visual style of the other tabs.
- **Open Portmaster button**: When Portmaster is installed an "Open Portmaster" button launches the app via `gtk-launch portmaster` with a `/opt/safing/portmaster/portmaster` fallback.
- **UFW conflict warning**: When Portmaster is installed and UFW is active, an orange warning label recommends disabling UFW to avoid rule conflicts.

### 🎮 Gaming Tab — GeForce NOW, Badges & Tooltips
- **GeForce NOW WebApp launcher**: New launcher that installs a Soplos WebApp Manager `.desktop` entry pointing to `https://play.geforcenow.com/` using the system's Chromium/Brave/Firefox (auto-detected).
- **Flatpak / AppImage / WebApp badges**: All launcher widgets now display a small badge indicating the installation method.
- **Optimization button tooltips**: All 7 optimization buttons in the Gaming tab now show a tooltip on hover explaining what each option does.
- **MangoHud Flatpak package IDs corrected**: Fixed to the exact IDs required — `io.github.benjamimgois.goverlay`, `org.freedesktop.Platform.VulkanLayer.MangoHud`, `org.freedesktop.Platform.VulkanInfo`, `org.freedesktop.Platform.VulkanLayer.gamescope`, `org.winehq.Wine.DLLs.dxvk`, `org.freedesktop.Platform.VulkanLayer.vkBasalt`.

### 💻 Software Tab (XFCE)
- **GNOME Software**: Now also installs `gnome-packagekit` so that the XFCE panel update indicator can actually apply updates when clicked.

### 🌍 Translations
- Added `"Complete installation"` string in all 8 languages (ES, EN, FR, DE, PT, IT, RO, RU).
- Added translations for new apps (ProtonVPN, ClamUI, LACT, Resources) in all 8 languages.
- Added translations for PPSSPP, LACT (utilities), CoolerControl, and updated Drivers tab subtitle in all 8 languages.
- Added missing translations for all Security tab tool descriptions, driver status labels (Audio, Not installed, Driver installed, Hybrid Graphics, Partially installed, Different version installed), kernel AVX2 description, and app descriptions (JDownloader, qBittorrent, JoPDF) in all 8 languages.

## [2.0.8] - 2026-03-31

### ✨ Customization Tab
- **Install dialog for Soplos tools**: Buttons for Soplos tools (Soplos Theme Manager, Soplos Docklike, etc.) now detect whether the tool is installed. If not, they show a confirmation dialog inviting the user to install it via `pkexec apt-get install`, and auto-launch the tool on success.

### ⭐ Recommended Tab
- Added 6 new Flatpak applications: **Bitwig Studio**, **Reaper**, **Zrythm**, **Ardour** (Multimedia), **Warehouse** (Flatpak manager), **PeaZip** (archive manager).

### ⌨️ Keyboard Navigation
- **Ctrl+Shift+Tab**: Navigate to previous tab (backward navigation now works).
- **F1**: Opens the About dialog, consistent with all other Soplos applications.

### 🎨 UI Fixes
- **About dialog**: Fixed dark strip between content and action area in both dark and light themes.
- **Welcome tab**: Added Security to the features list (was missing). Fixed icon order to match tab order. Updated tab icons to match the feature list icons.
- **Drivers tab**: Removed emojis from Frame labels (Processor, Graphics Card, Hybrid Graphics, RAM Memory, Virtual Machine) for better font compatibility.

### 🔧 Code Audit
- Removed unused demo code (`_add_software_demo_buttons`, `_on_demo_install`, `_on_demo_uninstall` and related methods) from `main_window.py`.
- Fixed deprecated `get_action_area()` call in `drivers_tab.py` (replaced with manual button box in `get_content_area()`).
- Fixed duplicate imports in `welcome_tab.py`.
- Removed "coming soon" placeholder text from tab fallback view.
- Unified version string to 2.0.8 across all modules.

### 🌍 Translations
- Added `• Manage system security` string in all 8 languages (ES, EN, FR, DE, PT, IT, RO, RU).
- Added install flow strings for Soplos tools dialog in all 8 languages.
- Added descriptions for 6 new Recommended apps in all 8 languages.

## [2.0.7-3] - 2026-03-24

### 🚀 NVIDIA 580 Driver Fix
- **SHA1/sqv workaround**: Replaced cuda-keyring with `[trusted=yes]` in sources.list for the debian12 CUDA repo, bypassing `sqv` rejection of SHA1 key binding signatures on Debian 13.
- **Version pinning**: Added `nvidia-driver-pinning-580` installation step to force apt to resolve the 580 branch instead of the latest (595+).
- **Downgrade support**: Added `--allow-downgrades` flag to handle packages already at a newer version (e.g. `firmware-nvidia-gsp`, `libxnvctrl0`).
- **Uninstall cleanup**: `_on_uninstall_nvidia_clicked` now also removes `99nvidia-sha1-exception` leftover file.

### 🔧 Hardware Detection Improvements
- **GTX 16xx / MX550/MX450**: Correctly mapped to `nvidia-driver-590` (CUDA repo, debian13).
- **Maxwell GPUs** (GTX 9xx, 8xx, 9xxM): Correctly mapped to `nvidia-driver-580` (CUDA repo, debian12).
- **lspci caching**: Added `_get_lspci_output()` helper; `scan_hardware` now calls lspci once and passes the result to both `detect_gpu` and `detect_hybrid_gpu`.

### 🛡️ Security Tab
- **Soplos Sys Cleaner**: Added to the Cleaning section with install/uninstall and "Open" button.

### ⭐ Recommended Tab
- **Soplos AppImage Manager**: Added to the Utilities category.
- **OBS Studio** and **HandBrake**: Switched to Flatpak installation (apt versions cause dependency issues on Debian 13).
- **Lutris**: Switched to Flatpak in both Recommended and Gaming tabs.
- **AppImage badge**: Packages installed as AppImage now display an AppImage badge alongside their name.
- **Official badge**: Now only shown when the install method is APT (not Flatpak or AppImage).

### 🌍 Translations
- Updated all 8 languages (ES, EN, FR, DE, PT, IT, RO, RU) with 4 new strings: Soplos AppImage Manager description, AppImage badge, Soplos Sys Cleaner description, and "Open Soplos Sys Cleaner" button.

## [2.0.7-2] - 2026-03-13

### 🚀 NVIDIA Driver Fixes
- **Hardware Detection**: Corrected mapping for GeForce 650M/750M (Kepler MacBooks) to use driver 470 instead of nouveau.
- **MX/GT Series**: Improved detection patterns for MX and legacy GT series GPUs.
- **Installation Workflow**:
  - Added mandatory confirmation dialogs before starting driver installation.
  - Implemented automatic `apt purge` of existing NVIDIA drivers to prevent conflicts.
  - Ensured explicit installation of `nvidia-smi`, `nvidia-settings`, `nvidia-modprobe`, and `libglu1-mesa`.
  - Added fallback support for `update-initramfs` when `dracut` is not available.

### 🌍 Translations
- Updated all 8 supported languages (ES, EN, FR, DE, PT, IT, RO, RU) with new confirmation dialog strings.

## [2.0.7-1] - 2026-03-12


### 🚀 NVIDIA Driver Improvements
- **Official Repository Logic**: Refactored official NVIDIA repository installation logic to follow official documentation.
- **Keyring Handling**: Uses the official `cuda-keyring` package to manage repositories and GPG keys, resolving issues with empty GPG files.
- **Robustness**: Improved the installation script for Debian 12 (driver 580) and 13 (driver 590) with better fallback logic and error handling.

## [2.0.7] - 2026-03-11

### 🔧 NVIDIA Legacy Drivers Overhaul
- **APT-based Legacy Installation**: Legacy NVIDIA drivers (340, 390, 470) are now installed via APT from Debian Sid instead of `.run` files, for cleaner integration and fewer dependency conflicts.
- **Debian Sid Workflow**: New two-step dialog guides users to temporarily enable Debian Sid (Unstable) via **Soplos Repo Selector** before installing legacy drivers, with clear warnings to disable Sid afterwards.
- **Automatic Repo Selector Launch**: Clicking a legacy driver button now opens Soplos Repo Selector automatically and waits for the user to finish before proceeding with the installation.
- **Correct APT Package Names**: Updated hardware detector to use `nvidia-legacy-340xx-driver`, `nvidia-legacy-390xx-driver`, and `nvidia-tesla-470-driver` from Debian Sid.

### 🌍 Translations
- Added 4 new translation strings for the legacy driver dialogs in all 8 languages (ES, EN, FR, DE, PT, IT, RO, RU).

## [2.0.6-3] - 2026-03-08

### 🛠️ Bug Fixes
- **AppImages**: Fixed `Errno 13 Permission denied` when creating web apps by installing all AppImages (Affinity Suite, ES-DE, Stacer) to `~/AppImage` instead of `/opt`, and removing the use of `pkexec` to prevent root ownership of user directories.

## [2.0.6-2] - 2026-03-07

### 🛠️ Bug Fixes
- **Gaming Tab**: Fixed an issue where installing gaming wallpapers on GNOME (Boro) would duplicate existing Soplos wallpapers in the background settings.

## [2.0.6] - 2026-03-04
 
### 🆕 Added
- **Recommended Tab**: New "Utilities" section featuring Soplos WebApp Manager, Flatseal, and Gear Lever.
- **Gaming Tab**: Added ProtonUp-Qt to the launchers list for managing GE-Proton and Wine versions.
 
### 🔧 Kernels Tab Fixes
- **Clean Old Kernels**: Fixed critical logic bug where older kernels were sometimes kept instead of newer ones due to lexicographical sorting.
  - Implemented version-aware sorting (`sort -V`) for accurate identification of the latest kernels.
  - Enhanced preservation logic: now keeps the running kernel PLUS the latest version of each branch (Main, Liquorix, XanMod).
  - Deep cleaning: Switched to `apt purge` to remove configuration files and stale modules.
  - Automatic header cleanup: Matching `linux-headers-*` packages are now purged alongside images.
 
## [2.0.5] - 2026-03-02

### 🛠️ Bug Fixes
- **Recommended Tab**: Fixed logic bug in batch installation mode ("Selección Múltiple") that caused custom script applications (like ES-DE and Affinity Suite) to collide and fail during selection or removal.

## [2.0.4] - 2026-02-24

### 🎮 Gaming Tab Enhancements
- **Sober (Roblox)**: Added Sober launcher to Gaming tab (successor to Vinegar)
- **EmulationStation-DE**: Added as AppImage in both Gaming tab and Recommended tab
- **Internationalized Launchers**: All 14 launcher descriptions now use `_()` instead of hardcoded Spanish strings, with translations in all 8 languages
- **Launcher Alignment Fix**: Fixed visual alignment of launcher entries with uniform height (60px), centered icons, and consistent description wrapping

### 🔧 Kernels Tab Improvements
- **"Kernels" tab name**: Changed to "Kernels" in all 8 languages (was translated as "Núcleos", "Noyaux", "Ядра", etc.)
- **Clean Old Kernels**: Completely rewritten kernel cleanup with Python-based logic:
  - Smart classification: keeps running kernel + latest base + latest Liquorix + latest XanMod
  - Confirmation dialog showing ✓ kernels to keep and ✗ packages to remove (including headers)
  - Single `pkexec` execution with `apt autoremove` and `update-grub`
  - Proper "System is clean" message when nothing to remove

### 🛡️ Security Tab Changes
- **Stacer AppImage**: Converted from broken `.deb` installation to stable AppImage (`/opt/stacer/Stacer.AppImage`)
  - Survives `apt upgrade` without breaking
  - Creates `.desktop` file for system integration
  - Clean uninstall removes AppImage and desktop entry

### 🌍 Internationalization
- Added 8 new gaming launcher translations (R2ModMan, Vinegar, Prism Launcher, Itch.io, Minigalaxy, Moonlight, Chiaki, Discord)
- Added EmulationStation-DE description translations for all 8 languages
- Added 7 new kernel cleanup dialog translations (confirmation, keep/remove labels)
- Changed "Kernels" to remain untranslated as a universal technical term

## [2.0.3] - 2026-01-09

### 📚 Documentation
- **Man Page**: Added complete manual page (`docs/soplos-welcome.1`) with standard sections (NAME, SYNOPSIS, DESCRIPTION, OPTIONS, FILES, AUTHOR, COPYRIGHT, SEE ALSO).
- **Debian Copyright**: Added machine-readable copyright file (`debian/copyright`) following Debian 1.0 format with full GPL-3.0+ license block.

## [2.0.2] - 2026-01-04

### 🛡️ Security Tab Enhancements
- **New Feature: Grub BTRFS Integration** - Added one-click installation for `grub-btrfs` to automatically add snapshots to GRUB boot menu.
- **Intelligent Detection** - Only shows Grub BTRFS option if BTRFS filesystem is detected (same as BTRFS Assistant).
- **Streamlined Installation** - Uses `pkexec` for secure installation from official Soplos repositories.
- **Complementary Tool** - Positioned next to TimeShift in System Backups section as a companion tool.

### 🌍 Internationalization
- **Updated Translations** - Added translations for Grub BTRFS feature in all 8 languages (ES, EN, FR, DE, PT, IT, RO, RU).
- **Dictionary Updates** - Verified and synchronized translation keys.

## [2.0.1] - 2025-12-27

### 🚀 Hybrid Graphics Support (NEW)
- **Hybrid GPU Detection**: Automatic detection of Intel/AMD + NVIDIA configurations on laptops
- **PRIME Render Offload**: On-demand NVIDIA usage for battery saving (recommended for most users)
- **NVIDIA Primary Mode**: Always use dedicated GPU for maximum performance
- **Multi-DE Configuration**: Automatic configuration for GNOME (GDM3), KDE Plasma (SDDM), and XFCE (LightDM)
- **X11 and Wayland Support**: Proper configuration for both display protocols
- **Environment Detection Integration**: Uses `EnvironmentDetector` for smart DE/DM/protocol detection

### 🔧 Two-Phase NVIDIA Installation (NEW)
- **Systemd-based .run Installation**: Prevents black screen issues after driver installation
- **Phase 1 - Preparation**: Creates systemd service, blacklists nouveau, configures GRUB, reboots to multi-user.target
- **Phase 2 - Installation**: Installs driver without X running, regenerates initramfs, restores graphical boot
- **Fully Automatic**: User only needs to wait for two automatic reboots
- **Display Manager Support**: Automatic detection and restart of GDM3, SDDM, or LightDM

### 🎮 NVIDIA Driver Improvements
- Added **NVIDIA 590 driver** (590.48.01) - Latest driver for RTX 50/40/30 series
- Added **NVIDIA 580 Production driver** (580.119.02) for RTX 40/50 series
- **RTX 50 series (Blackwell)** now properly detected and recommended driver 590
- **RTX 40 series (Ada Lovelace)** now properly detected and recommended driver 580
- **GTX 10xx series (Pascal)** moved to latest driver support (was incorrectly recommending legacy 470)
- Drivers now ordered by version (590 → 580 → 550 → 470 → 390 → 340)
- **New "NVIDIA Extras" section** - Separated DaVinci Resolve and Blender CUDA tools from drivers
- Updated driver version labels in UI: "NVIDIA 590 (Latest)", "NVIDIA 580 (Production)", "NVIDIA 550 (Repo)"
- Improved hardware detection logic for modern NVIDIA GPUs

### � New Recommended Software
- **Multimedia**: Spotify (streaming service), HandBrake (video transcoder)
- **Communications**: Slack (team collaboration), Zoom (video conferencing)
- **Developer**: Postman (API testing)
- **Graphics**: RawTherapee (RAW processing), Hugin (panorama stitcher)

### �🛠️ Fixed
- **Single pkexec authentication** - All driver installation scripts now use single `pkexec bash` call instead of multiple `pkexec` commands (one password prompt instead of many)
- **Fixed `echo | pkexec tee` pattern** - Replaced with direct file writes since scripts run as root
- Corrected driver recommendation mapping for RTX 40/50 to use nvidia-driver-580/590
- Updated driver installation version map for automated driver selection
- **Fixed GPU detection always recommending driver 580** - Now correctly maps GPU series to appropriate drivers
- **Legacy GPU detection** (GeForce 8000/9000, MacBook GPUs) now recommends `nouveau` instead of proprietary drivers
- **Quadro/Tesla professional cards** now properly detected and recommended `nvidia-driver` (repo)
- **Changed default fallback** from `nvidia-driver-580` to `nvidia-driver` (repo) for safer unknown GPU handling

## [2.0.0] - 2025-12-06

### 🏗️ Architecture Rewrite
- Complete rewrite with modern, modular architecture.
- Separation of concerns: Core, UI, Services, Utils layers.
- Professional project structure with focused, maintainable modules.

### 🔧 Universal Desktop Compatibility
- Smart desktop environment detection.
- GNOME 48+ full integration.
- KDE Plasma 6 native support.
- XFCE 4.20 optimization.
- Complete X11 and Wayland compatibility.

### 🌍 Internationalization Overhaul
- Migrated to GNU Gettext standard with .mo files.
- Support for 8 languages: ES, EN, FR, DE, PT, IT, RO, RU.

### 🎨 Advanced Theming System
- CSS-based theming engine.
- Automatic dark/light theme detection.


### 🖥️ Complete Drivers Tab Implementation
- Hardware detection (CPU, GPU, RAM, storage, network, VM)
- NVIDIA drivers (Latest + Legacy 470/390/340 via .run files)
- DaVinci Resolve extras (OpenCL/CUDA libraries)
- Blender CUDA toolkit
- Full Dracut configuration (blacklist nouveau, NVIDIA modules, initramfs regeneration)
- AMD drivers (firmware-amd-graphics + Mesa + Vulkan)
- Wi-Fi drivers (Intel/Realtek/Broadcom)
- VM Tools (VMware/QEMU/VirtualBox)
- One-click installation from hardware scan results

### 🔧 Complete Kernels Tab Implementation
- Liquorix kernel with NVIDIA incompatibility detection and blocking
- XanMod kernel variants (x64v3 Standard, x64v4 Advanced, EDGE Experimental, LTS Long-term)
- CPU Microcode updates (Intel and AMD with automatic vendor detection)
- System maintenance tools (Clean old kernels, Update GRUB)
- Clear variant descriptions with CPU compatibility information
- NVIDIA compatibility warnings and safety checks

### ✨ Recommended Tab Complete Overhaul
- **Search and Filter**: Real-time search functionality to quickly find applications
  - Search bar positioned in header for instant access
  - Filters applications by name and description as you type
  - Displays "No results found" message when search yields no matches
  - Search state persists across mode switches (normal ↔ batch)
- **Batch Installation Mode**: New "Selección Múltiple" mode allows selecting and installing multiple packages simultaneously
  - Toggle between normal (individual buttons) and batch (checkboxes) modes
  - "Seleccionar Todos" button selects all visible uninstalled packages (respects search filter)
  - "Deseleccionar Todos" button clears all selections instantly
  - Smart grouping: APT packages installed in single command, Flatpak/deb/custom scripts sequential
  - Bottom action bar with selection counter and batch install button
  - Selection state persists during UI refresh operations
  - Full support for custom scripts (Google Antigravity, Brave, Zed, Sublime Text, etc.)
  - Only DaVinci Resolve excluded due to complex multi-step installation
- **Custom Script Support**: Complex installation workflows with repository setup, GPG keys, and multi-step installations
- **Global Progress Bar Integration**: Unified progress reporting across all installation methods
- **Enhanced Error Handling**: Robust error recovery with proper UI state management
- **Installation Methods**: Full support for APT, Flatpak, .deb URLs, and custom installation scripts
- **UI Stability Fixes**: 
  - Resolved UI freezing during package operations
  - Fixed deformation issues during installation
  - Improved cache invalidation and status updates
- **Software Ecosystem Updates**:
  - **DaVinci Resolve**: Added professional video editor with optimized custom installation workflow:
    - Sequential installation process (dependencies → extraction → conversion → installation)
    - Performance optimization: Reduced package build time from ~45 minutes to ~5-10 minutes using faster gzip compression (level 1)
    - Fixed .deb installation using `dpkg -i` instead of `apt-get install` for local packages
    - Added automatic dependency resolution with `apt-get install -f`
    - Enhanced error handling in CommandRunner to prevent UI crashes during progress updates
    - Comprehensive file-based debug logging (`~/soplos_davinci_debug.log`)
    - Script by Daniel Tufvesson with Soplos optimizations
  - **RapidRAW**: Replaced RawTherapee with modern RAW photo editor (via .deb from GitHub releases)
  - **Google Antigravity**: Replaced Geany with advanced IDE (custom repository + GPG key installation)
  - **Midori**: Replaced Epiphany with lightweight browser (.deb installation)
  - **Snap Removal**: Removed Snap support from Recommended software to prioritize native and Flatpak packages
  - **Gaming Features**:
  - **System Optimizations**: GameMode installation, CPU performance mode script with power-profiles-daemon, gaming sysctl profile
  - **Performance Mode**: Fully implemented with automatic power-profiles-daemon installation and configuration
  - **GPU Optimization**: Automatic GPU vendor detection (NVIDIA/AMD/Intel) with environment configuration files for optimal gaming drivers
  - **Disk I/O Optimization**: Udev rules implementation for optimal disk schedulers (mq-deadline for SSD, none for NVMe, BFQ for HDD)
  - **Performance Monitoring**: MangoHud + Goverlay integration for FPS overlay
  - **Game Launchers**: Full installation/uninstallation support for 13 gaming platforms:
    - **Steam (Flatpak)**: Digital game distribution platform
    - **Lutris (APT/Flatpak)**: Unified game manager for Linux with official repository package badge
    - **Heroic Games Launcher (Flatpak)**: Launcher for Epic Games, GOG, and Amazon Games
    - **Bottles (Flatpak)**: Run Windows applications using Wine with intuitive prefix management
    - **Vinegar (Flatpak)**: Modern Roblox launcher for Linux
    - **R2ModMan (Flatpak)**: Mod manager for games like Lethal Company, Valheim, Risk of Rain 2
    - **Prism Launcher (Flatpak)**: Custom Minecraft launcher with mod support
    - **Itch.io (Flatpak)**: Indie game marketplace and distribution platform
    - **Minigalaxy (APT/Flatpak)**: Simple GOG.com client with official repository package badge
    - **RetroArch (APT/Flatpak)**: Multi-system emulator frontend with official repository package badge
    - **Moonlight (Flatpak)**: NVIDIA GameStream and Sunshine streaming client
    - **Chiaki (Flatpak)**: PlayStation Remote Play client with PS4/PS5 HDR support
    - **Discord (Flatpak)**: Gaming community communication platform
  - **Installation Method Badges**: Visual indicators (Flatpak badge) to show package installation source
  - **Official Package Badges**: Security shield icon for packages from official Debian repositories
  - **RGB Gaming Theme**: Toggle-able gaming theme with black background and red neon accents:
    - Applies instantly without requiring application restart
    - Modern gaming aesthetic with glowing effects
    - One-click activation/deactivation from Gaming tab
  - **Gaming Wallpapers**: Automatic installation with GNOME XML registry support for seamless integration
  - **Revert Functionality**: One-click rollback of all gaming optimizations
  - **Custom Icons**: Vibrant gaming-themed icons for better visual identity
- **UI Enhancements**:
  - **Category Icons**: Updated Development category icon to VS Code, Gaming category icon to Steam
  - Improved category icon loading with configurable support
- **System Integration**:
  - **Icon Fixes**: Corrected application icon visibility by renaming assets to match App ID (`org.soplos.welcome`)
  - **Desktop Entry**: Added proper `.desktop` file for system integration

### 🔒 Security Tab Implementation
- **System Backups**: Integration with Timeshift and Deja Dup.
- **Firewall Management**: GUFW integration and real-time UFW status monitoring.
- **Filesystem Tools**: BTRFS Assistant detection and management.
- **Antivirus & Security**: ClamTk and rkhunter integration.
- **One-Click Actions**: Configure, Activate, Update, and Scan buttons.

### 🎨 Customization Tab Implementation
- **Universal Desktop Support**: Native customization for XFCE, GNOME, and Plasma.
- **XFCE Integration**: 
  - 4 Soplos Tools: Theme Manager, Docklike, GRUB Editor, Plymouth Manager.
  - 7 Native Settings: Appearance, Desktop, Window Manager, Keyboard, Mouse, Notifications, Settings Editor.
- **GNOME Integration**:
  - Soplos Tools: GRUB Editor, Plymouth Manager.
  - Native Settings: Control Center, Tweaks, Extensions, dconf Editor.
- **Plasma Integration**:
  - Soplos Tools: GRUB Editor, Plymouth Manager.
  - Native Settings: Look and Feel, Login Screen, Plymouth, System Settings (via .desktop files).
- **Smart Features**: Automatic DE detection, visual descriptions, debounce protection.

### 🛠️ Fixed
- **CRITICAL: GPU Detection Fix**: Resolved false positive AMD detection caused by 'compatible' string matching. Now correctly identifies NVIDIA, Intel, and VMware SVGA adapters using regex word boundaries.
- **Gaming Tab Dialog Messages**: Fixed dialog messages showing literal `\n` instead of line breaks by correcting double-escaped newlines (`\\n` → `\n`) in 8 locations
- **Gaming Tab GPU Detection**: Improved GPU detection to avoid false AMD detection in VMs (Red Hat VirtIO), now uses word-boundary checks for ATI matching
- **Gaming Tab 32-bit Packages**: Removed `:i386` package dependencies (GameMode and MangoHud) to support 64-bit only systems
- **Gaming Tab Single Password**: All optimization operations now use single `pkexec bash -c` call (Performance Mode, Gaming Sysctl, Disk I/O, GPU, Revert All)
- **Gaming Tab Revert All**: Complete revert functionality now removes sysctl, GPU environment vars, Disk I/O rules, and Performance Mode script
- **KDE Plasma Icon**: Resolved application icon display issue in KDE Plasma with proper WM_CLASS and .desktop file association.
- **Welcome Tab Autostart**: Fixed .desktop file creation and dynamic path resolution for autostart functionality.
- **Flatpak Installation**: Corrected Flathub repository setup and package installation in Tyson variant, ensuring user-level installations work without password prompts.
- **Recommends Tab UI**: Improved button alignment consistency by enforcing minimum height for description labels, eliminating visual inconsistencies.
- **Security Tab - UFW Firewall**: Fixed status detection by reading `/etc/ufw/ufw.conf` directly, simplified activation to single `pkexec` call, added `--force` flag to prevent interactive prompts, enabled systemd service persistence, added periodic status check (every 3s) to detect external changes from GUFW
- **Security Tab - BTRFS Detection**: Fixed filesystem detection using `findmnt` instead of incompatible `df` flags, now correctly detects BTRFS with Calamares subvolumes (@, @home)
- **Window Deformation**: Fixed progress label stretching during downloads by adding text ellipsization and width limits
- **Gaming Tab**: Fixed wallpaper installation progress bar (now shows progress during extraction)
- **Gaming Tab**: Added toggle functionality for Performance Mode (install/uninstall)
- **Gaming Tab**: Safety update - Removed wallpaper uninstallation to protect system files
- **Gaming Tab**: Updated "Revert All" dialog to accurately reflect implemented optimizations (GPU/Disk I/O)
- **Gaming Tab**: Added support for 4 new Flatpak launchers: R2ModMan (Mods), Moonlight (Streaming), Chiaki4deck (PS4/PS5), Vinegar (Roblox)
- **Gaming Tab**: Reordered launchers list for better organization
- Fixed DriversTab initialization
- Fixed Repo Selector button to launch application
- Updated Welcome tab URLs to soplos.org
- **Fixed Batch Installation**: Improved reliability for Chrome, RapidRAW, Midori, and Cursor installations (now use sequential logic with `dpkg -i`).
- **Fixed Clean System**: Consolidated cleanup commands into a single administrator password prompt (GNOME, Plasma, XFCE).
- **Fixed Recommended Tab UI**: Resolved vertical scrollbar overlapping content boxes.
- **Updated Google Antigravity**: Description updated to "Advanced Agentic AI Coding Assistant".
- **Fixed Translations**: Comprehensive cleanup of Spanish dictionary (removed duplicates, fixed fuzzy entries) and added missing gaming wallpaper confirmations.
- **Fixed ClamAV**: Resolved single password prompt issue and added missing translations for update process.
- **Fixed Progress Bar**: Corrected calculation logic to prevent percentage overflow (>100%) during batch installations.
- **Fixed Recommended Tab Scrollbar**: Resolved vertical scrollbar overlapping content boxes by adding right margin (20px) to FlowBox.
- **Complete French Dictionary**: Full revision and completion of French translations (565/565 messages):
  - Synchronized with latest .pot template using msgmerge
  - Added 35+ new translations (GNOME/KDE Settings, Gaming, Security, Recommended sections)
  - Fixed 23 fuzzy translations with incorrect inherited values
  - Corrected syntax error (corrupted X11 msgstr with mixed translation text)
  - Updated header with correct translator info (Sergi Perich)
- **Complete German Dictionary**: Full revision of German translations (565/565 messages):
  - Fixed typo "Dukle" → "Dunkle" (Dark theme)
  - Updated header with correct translator info
- **Complete Italian Dictionary**: Full revision of Italian translations (565/565 messages):
  - Synchronized with latest .pot template using msgmerge
  - Added 35 missing translations (GNOME/KDE Settings, Gaming, Security sections)
  - Removed 23 fuzzy flags with corrected translations
  - Updated header with translator info (Sergi Perich)
- **Complete Portuguese Dictionary**: Full revision of Portuguese translations (565/565 messages):
  - Fixed missing translation ("Symlinks created in:")
  - Fixed typo "PROPÓSITIO" → "PROPÓSITO"
  - Changed "Upgrade" to "Atualizar Sistema" for better localization
  - Updated header with translator info
- **Complete Romanian Dictionary**: Full revision of Romanian translations (565/565 messages):
  - Added 2 missing help text translations
  - Changed "Upgrade" to "Actualizare Sistem"
  - Updated header with translator info
- **Complete Russian Dictionary**: Full revision of Russian translations (565/565 messages):
  - Added 14 missing translations (AI Assistant, GNOME/KDE settings, Gaming messages)
  - Fixed 23 fuzzy translations with correct Russian text
  - Fixed typo "интерфейфейс" → "интерфейс"
  - Changed "Модернизировать" to "Обновить систему" for better localization
  - Updated header with translator info
- **Updated English/Spanish Dictionary Headers**: Corrected Last-Translator and Language-Team metadata.
- **Translation Quality**: All 8 languages (EN, ES, DE, FR, IT, PT, RO, RU) now at 100% with 565 messages each.

---

## Tyson Branch

## [1.1.5] - 2025-09-08

### 🆕 Changed / Fixed
- Updated all welcome tab link buttons to soplos.org: website (`https://soplos.org`), forum (`https://soplos.org/forums/`) and wiki (`https://soplos.org/wiki/`).
- Removed deprecated `on_website_clicked` and `on_wiki_clicked` method handlers — buttons now use inline lambdas consistently.
- Updated Blender icon to the new design.

## [1.1.4] - 2025-09-08

### 🆕 Added / Fixed
- Updated Blender icon to the requested image.
- Fixed welcome tab link buttons (website, forums, wiki).

## [1.1.3] - 2025-08-02

### 🆕 Added / Improved
- Updated all translation dictionaries.
- Fixed several functions in the hardware detector.
- Updated all program icons.

## [1.1.2] - 2025-07-27

### 🆕 Changed
- Changed program icon to a new design.

## [1.1.1] - 2025-07-27

### 🛠️ Fixed
- Fixed office install/uninstall button logic in the Recommended tab (now works like other categories).
- Fixed hardware detector: now always returns the correct recommended driver for NVIDIA and other hardware.

## [1.1.0] - 2025-07-24

### 🛠️ Fixed
- Fixed Flatpak/Flathub installation bug: Now Flatpak applications can be installed from Flathub without requiring administrator privileges. The Software Center correctly adds Flathub for the current user.

## [1.0.9] - 2025-07-18

### 🛠️ Fixed
- Fixed install buttons in the Software Center (now work correctly).

## [1.0.8] - 2025-07-15

### 🆕 Added / Improved
- Improvements in QEMU/KVM integration and operation for virtual machines.
- Enhanced management and installation of NVIDIA drivers (detection, recommendation, and a more robust installation process).
- **Translation dictionary fragmentation completed:** Interface texts are now organized by language in separate files for Spanish, English, French, Portuguese, German, Italian, Russian, and Romanian.
- **Internationalization:** The program has been fully internationalized to facilitate global collaboration and translation contributions.
- **Recommended Tab:** Improved logic for install/uninstall buttons, now updates state and action dynamically after each operation.
- **LibreWolf:** Installation now uses Flatpak (Flathub) instead of APT or external repositories, avoiding conflicts and simplifying maintenance.

## [1.0.7] - 2025-07-13

### 🛠️ Improved - Metainfo and AppStream/DEP-11 compatibility
- Metainfo updated to comply with AppStream/DEP-11.
- Minor improvements in integration and documentation.
- No functional changes in the application.

## [1.0.6] - 2025-06-24

### 🆕 Added
- Improvements to the Software Center and browser updates.
- Software Center now detects if programs are installed.
- Midori replaced with Epiphany (GNOME Web) as lightweight browser.
- DaVinci Resolve replaced with Shotcut for video editing.
- Driver Center improved with optimized hardware detection.
- Enhanced hardware scanning functionality.

## [1.0.5] - 2025-06-14

### 🔧 Fixed
- Reverted App ID to `com.soplos.welcome` (dot notation restored after 1.0.2 change).
- Soplos Packager injection block removed from `main.py` (reverted to clean entry point).
- Assets renamed back to `com.soplos.welcome` convention (desktop file, icons, metainfo, pixmaps).

## [1.0.4] - 2025-06-09

### 🔧 Fixed
- Autostart updated: now copies `com.soploswelcome.desktop` from `/usr/share/applications/` instead of writing inline content, ensuring the autostart entry always matches the installed desktop file.
- Desktop file references updated (`X-GNOME-Application-ID`, `X-AppStream-Metadata`, `Icon`, `StartupWMClass`) to use `com.soploswelcome`.

## [1.0.3] - 2025-06-05

### 🔧 Fixed
- Soplos Packager App ID initialization block injected into `main.py`: sets `GLib.set_prgname`, `GLib.set_application_name` and `Gtk.Window.set_default_icon_name` to `com.soploswelcome` for correct window manager integration.

## [1.0.2] - 2025-06-04

### 🔄 Changed
- Renamed all assets from `com.soplos.welcome` to `com.soploswelcome` (dot removed) for Soplos Packager compatibility: desktop file, icons (all sizes), metainfo and pixmaps.
- App ID changed from `com.soplos.welcome` to `com.soploswelcome`.

## [1.0.1] - 2025-05-28

### 🔧 Fixed
- Welcome tab: corrected website button URL from `soploslinux.com/distro` to the distro-specific URL (`soploslinux.com/tyson`).

## [1.0.0] - 2025-05-20

### 🎉 Initial Release
- Port of Tyron 1.0.0 to Soplos Tyson. Initial release of Soplos Welcome for Tyson.
- Welcome screen for Soplos Linux.
- Initial system setup.
- Installation of recommended software.
- Desktop customization.
- Access to help and support resources.
- Intuitive and user-friendly interface.
- Support for multiple languages.

---

## Tyron Branch

## [1.1.4] - 2025-09-08

### 🆕 Added / Fixed
- Updated Blender icon to the requested image.
- Fixed welcome tab link buttons (website, forums, wiki).

## [1.1.3] - 2025-08-03

### 🆕 Added / Improved
- Updated all translation dictionaries.
- Fixed several functions in the hardware detector.
- Updated all program icons.

## [1.1.2] - 2025-07-27

### 🆕 Changed
- Changed program icon to a new design.

## [1.1.1] - 2025-07-27

### 🛠️ Fixed
- Fixed office install/uninstall button logic in the Recommended tab (now works like other categories).
- Fixed hardware detector: now always returns the correct recommended driver for NVIDIA and other hardware.

## [1.1.0] - 2025-07-25

### 🛠️ Fixed
- Fixed Flatpak/Flathub installation bug: Now Flatpak applications can be installed from Flathub without requiring administrator privileges. The Software Center correctly adds Flathub for the current user.

## [1.0.9] - 2025-07-24

### 🛠️ Fixed
- Fixed install buttons in the Software Center (now work correctly).

## [1.0.8] - 2025-07-24

### 🆕 Added / Improved
- Improvements in QEMU/KVM integration and operation for virtual machines.
- Enhanced management and installation of NVIDIA drivers (detection, recommendation, and a more robust installation process).
- **Translation dictionary fragmentation completed:** Interface texts are now organized by language in separate files for Spanish, English, French, Portuguese, German, Italian, Russian, and Romanian.
- **Internationalization:** The program has been fully internationalized to facilitate global collaboration and translation contributions.
- **Recommended Tab:** Improved logic for install/uninstall buttons, now updates state and action dynamically after each operation.
- **LibreWolf:** Installation now uses Flatpak (Flathub) instead of APT or external repositories, avoiding conflicts and simplifying maintenance.

## [1.0.7] - 2025-07-18

### 🛠️ Improved - Metainfo and AppStream/DEP-11 compatibility
- Metainfo updated to comply with AppStream/DEP-11.
- Minor improvements in integration and documentation.
- No functional changes in the application.

## [1.0.6] - 2025-05-20

### 🆕 Added
- Improvements to the Software Center and browser updates.
- Software Center now detects if programs are installed.
- Midori replaced with Epiphany (GNOME Web) as lightweight browser.
- DaVinci Resolve replaced with Shotcut for video editing.
- Driver Center improved with optimized hardware detection.
- Enhanced hardware scanning functionality.

## [1.0.5] - 2025-05-08

### 🔧 Fixed
- Reverted App ID to `com.soplos.welcome` (dot notation restored after 1.0.2 change).
- Soplos Packager injection block removed from `main.py` (reverted to clean entry point).
- Assets renamed back to `com.soplos.welcome` convention (desktop file, icons, metainfo, pixmaps).

## [1.0.4] - 2025-05-07

### 🔧 Fixed
- Autostart updated: now copies `com.soploswelcome.desktop` from `/usr/share/applications/` instead of writing inline content, ensuring the autostart entry always matches the installed desktop file.
- Desktop file references updated (`X-GNOME-Application-ID`, `X-AppStream-Metadata`, `Icon`, `StartupWMClass`) to use `com.soploswelcome`.

## [1.0.3] - 2025-05-06

### 🔧 Fixed
- Soplos Packager App ID initialization block injected into `main.py`: sets `GLib.set_prgname`, `GLib.set_application_name` and `Gtk.Window.set_default_icon_name` to `com.soploswelcome` for correct window manager integration.

## [1.0.2] - 2025-05-05

### 🔄 Changed
- Renamed all assets from `com.soplos.welcome` to `com.soploswelcome` (dot removed) for Soplos Packager compatibility: desktop file, icons (all sizes), metainfo and pixmaps.
- App ID changed from `com.soplos.welcome` to `com.soploswelcome`.

## [1.0.1] - 2025-04-25

### 🔧 Fixed
- Welcome tab: corrected website button URL from `soploslinux.com/distro` to the distro-specific URL (`soploslinux.com/tyron`).

## [1.0.0] - 2025-04-08

### 🎉 Initial Release
- Welcome screen for Soplos Linux.
- Initial system setup.
- Installation of recommended software.
- Desktop customization.
- Access to help and support resources.
- Intuitive and user-friendly interface.
- Support for multiple languages.

---

## Types of Changes

- **Added** for new features
- **Improved** for changes in existing functionality
- **Deprecated** for soon-to-be removed features
- **Removed** for removed features
- **Fixed** for bug fixes
- **Security** for vulnerabilities


## Author

Developed and maintained by Sergi Perich  
Website: https://soplos.org  
Contact: info@soploslinux.com

## Contributing

To report bugs or request features:
- **Issues**: https://github.com/SoplosLinux/soplos-welcome/issues
- **Email**: info@soploslinux.com

## Support

- **Documentation**: https://soplos.org
- **Community**: https://soplos.org/forums/
- **Support**: info@soploslinux.com
