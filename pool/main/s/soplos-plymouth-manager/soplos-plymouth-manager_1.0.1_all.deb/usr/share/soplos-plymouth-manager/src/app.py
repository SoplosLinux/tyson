import gi
import os
import sys
import shutil
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk

from .config import Config
from .logger import logger
from .main_window import PlymouthThemeManager

class PlymouthApp:
    def __init__(self):
        # Intentar obtener APP_ID y WMCLASS desde el módulo principal
        try:
            from main import APP_ID, WMCLASS
            self.app_id = APP_ID
            self.wmclass = WMCLASS
        except ImportError:
            # Valores por defecto si no se puede importar
            self.app_id = "com.soplos.plymouthmanager"
            self.wmclass = self.app_id
        
        # Establecer el icono por defecto para todas las ventanas
        Gtk.Window.set_default_icon_name(self.app_id)
        
        # Limpiar __pycache__ al inicio
        self.clean_pycache()
        
        self.config = Config()
        self.logger = logger
        
        # Establecer tamaño de ventana por defecto
        if 'window_size' not in self.config.data:
            self.config.data['window_size'] = (450, 600)

    def clean_pycache(self):
        """Limpia los archivos __pycache__"""
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        for root, dirs, files in os.walk(base_dir):
            if "__pycache__" in dirs:
                try:
                    shutil.rmtree(os.path.join(root, "__pycache__"))
                except Exception as e:
                    self.logger.warning(f"No se pudo limpiar __pycache__ en {root}: {e}")

    def save_window_size(self, window):
        """Guarda el tamaño de la ventana antes de cerrar"""
        width, height = window.get_size()
        self.config.set('window_size', (width, height))
    
    def toggle_theme(self):
        """Cambia entre tema claro y oscuro"""
        settings = Gtk.Settings.get_default()
        current = self.config.get('dark_mode', True)
        settings.set_property("gtk-application-prefer-dark-theme", not current)
        self.config.set('dark_mode', not current)

    def run(self):
        try:
            # Limpiar al inicio
            self.clean_pycache()
            
            window = PlymouthThemeManager(self.config)
            window.app = self
            
            # Establecer WM_CLASS explícitamente
            window.set_wmclass(self.wmclass, self.wmclass)
            
            # Forzar actualización de propiedades de ventana antes de mostrar
            window.realize()
            
            window.connect("destroy", self.on_window_destroy)
            window.show_all()
            window.progress_frame.hide()
            Gtk.main()
        except Exception as e:
            self.logger.error(f"Error iniciando la aplicación: {e}")
            raise

    def on_window_destroy(self, window):
        """Manejador del evento de cierre de ventana"""
        self.save_window_size(window)
        Gtk.main_quit()
        import sys
        sys.exit(0)  # Forzar la terminación del programa
