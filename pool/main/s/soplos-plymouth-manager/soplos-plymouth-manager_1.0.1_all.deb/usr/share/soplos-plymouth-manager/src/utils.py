import os

def get_resource_path(relative_path):
    """
    Obtiene la ruta absoluta a un recurso
    Args:
        relative_path: Ruta relativa desde la carpeta assets
    """
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base_dir, "assets", relative_path)

def show_error_dialog(parent, message):
    """Muestra un diálogo de error"""
    from gi.repository import Gtk
    dialog = Gtk.MessageDialog(
        transient_for=parent,
        modal=True,
        message_type=Gtk.MessageType.ERROR,
        buttons=Gtk.ButtonsType.OK,
        text="Error"
    )
    dialog.format_secondary_text(message)
    dialog.run()
    dialog.destroy()

def show_info_dialog(parent, message):
    """Muestra un diálogo informativo"""
    from gi.repository import Gtk
    dialog = Gtk.MessageDialog(
        transient_for=parent,
        modal=True,
        message_type=Gtk.MessageType.INFO,
        buttons=Gtk.ButtonsType.OK,
        text="Información"
    )
    dialog.format_secondary_text(message)
    dialog.run()
    dialog.destroy()
