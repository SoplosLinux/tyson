import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

def create_button(text, icon_name, tooltip, callback):
    """Crea un botón estilizado con icono y texto"""
    button = Gtk.Button()
    button.set_size_request(-1, 50)
    button.set_tooltip_text(tooltip)
    
    hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
    hbox.set_halign(Gtk.Align.CENTER)
    
    icon = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.BUTTON)
    label = Gtk.Label(label=text)
    
    hbox.pack_start(icon, False, False, 0)
    hbox.pack_start(label, False, False, 0)
    
    button.add(hbox)
    button.connect("clicked", callback)
    
    return button

def create_header(title_text, description_text):
    """Crea un encabezado con título y descripción"""
    box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=5)
    box.set_margin_top(15)
    box.set_margin_bottom(15)
    box.set_margin_start(20)
    box.set_margin_end(20)
    
    title = Gtk.Label()
    title.set_markup(f"<span size='large' weight='bold'>{title_text}</span>")
    title.set_xalign(0.5)
    
    description = Gtk.Label(label=description_text)
    description.set_xalign(0.5)
    
    box.pack_start(title, False, False, 5)
    box.pack_start(description, False, False, 5)
    
    return box
