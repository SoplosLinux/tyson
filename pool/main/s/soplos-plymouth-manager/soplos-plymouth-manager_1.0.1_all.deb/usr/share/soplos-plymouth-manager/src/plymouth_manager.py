import os
import subprocess
import shutil
import time  # Añadir import de time
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
from .constants import PLYMOUTH_THEME_DIRS
from .logger import logger

class PlymouthManager:
    def __init__(self):
        self.commands = self.find_plymouth_commands()
        self.plymouth_bin = shutil.which('plymouth')
        self.plymouthd_bin = shutil.which('plymouthd')
        self.logger = logger
        # NO inicializar nada de Plymouth aquí

    def _run_privileged(self, script_path):
        """Ejecuta un script con privilegios solo cuando sea necesario"""
        try:
            result = subprocess.run(
                ["pkexec", "bash", script_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            return result
        except Exception as e:
            self.logger.error(f"Error al ejecutar script privilegiado: {e}")
            return None
    
    def find_plymouth_commands(self):
        """Busca las ubicaciones de los comandos de Plymouth"""
        commands = {
            'list_themes': None,
            'set_theme': None
        }
        
        # Posibles ubicaciones para los comandos
        possible_list_commands = [
            'plymouth-set-default-theme',
            '/usr/sbin/plymouth-set-default-theme',
            '/sbin/plymouth-set-default-theme'
        ]
        
        possible_set_commands = [
            'plymouth-set-default-theme',
            '/usr/sbin/plymouth-set-default-theme',
            '/sbin/plymouth-set-default-theme'
        ]
        
        # Alternativamente, buscar el comando plymouth
        plymouth_bin = shutil.which('plymouth')
        
        # Comprobar los comandos de listar temas
        for cmd in possible_list_commands:
            if shutil.which(cmd):
                commands['list_themes'] = cmd
                break
        
        # Si no encontramos el comando específico, pero tenemos plymouth
        if not commands['list_themes'] and plymouth_bin:
            commands['list_themes'] = f"{plymouth_bin} --list-themes"
        
        # Comprobar los comandos de cambiar tema
        for cmd in possible_set_commands:
            if shutil.which(cmd):
                commands['set_theme'] = cmd
                break
        
        return commands
    
    # Alias para mantener consistencia
    def list_themes(self):
        """Alias para get_themes()"""
        return self.get_themes()
    
    def get_themes(self):
        """Obtiene la lista de temas disponibles"""
        if not self.commands['list_themes']:
            return []
            
        try:
            # No necesitamos privilegios para listar temas
            if ' ' in self.commands['list_themes']:
                cmd_parts = self.commands['list_themes'].split()
                result = subprocess.run(
                    cmd_parts,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True
                )
            else:
                result = subprocess.run(
                    [self.commands['list_themes'], "--list"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True
                )
            
            output = result.stdout.strip()
            if not output:
                # Intenta directamente listar los directorios de temas
                themes = []
                for theme_dir in PLYMOUTH_THEME_DIRS:
                    if os.path.exists(theme_dir):
                        for item in os.listdir(theme_dir):
                            if os.path.isdir(os.path.join(theme_dir, item)):
                                themes.append(item)
                
                if not themes:
                    raise ValueError("No se encontraron temas")
            else:
                themes = []
                for line in output.split('\n'):
                    theme_name = line.split('(')[0].strip() if '(' in line else line.strip()
                    if theme_name:
                        themes.append(theme_name)
            
            return sorted(set(themes))
                    
        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"Error al ejecutar comandos de Plymouth: {e.stderr}")
        except Exception as e:
            self.logger.error(f"Error al obtener temas: {e}")
            return []
    
    def cleanup_plymouth(self):
        """Solo verifica si hay procesos de Plymouth y los termina sin privilegios"""
        try:
            # Intentar terminar los procesos sin privilegios primero
            subprocess.run(['plymouth', 'quit'], check=False)
            subprocess.run(['plymouthd', '--quit'], check=False)
            time.sleep(0.5)  # Pequeña pausa
            
            # Verificar si aún hay procesos
            processes = subprocess.run(
                ['pgrep', '-f', 'plymouth'],
                capture_output=True,
                text=True
            )
            
            if processes.stdout.strip():
                # Si aún hay procesos, intentar matarlos
                subprocess.run(['pkill', '-9', 'plymouth'], check=False)
                subprocess.run(['pkill', '-9', 'plymouthd'], check=False)
                time.sleep(0.5)  # Esperar a que terminen
                
        except Exception as e:
            self.logger.debug(f"Error en limpieza de Plymouth (no crítico): {e}")
            pass

    def force_kill_plymouth(self):
        """Mata forzadamente todos los procesos de Plymouth"""
        try:
            # Intentar terminación normal primero
            subprocess.run(['plymouth', 'quit'], check=False)
            subprocess.run(['plymouthd', '--quit'], check=False)
            time.sleep(0.5)  # Pequeña pausa
            
            # Forzar terminación de cualquier proceso restante
            subprocess.run(['pkill', '-9', 'plymouth'], check=False)
            subprocess.run(['pkill', '-9', 'plymouthd'], check=False)
            time.sleep(0.5)  # Esperar a que terminen
            
            # Verificar que no queden procesos
            check = subprocess.run(['pgrep', '-f', 'plymouth'], capture_output=True, text=True)
            if check.stdout.strip():
                # Si aún hay procesos, intentar una última vez con killall
                subprocess.run(['killall', '-9', 'plymouth', 'plymouthd'], check=False)
                time.sleep(0.5)  # Esperar una última vez
                
        except Exception as e:
            self.logger.debug(f"Error en terminación forzada de Plymouth (no crítico): {e}")
            pass

    def _detect_initramfs_tool(self):
        """Detecta qué herramienta de initramfs está disponible en el sistema"""
        tools = {
            'update-initramfs': '-u',  # Debian/Ubuntu
            'dracut': '-f',            # Fedora/RHEL
            'mkinitcpio': '-P',        # Arch Linux
            'genkernel': '--install',  # Gentoo
            'mkinitrd': '--force'      # SUSE
        }
        
        for tool, args in tools.items():
            if shutil.which(tool):
                return tool, args
                
        return None, None

    def _update_initramfs(self):
        """Actualiza el initramfs usando la herramienta apropiada del sistema"""
        tool, args = self._detect_initramfs_tool()
        
        if not tool:
            raise RuntimeError(
                "No se encontró ninguna herramienta compatible para actualizar initramfs.\n"
                "Herramientas soportadas:\n"
                "- update-initramfs (Debian/Ubuntu)\n"
                "- dracut (Fedora/RHEL)\n"
                "- mkinitcpio (Arch Linux)\n"
                "- genkernel (Gentoo)\n"
                "- mkinitrd (SUSE)"
            )
            
        try:
            subprocess.run([tool, args], check=True)
            return True
        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"Error al actualizar initramfs: {e}")

    def set_theme(self, theme_name, generate_preview=False):
        """Cambia el tema de Plymouth"""
        if not self.commands['set_theme']:
            return False, "No se encontró el comando para cambiar el tema"
        
        try:
            # Limpiar procesos de Plymouth primero
            self.cleanup_plymouth()
            
            # Crear script temporal para ejecutar todos los comandos en una sola elevación
            script_path = "/tmp/plymouth-theme-apply.sh"
            with open(script_path, "w") as f:
                f.write(f"""#!/bin/bash
# Asegurarse de que Plymouth está detenido
killall -9 plymouth plymouthd 2>/dev/null || true
sleep 1

# Aplicar tema
{self.commands['set_theme']} {theme_name}

# Detectar y usar la herramienta de initramfs apropiada
if command -v update-initramfs >/dev/null 2>&1; then
    update-initramfs -u
elif command -v dracut >/dev/null 2>&1; then
    dracut -f
elif command -v mkinitcpio >/dev/null 2>&1; then
    mkinitcpio -P
elif command -v genkernel >/dev/null 2>&1; then
    genkernel --install initramfs
elif command -v mkinitrd >/dev/null 2>&1; then
    mkinitrd --force
else
    echo "No se encontró ninguna herramienta compatible para actualizar initramfs"
    exit 1
fi

# Asegurarse de que Plymouth está detenido al finalizar
killall -9 plymouth plymouthd 2>/dev/null || true
""")
            os.chmod(script_path, 0o755)

            # Ejecutar todo como root en una sola operación
            process = self._run_privileged(script_path)
            
            # Limpiar script temporal
            if os.path.exists(script_path):
                os.remove(script_path)
            
            if process.returncode != 0:
                error_msg = process.stderr or process.stdout or "Error desconocido"
                return False, error_msg
            
            return True, "Tema aplicado correctamente"
            
        except Exception as e:
            return False, str(e)

    def check_commands(self):
        """Verifica si los comandos de Plymouth están disponibles"""
        return bool(self.commands['list_themes'] and self.commands['set_theme'])
    
    def get_current_theme(self):
        """Obtiene el tema actual"""
        if not self.commands['list_themes']:
            return None
            
        try:
            # Primero intentar con --get-default-theme
            if shutil.which('plymouth-set-default-theme'):
                result = subprocess.run(
                    ['plymouth-set-default-theme'],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True
                )
                if result.returncode == 0:
                    return result.stdout.strip()
            
            # Si no funciona, intentar con --list y buscar el tema marcado como default
            if ' ' in self.commands['list_themes']:
                parts = self.commands['list_themes'].split()
                result = subprocess.run(
                    parts,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True
                )
            else:
                result = subprocess.run(
                    [self.commands['list_themes'], "--list"],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True
                )
            
            output = result.stdout.strip()
            for line in output.split('\n'):
                if '[default]' in line or '(default)' in line:
                    return line.split('[')[0].split('(')[0].strip()
            
            # Si aún no lo encontramos, buscar en la configuración del sistema
            if os.path.exists('/etc/plymouth/plymouthd.conf'):
                with open('/etc/plymouth/plymouthd.conf', 'r') as f:
                    for line in f:
                        if line.startswith('Theme='):
                            return line.split('=')[1].strip()
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error al obtener tema actual: {e}")
            return None
    
    def get_theme_preview_path(self, theme_name):
        """Obtiene la ruta de la vista previa de un tema"""
        theme_dir = f"/usr/share/plymouth/themes/{theme_name}"
        if not os.path.isdir(theme_dir):
            self.logger.error(f"El directorio del tema no existe: {theme_dir}")
            return None
            
        return os.path.join(theme_dir, "preview.png")

    def generate_theme_preview(self, theme_name):
        """Genera una vista previa para el tema especificado"""
        try:
            self.logger.info(f"Generando vista previa para {theme_name}")
            
            # Asegurarnos que Plymouth no está en ejecución
            self.force_kill_plymouth()
            
            # Ruta del archivo de vista previa
            preview_path = os.path.join("/usr/share/plymouth/themes", theme_name, "preview.png")
            
            # Eliminar cualquier archivo preview_*.png que pueda existir
            theme_dir = os.path.dirname(preview_path)
            for file in os.listdir(theme_dir):
                if file.startswith("preview_") and file.endswith(".png"):
                    try:
                        os.remove(os.path.join(theme_dir, file))
                    except:
                        pass
            
            # Obtener variables de entorno necesarias
            display = os.environ.get('DISPLAY', ':0')
            xauthority = os.environ.get('XAUTHORITY', os.path.expanduser('~/.Xauthority'))
            
            # Crear script temporal para ejecutar todos los comandos en una sola elevación
            script_path = "/tmp/plymouth-preview.sh"
            with open(script_path, "w") as f:
                f.write(f"""#!/bin/bash
set -e

# Preservar variables de entorno X11
export DISPLAY="{display}"
export XAUTHORITY="{xauthority}"

# Aplicar tema primero
{self.commands['set_theme']} {theme_name}

# Ejecutar capturador asegurando permisos
python3 {os.path.join(os.path.dirname(os.path.dirname(__file__)), 'capturador.py')} --output "{preview_path}"

# Ajustar permisos
chown root:root "{preview_path}"
chmod 644 "{preview_path}"
""")
            os.chmod(script_path, 0o755)

            # Ejecutar script con privilegios preservando variables de entorno
            result = subprocess.run(
                ["pkexec", "env", f"DISPLAY={display}", f"XAUTHORITY={xauthority}", 
                 "bash", script_path],
                capture_output=True,
                text=True
            )
            
            # Limpiar script temporal
            os.remove(script_path)

            # Verificar que la captura fue exitosa y el archivo existe con tamaño > 0
            if result.returncode == 0 and os.path.exists(preview_path):
                if os.path.getsize(preview_path) > 0:
                    self.refresh_themes()  # Añadimos esta línea
                    return preview_path
            
            return None
                
        except Exception as e:
            self.logger.error(f"Error generando vista previa: {e}")
            return None

    def on_preview_complete(self, success):
        """Manejador de captura completa"""
        if success:
            # Refrescar lista de temas
            self.refresh_themes()
        return False

    def refresh_themes(self):
        """Refresca la lista de temas y sus vistas previas"""
        try:
            themes = self.get_themes()
            if themes:
                self.logger.debug("Lista de temas actualizada")
                return themes
            return []
        except Exception as e:
            self.logger.error(f"Error actualizando temas: {e}")
            return []

    def install_theme(self, theme_path):
        """Instala un nuevo tema desde un archivo comprimido"""
        try:
            # Forzar terminación de Plymouth antes de instalar
            self.force_kill_plymouth()
            time.sleep(1)  # Esperar a que los procesos terminen

            script = f'''#!/bin/bash
set -e

# Asegurar que Plymouth no está corriendo
plymouth quit >/dev/null 2>&1 || true
plymouthd --quit >/dev/null 2>&1 || true
pkill -9 plymouth >/dev/null 2>&1 || true
pkill -9 plymouthd >/dev/null 2>&1 || true
sleep 1

THEME_DIR="/usr/share/plymouth/themes"
TEMP_DIR=$(mktemp -d)

echo "Descomprimiendo tema en $TEMP_DIR..."

# Descomprimir el tema según su extensión
if [[ "{theme_path}" == *.tar.gz ]] || [[ "{theme_path}" == *.tgz ]]; then
    tar xzf "{theme_path}" -C "$TEMP_DIR"
elif [[ "{theme_path}" == *.zip ]]; then
    unzip -q "{theme_path}" -d "$TEMP_DIR"
else
    echo "Formato de archivo no soportado"
    rm -rf "$TEMP_DIR"
    exit 1
fi

# Buscar el directorio que contiene el archivo .plymouth
for file in $(find "$TEMP_DIR" -name "*.plymouth"); do
    PLYMOUTH_DIR=$(dirname "$file")
    break
done

if [ -z "$PLYMOUTH_DIR" ]; then
    echo "No se encontró archivo .plymouth en el tema"
    rm -rf "$TEMP_DIR"
    exit 1
fi

# Obtener el nombre del tema
THEME_NAME=$(basename "$PLYMOUTH_DIR")
echo "Instalando tema: $THEME_NAME"

# Verificar si el tema ya existe y hacer backup
if [ -d "$THEME_DIR/$THEME_NAME" ]; then
    echo "Haciendo backup del tema existente..."
    rm -rf "$THEME_DIR/$THEME_NAME.bak" 2>/dev/null || true
    mv "$THEME_DIR/$THEME_NAME" "$THEME_DIR/$THEME_NAME.bak"
fi

# Mover los archivos al directorio de temas
echo "Moviendo archivos del tema..."
cp -r "$PLYMOUTH_DIR" "$THEME_DIR/"

# Establecer permisos correctos
echo "Configurando permisos..."
chmod -R 755 "$THEME_DIR/$THEME_NAME"
chown -R root:root "$THEME_DIR/$THEME_NAME"

# Limpiar
rm -rf "$TEMP_DIR"

echo "Tema $THEME_NAME instalado correctamente"
exit 0'''

            script_path = "/tmp/install_plymouth_theme.sh"
            with open(script_path, "w") as f:
                f.write(script)
            os.chmod(script_path, 0o755)

            # Ejecutar script con privilegios
            result = self._run_privileged(script_path)

            # Limpiar script temporal
            try:
                os.remove(script_path)
            except:
                pass

            if result and result.returncode == 0:
                # Asegurar que Plymouth está detenido después de la instalación
                self.force_kill_plymouth()
                time.sleep(1)
                return True, "Tema instalado correctamente"
            else:
                error_msg = result.stderr if result else "Error desconocido"
                return False, f"Error al instalar tema: {error_msg}"

        except Exception as e:
            self.logger.error(f"Error al instalar tema: {e}")
            return False, str(e)

    def remove_theme(self, theme_name):
        """Elimina un tema instalado"""
        try:
            script = f"""#!/bin/bash
THEME_DIR="/usr/share/plymouth/themes/{theme_name}"

# Verificar que no sea el tema actual
CURRENT_THEME=$(plymouth-set-default-theme)
if [ "$CURRENT_THEME" = "{theme_name}" ]
then
    echo "No se puede eliminar el tema actualmente en uso"
    exit 1
fi

# Eliminar el directorio del tema
if [ -d "$THEME_DIR" ]
then
    rm -rf "$THEME_DIR"
    echo "Tema {theme_name} eliminado correctamente"
    exit 0
else
    echo "Tema no encontrado"
    exit 1
fi
"""
            script_path = "/tmp/remove_theme.sh"
            with open(script_path, "w") as f:
                f.write(script)
            os.chmod(script_path, 0o755)

            result = self._run_privileged(script_path)

            os.remove(script_path)
            return result.returncode == 0, result.stdout or result.stderr

        except Exception as e:
            return False, str(e)