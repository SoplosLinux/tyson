"""
Package principal de la aplicación Plymouth Theme Manager
"""
