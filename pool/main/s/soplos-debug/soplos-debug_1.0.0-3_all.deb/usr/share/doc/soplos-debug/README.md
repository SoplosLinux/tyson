# Soplos Debug

[![License: GPL-3.0+](https://img.shields.io/badge/License-GPL--3.0%2B-blue.svg)](https://www.gnu.org/licenses/gpl-3.0)
[![Version](https://img.shields.io/badge/version-1.0.0--3-green.svg)]()

Full hardware and system diagnostic report for Soplos Linux. Runs locally and sends nothing anywhere.

*Informe completo de diagnóstico de hardware y sistema para Soplos Linux. Se ejecuta en local y no envía nada a ningún sitio.*

## Description

`soplos-debug` collects a complete picture of the machine and its faults into a single text file the user can attach to a support request. It is meant for the case where nobody knows yet what is broken: instead of answering one question, it reports what the hardware is, what the kernel bound to it, and what failed.

The report opens with a list of the anomalies found, so it can be triaged at a glance without reading the rest.

## Usage

From the menu, as **Informe del sistema Soplos**, or from a terminal:

```
soplos-debug
```

The script elevates itself through `pkexec` when needed, because several sections require privileges. The report is written to the home directory of the real user, not root's:

```
~/soplos-debug.txt
```

### Options

| Option | Effect |
|---|---|
| `--no-redact` | Do not mask personal data. For reports you generate on your own machine. |
| `--no-pause` | Do not wait for a keypress when finished. |

## What it collects

| Section | Contents |
|---|---|
| System | os-release, kernel, installed kernels, cmdline, system time against the RTC |
| Machine and firmware | DMI, motherboard, BIOS and its date, UEFI or legacy, Secure Boot |
| CPU | Model, microcode, frequency scaling, known vulnerabilities |
| Memory | Modules, speed, swap and zram, memory errors |
| Storage | Block devices, usage, fstab, SMART health, BTRFS subvolumes and stats |
| PCI and USB | Full device tree, and every PCI device with no driver bound |
| Firmware | Firmware load failures and installed firmware packages |
| Kernel errors | Taint, hardware and ACPI errors, device resets, call traces |
| Graphics | GPU, DRM nodes, Mesa and Vulkan, renderer, nouveau parameters, Xorg log |
| Network | Interfaces and drivers, rfkill, NetworkManager, DNS and connectivity |
| Audio | Audio hardware, ALSA cards, sound server |
| Power and thermal | Battery wear, sensors, thermal zones, sleep states |
| Boot and packages | GRUB, dracut, DKMS and failed build logs, failed services, apt sources |
| Installation | Calamares log, in a live session only |

Every block reports one of three states, which are never confused with each other: collected content, `(none)` when there was nothing to report, and `(not applicable: reason)` when the section does not apply to this machine.

## Privacy

These reports get pasted into public chats, so personal data is masked before the file is written:

- MAC addresses
- Wi-Fi network names and stored passwords
- Serial numbers of machine, motherboard, BIOS and disks
- Chassis UUID
- Home directory path of the user

Masking is stable, not blind: the same MAC always becomes the same marker (`<MAC-01>`, `<MAC-02>`), so a device appearing in several sections is still recognisable as one device.

Everything with diagnostic value is left untouched: hardware models, drivers in use, missing firmware, package and kernel versions, partition UUIDs, fstab, GRUB and kernel logs.

Nothing is uploaded or transmitted. The file stays on the machine until the user decides to share it.

## Requirements

The report degrades gracefully: any tool that is not installed is reported as such rather than failing, and the rest of the sections are still collected.

For a complete report: `pciutils`, `usbutils`, `dmidecode`, `smartmontools`, `efibootmgr`, `mokutil`, `lm-sensors`, `vulkan-tools`, `mesa-utils-extra`, `btrfs-progs`, `network-manager`.

## License

GPL-3.0+. See [LICENSE](LICENSE).
