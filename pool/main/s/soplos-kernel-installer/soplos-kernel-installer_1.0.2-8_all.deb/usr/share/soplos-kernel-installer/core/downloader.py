"""
Downloader module for fetching kernel sources and patches.

Kernel sources: cdn.kernel.org / git.kernel.org
Patches:
  - BORE:       github.com/firelzrd/bore-scheduler
  - PREEMPT_RT: www.kernel.org/pub/linux/kernel/projects/rt
  - Zen:        github.com/zen-kernel/zen-kernel (releases)
  - NTSYNC:     config option only (mainlined in 6.14+), no patch file
"""

import json
import os
import re
import sys
import urllib.request
import urllib.error
from typing import List, Optional, Callable, Dict
from .common_types import KernelVersion, PatchInfo
from utils.system import ensure_directory, run_command_with_callback

KERNEL_CDN_URL = "https://cdn.kernel.org/pub/linux/kernel"
KERNEL_ORG_URL = "https://www.kernel.org/"

BORE_GITHUB_TREE = "https://github.com/firelzrd/bore-scheduler/tree/main/patches/{tree}/linux-{major_minor}-bore"
BORE_RAW_BASE = "https://raw.githubusercontent.com/firelzrd/bore-scheduler/main/patches/{tree}/linux-{major_minor}-bore/{filename}"
CACHY_RAW_BASE = "https://raw.githubusercontent.com/CachyOS/kernel-patches/master/{major_minor}/{subdir}/{filename}"
RT_BASE_URL = "https://www.kernel.org/pub/linux/kernel/projects/rt/{major_minor}/"
ZEN_RELEASES_WEB = "https://github.com/zen-kernel/zen-kernel/releases"
X3D_PATCH_URL = "https://raw.githubusercontent.com/SoplosLinux/x3d-soplos/main/patches/0001-sched-amd-x3d-vcache-{tag}.patch"
MARCH_PATCH_URL = "https://raw.githubusercontent.com/SoplosLinux/soplos-cpu-kernel-patch/main/patches/0001-x86-64-isa-level-{tag}.patch"
BORE_SOPLOS_URL = "https://raw.githubusercontent.com/SoplosLinux/bore-soplos/main/patches/0001-bore-{major_minor}.patch"
ZEN_SOPLOS_URL = "https://raw.githubusercontent.com/SoplosLinux/zen-soplos/main/patches/0001-zen-{major_minor}.patch"
RT_I915_SOPLOS_URL = "https://raw.githubusercontent.com/SoplosLinux/rt-i915-soplos/main/patches/0001-rt-i915-{major_minor}.patch"

DEBIAN_PACKAGES_INDEX = "https://deb.debian.org/debian/dists/sid/main/binary-amd64/Packages.xz"
DEBIAN_POOL_ROOT = "https://deb.debian.org/debian/"


class KernelDownloader:
    """Handles fetching available versions and downloading kernel sources + patches."""

    def __init__(self, build_dir: str,
                 progress_callback: Optional[Callable[[str, int], None]] = None):
        self._build_dir = build_dir
        self._progress_callback = progress_callback
        self._cancel_check: Optional[Callable[[], bool]] = None

    def set_cancel_check(self, check_func: Callable[[], bool]) -> None:
        self._cancel_check = check_func

    def _is_cancelled(self) -> bool:
        return self._cancel_check() if self._cancel_check else False

    def _report_progress(self, message: str, percent: int = -1) -> None:
        if self._progress_callback:
            self._progress_callback(message, percent)

    # ------------------------------------------------------------------
    # Version listing
    # ------------------------------------------------------------------

    def fetch_available_versions(self) -> List[KernelVersion]:
        """Fetch available kernel versions from kernel.org."""
        versions = []
        try:
            req = urllib.request.Request(
                KERNEL_ORG_URL,
                headers={'User-Agent': 'Mozilla/5.0 SoplosKernelInstaller/1.0'}
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                html = resp.read().decode('utf-8')

            row_pattern = re.compile(
                r'(<tr[^>]*>.*?</tr>)',
                re.IGNORECASE | re.DOTALL
            )
            cell_pattern = re.compile(
                r'<td[^>]*>\s*(\w+):?</td>\s*<td[^>]*>\s*<strong>\s*'
                r'([0-9]+\.[0-9]+(?:\.[0-9]+)?(?:-rc\d+)?)',
                re.IGNORECASE | re.DOTALL
            )

            seen = set()
            first_stable = True

            for row_match in row_pattern.finditer(html):
                row_html = row_match.group(1)
                cell_match = cell_pattern.search(row_html)
                if not cell_match:
                    continue

                kernel_type = cell_match.group(1).lower()
                version = cell_match.group(2)
                if version in seen:
                    continue
                seen.add(version)

                is_eol = 'eolkernel' in row_html
                major = version.split('.')[0]

                if '-rc' in version:
                    url = f"https://git.kernel.org/torvalds/t/linux-{version}.tar.gz"
                    versions.append(KernelVersion(
                        version=version, url=url,
                        channel="rc", is_rc=True
                    ))
                elif kernel_type == 'stable':
                    url = f"{KERNEL_CDN_URL}/v{major}.x/linux-{version}.tar.xz"
                    is_latest = first_stable and not is_eol
                    if not is_eol:
                        first_stable = False
                    versions.append(KernelVersion(
                        version=version, url=url,
                        channel="stable", is_latest=is_latest, is_eol=is_eol
                    ))
                elif kernel_type == 'mainline':
                    url = f"{KERNEL_CDN_URL}/v{major}.x/linux-{version}.tar.xz"
                    versions.append(KernelVersion(
                        version=version, url=url,
                        channel="mainline", is_mainline=True
                    ))
                elif kernel_type == 'longterm':
                    url = f"{KERNEL_CDN_URL}/v{major}.x/linux-{version}.tar.xz"
                    versions.append(KernelVersion(
                        version=version, url=url,
                        channel="lts", is_longterm=True
                    ))

            def _ver_key(v):
                m = re.match(r'(\d+)\.(\d+)(?:\.(\d+))?(?:-rc(\d+))?', v.version)
                if m:
                    major = int(m.group(1) or 0)
                    minor = int(m.group(2) or 0)
                    patch = int(m.group(3) or 0)
                    rc    = int(m.group(4)) if m.group(4) else 999
                    return (-major, -minor, -patch, -rc)
                return (0, 0, 0, 0)

            versions.sort(key=_ver_key)

        except Exception as e:
            print(f"Error fetching kernel versions: {e}", file=sys.stderr)

        return versions

    # ------------------------------------------------------------------
    # Kernel source download
    # ------------------------------------------------------------------

    def reextract(self, version: str) -> bool:
        """Re-extract kernel sources from cached tarball without re-downloading."""
        import shutil
        source_dir = os.path.join(self._build_dir, f"linux-{version}")

        for ext in ("tar.gz", "tar.xz"):
            tarball = os.path.join(self._build_dir, f"linux-{version}.{ext}")
            if os.path.exists(tarball):
                self._report_progress("Re-extracting sources from cached tarball...", 5)
                patches_dir = os.path.join(self._build_dir, "patches")
                for path in (source_dir, patches_dir):
                    try:
                        shutil.rmtree(path)
                    except Exception:
                        pass

                def tar_callback(line: str) -> None:
                    if line.strip():
                        self._report_progress(line.strip()[:80], -1)

                exit_code = run_command_with_callback(
                    f'tar -xvf "{tarball}"',
                    cwd=self._build_dir,
                    line_callback=tar_callback,
                    stop_check=self._is_cancelled
                )
                if exit_code == 0 and os.path.exists(os.path.join(source_dir, "Makefile")):
                    self._report_progress("Re-extraction complete.", 15)
                    return True
                self._report_progress("Error re-extracting sources.", -1)
                return False

        self._report_progress("Error: Cached tarball not found. Download the kernel first.", -1)
        return False

    def download(self, version: str, skip_download: bool = False) -> bool:
        """Download and extract kernel sources."""
        if skip_download:
            source_dir = os.path.join(self._build_dir, f"linux-{version}")
            if os.path.isdir(source_dir):
                self._report_progress("Using existing sources...", 100)
                return True
            self._report_progress("Error: Source directory not found.", -1)
            return False

        self._report_progress(f"Preparing download for Linux {version}...", 0)

        if not ensure_directory(self._build_dir):
            self._report_progress("Error: Could not create build directory", -1)
            return False

        major = version.split('.')[0]

        if '-rc' in version:
            url = f"https://git.kernel.org/torvalds/t/linux-{version}.tar.gz"
            extension = "tar.gz"
        else:
            url = f"{KERNEL_CDN_URL}/v{major}.x/linux-{version}.tar.xz"
            extension = "tar.xz"

        tarball = os.path.join(self._build_dir, f"linux-{version}.{extension}")
        source_dir = os.path.join(self._build_dir, f"linux-{version}")
        patches_dir = os.path.join(self._build_dir, "patches")

        # Clean tarball, source dir, and patches when starting fresh
        import shutil
        for path in [tarball, source_dir, patches_dir]:
            try:
                if os.path.isfile(path):
                    os.remove(path)
                elif os.path.isdir(path):
                    shutil.rmtree(path)
            except Exception:
                pass

        self._report_progress(f"Downloading linux-{version}.{extension}...", 7)

        def wget_callback(line: str) -> None:
            match = re.search(r'(\d+)%', line)
            if match:
                percent = 7 + int(int(match.group(1)) * 0.08)
                self._report_progress(line.strip(), percent)

        exit_code = run_command_with_callback(
            f'wget --progress=dot -O "{tarball}" "{url}" 2>&1',
            cwd=self._build_dir,
            line_callback=wget_callback,
            stop_check=self._is_cancelled
        )

        if self._is_cancelled() or exit_code != 0:
            return False

        self._report_progress("Download complete. Extracting...", 15)

        def tar_callback(line: str) -> None:
            if line.strip():
                self._report_progress(line.strip()[:80], -1)

        exit_code = run_command_with_callback(
            f'tar -xvf "{tarball}"',
            cwd=self._build_dir,
            line_callback=tar_callback,
            stop_check=self._is_cancelled
        )

        if self._is_cancelled() or exit_code != 0:
            return False

        if not os.path.exists(os.path.join(source_dir, "Makefile")):
            self._report_progress("Error: Extraction failed", -1)
            return False

        self._report_progress("Extraction complete.", 25)
        return True

    # ------------------------------------------------------------------
    # Patch download
    # ------------------------------------------------------------------

    def download_patches(self, version: str, patch_ids: List[str],
                         patches_dir: str) -> Dict[str, str]:
        """
        Download requested patches for the given kernel version.
        NTSYNC is skipped here (config-only, handled by installer).

        Returns a dict: {patch_id: [local_paths]} for successfully downloaded patches.
        """
        ensure_directory(patches_dir)
        downloaded: Dict[str, str] = {}

        m = re.match(r'(\d+\.\d+)', version)
        major_minor = m.group(1) if m else version

        for patch_id in patch_ids:
            if self._is_cancelled():
                break

            if patch_id == "ntsync":
                # Config-only, no file to download.
                # Warn if the kernel doesn't support it.
                m_v = re.match(r'(\d+)\.(\d+)', version)
                if m_v and (int(m_v.group(1)), int(m_v.group(2))) < (6, 14):
                    self._report_progress(
                        f"⚠ NTSYNC requires kernel 6.14+ — kernel {version} does not support it. "
                        f"Skipping.", -1
                    )
                continue
            elif patch_id == "rt" and self._rt_is_builtin(version):
                # PREEMPT_RT is mainlined since 6.12 — no RT patch file needed.
                # Mainline still marks i915 as depends on !PREEMPT_RT, so an RT
                # kernel silently loses the Intel driver. Soplos' own fix is
                # always applied, whatever GPU the build machine has.
                self._report_progress(
                    f"PREEMPT_RT is built into kernel {version} — no RT patch needed.", -1
                )
                rt_i915 = self._download_rt_i915_soplos(version, major_minor, patches_dir)
                if rt_i915:
                    downloaded["rt"] = rt_i915
                continue
            elif patch_id == "bore":
                paths = self._download_bore(version, major_minor, patches_dir)
            elif patch_id == "rt":
                paths = self._download_rt(version, major_minor, patches_dir)
            elif patch_id == "zen":
                paths = self._download_zen(version, major_minor, patches_dir)
            elif patch_id == "x3d":
                paths = self._download_x3d(version, major_minor, patches_dir)
            elif patch_id == "march":
                paths = self._download_march(version, major_minor, patches_dir)
            else:
                print(f"Unknown patch id: {patch_id}", file=sys.stderr)
                continue

            if paths:
                downloaded[patch_id] = paths
                self._report_progress(f"Patch {patch_id} ready.", -1)
            else:
                self._report_progress(
                    f"⚠ Patch '{patch_id}' not available for kernel {version} — compiling without it.",
                    -1
                )
                print(f"Warning: Could not download patch '{patch_id}'", file=sys.stderr)

        return downloaded

    @staticmethod
    def _rt_is_builtin(version: str) -> bool:
        """PREEMPT_RT is mainlined since 6.12."""
        m = re.match(r'(\d+)\.(\d+)', version)
        if m:
            major, minor = int(m.group(1)), int(m.group(2))
            return (major, minor) >= (6, 12)
        return False

    def _download_file(self, url: str, dest: str) -> bool:
        """Download a single file with wget."""
        exit_code = run_command_with_callback(
            f'wget -q -O "{dest}" "{url}" 2>&1',
            stop_check=self._is_cancelled
        )
        return exit_code == 0 and os.path.exists(dest) and os.path.getsize(dest) > 0

    def _github_api_get(self, url: str) -> Optional[list]:
        """Fetch JSON from GitHub API. Returns parsed JSON or None."""
        try:
            req = urllib.request.Request(
                url,
                headers={
                    'User-Agent': 'SoplosKernelInstaller/1.0',
                    'Accept': 'application/vnd.github+json',
                }
            )
            with urllib.request.urlopen(req, timeout=15) as resp:
                return json.loads(resp.read().decode('utf-8'))
        except Exception as e:
            print(f"GitHub API error ({url}): {e}", file=sys.stderr)
            return None

    def _patches_apply(self, version: str, patch_paths: List[str]) -> bool:
        """
        Verify a set of downloaded patch files actually apply (dry-run) against
        the extracted source tree for `version`. A patch that merely downloaded
        successfully is not the same as one that will apply — a stale upstream
        patch (built against an older point release) downloads fine and then
        fails at real apply time, which is too late to fall back to another
        source. This lets source-selection loops check before committing.
        """
        source_dir = os.path.join(self._build_dir, f"linux-{version}")
        if not os.path.isdir(source_dir):
            # Source tree not extracted yet (e.g. called before download()) —
            # can't verify, assume it applies and let the real apply step catch it.
            return True

        from utils.system import run_command
        for patch_path in patch_paths:
            result = run_command(
                f'patch -p1 --batch --forward --dry-run -i "{patch_path}"',
                cwd=source_dir
            )
            if result.returncode != 0:
                return False
        return True

    def _download_bore(self, version: str, major_minor: str,
                       patches_dir: str) -> Optional[List[str]]:
        """
        Download BORE scheduler patches.
        Tries: firelzrd/bore-scheduler (stable → legacy) → CachyOS/kernel-patches
        → SoplosLinux/bore-soplos. Each candidate is verified with a dry-run
        apply before being accepted — a source that downloads fine but doesn't
        actually apply to this point release falls through to the next one.
        """
        self._report_progress(f"Downloading BORE patch for {version}...", -1)

        # --- Source 1: firelzrd/bore-scheduler (stable, then legacy) ---
        for tree in ("stable", "legacy"):
            web_url = BORE_GITHUB_TREE.format(tree=tree, major_minor=major_minor)
            try:
                req = urllib.request.Request(web_url, headers={'User-Agent': 'SoplosInstaller/1.0'})
                with urllib.request.urlopen(req, timeout=15) as resp:
                    html = resp.read().decode('utf-8')
            except Exception:
                continue

            filenames = set(re.findall(r'title="([^"]+\.patch)"', html))
            filenames.update(re.findall(r'href="[^"]+linux-[^"]+-bore/([^"]+\.patch)"', html))

            if not filenames:
                continue

            local_paths = []
            for filename in sorted(filenames):
                raw_url = BORE_RAW_BASE.format(tree=tree, major_minor=major_minor, filename=filename)
                dest = os.path.join(patches_dir, f"bore-{filename}")
                if self._download_file(raw_url, dest):
                    local_paths.append(dest)
                else:
                    self._report_progress(f"Error downloading BORE file: {filename}", -1)
                    local_paths = []
                    break

            if local_paths:
                if self._patches_apply(version, local_paths):
                    return local_paths
                self._report_progress(
                    f"BORE patch from firelzrd ({tree}) downloaded but doesn't apply "
                    f"to {version} — trying next source...", -1
                )

        # --- Source 2: CachyOS/kernel-patches fallback ---
        self._report_progress(
            f"BORE not found in firelzrd repo — trying CachyOS fallback for {major_minor}...", -1
        )
        cachy_paths = self._download_bore_cachy(major_minor, patches_dir)
        if cachy_paths:
            if self._patches_apply(version, cachy_paths):
                return cachy_paths
            self._report_progress(
                f"CachyOS BORE patch downloaded but doesn't apply to {version} — "
                f"trying next source...", -1
            )

        # --- Source 3: SoplosLinux/bore-soplos rebase fallback ---
        self._report_progress(
            f"BORE not found upstream — trying SoplosLinux/bore-soplos fallback for {major_minor}...", -1
        )
        soplos_paths = self._download_bore_soplos(major_minor, patches_dir)
        if soplos_paths:
            if self._patches_apply(version, soplos_paths):
                return soplos_paths
            self._report_progress(
                f"⚠ SoplosLinux/bore-soplos patch doesn't apply to {version} either — "
                f"no working BORE source found.", -1
            )

        print(f"No BORE patch available for {major_minor}", file=sys.stderr)
        return None

    def _download_bore_soplos(self, major_minor: str, patches_dir: str) -> Optional[List[str]]:
        """
        Download BORE from SoplosLinux/bore-soplos — a Soplos-maintained rebase
        used only when upstream (firelzrd, CachyOS) hasn't published a patch
        for this kernel line yet. Not build/boot verified upstream: see
        github.com/SoplosLinux/bore-soplos README before trusting a build made
        from this source.
        """
        raw_url = BORE_SOPLOS_URL.format(major_minor=major_minor)
        dest = os.path.join(patches_dir, f"bore-soplos-{major_minor}.patch")
        if self._download_file(raw_url, dest):
            self._report_progress(f"SoplosLinux/bore-soplos patch downloaded for {major_minor}.", -1)
            return [dest]

        print(f"SoplosLinux/bore-soplos: no patch for {major_minor}", file=sys.stderr)
        return None

    def _download_bore_cachy(self, major_minor: str, patches_dir: str) -> Optional[List[str]]:
        """
        Download BORE patch from CachyOS/kernel-patches.
        Structure: {major_minor}/sched/0001-bore.patch
        """
        filename = "0001-bore.patch"
        raw_url = CACHY_RAW_BASE.format(
            major_minor=major_minor, subdir="sched", filename=filename
        )
        dest = os.path.join(patches_dir, f"bore-cachy-{major_minor}.patch")
        if self._download_file(raw_url, dest):
            self._report_progress(f"CachyOS BORE patch downloaded for {major_minor}.", -1)
            return [dest]

        print(f"CachyOS: no bore patch for {major_minor}", file=sys.stderr)
        return None

    def _download_rt_i915_soplos(self, version: str, major_minor: str,
                                 patches_dir: str) -> Optional[List[str]]:
        """
        Download the rt-i915 patch from SoplosLinux/rt-i915-soplos, which lets
        i915 build on PREEMPT_RT. Without it the RT kernel loses the driver at
        olddefconfig and an Intel iGPU boots to a black screen. The patch is
        verified with a dry-run apply before being accepted. If it cannot be
        obtained, the RT build stops at the DRM_I915 check in configure().
        """
        raw_url = RT_I915_SOPLOS_URL.format(major_minor=major_minor)
        dest = os.path.join(patches_dir, f"rt-i915-soplos-{major_minor}.patch")
        if not self._download_file(raw_url, dest):
            self._report_progress(
                f"Warning: no rt-i915-soplos patch for {major_minor} — the RT "
                f"build will stop at the Intel graphics driver check.", -1
            )
            print(f"SoplosLinux/rt-i915-soplos: no patch for {major_minor}", file=sys.stderr)
            return None

        if not self._patches_apply(version, [dest]):
            self._report_progress(
                f"Warning: rt-i915-soplos patch does not apply to {version} — the "
                f"RT build will stop at the Intel graphics driver check.", -1
            )
            return None

        self._report_progress(f"rt-i915-soplos patch ready for {version}.", -1)
        return [dest]

    def _download_rt(self, version: str, major_minor: str,
                     patches_dir: str) -> Optional[List[str]]:
        """
        Download PREEMPT_RT patch from kernel.org/rt.
        Returns list with one local path or None if not available.
        """
        self._report_progress(f"Downloading PREEMPT_RT patch for {version}...", -1)

        rt_index_url = RT_BASE_URL.format(major_minor=major_minor)

        try:
            req = urllib.request.Request(
                rt_index_url,
                headers={'User-Agent': 'SoplosKernelInstaller/1.0'}
            )
            with urllib.request.urlopen(req, timeout=15) as resp:
                index_html = resp.read().decode('utf-8')
        except Exception as e:
            print(f"RT index fetch error for {major_minor}: {e}", file=sys.stderr)
            return None

        # RT patches use major.minor only (e.g. patch-6.9-rt5, patch-7.0-rc1-rt1)
        pattern = re.compile(
            rf'patch-{re.escape(major_minor)}[^"]*-rt(\d+)\.patch\.xz'
        )
        matches = pattern.findall(index_html)
        if not matches:
            print(f"No RT patch found for {major_minor}", file=sys.stderr)
            return None

        latest_rt = max(matches, key=int)
        # Find the full filename from the index
        full_pattern = re.compile(
            rf'(patch-{re.escape(major_minor)}[^"]*-rt{re.escape(latest_rt)}\.patch\.xz)'
        )
        full_match = full_pattern.search(index_html)
        if not full_match:
            return None
        patch_filename = full_match.group(1)
        xz_dest = os.path.join(patches_dir, patch_filename)
        dest = os.path.join(patches_dir, f"rt-{version}.patch")

        if not self._download_file(rt_index_url + patch_filename, xz_dest):
            return None

        from utils.system import run_command
        result = run_command(f'xz -d "{xz_dest}"')
        uncompressed = xz_dest.replace('.xz', '')
        if result.returncode == 0 and os.path.exists(uncompressed):
            import shutil
            shutil.move(uncompressed, dest)
            return [dest]

        return None

    def get_base_config(self, cache_path: str) -> Optional[str]:
        """
        Fetch a broad, curated .config to use as the build's starting point:
        Debian sid's current amd64 kernel config. Re-fetched on every build so
        it never goes stale the way a config inherited from a previous local
        build does — new hardware Kconfig symbols keep getting picked up
        automatically instead of defaulting to "n" forever.

        Falls back to the last successfully cached copy if the network fetch
        fails — never falls back to this machine's own installed kernel config.
        """
        self._report_progress("Fetching Debian base kernel config...", -1)
        fresh = self._fetch_debian_config()
        if fresh:
            try:
                import shutil
                ensure_directory(os.path.dirname(cache_path))
                shutil.copy(fresh, cache_path)
            except Exception:
                pass
            return fresh

        if os.path.exists(cache_path):
            self._report_progress(
                "Could not reach Debian — using last cached base config.", -1
            )
            return cache_path

        print("No base config available (download failed, no cache)", file=sys.stderr)
        return None

    def _fetch_debian_config(self) -> Optional[str]:
        """Download Debian sid's current linux-headers-*-amd64 package and
        extract its .config. Uses the real apt package index (Packages.xz),
        not the packages.debian.org website — the index format is stable,
        the website's HTML is not."""
        import lzma
        import glob
        import shutil
        import tempfile
        from utils.system import run_command

        try:
            req = urllib.request.Request(
                DEBIAN_PACKAGES_INDEX,
                headers={'User-Agent': 'SoplosKernelInstaller/1.0'}
            )
            with urllib.request.urlopen(req, timeout=30) as resp:
                raw = resp.read()
            text = lzma.decompress(raw).decode('utf-8', errors='replace')
        except Exception as e:
            print(f"Debian Packages index fetch error: {e}", file=sys.stderr)
            return None

        pkg_re = re.compile(r'^linux-headers-\d[\w.+~-]*-amd64$', re.MULTILINE)
        filename = None
        for block in text.split("\n\n"):
            m_name = re.search(r'^Package:\s*(\S+)$', block, re.MULTILINE)
            if not m_name or not pkg_re.match(m_name.group(1)):
                continue
            m_file = re.search(r'^Filename:\s*(\S+)$', block, re.MULTILINE)
            if m_file:
                filename = m_file.group(1)
                break

        if not filename:
            print("Debian Packages index: linux-headers-*-amd64 not found", file=sys.stderr)
            return None

        tmp_dir = tempfile.mkdtemp(prefix="soplos-debian-config-")
        deb_path = os.path.join(tmp_dir, "linux-headers.deb")
        if not self._download_file(DEBIAN_POOL_ROOT + filename, deb_path):
            print("Could not download Debian linux-headers package", file=sys.stderr)
            return None

        extract_dir = os.path.join(tmp_dir, "extracted")
        result = run_command(f'dpkg-deb -x "{deb_path}" "{extract_dir}"')
        if result.returncode != 0:
            print("Could not extract Debian linux-headers package", file=sys.stderr)
            return None

        matches = glob.glob(os.path.join(extract_dir, "usr", "src", "linux-headers-*", ".config"))
        if not matches:
            print("Debian headers package: .config not found inside", file=sys.stderr)
            return None
        return matches[0]

    def _download_x3d(self, version: str, major_minor: str,
                      patches_dir: str) -> Optional[List[str]]:
        """
        Download the Soplos AMD X3D VCache scheduler patch.
        A separate patch file is maintained per kernel line — 6.x, 7.0, 7.1 — since
        the hunk offsets differ between them (fair.c changes between releases).
        Source: github.com/SoplosLinux/x3d-soplos
        """
        major = version.split('.')[0]
        tag = major_minor if major_minor in ("7.0", "7.1") else f"{major}.x"

        self._report_progress(f"Downloading X3D VCache scheduler patch ({tag})...", -1)
        dest = os.path.join(patches_dir, f"soplos-x3d-vcache-{tag}.patch")
        if self._download_file(X3D_PATCH_URL.format(tag=tag), dest):
            return [dest]
        print(f"Could not download X3D VCache patch for {tag}", file=sys.stderr)
        return None

    def _download_march(self, version: str, major_minor: str,
                        patches_dir: str) -> Optional[List[str]]:
        """
        Download the Soplos x86-64 ISA level patch.
        Adds the Kconfig choice that lets the build target x86-64-v2, v3 or v4;
        mainline only offers -march=native, which cannot be redistributed.
        The repo only ships one file, tagged "{major}.x" — it has been stable
        across the whole 7.x line so far (verified against 7.1.8 and 7.2).
        Do NOT special-case an exact "major.minor" tag here again: the repo
        has no such file, and requesting one 404s and silently skips the
        patch (builds requesting v2/v3/v4 silently fall back to v1 with no
        visible error) — this is exactly what happened on the first 7.2 build.
        Source: github.com/SoplosLinux/soplos-cpu-kernel-patch
        """
        major = version.split('.')[0]
        tag = f"{major}.x"

        self._report_progress(f"Downloading x86-64 ISA level patch ({tag})...", -1)
        dest = os.path.join(patches_dir, f"soplos-x86-64-isa-level-{tag}.patch")
        if self._download_file(MARCH_PATCH_URL.format(tag=tag), dest):
            return [dest]
        print(f"Could not download x86-64 ISA level patch for {tag}", file=sys.stderr)
        return None

    def _download_zen(self, version: str, major_minor: str,
                      patches_dir: str) -> Optional[List[str]]:
        """
        Download Zen kernel patch. SoplosLinux/zen-soplos (Soplos-maintained
        rebase) is tried FIRST; zen-kernel/zen-kernel's own GitHub releases
        are only a fallback when zen-soplos has no patch for this line yet,
        or the one it has doesn't apply to this exact point release.
        RC kernels are skipped — Zen only patches stable releases.
        """
        if '-rc' in version:
            print(f"Zen: no patch available for RC kernel {version}", file=sys.stderr)
            self._report_progress(
                f"Zen patch not available for RC kernel {version} — skipping.", -1
            )
            return None

        self._report_progress(f"Downloading Zen patch for {version}...", -1)

        # --- Source 1: SoplosLinux/zen-soplos (Soplos-maintained) ---
        soplos_paths = self._download_zen_soplos(major_minor, patches_dir)
        if soplos_paths:
            if self._patches_apply(version, soplos_paths):
                return soplos_paths
            self._report_progress(
                f"SoplosLinux/zen-soplos patch doesn't apply to {version} — "
                f"trying zen-kernel/zen-kernel fallback...", -1
            )

        # --- Source 2: zen-kernel/zen-kernel upstream releases (fallback) ---
        target_prefix = f"v{version}-zen"
        asset_url = None
        asset_name = None
        page = 1

        while not asset_url:
            if self._is_cancelled():
                return None
            api_url = (
                f"https://api.github.com/repos/zen-kernel/zen-kernel/releases"
                f"?per_page=100&page={page}"
            )
            releases = self._github_api_get(api_url)
            if not releases:
                self._report_progress(
                    "⚠ Could not reach GitHub API for Zen patch (rate limit or network error).", -1
                )
                break

            for release in releases:
                tag = release.get("tag_name", "")
                if not tag.startswith(target_prefix):
                    continue
                for asset in release.get("assets", []):
                    name = asset.get("name", "")
                    if name.endswith(".patch.zst"):
                        asset_url = asset.get("browser_download_url")
                        asset_name = name
                        break
                if asset_url:
                    break

            if len(releases) < 100:
                # Last page reached without a match
                break
            page += 1

        if not asset_url:
            self._report_progress(
                f"⚠ Zen patch not found for kernel {version} "
                f"(no release matching {target_prefix} in zen-kernel/zen-kernel either) — "
                f"no working Zen source found.", -1
            )
            print(f"No Zen release matching {target_prefix} found", file=sys.stderr)
            return None

        zst_dest = os.path.join(patches_dir, asset_name)
        dest = os.path.join(patches_dir, f"zen-{version}.patch")

        if not self._download_file(asset_url, zst_dest):
            return None

        from utils.system import run_command
        result = run_command(f'zstd -d "{zst_dest}" -o "{dest}"')
        if result.returncode == 0 and os.path.exists(dest):
            if self._patches_apply(version, [dest]):
                return [dest]
            self._report_progress(
                f"⚠ Zen release {asset_name} doesn't apply to {version} either — "
                f"no working Zen source found.", -1
            )
            return None

        return None

    def _download_zen_soplos(self, major_minor: str, patches_dir: str) -> Optional[List[str]]:
        """
        Download Zen from SoplosLinux/zen-soplos — the Soplos-maintained
        rebase, tried before zen-kernel/zen-kernel's own upstream releases.
        Not build/boot verified upstream: see
        github.com/SoplosLinux/zen-soplos README before trusting a build made
        from this source — it's a much larger patch surface than BORE/x3d.
        """
        raw_url = ZEN_SOPLOS_URL.format(major_minor=major_minor)
        dest = os.path.join(patches_dir, f"zen-soplos-{major_minor}.patch")
        if self._download_file(raw_url, dest):
            self._report_progress(f"SoplosLinux/zen-soplos patch downloaded for {major_minor}.", -1)
            return [dest]

        print(f"SoplosLinux/zen-soplos: no patch for {major_minor}", file=sys.stderr)
        return None
