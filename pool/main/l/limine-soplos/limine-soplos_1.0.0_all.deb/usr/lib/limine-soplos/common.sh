# shellcheck shell=bash
# limine-soplos -- common.sh
#
# Shared by limine-install and limine-update. It is sourced, not run: the
# caller sets PROG before sourcing it.

STATE_DIR=/etc/limine-soplos
STATE_FILE=$STATE_DIR/install.conf
DEFAULTS_FILE=/etc/default/limine
CMDLINE_FILE=/etc/kernel/cmdline
LOCK_FILE=/run/limine-soplos.lock

# soplos-kernel-installer's Secure Boot hardening of Limine: when its marker
# exists, every file limine.conf names carries a hash and the configuration is
# enrolled in a signed binary. Any change to those files has to be followed by
# its --sign-boot, or Limine refuses to boot.
KI_MARKER=/etc/soplos-kernel-installer/limine-enrolled
KI_BINARY=/usr/bin/soplos-kernel-installer

# GPT partition types.
ESP_TYPE=c12a7328-f81f-11d2-ba4b-00a0c93ec93b
BIOS_BOOT_TYPE=21686148-6449-6e6f-744e-656564454649

say() {
    printf '%s: %s\n' "$PROG" "$*"
}

warn() {
    printf '%s: warning: %s\n' "$PROG" "$*" >&2
}

die() {
    printf '%s: %s\n' "$PROG" "$*" >&2
    exit 1
}

require_root() {
    [ "$(id -u)" -eq 0 ] || die "this has to be run as root"
}

# A live session: nothing is installed or updated there unless --force is
# given (the installer passes it when it works inside the target system).
in_live() {
    [ -d /run/live ] || grep -qiE 'boot=live|LiveOS|root=live' /proc/cmdline 2>/dev/null
}

installed() {
    [ -f "$STATE_FILE" ]
}

load_state() {
    # shellcheck source=/dev/null
    . "$STATE_FILE"
}

load_defaults() {
    LIMINE_TIMEOUT=5
    LIMINE_DEFAULT=newest
    LIMINE_RECOVERY=yes
    LIMINE_OTHER_OSES=yes
    LIMINE_THEME=/etc/limine-soplos/theme.conf
    if [ -f "$DEFAULTS_FILE" ]; then
        # shellcheck source=/dev/null
        . "$DEFAULTS_FILE"
    fi
}

# Sets OS_PRETTY ("Soplos Linux Tyson") and OS_CODENAME ("tyson").
os_release() {
    OS_PRETTY=$(. /etc/os-release 2>/dev/null; echo "${PRETTY_NAME:-Linux}")
    OS_CODENAME=$(. /etc/os-release 2>/dev/null; echo "${VERSION_CODENAME:-}")
}

# The directory must be a mount point of a FAT filesystem.
check_fat() {
    mountpoint -q "$1" || die "$1 is not a mount point"
    [ "$(findmnt -no FSTYPE --mountpoint "$1")" = vfat ] \
        || die "$1 is not a FAT partition: Limine only reads FAT"
}

# The block device mounted on a directory.
device_of() {
    findmnt -no SOURCE --mountpoint "$1" | head -n1
}

# The whole disk a partition belongs to, as /dev/NAME.
disk_of() {
    local parent
    parent=$(lsblk -no PKNAME "$1" | head -n1)
    [ -n "$parent" ] || return 1
    echo "/dev/$parent"
}

# The 1-based number of a partition.
partnum_of() {
    local name
    name=$(basename "$(readlink -f "$1")")
    cat "/sys/class/block/$name/partition" 2>/dev/null
}

is_limine_binary() {
    [ -f "$1" ] && grep -qa 'Limine' "$1"
}

maybe_sign() {
    if [ -f "$KI_MARKER" ] && [ -x "$KI_BINARY" ]; then
        say "the Secure Boot hardening of Kernel Installer is on: refreshing the hashes and the signature"
        "$KI_BINARY" --sign-boot || warn "soplos-kernel-installer --sign-boot failed"
    fi
}
